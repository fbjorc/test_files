package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class MurmurHash2SapientGeneratedTest {

    //Sapient generated method id: ${hash32Test}, hash: 6EFE0D17050792DF4797B8F97A0DEFCE
    @Test()
    void hash32Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash2> murmurHash2 = mockStatic(MurmurHash2.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            murmurHash2.when(() -> MurmurHash2.hash32(byteArray, 0, -1756908916)).thenReturn(0);
            //Act Statement(s)
            int result = MurmurHash2.hash32(byteArray, 0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                murmurHash2.verify(() -> MurmurHash2.hash32(byteArray, 0, -1756908916), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash323Test}, hash: DE0681E71E6CC6B2DB8253AA8795D68D
    @Test()
    void hash323Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash2> murmurHash2 = mockStatic(MurmurHash2.class, CALLS_REAL_METHODS)) {
            murmurHash2.when(() -> MurmurHash2.hash32("")).thenReturn(0);
            //Act Statement(s)
            int result = MurmurHash2.hash32("A", 0, 0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                murmurHash2.verify(() -> MurmurHash2.hash32(""), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash64Test}, hash: 2875FDA3034029FAA8EEB033FB8FB46E
    @Test()
    void hash64Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash2> murmurHash2 = mockStatic(MurmurHash2.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            murmurHash2.when(() -> MurmurHash2.hash64(byteArray, 0, -512093083)).thenReturn(0L);
            //Act Statement(s)
            long result = MurmurHash2.hash64(byteArray, 0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0L));
                murmurHash2.verify(() -> MurmurHash2.hash64(byteArray, 0, -512093083), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash643Test}, hash: 93E3343061C5AA21E0233013514E3FC3
    @Test()
    void hash643Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash2> murmurHash2 = mockStatic(MurmurHash2.class, CALLS_REAL_METHODS)) {
            murmurHash2.when(() -> MurmurHash2.hash64("")).thenReturn(0L);
            //Act Statement(s)
            long result = MurmurHash2.hash64("A", 0, 0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0L));
                murmurHash2.verify(() -> MurmurHash2.hash64(""), atLeast(1));
            });
        }
    }
}
