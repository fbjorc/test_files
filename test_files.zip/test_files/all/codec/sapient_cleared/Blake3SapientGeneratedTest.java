package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class Blake3SapientGeneratedTest {

    //Sapient generated method id: ${initHashTest}, hash: 7FFC85AF78170334E024660C75410F6F
    @Test()
    void initHashTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Act Statement(s)
        Blake3 result = Blake3.initHash();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${initKeyDerivationFunctionWhenILessThanNrInts}, hash: 7323C88BB6646279358CF17EC4270B37
    @Test()
    void initKeyDerivationFunctionWhenILessThanNrInts() {
        /* Branches:
         * (i < nrInts) : true  #  inside unpackInts method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] { (byte) 0 };
        //Act Statement(s)
        Blake3 result = Blake3.initKeyDerivationFunction(byteArray);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${initKeyedHashWhenKeyLengthNotEqualsKEY_LENThrowsIllegalArgumentException}, hash: 3C49EE2A49FF22907793229E4891C6FA
    @Test()
    void initKeyedHashWhenKeyLengthNotEqualsKEY_LENThrowsIllegalArgumentException() {
        /* Branches:
         * (key.length != KEY_LEN) : true
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Blake3 keys must be 32 bytes");
        //Act Statement(s)
        final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
            Blake3.initKeyedHash(byteArray);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
        });
    }

    //Sapient generated method id: ${initKeyedHashWhenILessThanNrInts}, hash: 839E5B29253D0AF6A257EB96DEB644E6
    @Test()
    void initKeyedHashWhenILessThanNrInts() {
        /* Branches:
         * (key.length != KEY_LEN) : false
         * (i < nrInts) : true  #  inside unpackInts method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] { (byte) 0, (byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5, (byte) 6, (byte) 7, (byte) 8, (byte) 9, (byte) 10, (byte) 11, (byte) 12, (byte) 13, (byte) 14, (byte) 15, (byte) 16, (byte) 17, (byte) 18, (byte) 19, (byte) 20, (byte) 21, (byte) 22, (byte) 23, (byte) 24, (byte) 25, (byte) 26, (byte) 27, (byte) 28, (byte) 29, (byte) 30, (byte) 31 };
        //Act Statement(s)
        Blake3 result = Blake3.initKeyedHash(byteArray);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${doFinalize1WhenOffsetLessThan0ThrowsIndexOutOfBoundsException}, hash: CFD53ACD565594666B30CBB863B8F9D9
    @Test()
    void doFinalize1WhenOffsetLessThan0ThrowsIndexOutOfBoundsException() {
        /* Branches:
         * (offset < 0) : true  #  inside checkBufferArgs method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] { (byte) 0 };
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        byte[] byteArray2 = new byte[] { (byte) 0 };
        IndexOutOfBoundsException indexOutOfBoundsException = new IndexOutOfBoundsException("Offset must be non-negative");
        //Act Statement(s)
        final IndexOutOfBoundsException result = assertThrows(IndexOutOfBoundsException.class, () -> {
            target.doFinalize(byteArray2, -1, 0);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(indexOutOfBoundsException.getMessage()));
        });
    }

    //Sapient generated method id: ${doFinalize1WhenLengthLessThan0ThrowsIndexOutOfBoundsException}, hash: D855CEA2B1D34D8691990768776C46F5
    @Test()
    void doFinalize1WhenLengthLessThan0ThrowsIndexOutOfBoundsException() {
        /* Branches:
         * (offset < 0) : false  #  inside checkBufferArgs method
         * (length < 0) : true  #  inside checkBufferArgs method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        byte[] byteArray2 = new byte[] {};
        IndexOutOfBoundsException indexOutOfBoundsException = new IndexOutOfBoundsException("Length must be non-negative");
        //Act Statement(s)
        final IndexOutOfBoundsException result = assertThrows(IndexOutOfBoundsException.class, () -> {
            target.doFinalize(byteArray2, 0, -1);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(indexOutOfBoundsException.getMessage()));
        });
    }

    //Sapient generated method id: ${doFinalize1WhenOffsetGreaterThanBufferLengthMinusLengthThrowsIndexOutOfBoundsException}, hash: 2DA9C59FA2E8C98FBAB2BD7164108476
    @Test()
    void doFinalize1WhenOffsetGreaterThanBufferLengthMinusLengthThrowsIndexOutOfBoundsException() {
        /* Branches:
         * (offset < 0) : false  #  inside checkBufferArgs method
         * (length < 0) : false  #  inside checkBufferArgs method
         * (offset > bufferLength - length) : true  #  inside checkBufferArgs method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        byte[] byteArray2 = new byte[] {};
        IndexOutOfBoundsException indexOutOfBoundsException = new IndexOutOfBoundsException("Offset 2 and length 2 out of bounds with buffer length 0");
        //Act Statement(s)
        final IndexOutOfBoundsException result = assertThrows(IndexOutOfBoundsException.class, () -> {
            target.doFinalize(byteArray2, 2, 2);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(indexOutOfBoundsException.getMessage()));
        });
    }

    //Sapient generated method id: ${doFinalize1WhenOffsetNotGreaterThanBufferLengthMinusLength}, hash: 898F986C54C16BC06211491B9587BE22
    @Test()
    void doFinalize1WhenOffsetNotGreaterThanBufferLengthMinusLength() {
        /* Branches:
         * (offset < 0) : false  #  inside checkBufferArgs method
         * (length < 0) : false  #  inside checkBufferArgs method
         * (offset > bufferLength - length) : false  #  inside checkBufferArgs method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        byte[] byteArray2 = new byte[] {};
        //Act Statement(s)
        Blake3 result = target.doFinalize(byteArray2, 0, 0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${doFinalize2WhenNrBytesLessThan0ThrowsIllegalArgumentException}, hash: 44285D0DC3C5090282A322F1CD3E4793
    @Test()
    void doFinalize2WhenNrBytesLessThan0ThrowsIllegalArgumentException() {
        /* Branches:
         * (nrBytes < 0) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Requested bytes must be non-negative");
        //Act Statement(s)
        final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
            target.doFinalize(-1);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
        });
    }

    //Sapient generated method id: ${doFinalize2WhenNrBytesNotLessThan0}, hash: 47326E046BAEEA8E916A77BAFD2FA72C
    @Test()
    void doFinalize2WhenNrBytesNotLessThan0() {
        /* Branches:
         * (nrBytes < 0) : false
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] { (byte) 0, (byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5, (byte) 6, (byte) 7, (byte) 8, (byte) 9, (byte) 10, (byte) 11, (byte) 12, (byte) 13, (byte) 14, (byte) 15 };
        Blake3 target = spy(Blake3.initKeyDerivationFunction(byteArray));
        Blake3 blake3 = Blake3.initHash();
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 };
        doReturn(blake3).when(target).doFinalize(byteArray2);
        //Act Statement(s)
        byte[] result = target.doFinalize(32);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(byteArray2));
            verify(target).doFinalize(byteArray2);
        });
    }

    //Sapient generated method id: ${update1WhenOffsetLessThan0ThrowsIndexOutOfBoundsException}, hash: E237202486BD7145AEDFD7C7062CDCF3
    @Test()
    void update1WhenOffsetLessThan0ThrowsIndexOutOfBoundsException() {
        /* Branches:
         * (offset < 0) : true  #  inside checkBufferArgs method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        byte[] byteArray2 = new byte[] {};
        IndexOutOfBoundsException indexOutOfBoundsException = new IndexOutOfBoundsException("Offset must be non-negative");
        //Act Statement(s)
        final IndexOutOfBoundsException result = assertThrows(IndexOutOfBoundsException.class, () -> {
            target.update(byteArray2, -1, 0);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(indexOutOfBoundsException.getMessage()));
        });
    }

    //Sapient generated method id: ${update1WhenLengthLessThan0ThrowsIndexOutOfBoundsException}, hash: C2DBDF8BFFABF51C63DC46139839CD23
    @Test()
    void update1WhenLengthLessThan0ThrowsIndexOutOfBoundsException() {
        /* Branches:
         * (offset < 0) : false  #  inside checkBufferArgs method
         * (length < 0) : true  #  inside checkBufferArgs method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        byte[] byteArray2 = new byte[] {};
        IndexOutOfBoundsException indexOutOfBoundsException = new IndexOutOfBoundsException("Length must be non-negative");
        //Act Statement(s)
        final IndexOutOfBoundsException result = assertThrows(IndexOutOfBoundsException.class, () -> {
            target.update(byteArray2, 0, -1);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(indexOutOfBoundsException.getMessage()));
        });
    }

    //Sapient generated method id: ${update1WhenOffsetGreaterThanBufferLengthMinusLengthThrowsIndexOutOfBoundsException}, hash: 546AC29E06B46AB3D982EA7122488273
    @Test()
    void update1WhenOffsetGreaterThanBufferLengthMinusLengthThrowsIndexOutOfBoundsException() {
        /* Branches:
         * (offset < 0) : false  #  inside checkBufferArgs method
         * (length < 0) : false  #  inside checkBufferArgs method
         * (offset > bufferLength - length) : true  #  inside checkBufferArgs method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        byte[] byteArray2 = new byte[] {};
        IndexOutOfBoundsException indexOutOfBoundsException = new IndexOutOfBoundsException("Offset 2 and length 2 out of bounds with buffer length 0");
        //Act Statement(s)
        final IndexOutOfBoundsException result = assertThrows(IndexOutOfBoundsException.class, () -> {
            target.update(byteArray2, 2, 2);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(indexOutOfBoundsException.getMessage()));
        });
    }

    //Sapient generated method id: ${update1WhenOffsetNotGreaterThanBufferLengthMinusLength}, hash: D981C4754551E54AC37AAE8465FF8880
    @Test()
    void update1WhenOffsetNotGreaterThanBufferLengthMinusLength() {
        /* Branches:
         * (offset < 0) : false  #  inside checkBufferArgs method
         * (length < 0) : false  #  inside checkBufferArgs method
         * (offset > bufferLength - length) : false  #  inside checkBufferArgs method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        byte[] byteArray2 = new byte[] {};
        //Act Statement(s)
        Blake3 result = target.update(byteArray2, 0, 0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${resetTest}, hash: BA0BC15771191457708C395E6CBA8A57
    @Test()
    void resetTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] { (byte) 0 };
        Blake3 target = Blake3.initKeyDerivationFunction(byteArray);
        //Act Statement(s)
        Blake3 result = target.reset();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${updateTest}, hash: D3862098BAD7E02516FCEF0734F6D2D1
    @Test()
    void updateTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Blake3 target = spy(Blake3.initKeyDerivationFunction(byteArray));
        Blake3 blake3 = Blake3.initHash();
        byte[] byteArray2 = new byte[] {};
        doReturn(blake3).when(target).update(byteArray2, 0, 0);
        //Act Statement(s)
        Blake3 result = target.update(byteArray2);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(blake3));
            verify(target).update(byteArray2, 0, 0);
        });
    }
}
