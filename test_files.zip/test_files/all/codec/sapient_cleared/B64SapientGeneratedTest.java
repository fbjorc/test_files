package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import java.util.Random;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doReturn;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class B64SapientGeneratedTest {

    //Sapient generated method id: ${b64from24bitWhenNGreaterThan0}, hash: 5E4AB7A22270691F92DAB98E124018FE
    @Test()
    void b64from24bitWhenNGreaterThan0() {
        /* Branches:
         * (n-- > 0) : true
         */
         //Arrange Statement(s)
        StringBuilder stringBuilder = new StringBuilder();
        
        //Act Statement(s)
        B64.b64from24bit((byte) 0, (byte) 0, (byte) 0, 1, stringBuilder);
    }

    //Sapient generated method id: ${getRandomSaltTest}, hash: 27A2D6C39C9838E170746F58B589CAF5
    @Test()
    void getRandomSaltTest() {
        //Arrange Statement(s)
        try (MockedStatic<B64> b64 = mockStatic(B64.class, CALLS_REAL_METHODS)) {
            b64.when(() -> B64.getRandomSalt(eq(0), (Random) any())).thenReturn("return_of_getRandomSalt1");
            //Act Statement(s)
            String result = B64.getRandomSalt(0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_getRandomSalt1"));
                b64.verify(() -> B64.getRandomSalt(eq(0), (Random) any()), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getRandomSalt1WhenILessThanOrEqualsToNum}, hash: 483902FEA9EAEDE764B10922C3CEB893
    @Test()
    void getRandomSalt1WhenILessThanOrEqualsToNum() {
        /* Branches:
         * (i <= num) : true
         */
         //Arrange Statement(s)
        Random randomMock = mock(Random.class);
        doReturn(0).when(randomMock).nextInt(64);
        
        //Act Statement(s)
        String result = B64.getRandomSalt(1, randomMock);
        
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("."));
            verify(randomMock).nextInt(64);
        });
    }
}
