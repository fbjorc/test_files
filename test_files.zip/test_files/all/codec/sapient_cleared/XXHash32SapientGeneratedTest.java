package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertAll;

import org.junit.jupiter.api.Disabled;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.spy;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class XXHash32SapientGeneratedTest {

    //Sapient generated method id: ${resetTest}, hash: 4B708DC48413A33333E2B3F8866644B3
    @Test()
    void resetTest() {
        //Arrange Statement(s)
        XXHash32 target = new XXHash32(2048144778);
        //Act Statement(s)
        target.reset();
    }

    //Sapient generated method id: ${updateWhenLenLessThanOrEqualsTo0}, hash: 8BEEF5457C9BE47B052B5574C0A0B8F1
    @Test()
    void updateWhenLenLessThanOrEqualsTo0() {
        /* Branches:
         * (len <= 0) : true
         */
        //Arrange Statement(s)
        XXHash32 target = new XXHash32(-1);
        byte[] byteArray = new byte[]{};
        //Act Statement(s)
        target.update(byteArray, 0, -1);
    }

    //Sapient generated method id: ${updateWhenOffNotLessThanEnd}, hash: 1096B4FB9F293B4CDAC4F62F83BF58C8
    @Test()
    void updateWhenOffNotLessThanEnd() {
        /* Branches:
         * (len <= 0) : false
         * (pos + len - BUF_SIZE < 0) : false
         * (pos > 0) : false
         * (off <= limit) : true
         * (off < end) : false
         */
        //Arrange Statement(s)
        XXHash32 target = new XXHash32(0);
        byte[] byteArray = new byte[]{(byte) 0, (byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5, (byte) 6, (byte) 7, (byte) 8, (byte) 9, (byte) 10, (byte) 11, (byte) 12, (byte) 13, (byte) 14, (byte) 15};
        //Act Statement(s)
        target.update(byteArray, 0, 16);
    }

    //Sapient generated method id: ${update1Test}, hash: 47276EA7AC792C12A2A1FEEA7AA5DBF4
    @Test()
    void update1Test() {
        //Arrange Statement(s)
        XXHash32 target = spy(new XXHash32(1));
        byte[] byteArray = new byte[]{(byte) 0};
        doNothing().when(target).update(byteArray, 0, 1);
        //Act Statement(s)
        target.update(0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).update(byteArray, 0, 1));
    }
}
