package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import java.util.Random;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import static org.hamcrest.Matchers.is;
import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class Md5CryptSapientGeneratedTest {


    //Sapient generated method id: ${apr1Crypt2WhenSaltNotStartsWithAPR1_PREFIX}, hash: 92AB23D873CC82C7DD2614BD283DB502
    @Test()
    void apr1Crypt2WhenSaltNotStartsWithAPR1_PREFIX() {
        /* Branches:
         * (salt != null) : true
         * (!salt.startsWith(APR1_PREFIX)) : true
         */
        //Arrange Statement(s)
        try (MockedStatic<Md5Crypt> md5Crypt = mockStatic(Md5Crypt.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[] {};
            md5Crypt.when(() -> Md5Crypt.md5Crypt(byteArray, "$apr1$A", "$apr1$")).thenReturn("return_of_md5Crypt1");
            //Act Statement(s)
            String result = Md5Crypt.apr1Crypt(byteArray, "A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_md5Crypt1"));
                md5Crypt.verify(() -> Md5Crypt.md5Crypt(byteArray, "$apr1$A", "$apr1$"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md5Crypt2Test}, hash: 6FADAAE1D5CECBFAF22D8395C3BAEA48
    @Test()
    void md5Crypt2Test() {
        //Arrange Statement(s)
        try (MockedStatic<Md5Crypt> md5Crypt = mockStatic(Md5Crypt.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[] {};
            md5Crypt.when(() -> Md5Crypt.md5Crypt(byteArray, "salt1", "$1$")).thenReturn("return_of_md5Crypt1");
            //Act Statement(s)
            String result = Md5Crypt.md5Crypt(byteArray, "salt1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_md5Crypt1"));
                md5Crypt.verify(() -> Md5Crypt.md5Crypt(byteArray, "salt1", "$1$"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md5Crypt3Test}, hash: 0813A90EAF9970DA1710AB20F531EA6B
    @Test()
    void md5Crypt3Test() {
        //Arrange Statement(s)
        try (MockedStatic<Md5Crypt> md5Crypt = mockStatic(Md5Crypt.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[] {};
            md5Crypt.when(() -> Md5Crypt.md5Crypt(eq(byteArray), eq("salt1"), eq("prefix1"), (Random) any())).thenReturn("return_of_md5Crypt1");
            //Act Statement(s)
            String result = Md5Crypt.md5Crypt(byteArray, "salt1", "prefix1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_md5Crypt1"));
                md5Crypt.verify(() -> Md5Crypt.md5Crypt(eq(byteArray), eq("salt1"), eq("prefix1"), (Random) any()), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md5Crypt4WhenPrefixLengthLessThan3ThrowsIllegalArgumentException}, hash: E8B72CEE307FDF9F5D65D77E7114C713
    @Test()
    void md5Crypt4WhenPrefixLengthLessThan3ThrowsIllegalArgumentException() {
        /* Branches:
         * (salt == null) : false
         * (prefix.length() < 3) : true
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Random random = new Random();
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Invalid prefix value: A");
        //Act Statement(s)
        final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(byteArray, "salt1", "A", random);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
        });
    }

    //Sapient generated method id: ${md5Crypt4WhenPrefixCharAtPrefixLengthMinus1NotEquals___ThrowsIllegalArgumentException}, hash: AAB990D973693903282C3679C84D7E5F
    @Test()
    void md5Crypt4WhenPrefixCharAtPrefixLengthMinus1NotEquals___ThrowsIllegalArgumentException() {
        /* Branches:
         * (salt == null) : false
         * (prefix.length() < 3) : false
         * (prefix.charAt(0) != '$') : true
         * (prefix.charAt(prefix.length() - 1) != '$') : true
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Random random = new Random();
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Invalid prefix value: BED");
        //Act Statement(s)
        final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(byteArray, "salt1", "BED", random);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
        });
    }

    //Sapient generated method id: ${md5Crypt4WhenPrefixCharAtPrefixLengthMinus1Equals___AndMNotFindThrowsIllegalArgumentException}, hash: 6FDE4F546FA411EDB27B0594DA3A9125
    @Test()
    void md5Crypt4WhenPrefixCharAtPrefixLengthMinus1Equals___AndMNotFindThrowsIllegalArgumentException() {
        /* Branches:
         * (salt == null) : false
         * (prefix.length() < 3) : false
         * (prefix.charAt(0) != '$') : true
         * (prefix.charAt(prefix.length() - 1) != '$') : false
         * (!m.find()) : true
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[] {};
        Random random = new Random();
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Invalid salt value: ");
        //Act Statement(s)
        final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(byteArray, "", "D$E$", random);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
        });
    }

}
