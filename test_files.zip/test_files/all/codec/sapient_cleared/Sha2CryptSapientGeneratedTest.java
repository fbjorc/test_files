package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Disabled;

import java.util.Random;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class Sha2CryptSapientGeneratedTest {

    //Sapient generated method id: ${sha512CryptTest}, hash: 42787BE9AB8B94D8AFE136ED72401EE9
    @Test()
    void sha512CryptTest() {
        //Arrange Statement(s)
        try (MockedStatic<Sha2Crypt> sha2Crypt = mockStatic(Sha2Crypt.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            sha2Crypt.when(() -> Sha2Crypt.sha512Crypt(byteArray, (String) null)).thenReturn("return_of_sha512Crypt1");
            //Act Statement(s)
            String result = Sha2Crypt.sha512Crypt(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_sha512Crypt1"));
                sha2Crypt.verify(() -> Sha2Crypt.sha512Crypt(byteArray, (String) null), atLeast(1));
            });
        }
    }

}
