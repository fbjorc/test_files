package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class CryptSapientGeneratedTest {

    //Sapient generated method id: ${crypt2Test}, hash: 4F6EEAF70386DFDB036F77ED7D1978C5
    @Test()
    void crypt2Test() {
        //Arrange Statement(s)
        try (MockedStatic<Crypt> crypt = mockStatic(Crypt.class, CALLS_REAL_METHODS)) {
            crypt.when(() -> Crypt.crypt("key1", (String) null)).thenReturn("return_of_crypt1");
            //Act Statement(s)
            String result = Crypt.crypt("key1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_crypt1"));
                crypt.verify(() -> Crypt.crypt("key1", (String) null), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${crypt3Test}, hash: 89A44DAD81949EB2CD0925F3C40E6F58
    @Test()
    void crypt3Test() {
        //Arrange Statement(s)
        try (MockedStatic<Crypt> crypt = mockStatic(Crypt.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[] { (byte) 107, (byte) 101, (byte) 121, (byte) 49 };
            crypt.when(() -> Crypt.crypt(byteArray, "salt1")).thenReturn("return_of_crypt1");
            //Act Statement(s)
            String result = Crypt.crypt("key1", "salt1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_crypt1"));
                crypt.verify(() -> Crypt.crypt(byteArray, "salt1"), atLeast(1));
            });
        }
    }
}
