package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.nio.ByteBuffer;
import javax.crypto.Mac;
import java.security.GeneralSecurityException;

import org.mockito.MockedStatic;

import java.io.File;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.security.Key;
import java.io.ByteArrayOutputStream;

import static org.mockito.Mockito.doNothing;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class HmacUtilsSapientGeneratedTest {

    private final Mac macMock = mock(Mac.class);

    //Sapient generated method id: ${getHmacMd5Test}, hash: 7152257C5550C8853ADE57292D00A8F5
    @Test()
    void getHmacMd5Test() throws NoSuchAlgorithmException, InvalidKeyException {
        //Arrange Statement(s)
        try (MockedStatic<HmacUtils> hmacUtils = mockStatic(HmacUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            hmacUtils.when(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_MD5, byteArray)).thenReturn(macMock);
            //Act Statement(s)
            Mac result = HmacUtils.getHmacMd5(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(macMock));
                hmacUtils.verify(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_MD5, byteArray), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getHmacSha1Test}, hash: 6582510D8A39C5EF8D69783EEB0F826D
    @Test()
    void getHmacSha1Test() throws NoSuchAlgorithmException, InvalidKeyException {
        //Arrange Statement(s)
        try (MockedStatic<HmacUtils> hmacUtils = mockStatic(HmacUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            hmacUtils.when(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_1, byteArray)).thenReturn(macMock);
            //Act Statement(s)
            Mac result = HmacUtils.getHmacSha1(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(macMock));
                hmacUtils.verify(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_1, byteArray), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getHmacSha256Test}, hash: E6686738B0D97DDEB26240FD5768D4B9
    @Test()
    void getHmacSha256Test() throws NoSuchAlgorithmException, InvalidKeyException {
        //Arrange Statement(s)
        try (MockedStatic<HmacUtils> hmacUtils = mockStatic(HmacUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            hmacUtils.when(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_256, byteArray)).thenReturn(macMock);
            //Act Statement(s)
            Mac result = HmacUtils.getHmacSha256(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(macMock));
                hmacUtils.verify(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_256, byteArray), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getHmacSha384Test}, hash: B5CD82571222E7B7408FA5D196628C99
    @Test()
    void getHmacSha384Test() throws NoSuchAlgorithmException, InvalidKeyException {
        //Arrange Statement(s)
        try (MockedStatic<HmacUtils> hmacUtils = mockStatic(HmacUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            hmacUtils.when(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_384, byteArray)).thenReturn(macMock);
            //Act Statement(s)
            Mac result = HmacUtils.getHmacSha384(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(macMock));
                hmacUtils.verify(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_384, byteArray), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getHmacSha512Test}, hash: 07DF0085DDDFD4D37130E2A2F4FB0933
    @Test()
    void getHmacSha512Test() throws NoSuchAlgorithmException, InvalidKeyException {
        //Arrange Statement(s)
        try (MockedStatic<HmacUtils> hmacUtils = mockStatic(HmacUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            hmacUtils.when(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_512, byteArray)).thenReturn(macMock);
            //Act Statement(s)
            Mac result = HmacUtils.getHmacSha512(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(macMock));
                hmacUtils.verify(() -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_512, byteArray), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getInitializedMacTest}, hash: 7B30AC763D44BB223D99A9956996755F
    @Test()
    void getInitializedMacTest() throws NoSuchAlgorithmException, InvalidKeyException {
        //Arrange Statement(s)
        try (MockedStatic<HmacUtils> hmacUtils = mockStatic(HmacUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            hmacUtils.when(() -> HmacUtils.getInitializedMac("HmacSHA1", byteArray)).thenReturn(macMock);
            //Act Statement(s)
            Mac result = HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_1, byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(macMock));
                hmacUtils.verify(() -> HmacUtils.getInitializedMac("HmacSHA1", byteArray), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getInitializedMac1WhenKeyIsNullThrowsIllegalArgumentException}, hash: 82E3B63FF105E7A08C2FFD8D7181F63E
    @Test()
    void getInitializedMac1WhenKeyIsNullThrowsIllegalArgumentException() {
        /* Branches:
         * (key == null) : true
         */
        //Arrange Statement(s)
        byte[] _byte = null;
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Null key");
        //Act Statement(s)
        final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
            HmacUtils.getInitializedMac("algorithm1", _byte);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
        });
    }


    //Sapient generated method id: ${isAvailableTest}, hash: 149FF75DC3390A4979D8856445C6C85E
    @Test()
    void isAvailableTest() throws NoSuchAlgorithmException {
        //Act Statement(s)
        boolean result = HmacUtils.isAvailable(HmacAlgorithms.HMAC_SHA_1);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.TRUE)));
    }

    //Sapient generated method id: ${isAvailableWhenCaughtNoSuchAlgorithmException}, hash: 3EE752E87B1487838EC15A3366E789DE
    @Test()
    void isAvailableWhenCaughtNoSuchAlgorithmException() throws NoSuchAlgorithmException {
        /* Branches:
         * (catch-exception (NoSuchAlgorithmException)) : true
         */
        //Arrange Statement(s)
        try (MockedStatic<Mac> mac = mockStatic(Mac.class)) {
            NoSuchAlgorithmException noSuchAlgorithmException = new NoSuchAlgorithmException();
            mac.when(() -> Mac.getInstance("HmacSHA1")).thenThrow(noSuchAlgorithmException);
            //Act Statement(s)
            boolean result = HmacUtils.isAvailable(HmacAlgorithms.HMAC_SHA_1);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                mac.verify(() -> Mac.getInstance("HmacSHA1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${isAvailable1Test}, hash: AE7F23C94CF3DAF1631D4E13631E5831
    @Test()
    void isAvailable1Test() throws NoSuchAlgorithmException {
        //Act Statement(s)
        boolean result = HmacUtils.isAvailable("HmacMD5");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.TRUE)));
    }

    //Sapient generated method id: ${isAvailable1WhenCaughtNoSuchAlgorithmException}, hash: 32B96C2766C7BE3559A37F8883EE26CC
    @Test()
    void isAvailable1WhenCaughtNoSuchAlgorithmException() throws NoSuchAlgorithmException {
        /* Branches:
         * (catch-exception (NoSuchAlgorithmException)) : true
         */
        //Arrange Statement(s)
        try (MockedStatic<Mac> mac = mockStatic(Mac.class)) {
            NoSuchAlgorithmException noSuchAlgorithmException = new NoSuchAlgorithmException();
            mac.when(() -> Mac.getInstance("name1")).thenThrow(noSuchAlgorithmException);
            //Act Statement(s)
            boolean result = HmacUtils.isAvailable("name1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                mac.verify(() -> Mac.getInstance("name1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${updateHmacTest}, hash: 182FDEE73AE034263886124125461518
    @Test()
    void updateHmacTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[]{};
        //Act Statement(s)
        Mac result = HmacUtils.updateHmac(macMock, byteArray);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(macMock)));
    }

    //Sapient generated method id: ${updateHmac1WhenReadGreaterThanMinus1}, hash: 16C9D3DA24991FF6D1408260F4C5FD51
    @Test()
    void updateHmac1WhenReadGreaterThanMinus1() throws IOException {
        /* Branches:
         * (read > -1) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
        //Act Statement(s)
        Mac result = HmacUtils.updateHmac(macMock, inputStream);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(macMock)));
    }

    //Sapient generated method id: ${updateHmac2Test}, hash: 6D6C5F9C49E6A6C1B1E490C7A5A2C870
    @Test()
    void updateHmac2Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Act Statement(s)
        Mac result = HmacUtils.updateHmac(macMock, "A");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(macMock)));
    }

}
