package org.apache.commons.codec.digest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.security.SecureRandom;

import org.junit.jupiter.api.Test;

public class B64CopilotTest {

    @Test
    public void b64from24bitProducesExpectedOutput() {
        final StringBuilder buffer = new StringBuilder();
        B64.b64from24bit((byte) 8, (byte) 16, (byte) 64, 2, buffer);
        assertEquals("./", buffer.toString());
    }

    @Test
    public void b64from24bitHandlesZeroOutputLength() {
        final StringBuilder buffer = new StringBuilder();
        B64.b64from24bit((byte) 8, (byte) 16, (byte) 64, 0, buffer);
        assertEquals("", buffer.toString());
    }

    @Test
    public void b64from24bitHandlesNegativeOutputLength() {
        final StringBuilder buffer = new StringBuilder();
        B64.b64from24bit((byte) 8, (byte) 16, (byte) 64, -1, buffer);
        assertEquals("", buffer.toString());
    }

    @Test
    public void getRandomSaltProducesExpectedLength() {
        String salt = B64.getRandomSalt(10);
        assertEquals(10, salt.length());
    }

    @Test
    public void getRandomSaltProducesDifferentSalts() {
        String salt1 = B64.getRandomSalt(10);
        String salt2 = B64.getRandomSalt(10);
        assertTrue(!salt1.equals(salt2));
    }

    @Test
    public void getRandomSaltHandlesZeroLength() {
        String salt = B64.getRandomSalt(0);
        assertEquals("", salt);
    }

    @Test
    public void getRandomSaltWithRandomProducesExpectedLength() {
        String salt = B64.getRandomSalt(10, new SecureRandom());
        assertEquals(10, salt.length());
    }
}
