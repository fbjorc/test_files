package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CryptCopilotTest {

    @Test
    public void crypt_withOnlyKeyBytes_returnsNonNullString() {
        byte[] keyBytes = "test key".getBytes();
        String result = Crypt.crypt(keyBytes);

        assertNotNull(result);
    }

    @Test
    public void crypt_withKeyBytesAndNullSalt_returnsNonNullString() {
        byte[] keyBytes = "test key".getBytes();
        String result = Crypt.crypt(keyBytes, null);

        assertNotNull(result);
    }

    @Test
    public void crypt_withKeyBytesAndSalt_returnsNonNullString() {
        byte[] keyBytes = "test key".getBytes();
        String salt = "$5$rounds=5000$abcdefghijklmnopqrstuvwx";
        String result = Crypt.crypt(keyBytes, salt);

        assertNotNull(result);
    }

    @Test
    public void crypt_withKeyBytesAndInvalidSalt_throwsException() {
        byte[] keyBytes = "test key".getBytes();
        String salt = "invalid salt";

        assertThrows(IllegalArgumentException.class, () -> Crypt.crypt(keyBytes, salt));
    }

    @Test
    public void crypt_withKeyBytesAndSha512Salt_returnsSha512Hash() {
        byte[] keyBytes = "test key".getBytes();
        String salt = "$6$rounds=5000$abcdefghijklmnopqrstuvwx";
        String result = Crypt.crypt(keyBytes, salt);

        assertTrue(result.startsWith("$6$"));
    }

    @Test
    public void crypt_withKeyBytesAndSha256Salt_returnsSha256Hash() {
        byte[] keyBytes = "test key".getBytes();
        String salt = "$5$rounds=5000$abcdefghijklmnopqrstuvwx";
        String result = Crypt.crypt(keyBytes, salt);

        assertTrue(result.startsWith("$5$"));
    }

    @Test
    public void crypt_withKeyBytesAndMd5Salt_returnsMd5Hash() {
        byte[] keyBytes = "test key".getBytes();
        String salt = "$1$abcdefghijklmnop";
        String result = Crypt.crypt(keyBytes, salt);

        assertTrue(result.startsWith("$1$"));
    }

    @Test
    public void crypt_withKeyBytesAndUnixSalt_returnsUnixCryptHash() {
        byte[] keyBytes = "test key".getBytes();
        String salt = "ab";
        String result = Crypt.crypt(keyBytes, salt);

        assertFalse(result.startsWith("$"));
    }

    @Test
    public void crypt_withOnlyKey_returnsNonNullString() {
        String key = "test key";
        String result = Crypt.crypt(key);

        assertNotNull(result);
    }

    @Test
    public void crypt_withKeyAndNullSalt_returnsNonNullString() {
        String key = "test key";
        String result = Crypt.crypt(key, null);

        assertNotNull(result);
    }

    @Test
    public void crypt_withKeyAndSalt_returnsNonNullString() {
        String key = "test key";
        String salt = "$5$rounds=5000$abcdefghijklmnopqrstuvwx";
        String result = Crypt.crypt(key, salt);

        assertNotNull(result);
    }

    @Test
    public void crypt_withKeyAndInvalidSalt_throwsException() {
        String key = "test key";
        String salt = "invalid salt";

        assertThrows(IllegalArgumentException.class, () -> Crypt.crypt(key, salt));
    }

    @Test
    public void crypt_withKeyAndSha512Salt_returnsSha512Hash() {
        String key = "test key";
        String salt = "$6$rounds=5000$abcdefghijklmnopqrstuvwx";
        String result = Crypt.crypt(key, salt);

        assertTrue(result.startsWith("$6$"));
    }

    @Test
    public void crypt_withKeyAndSha256Salt_returnsSha256Hash() {
        String key = "test key";
        String salt = "$5$rounds=5000$abcdefghijklmnopqrstuvwx";
        String result = Crypt.crypt(key, salt);

        assertTrue(result.startsWith("$5$"));
    }

    @Test
    public void crypt_withKeyAndMd5Salt_returnsMd5Hash() {
        String key = "test key";
        String salt = "$1$abcdefghijklmnop";
        String result = Crypt.crypt(key, salt);

        assertTrue(result.startsWith("$1$"));
    }

    @Test
    public void crypt_withKeyAndUnixSalt_returnsUnixCryptHash() {
        String key = "test key";
        String salt = "ab";
        String result = Crypt.crypt(key, salt);

        assertFalse(result.startsWith("$"));
    }
}
