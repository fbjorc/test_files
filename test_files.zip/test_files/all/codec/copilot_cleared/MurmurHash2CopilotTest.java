package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MurmurHash2CopilotTest {

    @Test
    public void hash32_withValidDataAndDefaultSeed_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int result = MurmurHash2.hash32(data, data.length);
        assertNotNull(result);
    }

    @Test
    public void hash32_withEmptyDataAndDefaultSeed_returnsExpectedHash() {
        byte[] data = new byte[]{};
        int result = MurmurHash2.hash32(data, data.length);
        assertNotNull(result);
    }

    @Test
    public void hash32_withNullDataAndDefaultSeed_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash2.hash32(null, 0));
    }

    @Test
    public void hash32_withValidDataAndSpecificSeed_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int seed = 0x12345678;
        int result = MurmurHash2.hash32(data, data.length, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withEmptyDataAndSpecificSeed_returnsExpectedHash() {
        byte[] data = new byte[]{};
        int seed = 0x12345678;
        int result = MurmurHash2.hash32(data, data.length, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withValidString_returnsExpectedHash() {
        String text = "Hello, World!";
        int result = MurmurHash2.hash32(text);
        assertNotNull(result);
    }

    @Test
    public void hash32_withEmptyString_returnsExpectedHash() {
        String text = "";
        int result = MurmurHash2.hash32(text);
        assertNotNull(result);
    }

    @Test
    public void hash32_withNullString_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash2.hash32(null));
    }

    @Test
    public void hash32_withValidSubstring_returnsExpectedHash() {
        String text = "Hello, World!";
        int from = 0;
        int length = 5;
        int result = MurmurHash2.hash32(text, from, length);
        assertNotNull(result);
    }

    @Test
    public void hash32_withEmptySubstring_returnsExpectedHash() {
        String text = "Hello, World!";
        int from = 0;
        int length = 0;
        int result = MurmurHash2.hash32(text, from, length);
        assertNotNull(result);
    }

    @Test
    public void hash32_withOutOfBoundsSubstring_throwsException() {
        String text = "Hello, World!";
        int from = 0;
        int length = text.length() + 1;
        assertThrows(StringIndexOutOfBoundsException.class, () -> MurmurHash2.hash32(text, from, length));
    }

    @Test
    public void hash64_withValidDataAndDefaultSeed_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        long result = MurmurHash2.hash64(data, data.length);
        assertNotNull(result);
    }

    @Test
    public void hash64_withEmptyDataAndDefaultSeed_returnsExpectedHash() {
        byte[] data = new byte[]{};
        long result = MurmurHash2.hash64(data, data.length);
        assertNotNull(result);
    }

    @Test
    public void hash64_withNullDataAndDefaultSeed_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash2.hash64(null, 0));
    }

    @Test
    public void hash64_withValidDataAndSpecificSeed_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int seed = 0xe17a1465;
        long result = MurmurHash2.hash64(data, data.length, seed);
        assertNotNull(result);
    }

    @Test
    public void hash64_withEmptyDataAndSpecificSeed_returnsExpectedHash() {
        byte[] data = new byte[]{};
        int seed = 0xe17a1465;
        long result = MurmurHash2.hash64(data, data.length, seed);
        assertNotNull(result);
    }

    @Test
    public void hash64_withValidString_returnsExpectedHash() {
        String text = "Hello, World!";
        long result = MurmurHash2.hash64(text);
        assertNotNull(result);
    }

    @Test
    public void hash64_withEmptyString_returnsExpectedHash() {
        String text = "";
        long result = MurmurHash2.hash64(text);
        assertNotNull(result);
    }

    @Test
    public void hash64_withNullString_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash2.hash64(null));
    }

    @Test
    public void hash64_withValidSubstring_returnsExpectedHash() {
        String text = "Hello, World!";
        int from = 0;
        int length = 5;
        long result = MurmurHash2.hash64(text, from, length);
        assertNotNull(result);
    }

    @Test
    public void hash64_withEmptySubstring_returnsExpectedHash() {
        String text = "Hello, World!";
        int from = 0;
        int length = 0;
        long result = MurmurHash2.hash64(text, from, length);
        assertNotNull(result);
    }

    @Test
    public void hash64_withOutOfBoundsSubstring_throwsException() {
        String text = "Hello, World!";
        int from = 0;
        int length = text.length() + 1;
        assertThrows(StringIndexOutOfBoundsException.class, () -> MurmurHash2.hash64(text, from, length));
    }
}
