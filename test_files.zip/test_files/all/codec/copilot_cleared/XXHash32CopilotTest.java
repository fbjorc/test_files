package org.apache.commons.codec.digest;

import org.apache.commons.codec.digest.XXHash32;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class XXHash32CopilotTest {

    @Test
    public void xxHash32_defaultConstructor() {
        XXHash32 xxHash32 = new XXHash32();
        assertEquals(0, xxHash32.getValue());
    }

    @Test
    public void xxHash32_constructorWithSeed() {
        XXHash32 xxHash32 = new XXHash32(123);
        assertNotEquals(0, xxHash32.getValue());
    }

    @Test
    public void xxHash32_constructorWithDifferentSeeds() {
        XXHash32 xxHash32A = new XXHash32(123);
        XXHash32 xxHash32B = new XXHash32(456);
        assertNotEquals(xxHash32A.getValue(), xxHash32B.getValue());
    }

    @Test
    public void getValue_withStateUpdated() {
        XXHash32 xxHash32 = new XXHash32(123);
        xxHash32.update("test".getBytes(), 0, 4);
        long result = xxHash32.getValue();
        assertNotEquals(0, result);
    }

    @Test
    public void getValue_withoutStateUpdated() {
        XXHash32 xxHash32 = new XXHash32(123);
        long result = xxHash32.getValue();
        assertEquals(0, result);
    }

    @Test
    public void getValue_withDifferentInputs() {
        XXHash32 xxHash32A = new XXHash32(123);
        xxHash32A.update("test".getBytes(), 0, 4);
        long resultA = xxHash32A.getValue();

        XXHash32 xxHash32B = new XXHash32(123);
        xxHash32B.update("different".getBytes(), 0, 9);
        long resultB = xxHash32B.getValue();

        assertNotEquals(resultA, resultB);
    }

    @Test
    public void reset_resetsState() {
        XXHash32 xxHash32 = new XXHash32(123);
        xxHash32.update("test".getBytes(), 0, 4);
        xxHash32.reset();
        assertEquals(0, xxHash32.getValue());
    }

    @Test
    public void update_withPositiveLength() {
        XXHash32 xxHash32 = new XXHash32(123);
        xxHash32.update("test".getBytes(), 0, 4);
        assertNotEquals(0, xxHash32.getValue());
    }

    @Test
    public void update_withZeroLength() {
        XXHash32 xxHash32 = new XXHash32(123);
        xxHash32.update("test".getBytes(), 0, 0);
        assertEquals(0, xxHash32.getValue());
    }

    @Test
    public void update_withPositiveByte() {
        XXHash32 xxHash32 = new XXHash32(123);
        xxHash32.update(97); // ASCII value for 'a'
        assertNotEquals(0, xxHash32.getValue());
    }

    @Test
    public void update_withZeroByte() {
        XXHash32 xxHash32 = new XXHash32(123);
        xxHash32.update(0);
        assertEquals(0, xxHash32.getValue());
    }

    @Test
    public void update_withNegativeByte() {
        XXHash32 xxHash32 = new XXHash32(123);
        xxHash32.update(-1);
        assertNotEquals(0, xxHash32.getValue());
    }
}
