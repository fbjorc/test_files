package org.apache.commons.codec.digest;

import org.apache.commons.codec.binary.Hex;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class DigestUtilCopilotTest {

    @Test
    public void digest_withByteArray_returnsExpectedDigest() throws NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        byte[] data = "test data".getBytes();
        byte[] result = DigestUtils.digest(md5Digest, data);

        assertNotNull(result);
        assertEquals(md5Digest.digest(data), result);
    }

    @Test
    public void digest_withByteArray_throwsException_whenNullDigestProvided() {
        byte[] data = "test data".getBytes();

        assertThrows(NullPointerException.class, () -> DigestUtils.digest(null, data));
    }

    @Test
    public void digest_withByteBuffer_returnsExpectedDigest() throws NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        ByteBuffer data = ByteBuffer.wrap("test data".getBytes());
        byte[] result = DigestUtils.digest(md5Digest, data);

        assertNotNull(result);
        assertEquals(md5Digest.digest(data.array()), result);
    }

    @Test
    public void digest_withByteBuffer_throwsException_whenNullDigestProvided() {
        ByteBuffer data = ByteBuffer.wrap("test data".getBytes());

        assertThrows(NullPointerException.class, () -> DigestUtils.digest(null, data));
    }

    @Test
    public void digest_withByteBuffer_throwsException_whenNullDataProvided() throws NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");

        assertThrows(NullPointerException.class, () -> DigestUtils.digest(md5Digest, (ByteBuffer) null));
    }

    @Test
    public void digest_withFile_returnsExpectedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        File data = new File("test.txt");
        byte[] result = DigestUtils.digest(md5Digest, data);

        assertNotNull(result);
        assertEquals(md5Digest.digest(Files.readAllBytes(data.toPath())), result);
    }

    @Test
    public void digest_withFile_throwsIOException_whenFileNotFound() throws NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        File data = new File("nonexistent.txt");

        assertThrows(IOException.class, () -> DigestUtils.digest(md5Digest, data));
    }

    @Test
    public void digest_withFile_throwsNullPointerException_whenNullDigestProvided() throws IOException {
        File data = new File("test.txt");

        assertThrows(NullPointerException.class, () -> DigestUtils.digest(null, data));
    }

    @Test
    public void digest_withInputStream_returnsExpectedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        InputStream data = new FileInputStream("test.txt");
        byte[] result = DigestUtils.digest(md5Digest, data);

        assertNotNull(result);
        assertEquals(md5Digest.digest(Files.readAllBytes(Paths.get("test.txt"))), result);
    }

    @Test
    public void digest_withInputStream_throwsIOException_whenStreamClosed() throws IOException, NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        InputStream data = new FileInputStream("test.txt");
        data.close();

        assertThrows(IOException.class, () -> DigestUtils.digest(md5Digest, data));
    }

    @Test
    public void digest_withInputStream_throwsNullPointerException_whenNullDigestProvided() {
        InputStream data = new ByteArrayInputStream("test data".getBytes());

        assertThrows(NullPointerException.class, () -> DigestUtils.digest(null, data));
    }

    @Test
    public void digest_withPathAndOptions_returnsExpectedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        Path data = Paths.get("test.txt");
        byte[] result = DigestUtils.digest(md5Digest, data);

        assertNotNull(result);
        assertEquals(md5Digest.digest(Files.readAllBytes(data)), result);
    }

    @Test
    public void digest_withPathAndOptions_throwsIOException_whenFileNotFound() throws NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        Path data = Paths.get("nonexistent.txt");

        assertThrows(IOException.class, () -> DigestUtils.digest(md5Digest, data));
    }

    @Test
    public void digest_withPathAndOptions_throwsNullPointerException_whenNullDigestProvided() throws IOException {
        Path data = Paths.get("test.txt");

        assertThrows(NullPointerException.class, () -> DigestUtils.digest(null, data));
    }

    @Test
    public void digest_withRandomAccessFile_returnsExpectedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");
        RandomAccessFile data = new RandomAccessFile("test.txt", "r");
        byte[] result = DigestUtils.digest(md5Digest, data);

        assertNotNull(result);
        assertEquals(md5Digest.digest(Files.readAllBytes(Paths.get("test.txt"))), result);
    }

    @Test
    public void digest_withRandomAccessFile_throwsIOException_whenFileNotFound() throws NoSuchAlgorithmException {
        MessageDigest md5Digest = MessageDigest.getInstance("MD5");

        assertThrows(FileNotFoundException.class, () -> {
            try (RandomAccessFile data = new RandomAccessFile("nonexistent.txt", "r")) {
                DigestUtils.digest(md5Digest, data);
            }
        });
    }

    @Test
    public void digest_withRandomAccessFile_throwsNullPointerException_whenNullDigestProvided() {
        assertThrows(NullPointerException.class, () -> {
            try (RandomAccessFile data = new RandomAccessFile("test.txt", "r")) {
                DigestUtils.digest(null, data);
            }
        });
    }

    @Test
    public void getDigest_withValidAlgorithm_returnsDigest() {
        MessageDigest result = DigestUtils.getDigest("SHA-256");
        assertNotNull(result);
        assertEquals("SHA-256", result.getAlgorithm());
    }

    @Test
    public void getDigest_withInvalidAlgorithm_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> DigestUtils.getDigest("Invalid"));
    }

    @Test
    public void getDigest_withNullAlgorithm_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> DigestUtils.getDigest(null));
    }

    @Test
    public void getDigest_withValidAlgorithmAndDefaultDigest_returnsDigest() throws NoSuchAlgorithmException {
        MessageDigest defaultDigest = MessageDigest.getInstance("MD5");
        MessageDigest result = DigestUtils.getDigest("SHA-256", defaultDigest);
        assertNotNull(result);
        assertEquals("SHA-256", result.getAlgorithm());
    }

    @Test
    public void getDigest_withInvalidAlgorithmAndDefaultDigest_returnsDefaultDigest() throws NoSuchAlgorithmException {
        MessageDigest defaultDigest = MessageDigest.getInstance("MD5");
        MessageDigest result = DigestUtils.getDigest("Invalid", defaultDigest);
        assertNotNull(result);
        assertEquals("MD5", result.getAlgorithm());
    }

    @Test
    public void getDigest_withNullAlgorithmAndDefaultDigest_returnsDefaultDigest() throws NoSuchAlgorithmException {
        MessageDigest defaultDigest = MessageDigest.getInstance("MD5");
        MessageDigest result = DigestUtils.getDigest(null, defaultDigest);
        assertNotNull(result);
        assertEquals("MD5", result.getAlgorithm());
    }

    @Test
    public void getMd2Digest_returnsMd2DigestInstance() {
        MessageDigest result = DigestUtils.getMd2Digest();
        assertNotNull(result);
        assertEquals("MD2", result.getAlgorithm());
    }

    @Test
    public void getMd2Digest_throwsException_whenMd2AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getMd2Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getMd2Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getMd2Digest();
        MessageDigest result2 = DigestUtils.getMd2Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getMd5Digest_returnsMd5DigestInstance() {
        MessageDigest result = DigestUtils.getMd5Digest();
        assertNotNull(result);
        assertEquals("MD5", result.getAlgorithm());
    }

    @Test
    public void getMd5Digest_throwsException_whenMd5AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getMd5Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getMd5Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getMd5Digest();
        MessageDigest result2 = DigestUtils.getMd5Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha1Digest_returnsSha1DigestInstance() {
        MessageDigest result = DigestUtils.getSha1Digest();
        assertNotNull(result);
        assertEquals("SHA-1", result.getAlgorithm());
    }

    @Test
    public void getSha1Digest_throwsException_whenSha1AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha1Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha1Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha1Digest();
        MessageDigest result2 = DigestUtils.getSha1Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha256Digest_returnsSha256DigestInstance() {
        MessageDigest result = DigestUtils.getSha256Digest();
        assertNotNull(result);
        assertEquals("SHA-256", result.getAlgorithm());
    }

    @Test
    public void getSha256Digest_throwsException_whenSha256AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha256Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha256Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha256Digest();
        MessageDigest result2 = DigestUtils.getSha256Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha3_224Digest_returnsSha3_224DigestInstance() {
        MessageDigest result = DigestUtils.getSha3_224Digest();
        assertNotNull(result);
        assertEquals("SHA3-224", result.getAlgorithm());
    }

    @Test
    public void getSha3_224Digest_throwsException_whenSha3_224AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha3_224Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha3_224Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha3_224Digest();
        MessageDigest result2 = DigestUtils.getSha3_224Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha3_256Digest_returnsSha3_256DigestInstance() {
        MessageDigest result = DigestUtils.getSha3_256Digest();
        assertNotNull(result);
        assertEquals("SHA3-256", result.getAlgorithm());
    }

    @Test
    public void getSha3_256Digest_throwsException_whenSha3_256AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha3_256Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha3_256Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha3_256Digest();
        MessageDigest result2 = DigestUtils.getSha3_256Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha3_384Digest_returnsSha3_384DigestInstance() {
        MessageDigest result = DigestUtils.getSha3_384Digest();
        assertNotNull(result);
        assertEquals("SHA3-384", result.getAlgorithm());
    }

    @Test
    public void getSha3_384Digest_throwsException_whenSha3_384AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha3_384Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha3_384Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha3_384Digest();
        MessageDigest result2 = DigestUtils.getSha3_384Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha3_512Digest_returnsSha3_512DigestInstance() {
        MessageDigest result = DigestUtils.getSha3_512Digest();
        assertNotNull(result);
        assertEquals("SHA3-512", result.getAlgorithm());
    }

    @Test
    public void getSha3_512Digest_throwsException_whenSha3_512AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha3_512Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha3_512Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha3_512Digest();
        MessageDigest result2 = DigestUtils.getSha3_512Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha384Digest_returnsSha384DigestInstance() {
        MessageDigest result = DigestUtils.getSha384Digest();
        assertNotNull(result);
        assertEquals("SHA-384", result.getAlgorithm());
    }

    @Test
    public void getSha384Digest_throwsException_whenSha384AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha384Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha384Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha384Digest();
        MessageDigest result2 = DigestUtils.getSha384Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha512_224Digest_returnsSha512_224DigestInstance() {
        MessageDigest result = DigestUtils.getSha512_224Digest();
        assertNotNull(result);
        assertEquals("SHA-512/224", result.getAlgorithm());
    }

    @Test
    public void getSha512_224Digest_throwsException_whenSha512_224AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha512_224Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha512_224Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha512_224Digest();
        MessageDigest result2 = DigestUtils.getSha512_224Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha512_256Digest_returnsSha512_256DigestInstance() {
        MessageDigest result = DigestUtils.getSha512_256Digest();
        assertNotNull(result);
        assertEquals("SHA-512/256", result.getAlgorithm());
    }

    @Test
    public void getSha512_256Digest_throwsException_whenSha512_256AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha512_256Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha512_256Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha512_256Digest();
        MessageDigest result2 = DigestUtils.getSha512_256Digest();
        assertSame(result1, result2);
    }

    @Test
    public void getSha512Digest_returnsSha512DigestInstance() {
        MessageDigest result = DigestUtils.getSha512Digest();
        assertNotNull(result);
        assertEquals("SHA-512", result.getAlgorithm());
    }

    @Test
    public void getSha512Digest_throwsException_whenSha512AlgorithmNotSupported() {
        System.setProperty("java.security", "NoSuchAlgorithmException");
        assertThrows(IllegalArgumentException.class, DigestUtils::getSha512Digest);
        System.clearProperty("java.security");
    }

    @Test
    public void getSha512Digest_returnsSameInstance_onMultipleCalls() {
        MessageDigest result1 = DigestUtils.getSha512Digest();
        MessageDigest result2 = DigestUtils.getSha512Digest();
        assertSame(result1, result2);
    }

    @Test
    public void isAvailable_returnsTrue_forSupportedAlgorithm() {
        assertTrue(DigestUtils.isAvailable("SHA-256"));
    }

    @Test
    public void isAvailable_returnsFalse_forUnsupportedAlgorithm() {
        assertFalse(DigestUtils.isAvailable("Unsupported_Algorithm"));
    }

    @Test
    public void isAvailable_returnsFalse_forNullAlgorithm() {
        assertFalse(DigestUtils.isAvailable(null));
    }

    @Test
    public void md2_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-68, -107, -29, 70, -127, -99, -56, -56, -113, 96, -125, 63, 85, -58, -95, -89};
        assertArrayEquals(expectedDigest, DigestUtils.md2(data));
    }

    @Test
    public void md2_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.md2(data1)), Arrays.toString(DigestUtils.md2(data2)));
    }

    @Test
    public void md2_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[16];
        assertArrayEquals(expectedDigest, DigestUtils.md2(data));
    }

    @Test
    public void md2InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-68, -107, -29, 70, -127, -99, -56, -56, -113, 96, -125, 63, 85, -58, -95, -89};
        assertArrayEquals(expectedDigest, DigestUtils.md2(data));
    }

    @Test
    public void md2InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.md2(data1)), Arrays.toString(DigestUtils.md2(data2)));
    }

    @Test
    public void md2InputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[16];
        assertArrayEquals(expectedDigest, DigestUtils.md2(data));
    }

    @Test
    public void md2String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-68, -107, -29, 70, -127, -99, -56, -56, -113, 96, -125, 63, 85, -58, -95, -89};
        assertArrayEquals(expectedDigest, DigestUtils.md2(data));
    }

    @Test
    public void md2String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.md2(data1)), Arrays.toString(DigestUtils.md2(data2)));
    }

    @Test
    public void md2String_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[16];
        assertArrayEquals(expectedDigest, DigestUtils.md2(data));
    }

    @Test
    public void md2Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "098f6bcd4621d373cade4e832627b4f6";
        assertEquals(expectedHex, DigestUtils.md2Hex(data));
    }

    @Test
    public void md2Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.md2Hex(data1), DigestUtils.md2Hex(data2));
    }

    @Test
    public void md2Hex_returnsEmptyString_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "";
        assertEquals(expectedHex, DigestUtils.md2Hex(data));
    }

    @Test
    public void md2HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "098f6bcd4621d373cade4e832627b4f6";
        assertEquals(expectedHex, DigestUtils.md2Hex(data));
    }

    @Test
    public void md2HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.md2Hex(data1), DigestUtils.md2Hex(data2));
    }

    @Test
    public void md2HexInputStream_returnsEmptyString_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "";
        assertEquals(expectedHex, DigestUtils.md2Hex(data));
    }

    @Test
    public void md5_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-68, -107, -29, 70, -127, -99, -56, -56, -113, 96, -125, 63, 85, -58, -95, -89};
        assertArrayEquals(expectedDigest, DigestUtils.md5(data));
    }

    @Test
    public void md5_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.md5(data1)), Arrays.toString(DigestUtils.md5(data2)));
    }

    @Test
    public void md5_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[16];
        assertArrayEquals(expectedDigest, DigestUtils.md5(data));
    }

    @Test
    public void md5InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-68, -107, -29, 70, -127, -99, -56, -56, -113, 96, -125, 63, 85, -58, -95, -89};
        assertArrayEquals(expectedDigest, DigestUtils.md5(data));
    }

    @Test
    public void md5InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.md5(data1)), Arrays.toString(DigestUtils.md5(data2)));
    }

    @Test
    public void md5InputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[16];
        assertArrayEquals(expectedDigest, DigestUtils.md5(data));
    }

    @Test
    public void md5String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-68, -107, -29, 70, -127, -99, -56, -56, -113, 96, -125, 63, 85, -58, -95, -89};
        assertArrayEquals(expectedDigest, DigestUtils.md5(data));
    }

    @Test
    public void md5String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.md5(data1)), Arrays.toString(DigestUtils.md5(data2)));
    }

    @Test
    public void md5String_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[16];
        assertArrayEquals(expectedDigest, DigestUtils.md5(data));
    }

    @Test
    public void md5Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.md5Hex(data1), DigestUtils.md5Hex(data2));
    }

    @Test
    public void md5Hex_returnsEmptyString_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "";
        assertEquals(expectedHex, DigestUtils.md5Hex(data));
    }

    @Test
    public void md5HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "098f6bcd4621d373cade4e832627b4f6";
        assertEquals(expectedHex, DigestUtils.md5Hex(data));
    }

    @Test
    public void md5HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.md5Hex(data1), DigestUtils.md5Hex(data2));
    }

    @Test
    public void md5HexInputStream_returnsEmptyString_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "";
        assertEquals(expectedHex, DigestUtils.md5Hex(data));
    }

    @Test
    public void md5Hex_returnsCorrectHex_forGivenData() {
        String data = "test";
        String expectedHex = "098f6bcd4621d373cade4e832627b4f6";
        assertEquals(expectedHex, DigestUtils.md5Hex(data));
    }

    @Test
    public void sha_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha(data));
    }

    @Test
    public void sha_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.sha(data1)), Arrays.toString(DigestUtils.sha(data2)));
    }

    @Test
    public void sha_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha(data));
    }

    @Test
    public void shaInputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha(data));
    }

    @Test
    public void shaInputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.sha(data1)), Arrays.toString(DigestUtils.sha(data2)));
    }

    @Test
    public void shaInputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha(data));
    }

    @Test
    public void shaString_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha(data));
    }

    @Test
    public void shaString_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.sha(data1)), Arrays.toString(DigestUtils.sha(data2)));
    }

    @Test
    public void shaString_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha(data));
    }

    @Test
    public void sha1_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha1(data));
    }

    @Test
    public void sha1_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.sha1(data1)), Arrays.toString(DigestUtils.sha1(data2)));
    }

    @Test
    public void sha1_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha1(data));
    }

    @Test
    public void sha1InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha1(data));
    }

    @Test
    public void sha1InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.sha1(data1)), Arrays.toString(DigestUtils.sha1(data2)));
    }

    @Test
    public void sha1InputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha1(data));
    }

    @Test
    public void sha1String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha1(data));
    }

    @Test
    public void sha1String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.sha1(data1)), Arrays.toString(DigestUtils.sha1(data2)));
    }

    @Test
    public void sha1String_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha1(data));
    }

    @Test
    public void sha1Hex_returnsCorrectHex_forGivenData() {
        String data = "test";
        String expectedHex = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3";
        assertEquals(expectedHex, DigestUtils.sha1Hex(data));
    }

    @Test
    public void sha1Hex_returnsDifferentHex_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(DigestUtils.sha1Hex(data1), DigestUtils.sha1Hex(data2));
    }

    @Test
    public void sha1Hex_returnsCorrectHex_forEmptyData() {
        String data = "";
        String expectedHex = "da39a3ee5e6b4b0d3255bfef95601890afd80709";
        assertEquals(expectedHex, DigestUtils.sha1Hex(data));
    }

    @Test
    public void sha256_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha256(data));
    }

    @Test
    public void sha256_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.sha256(data1)), Arrays.toString(DigestUtils.sha256(data2)));
    }

    @Test
    public void sha256_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha256(data));
    }

    @Test
    public void sha256InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha256(data));
    }

    @Test
    public void sha256InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.sha256(data1)), Arrays.toString(DigestUtils.sha256(data2)));
    }

    @Test
    public void sha256InputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha256(data));
    }

    @Test
    public void sha256String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha256(data));
    }

    @Test
    public void sha256String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.sha256(data1)), Arrays.toString(DigestUtils.sha256(data2)));
    }

    @Test
    public void sha256String_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha256(data));
    }

    @Test
    public void sha256Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "532eaabd9574880dbf76b9b8cc00832c20a6ec113d682299550d7a6e0f345e25";
        assertEquals(expectedHex, DigestUtils.sha256Hex(data));
    }

    @Test
    public void sha256Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha256Hex(data1), DigestUtils.sha256Hex(data2));
    }

    @Test
    public void sha256Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
        assertEquals(expectedHex, DigestUtils.sha256Hex(data));
    }

    @Test
    public void sha256HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "532eaabd9574880dbf76b9b8cc00832c20a6ec113d682299550d7a6e0f345e25";
        assertEquals(expectedHex, DigestUtils.sha256Hex(data));
    }

    @Test
    public void sha256HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha256Hex(data1), DigestUtils.sha256Hex(data2));
    }

    @Test
    public void sha256HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
        assertEquals(expectedHex, DigestUtils.sha256Hex(data));
    }

    @Test
    public void sha3_224_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_224(data));
    }

    @Test
    public void sha3_224_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.sha3_224(data1)), Arrays.toString(DigestUtils.sha3_224(data2)));
    }

    @Test
    public void sha3_224_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_224(data));
    }

    @Test
    public void sha3_224InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_224(data));
    }

    @Test
    public void sha3_224InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.sha3_224(data1)), Arrays.toString(DigestUtils.sha3_224(data2)));
    }

    @Test
    public void sha3_224InputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_224(data));
    }

    @Test
    public void sha3_224String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_224(data));
    }

    @Test
    public void sha3_224String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.sha3_224(data1)), Arrays.toString(DigestUtils.sha3_224(data2)));
    }

    @Test
    public void sha3_224String_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_224(data));
    }

    @Test
    public void sha3_224Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "8a24108b154ada21c9b468beac8982a2ed7b9b3094daa3b1623b00d5";
        assertEquals(expectedHex, DigestUtils.sha3_224Hex(data));
    }

    @Test
    public void sha3_224Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha3_224Hex(data1), DigestUtils.sha3_224Hex(data2));
    }

    @Test
    public void sha3_224Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "6dcd4ce23d88e2ee95838f7b014b6284f174d7a9144c5b06150e5c76bfd2ff6b";
        assertEquals(expectedHex, DigestUtils.sha3_224Hex(data));
    }

    @Test
    public void sha3_224HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "8a24108b154ada21c9b468beac8982a2ed7b9b3094daa3b1623b00d5";
        assertEquals(expectedHex, DigestUtils.sha3_224Hex(data));
    }

    @Test
    public void sha3_224HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha3_224Hex(data1), DigestUtils.sha3_224Hex(data2));
    }

    @Test
    public void sha3_224HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "6dcd4ce23d88e2ee95838f7b014b6284f174d7a9144c5b06150e5c76bfd2ff6b";
        assertEquals(expectedHex, DigestUtils.sha3_224Hex(data));
    }

    @Test
    public void sha3_256_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{(byte) 0x4e, (byte) 0x74, (byte) 0x81, (byte) 0x92, (byte) 0x4f, (byte) 0xcd, (byte) 0x0d, (byte) 0x4e, (byte) 0x67, (byte) 0xb2, (byte) 0x8a, (byte) 0x41, (byte) 0x70, (byte) 0x5d, (byte) 0x4c, (byte) 0x78, (byte) 0x24, (byte) 0x8f, (byte) 0x8a, (byte) 0x8e, (byte) 0x70, (byte) 0x4a, (byte) 0x87, (byte) 0x71, (byte) 0xd5, (byte) 0xb6, (byte) 0x48, (byte) 0x86, (byte) 0xe7, (byte) 0x28, (byte) 0x7f, (byte) 0x8f, (byte) 0x54};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_256(data));
    }

    @Test
    public void sha3_256_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.sha3_256(data1)), Arrays.toString(DigestUtils.sha3_256(data2)));
    }

    @Test
    public void sha3_256_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{(byte) 0xa7, (byte) 0xff, (byte) 0xc6, (byte) 0xf8, (byte) 0xbf, (byte) 0x1e, (byte) 0xd7, (byte) 0x66, (byte) 0x51, (byte) 0xc1, (byte) 0x47, (byte) 0x56, (byte) 0xa0, (byte) 0x61, (byte) 0xd6, (byte) 0x62, (byte) 0xf5, (byte) 0x80, (byte) 0xff, (byte) 0x4d, (byte) 0xe4, (byte) 0x3b, (byte) 0x49, (byte) 0xfa, (byte) 0x82, (byte) 0xd8, (byte) 0x0a, (byte) 0x4b, (byte) 0x80, (byte) 0xf8, (byte) 0x43, (byte) 0x4a};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_256(data));
    }

    @Test
    public void sha3_256InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_256(data));
    }

    @Test
    public void sha3_256InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.sha3_256(data1)), Arrays.toString(DigestUtils.sha3_256(data2)));
    }

    @Test
    public void sha3_256InputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_256(data));
    }

    @Test
    public void sha3_256String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_256(data));
    }

    @Test
    public void sha3_256String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.sha3_256(data1)), Arrays.toString(DigestUtils.sha3_256(data2)));
    }

    @Test
    public void sha3_256String_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_256(data));
    }

    @Test
    public void sha3_256Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce";
        assertEquals(expectedHex, DigestUtils.sha3_256Hex(data));
    }

    @Test
    public void sha3_256Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha3_256Hex(data1), DigestUtils.sha3_256Hex(data2));
    }

    @Test
    public void sha3_256Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a";
        assertEquals(expectedHex, DigestUtils.sha3_256Hex(data));
    }

    @Test
    public void sha3_256HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce";
        assertEquals(expectedHex, DigestUtils.sha3_256Hex(data));
    }

    @Test
    public void sha3_256HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha3_256Hex(data1), DigestUtils.sha3_256Hex(data2));
    }

    @Test
    public void sha3_256HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a";
        assertEquals(expectedHex, DigestUtils.sha3_256Hex(data));
    }

    @Test
    public void sha3_384_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_384(data));
    }

    @Test
    public void sha3_384_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.sha3_384(data1)), Arrays.toString(DigestUtils.sha3_384(data2)));
    }

    @Test
    public void sha3_384_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_384(data));
    }

    @Test
    public void sha3_384InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_384(data));
    }

    @Test
    public void sha3_384InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.sha3_384(data1)), Arrays.toString(DigestUtils.sha3_384(data2)));
    }

    @Test
    public void sha3_384InputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_384(data));
    }

    @Test
    public void sha3_384String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_384(data));
    }

    @Test
    public void sha3_384String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.sha3_384(data1)), Arrays.toString(DigestUtils.sha3_384(data2)));
    }

    @Test
    public void sha3_384String_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_384(data));
    }

    @Test
    public void sha3_384Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha3_384Hex(data1), DigestUtils.sha3_384Hex(data2));
    }

    @Test
    public void sha3_384Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "0c63a75b845e4f7d01107d852e4c2485c51a50aaaa94fc61995e71bbee983a2ac3114748d01ee950e4472eb8a6106b56aa5582d88286755b";
        assertEquals(expectedHex, DigestUtils.sha3_384Hex(data));
    }

    @Test
    public void sha3_384HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "0c63a75b845e4f7d01107d852e4c2485c51a50aaaa94fc61995e71bbee983a2ac3114748d01ee950e4472eb8a6106b56aa5582d88286755b";
        assertEquals(expectedHex, DigestUtils.sha3_384Hex(data));
    }

    @Test
    public void sha3_384HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha3_384Hex(data1), DigestUtils.sha3_384Hex(data2));
    }

    @Test
    public void sha3_384HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "0c63a75b845e4f7d01107d852e4c2485c51a50aaaa94fc61995e71bbee983a2ac3114748d01ee950e4472eb8a6106b56aa5582d88286755b";
        assertEquals(expectedHex, DigestUtils.sha3_384Hex(data));
    }

    @Test
    public void sha3_384Hex_returnsCorrectHex_forGivenData() {
        String data = "test";
        String expectedHex = "0c63a75b845e4f7d01107d852e4c2485c51a50aaaa94fc61995e71bbee983a2ac3114748d01ee950e4472eb8a6106b56aa5582d88286755b";
        assertEquals(expectedHex, DigestUtils.sha3_384Hex(data));
    }

    @Test
    public void sha3_512_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_512(data));
    }

    @Test
    public void sha3_512_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.sha3_512(data1)), Arrays.toString(DigestUtils.sha3_512(data2)));
    }

    @Test
    public void sha3_512_returnsEmptyArray_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_512(data));
    }

    @Test
    public void sha3_512InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_512(data));
    }

    @Test
    public void sha3_512InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(Arrays.toString(DigestUtils.sha3_512(data1)), Arrays.toString(DigestUtils.sha3_512(data2)));
    }

    @Test
    public void sha3_512InputStream_returnsEmptyArray_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_512(data));
    }

    @Test
    public void sha3_512String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_512(data));
    }

    @Test
    public void sha3_512String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(Arrays.toString(DigestUtils.sha3_512(data1)), Arrays.toString(DigestUtils.sha3_512(data2)));
    }

    @Test
    public void sha3_512String_returnsEmptyArray_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha3_512(data));
    }

    @Test
    public void sha3_512Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "0c63a75b845e4f7d01107d852e4c2485c51a50aaaa94fc61995e71bbee983a2ac3114748d01ee950e4472eb8a6106b56aa5582d88286755b";
        assertEquals(expectedHex, DigestUtils.sha3_512Hex(data));
    }

    @Test
    public void sha3_512Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha3_512Hex(data1), DigestUtils.sha3_512Hex(data2));
    }

    @Test
    public void sha3_512Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "0c63a75b845e4f7d01107d852e4c2485c51a50aaaa94fc61995e71bbee983a2ac3114748d01ee950e4472eb8a6106b56aa5582d88286755b";
        assertEquals(expectedHex, DigestUtils.sha3_512Hex(data));
    }

    @Test
    public void sha3_512HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "0c63a75b845e4f7d01107d852e4c2485c51a50aaaa94fc61995e71bbee983a2ac3114748d01ee950e4472eb8a6106b56aa5582d88286755b";
        assertEquals(expectedHex, DigestUtils.sha3_512Hex(data));
    }

    @Test
    public void sha3_512HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha3_512Hex(data1), DigestUtils.sha3_512Hex(data2));
    }

    @Test
    public void sha3_512HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "0c63a75b845e4f7d01107d852e4c2485c51a50aaaa94fc61995e71bbee983a2ac3114748d01ee950e4472eb8a6106b56aa5582d88286755b";
        assertEquals(expectedHex, DigestUtils.sha3_512Hex(data));
    }

    @Test
    public void sha384_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{-87, -80, 62, 32, 115, 50, -115, -88, -56, -34, -94, -50, -40, -75, -21, -112, -126, -104, 108, 61};
        assertArrayEquals(expectedDigest, DigestUtils.sha384(data));
    }

    @Test
    public void sha384_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(Arrays.toString(DigestUtils.sha384(data1)), Arrays.toString(DigestUtils.sha384(data2)));
    }

    @Test
    public void sha384InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha384(data));
    }

    @Test
    public void sha384InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha384(data1), DigestUtils.sha384(data2));
    }

    @Test
    public void sha384InputStream_returnsCorrectDigest_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha384(data));
    }

    @Test
    public void sha384String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha384(data));
    }

    @Test
    public void sha384String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(DigestUtils.sha384(data1), DigestUtils.sha384(data2));
    }

    @Test
    public void sha384String_returnsCorrectDigest_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha384(data));
    }

    @Test
    public void sha384Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "768412320f7b488e9b6d8ef21156b16b8b9c5a04742d2967399b214f53761febdc57863b7e4fdd36fb39876c9ee60b6d";
        assertEquals(expectedHex, DigestUtils.sha384Hex(data));
    }

    @Test
    public void sha384Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha384Hex(data1), DigestUtils.sha384Hex(data2));
    }

    @Test
    public void sha384Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "38b060a751ac96384cd9327eb1b1e36a21fdb71114be07434c0cc7bf63f6e1da274edebfe76f65fbd51ad2f14898b95b";
        assertEquals(expectedHex, DigestUtils.sha384Hex(data));
    }

    @Test
    public void sha384HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "768412320f7b488e9b6d8ef21156b16b8b9c5a04742d2967399b214f53761febdc57863b7e4fdd36fb39876c9ee60b6d";
        assertEquals(expectedHex, DigestUtils.sha384Hex(data));
    }

    @Test
    public void sha384HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha384Hex(data1), DigestUtils.sha384Hex(data2));
    }

    @Test
    public void sha384HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "38b060a751ac96384cd9327eb1b1e36a21fdb71114be07434c0cc7bf63f6e1da274edebfe76f65fbd51ad2f14898b95b";
        assertEquals(expectedHex, DigestUtils.sha384Hex(data));
    }

    @Test
    public void sha512_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512(data));
    }

    @Test
    public void sha512_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha512(data1), DigestUtils.sha512(data2));
    }

    @Test
    public void sha512_returnsCorrectDigest_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512(data));
    }

    @Test
    public void sha512InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512(data));
    }

    @Test
    public void sha512InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha512(data1), DigestUtils.sha512(data2));
    }

    @Test
    public void sha512InputStream_returnsCorrectDigest_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512(data));
    }

    @Test
    public void sha512String_returnsCorrectDigest_forGivenData() {
        String data = "test";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512(data));
    }

    @Test
    public void sha512String_returnsDifferentDigest_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(DigestUtils.sha512(data1), DigestUtils.sha512(data2));
    }

    @Test
    public void sha512String_returnsCorrectDigest_forEmptyData() {
        String data = "";
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512(data));
    }

    @Test
    public void sha512_224_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512_224(data));
    }

    @Test
    public void sha512_224_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha512_224(data1), DigestUtils.sha512_224(data2));
    }

    @Test
    public void sha512_224_returnsCorrectDigest_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512_224(data));
    }

    @Test
    public void sha512_224InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512_224(data));
    }

    @Test
    public void sha512_224InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha512_224(data1), DigestUtils.sha512_224(data2));
    }

    @Test
    public void sha512_224InputStream_returnsCorrectDigest_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512_224(data));
    }

    @Test
    public void sha512_224Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "768412320f7b488e9b6d8ef21156b16b8b9c5a04742d2967399b214f53761febdc57863b7e4fdd36fb39876c9ee60b6d";
        assertEquals(expectedHex, DigestUtils.sha512_224Hex(data));
    }

    @Test
    public void sha512_224Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha512_224Hex(data1), DigestUtils.sha512_224Hex(data2));
    }

    @Test
    public void sha512_224Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "768412320f7b488e9b6d8ef21156b16b8b9c5a04742d2967399b214f53761febdc57863b7e4fdd36fb39876c9ee60b6d";
        assertEquals(expectedHex, DigestUtils.sha512_224Hex(data));
    }

    @Test
    public void sha512_224HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "94ba5dceba4f3df8efd89a9ed2efc7bea7c5e1f3";
        assertEquals(expectedHex, DigestUtils.sha512_224Hex(data));
    }

    @Test
    public void sha512_224HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha512_224Hex(data1), DigestUtils.sha512_224Hex(data2));
    }

    @Test
    public void sha512_224HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "6ed0dd02806fa89e25de060c19d3ac86cabb87d6a0ddd05c333b84f4";
        assertEquals(expectedHex, DigestUtils.sha512_224Hex(data));
    }

    @Test
    public void sha512_224HexString_returnsCorrectHex_forGivenData() {
        String data = "test";
        String expectedHex = "94ba5dceba4f3df8efd89a9ed2efc7bea7c5e1f3";
        assertEquals(expectedHex, DigestUtils.sha512_224Hex(data));
    }

    @Test
    public void sha512_224HexString_returnsDifferentHex_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(DigestUtils.sha512_224Hex(data1), DigestUtils.sha512_224Hex(data2));
    }

    @Test
    public void sha512_224HexString_returnsCorrectHex_forEmptyData() {
        String data = "";
        String expectedHex = "6ed0dd02806fa89e25de060c19d3ac86cabb87d6a0ddd05c333b84f4";
        assertEquals(expectedHex, DigestUtils.sha512_224Hex(data));
    }

    @Test
    public void sha512_256_returnsCorrectDigest_forGivenData() {
        byte[] data = "test".getBytes();
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512_256(data));
    }

    @Test
    public void sha512_256_returnsDifferentDigest_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha512_256(data1), DigestUtils.sha512_256(data2));
    }

    @Test
    public void sha512_256_returnsCorrectDigest_forEmptyData() {
        byte[] data = new byte[0];
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512_256(data));
    }

    @Test
    public void sha512_256InputStream_returnsCorrectDigest_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512_256(data));
    }

    @Test
    public void sha512_256InputStream_returnsDifferentDigest_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha512_256(data1), DigestUtils.sha512_256(data2));
    }

    @Test
    public void sha512_256InputStream_returnsCorrectDigest_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        byte[] expectedDigest = new byte[]{94, 122, -50, -70, 79, 61, -8, -17, -40, -102, -50, -17, -57, -126, -41, -5, -105, -58, -31, -13};
        assertArrayEquals(expectedDigest, DigestUtils.sha512_256(data));
    }

    @Test
    public void sha512_256Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "94ba5dceba4f3df8efd89a9ed2efc7bea7c5e1f3";
        assertEquals(expectedHex, DigestUtils.sha512_256Hex(data));
    }

    @Test
    public void sha512_256Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha512_256Hex(data1), DigestUtils.sha512_256Hex(data2));
    }

    @Test
    public void sha512_256Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "94ba5dceba4f3df8efd89a9ed2efc7bea7c5e1f3";
        assertEquals(expectedHex, DigestUtils.sha512_256Hex(data));
    }

    @Test
    public void sha512_256HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "5323477a8b20ffb5b6bc5a21c0b503a998f4b3c8dbd7e3dc047a57c1579792e3";
        assertEquals(expectedHex, DigestUtils.sha512_256Hex(data));
    }

    @Test
    public void sha512_256HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha512_256Hex(data1), DigestUtils.sha512_256Hex(data2));
    }

    @Test
    public void sha512_256HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "c672b8d1ef56ed28ab87c3622c5114069bdd3ad7b8f9737498d0c01ecef0967a";
        assertEquals(expectedHex, DigestUtils.sha512_256Hex(data));
    }

    @Test
    public void sha512_256HexString_returnsCorrectHex_forGivenData() {
        String data = "test";
        String expectedHex = "5323477a8b20ffb5b6bc5a21c0b503a998f4b3c8dbd7e3dc047a57c1579792e3";
        assertEquals(expectedHex, DigestUtils.sha512_256Hex(data));
    }

    @Test
    public void sha512_256HexString_returnsDifferentHex_forDifferentData() {
        String data1 = "test";
        String data2 = "different test";
        assertNotEquals(DigestUtils.sha512_256Hex(data1), DigestUtils.sha512_256Hex(data2));
    }

    @Test
    public void sha512_256HexString_returnsCorrectHex_forEmptyData() {
        String data = "";
        String expectedHex = "c672b8d1ef56ed28ab87c3622c5114069bdd3ad7b8f9737498d0c01ecef0967a";
        assertEquals(expectedHex, DigestUtils.sha512_256Hex(data));
    }

    @Test
    public void sha512Hex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff";
        assertEquals(expectedHex, DigestUtils.sha512Hex(data));
    }

    @Test
    public void sha512Hex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.sha512Hex(data1), DigestUtils.sha512Hex(data2));
    }

    @Test
    public void sha512Hex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e";
        assertEquals(expectedHex, DigestUtils.sha512Hex(data));
    }

    @Test
    public void sha512HexInputStream_returnsCorrectHex_forGivenData() throws IOException {
        InputStream data = new ByteArrayInputStream("test".getBytes());
        String expectedHex = "ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff";
        assertEquals(expectedHex, DigestUtils.sha512Hex(data));
    }

    @Test
    public void sha512HexInputStream_returnsDifferentHex_forDifferentData() throws IOException {
        InputStream data1 = new ByteArrayInputStream("test".getBytes());
        InputStream data2 = new ByteArrayInputStream("different test".getBytes());
        assertNotEquals(DigestUtils.sha512Hex(data1), DigestUtils.sha512Hex(data2));
    }

    @Test
    public void sha512HexInputStream_returnsCorrectHex_forEmptyData() throws IOException {
        InputStream data = new ByteArrayInputStream(new byte[0]);
        String expectedHex = "cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e";
        assertEquals(expectedHex, DigestUtils.sha512Hex(data));
    }

    @Test
    public void shaHex_returnsCorrectHex_forGivenData() {
        byte[] data = "test".getBytes();
        String expectedHex = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3";
        assertEquals(expectedHex, DigestUtils.shaHex(data));
    }

    @Test
    public void shaHex_returnsDifferentHex_forDifferentData() {
        byte[] data1 = "test".getBytes();
        byte[] data2 = "different test".getBytes();
        assertNotEquals(DigestUtils.shaHex(data1), DigestUtils.shaHex(data2));
    }

    @Test
    public void shaHex_returnsCorrectHex_forEmptyData() {
        byte[] data = new byte[0];
        String expectedHex = "5ba93c9db0cff93f52b521d7420e43f6eda2784f";
        assertEquals(expectedHex, DigestUtils.shaHex(data));
    }

    @Test
    public void updateDigest_withByteArray_returnsUpdatedDigest() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        byte[] valueToDigest = "test".getBytes();
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, valueToDigest);
        assertNotNull(updatedDigest);
        assertNotEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withEmptyByteArray_returnsSameDigest() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        byte[] valueToDigest = new byte[0];
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, valueToDigest);
        assertNotNull(updatedDigest);
        assertEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withByteBuffer_returnsUpdatedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        ByteBuffer valueToDigest = ByteBuffer.wrap("test".getBytes());
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, valueToDigest);
        assertNotNull(updatedDigest);
        assertNotEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withEmptyByteBuffer_returnsSameDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        ByteBuffer valueToDigest = ByteBuffer.wrap(new byte[0]);
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, valueToDigest);
        assertNotNull(updatedDigest);
        assertEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withNullByteBuffer_throwsException() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        assertThrows(NullPointerException.class, () -> DigestUtils.updateDigest(messageDigest, (ByteBuffer) null));
    }

    @Test
    public void updateDigest_withFile_returnsUpdatedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        File file = new File("test.txt");
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, file);
        assertNotNull(updatedDigest);
        assertNotEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withEmptyFile_returnsSameDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        File file = new File("empty.txt");
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, file);
        assertNotNull(updatedDigest);
        assertEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withNonExistentFile_throwsException() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        File file = new File("nonexistent.txt");
        assertThrows(IOException.class, () -> DigestUtils.updateDigest(messageDigest, file));
    }

    @Test
    public void updateDigest_withInputStream_returnsUpdatedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        InputStream inputStream = new ByteArrayInputStream("test".getBytes());
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, inputStream);
        assertNotNull(updatedDigest);
        assertNotEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withEmptyInputStream_returnsSameDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        InputStream inputStream = new ByteArrayInputStream(new byte[0]);
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, inputStream);
        assertNotNull(updatedDigest);
        assertEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withNullInputStream_throwsException() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        assertThrows(NullPointerException.class, () -> DigestUtils.updateDigest(messageDigest, (InputStream) null));
    }

    @Test
    public void updateDigest_withPath_returnsUpdatedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        Path path = Paths.get("test.txt");
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, path);
        assertNotNull(updatedDigest);
        assertNotEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withEmptyPath_returnsSameDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        Path path = Paths.get("empty.txt");
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, path);
        assertNotNull(updatedDigest);
        assertEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withNonExistentPath_throwsException() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        Path path = Paths.get("nonexistent.txt");
        assertThrows(IOException.class, () -> DigestUtils.updateDigest(messageDigest, path));
    }

    @Test
    public void updateDigest_withRandomAccessFile_returnsUpdatedDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        RandomAccessFile randomAccessFile = new RandomAccessFile("test.txt", "r");
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, randomAccessFile);
        assertNotNull(updatedDigest);
        assertNotEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withEmptyRandomAccessFile_returnsSameDigest() throws IOException, NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        RandomAccessFile randomAccessFile = new RandomAccessFile("empty.txt", "r");
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, randomAccessFile);
        assertNotNull(updatedDigest);
        assertEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withNonExistentRandomAccessFile_throwsException() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        assertThrows(FileNotFoundException.class, () -> {
            RandomAccessFile randomAccessFile = new RandomAccessFile("nonexistent.txt", "r");
            DigestUtils.updateDigest(messageDigest, randomAccessFile);
        });
    }

    @Test
    public void updateDigest_withValidString_updatesDigest() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        String valueToDigest = "test";
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, valueToDigest);
        assertNotNull(updatedDigest);
        assertNotEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void updateDigest_withEmptyString_returnsSameDigest() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        String valueToDigest = "";
        MessageDigest updatedDigest = DigestUtils.updateDigest(messageDigest, valueToDigest);
        assertNotNull(updatedDigest);
        assertEquals(messageDigest.digest(), updatedDigest.digest());
    }

    @Test
    public void digestUtils_withMessageDigest_returnsDigestUtils() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        DigestUtils digestUtils = new DigestUtils(messageDigest);
        assertNotNull(digestUtils);
    }

    @Test
    public void digestUtils_withInvalidMessageDigest_throwsException() {
        assertThrows(NoSuchAlgorithmException.class, () -> new DigestUtils("Invalid"));
    }

    @Test
    public void digestUtils_withValidMessageDigest_returnsDigestUtils() {
        DigestUtils digestUtils = new DigestUtils("SHA-256");
        assertNotNull(digestUtils);
    }

    @Test
    public void digest_withByteArray_returnsDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] data = "test".getBytes(StandardCharsets.UTF_8);
        byte[] digest = digestUtils.digest(data);
        assertNotNull(digest);
        assertNotEquals(data, digest);
    }

    @Test
    public void digest_withEmptyByteArray_returnsSameDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] data = new byte[0];
        byte[] digest = digestUtils.digest(data);
        assertNotNull(digest);
        assertEquals(data, digest);
    }

    @Test
    public void digest_withByteBuffer_returnsDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        ByteBuffer data = ByteBuffer.wrap("test".getBytes(StandardCharsets.UTF_8));
        byte[] digest = digestUtils.digest(data);
        assertNotNull(digest);
        assertNotEquals(data.array(), digest);
    }

    @Test
    public void digest_withEmptyByteBuffer_returnsSameDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        ByteBuffer data = ByteBuffer.wrap(new byte[0]);
        byte[] digest = digestUtils.digest(data);
        assertNotNull(digest);
        assertEquals(data.array(), digest);
    }

    @Test
    public void digest_withNullByteBuffer_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digest((ByteBuffer) null));
    }

    @Test
    public void digest_withValidFile_returnsDigest() throws IOException, NoSuchAlgorithmException {
        File file = new File("test.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] digest = digestUtils.digest(file);
        assertNotNull(digest);
    }

    @Test
    public void digest_withNonExistentFile_throwsException() throws NoSuchAlgorithmException {
        File file = new File("nonexistent.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(IOException.class, () -> digestUtils.digest(file));
    }

    @Test
    public void digest_withNullFile_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digest((File) null));
    }

    @Test
    public void digest_withValidInputStream_returnsDigest() throws IOException, NoSuchAlgorithmException {
        InputStream inputStream = new ByteArrayInputStream("test".getBytes(StandardCharsets.UTF_8));
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] digest = digestUtils.digest(inputStream);
        assertNotNull(digest);
    }

    @Test
    public void digest_withEmptyInputStream_returnsSameDigest() throws IOException, NoSuchAlgorithmException {
        InputStream inputStream = new ByteArrayInputStream(new byte[0]);
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] digest = digestUtils.digest(inputStream);
        assertNotNull(digest);
        assertEquals(MessageDigest.getInstance("SHA-256").digest(), digest);
    }

    @Test
    public void digest_withNullInputStream_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digest((InputStream) null));
    }

    @Test
    public void digest_withValidPath_returnsDigest() throws IOException, NoSuchAlgorithmException {
        Path path = Paths.get("test.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] digest = digestUtils.digest(path);
        assertNotNull(digest);
    }

    @Test
    public void digest_withNonExistentPath_throwsException() throws NoSuchAlgorithmException {
        Path path = Paths.get("nonexistent.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(IOException.class, () -> digestUtils.digest(path));
    }

    @Test
    public void digest_withNullPath_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digest((Path) null));
    }

    @Test
    public void digest_withValidString_returnsDigest() throws NoSuchAlgorithmException {
        String data = "test";
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] digest = digestUtils.digest(data);
        assertNotNull(digest);
    }

    @Test
    public void digest_withEmptyString_returnsSameDigest() throws NoSuchAlgorithmException {
        String data = "";
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] digest = digestUtils.digest(data);
        assertNotNull(digest);
        assertEquals(MessageDigest.getInstance("SHA-256").digest(), digest);
    }

    @Test
    public void digest_withNullString_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digest((String) null));
    }

    @Test
    public void digestAsHex_withValidByteArray_returnsHexDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] data = "test".getBytes(StandardCharsets.UTF_8);
        String hexDigest = digestUtils.digestAsHex(data);
        assertNotNull(hexDigest);
        assertNotEquals(new String(data, StandardCharsets.UTF_8), hexDigest);
    }

    @Test
    public void digestAsHex_withEmptyByteArray_returnsSameHexDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        byte[] data = new byte[0];
        String hexDigest = digestUtils.digestAsHex(data);
        assertNotNull(hexDigest);
        assertEquals(Hex.encodeHexString(MessageDigest.getInstance("SHA-256").digest()), hexDigest);
    }

    @Test
    public void digestAsHex_withNullByteArray_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digestAsHex((byte[]) null));
    }

    @Test
    public void digestAsHex_withValidByteBuffer_returnsHexDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        ByteBuffer data = ByteBuffer.wrap("test".getBytes(StandardCharsets.UTF_8));
        String hexDigest = digestUtils.digestAsHex(data);
        assertNotNull(hexDigest);
        assertNotEquals(new String(data.array(), StandardCharsets.UTF_8), hexDigest);
    }

    @Test
    public void digestAsHex_withEmptyByteBuffer_returnsSameHexDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        ByteBuffer data = ByteBuffer.wrap(new byte[0]);
        String hexDigest = digestUtils.digestAsHex(data);
        assertNotNull(hexDigest);
        assertEquals(Hex.encodeHexString(MessageDigest.getInstance("SHA-256").digest()), hexDigest);
    }

    @Test
    public void digestAsHex_withNullByteBuffer_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digestAsHex((ByteBuffer) null));
    }

    @Test
    public void digestAsHex_withValidFile_returnsHexDigest() throws IOException, NoSuchAlgorithmException {
        File file = new File("test.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        String hexDigest = digestUtils.digestAsHex(file);
        assertNotNull(hexDigest);
    }

    @Test
    public void digestAsHex_withNonExistentFile_throwsException() throws NoSuchAlgorithmException {
        File file = new File("nonexistent.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(IOException.class, () -> digestUtils.digestAsHex(file));
    }

    @Test
    public void digestAsHex_withNullFile_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digestAsHex((File) null));
    }

    @Test
    public void digestAsHex_withValidInputStream_returnsHexDigest() throws IOException, NoSuchAlgorithmException {
        InputStream inputStream = new FileInputStream("test.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        String hexDigest = digestUtils.digestAsHex(inputStream);
        assertNotNull(hexDigest);
    }

    @Test
    public void digestAsHex_withEmptyInputStream_returnsSameHexDigest() throws IOException, NoSuchAlgorithmException {
        InputStream inputStream = new ByteArrayInputStream(new byte[0]);
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        String hexDigest = digestUtils.digestAsHex(inputStream);
        assertNotNull(hexDigest);
        assertEquals(Hex.encodeHexString(MessageDigest.getInstance("SHA-256").digest()), hexDigest);
    }

    @Test
    public void digestAsHex_withNullInputStream_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digestAsHex((InputStream) null));
    }

    @Test
    public void digestAsHex_withValidPath_returnsHexDigest() throws IOException, NoSuchAlgorithmException {
        Path path = Paths.get("test.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        String hexDigest = digestUtils.digestAsHex(path);
        assertNotNull(hexDigest);
    }

    @Test
    public void digestAsHex_withNonExistentPath_throwsException() throws NoSuchAlgorithmException {
        Path path = Paths.get("nonexistent.txt");
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(IOException.class, () -> digestUtils.digestAsHex(path));
    }

    @Test
    public void digestAsHex_withNullPath_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digestAsHex((Path) null));
    }

    @Test
    public void digestAsHex_withValidString_returnsHexDigest() throws NoSuchAlgorithmException {
        String data = "test";
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        String hexDigest = digestUtils.digestAsHex(data);
        assertNotNull(hexDigest);
    }

    @Test
    public void digestAsHex_withEmptyString_returnsSameHexDigest() throws NoSuchAlgorithmException {
        String data = "";
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        String hexDigest = digestUtils.digestAsHex(data);
        assertNotNull(hexDigest);
        assertEquals(Hex.encodeHexString(MessageDigest.getInstance("SHA-256").digest()), hexDigest);
    }

    @Test
    public void digestAsHex_withNullString_throwsException() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        assertThrows(NullPointerException.class, () -> digestUtils.digestAsHex((String) null));
    }

    @Test
    public void getMessageDigest_returnsNonNullDigest() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        MessageDigest digest = digestUtils.getMessageDigest();
        assertNotNull(digest);
    }

    @Test
    public void getMessageDigest_returnsExpectedAlgorithm() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        MessageDigest digest = digestUtils.getMessageDigest();
        assertEquals("SHA-256", digest.getAlgorithm());
    }

    @Test
    public void getMessageDigest_returnsSeparateInstances() throws NoSuchAlgorithmException {
        DigestUtils digestUtils = new DigestUtils(MessageDigest.getInstance("SHA-256"));
        MessageDigest digest1 = digestUtils.getMessageDigest();
        MessageDigest digest2 = digestUtils.getMessageDigest();
        assertNotSame(digest1, digest2);
    }

}
