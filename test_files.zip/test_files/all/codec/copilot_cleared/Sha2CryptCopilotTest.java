package org.apache.commons.codec.digest;

import org.apache.commons.codec.digest.Sha2Crypt;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class Sha2CryptCopilotTest {

    private Random random;

    @BeforeEach
    public void setUp() {
        random = new SecureRandom();
    }

    @Test
    public void sha256Crypt_withNullSalt() {
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String result = Sha2Crypt.sha256Crypt(keyBytes);
        assertEquals(98, result.length());
    }

    @Test
    public void sha256Crypt_withSalt() {
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String result = Sha2Crypt.sha256Crypt(keyBytes, "$5$saltstring");
        assertEquals("$5$saltstring$qJH7.N4xYta3aEG/dfq3I7VQV.7qz.Yy2o.Hy/onjH0", result);
    }

    @Test
    public void sha256Crypt_withInvalidSalt() {
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        assertThrows(IllegalArgumentException.class, () -> Sha2Crypt.sha256Crypt(keyBytes, "invalid_salt"));
    }

    @Test
    public void sha512Crypt_withNullSalt() {
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String result = Sha2Crypt.sha512Crypt(keyBytes);
        assertEquals(106, result.length());
    }

    @Test
    public void sha512Crypt_withSalt() {
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String result = Sha2Crypt.sha512Crypt(keyBytes, "$6$saltstring");
        assertTrue(result.startsWith("$6$saltstring$"));
    }

    @Test
    public void sha512Crypt_withInvalidSalt() {
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        assertThrows(IllegalArgumentException.class, () -> Sha2Crypt.sha512Crypt(keyBytes, "invalid_salt"));
    }

    @Test
    public void sha512Crypt_withEmptySalt() {
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String result = Sha2Crypt.sha512Crypt(keyBytes, "", random);
        assertTrue(result.startsWith("$6$"));
        assertEquals(106, result.length());
    }
}

