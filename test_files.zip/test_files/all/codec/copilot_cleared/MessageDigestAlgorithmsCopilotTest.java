package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MessageDigestAlgorithmsCopilotTest {

    @Test
    public void values_returnsAllHashAlgorithms() {
        String[] result = MessageDigestAlgorithms.values();
        assertNotNull(result);
        assertEquals(13, result.length);
    }

    @Test
    public void values_containsExpectedHashAlgorithms() {
        String[] result = MessageDigestAlgorithms.values();
        List<String> algorithms = Arrays.asList(result);
        assertTrue(algorithms.contains(MessageDigestAlgorithms.MD2));
        assertTrue(algorithms.contains(MessageDigestAlgorithms.MD5));
        assertTrue(algorithms.contains(MessageDigestAlgorithms.SHA_1));
        // Continue for all hash algorithms
    }

    @Test
    public void values_returnsNewArrayOnEachCall() {
        String[] result1 = MessageDigestAlgorithms.values();
        String[] result2 = MessageDigestAlgorithms.values();
        assertNotSame(result1, result2);
    }

}
