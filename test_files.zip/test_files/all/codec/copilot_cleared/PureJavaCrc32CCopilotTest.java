package org.apache.commons.codec.digest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class PureJavaCrc32CCopilotTest {

    private PureJavaCrc32C crc32C;

    @BeforeEach
    public void setUp() {
        crc32C = new PureJavaCrc32C();
    }

    @Test
    public void getValue_afterReset() {
        long expected = 0xffffffffL;
        long actual = crc32C.getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void getValue_afterUpdate() {
        crc32C.update(1);
        long expected = 0x76F7BC83L;
        long actual = crc32C.getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void getValue_afterMultipleUpdates() {
        for (int i = 1; i <= 8; i++) {
            crc32C.update(i);
        }
        long expected = 0x4E416A60L;
        long actual = crc32C.getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void reset_afterUpdate() {
        crc32C.update(1);
        crc32C.reset();
        long expected = 0xffffffffL;
        long actual = crc32C.getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void reset_afterMultipleUpdates() {
        for (int i = 1; i <= 8; i++) {
            crc32C.update(i);
        }
        crc32C.reset();
        long expected = 0xffffffffL;
        long actual = crc32C.getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void reset_afterReset() {
        crc32C.reset();
        crc32C.reset();
        long expected = 0xffffffffL;
        long actual = crc32C.getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void updatesCrcWithByteArray() {
        byte[] input = new byte[] {1, 2, 3, 4, 5, 6, 7, 8};
        crc32C.update(input, 0, input.length);
        long result = crc32C.getValue();
        assertEquals(0x4E416A60L, result);
    }

    @Test
    public void updatesCrcWithByteArrayAndOffset() {
        byte[] input = new byte[] {0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8};
        crc32C.update(input, 4, 8);
        long result = crc32C.getValue();
        assertEquals(0x4E416A60L, result);
    }

    @Test
    public void updatesCrcWithByteArrayAndShortLength() {
        byte[] input = new byte[] {1, 2, 3, 4, 5, 6, 7, 8};
        crc32C.update(input, 0, 4);
        long result = crc32C.getValue();
        assertEquals(0x9AE0DAFBL, result);
    }

    @Test
    public void updatesCrcWithSingleByte() {
        crc32C.update(1);
        long result = crc32C.getValue();
        assertEquals(0x76F7BC83L, result);
    }

    @Test
    public void updatesCrcWithMultipleSingleBytes() {
        for (int i = 1; i <= 8; i++) {
            crc32C.update(i);
        }
        long result = crc32C.getValue();
        assertEquals(0x4E416A60L, result);
    }

    @Test
    public void updatesCrcWithZeroByte() {
        crc32C.update(0);
        long result = crc32C.getValue();
        assertEquals(0x76F7BC83L, result);
    }
}

