package org.apache.commons.codec.digest;

import org.apache.commons.codec.digest.UnixCrypt;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

public class UnixCryptCopilotTest {

    @Test
    public void crypt_withNullSalt() {
        byte[] original = "password".getBytes(StandardCharsets.UTF_8);
        String result = UnixCrypt.crypt(original);
        assertEquals(13, result.length());
    }

    @Test
    public void crypt_withSalt() {
        byte[] original = "password".getBytes(StandardCharsets.UTF_8);
        String result = UnixCrypt.crypt(original, "ab");
        assertEquals("ab", result.substring(0, 2));
    }

    @Test
    public void crypt_withInvalidSalt() {
        byte[] original = "password".getBytes(StandardCharsets.UTF_8);
        assertThrows(IllegalArgumentException.class, () -> UnixCrypt.crypt(original, "invalid_salt"));
    }

    @Test
    public void crypt_withOnlyOriginal() {
        String original = "password";
        String result = UnixCrypt.crypt(original);
        assertEquals(13, result.length());
    }

    @Test
    public void crypt_withOriginalAndSalt() {
        String original = "password";
        String salt = "ab";
        String result = UnixCrypt.crypt(original, salt);
        assertEquals("ab", result.substring(0, 2));
    }

    @Test
    public void crypt_withOriginalAndInvalidSalt() {
        String original = "password";
        assertThrows(IllegalArgumentException.class, () -> UnixCrypt.crypt(original, "invalid_salt"));
    }

    @Test
    public void unixCrypt_constructor() {
        UnixCrypt unixCrypt = new UnixCrypt();
        assertNotNull(unixCrypt);
    }

    @Test
    public void unixCrypt_constructor_deprecated() {
        UnixCrypt unixCrypt = new UnixCrypt();
        assertTrue(unixCrypt.getClass().isAnnotationPresent(Deprecated.class));
    }

    @Test
    public void unixCrypt_constructor_noFields() {
        UnixCrypt unixCrypt = new UnixCrypt();
        Field[] fields = unixCrypt.getClass().getDeclaredFields();
        assertEquals(0, fields.length);
    }
}
