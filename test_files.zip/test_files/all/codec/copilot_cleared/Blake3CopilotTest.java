package org.apache.commons.codec.digest;

import org.apache.commons.codec.digest.Blake3;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Blake3CopilotTest {

    @Test
    public void hash_returnsExpectedHash_whenValidDataProvided() {
        byte[] data = "test data".getBytes();
        byte[] result = Blake3.hash(data);

        assertNotNull(result);
        assertArrayEquals(new byte[32], result);
    }

    @Test
    public void hash_returnsDifferentHashes_forDifferentData() {
        byte[] data1 = "test data 1".getBytes();
        byte[] data2 = "test data 2".getBytes();

        byte[] result1 = Blake3.hash(data1);
        byte[] result2 = Blake3.hash(data2);

        assertNotNull(result1);
        assertNotNull(result2);
        assertArrayEquals(new byte[32], result1);
        assertArrayEquals(new byte[32], result2);
    }

    @Test
    public void hash_returnsSameHash_forSameData() {
        byte[] data1 = "test data".getBytes();
        byte[] data2 = "test data".getBytes();

        byte[] result1 = Blake3.hash(data1);
        byte[] result2 = Blake3.hash(data2);

        assertNotNull(result1);
        assertNotNull(result2);
        assertArrayEquals(result1, result2);
    }

    @Test
    public void initHash_returnsNonNullInstance() {
        Blake3 result = Blake3.initHash();

        assertNotNull(result);
    }

    @Test
    public void initHash_returnsDifferentInstances_forSubsequentCalls() {
        Blake3 result1 = Blake3.initHash();
        Blake3 result2 = Blake3.initHash();

        assertNotNull(result1);
        assertNotNull(result2);
        assertNotEquals(result1, result2);
    }

    @Test
    public void initHash_returnsSameHash_forSameData() {
        Blake3 instance1 = Blake3.initHash();
        Blake3 instance2 = Blake3.initHash();

        byte[] data = "test data".getBytes();

        byte[] result1 = instance1.update(data).doFinalize(32);
        byte[] result2 = instance2.update(data).doFinalize(32);

        assertArrayEquals(result1, result2);
    }

    @Test
    public void initKeyDerivationFunction_returnsNonNullInstance_whenValidContextProvided() {
        byte[] context = "test context".getBytes();
        Blake3 result = Blake3.initKeyDerivationFunction(context);

        assertNotNull(result);
    }

    @Test
    public void initKeyDerivationFunction_throwsException_whenNullContextProvided() {
        assertThrows(NullPointerException.class, () -> Blake3.initKeyDerivationFunction(null));
    }

    @Test
    public void initKeyDerivationFunction_returnsDifferentInstances_forDifferentContexts() {
        byte[] context1 = "test context 1".getBytes();
        byte[] context2 = "test context 2".getBytes();

        Blake3 result1 = Blake3.initKeyDerivationFunction(context1);
        Blake3 result2 = Blake3.initKeyDerivationFunction(context2);

        assertNotEquals(result1, result2);
    }

    @Test
    public void initKeyedHash_returnsNonNullInstance_whenValidKeyProvided() {
        byte[] key = new byte[32];
        Blake3 result = Blake3.initKeyedHash(key);

        assertNotNull(result);
    }

    @Test
    public void initKeyedHash_throwsException_whenNullKeyProvided() {
        assertThrows(NullPointerException.class, () -> Blake3.initKeyedHash(null));
    }

    @Test
    public void initKeyedHash_throwsException_whenInvalidKeyLengthProvided() {
        byte[] key = new byte[31];
        assertThrows(IllegalArgumentException.class, () -> Blake3.initKeyedHash(key));
    }

    @Test
    public void doFinalize_returnsBlake3Instance_whenCalledWithByteArray() {
        byte[] data = "test data".getBytes();
        Blake3 instance = Blake3.initHash().update(data);
        Blake3 result = instance.doFinalize(data);

        assertNotNull(result);
        assertNotEquals(instance, result);
    }

    @Test
    public void doFinalize_throwsNullPointerException_whenCalledWithNull() {
        byte[] data = null;
        Blake3 instance = Blake3.initHash();

        assertThrows(NullPointerException.class, () -> instance.doFinalize(data));
    }

    @Test
    public void doFinalize_returnsBlake3Instance_whenCalledWithEmptyByteArray() {
        byte[] data = new byte[0];
        Blake3 instance = Blake3.initHash().update(data);
        Blake3 result = instance.doFinalize(data);

        assertNotNull(result);
        assertNotEquals(instance, result);
    }

    @Test
    public void doFinalizeWithOffset_returnsBlake3Instance_whenCalledWithValidParameters() {
        byte[] data = "test data".getBytes();
        Blake3 instance = Blake3.initHash().update(data);
        Blake3 result = instance.doFinalize(data, 0, data.length);

        assertNotNull(result);
        assertNotEquals(instance, result);
    }

    @Test
    public void doFinalizeWithOffset_throwsNullPointerException_whenCalledWithNull() {
        byte[] data = null;
        Blake3 instance = Blake3.initHash();

        assertThrows(NullPointerException.class, () -> instance.doFinalize(data, 0, 0));
    }

    @Test
    public void doFinalizeWithOffset_throwsIndexOutOfBoundsException_whenCalledWithInvalidOffset() {
        byte[] data = "test data".getBytes();
        Blake3 instance = Blake3.initHash().update(data);

        assertThrows(IndexOutOfBoundsException.class, () -> instance.doFinalize(data, -1, data.length));
        assertThrows(IndexOutOfBoundsException.class, () -> instance.doFinalize(data, data.length + 1, data.length));
    }

    @Test
    public void doFinalizeWithOffset_throwsIndexOutOfBoundsException_whenCalledWithInvalidLength() {
        byte[] data = "test data".getBytes();
        Blake3 instance = Blake3.initHash().update(data);

        assertThrows(IndexOutOfBoundsException.class, () -> instance.doFinalize(data, 0, -1));
        assertThrows(IndexOutOfBoundsException.class, () -> instance.doFinalize(data, 0, data.length + 1));
    }

    @Test
    public void doFinalize_returnsExpectedBytes_whenPositiveNumberProvided() {
        Blake3 instance = Blake3.initHash();
        byte[] result = instance.doFinalize(32);

        assertNotNull(result);
        assertEquals(32, result.length);
    }

    @Test
    public void doFinalize_throwsException_whenNegativeNumberProvided() {
        Blake3 instance = Blake3.initHash();

        assertThrows(IllegalArgumentException.class, () -> instance.doFinalize(-1));
    }

    @Test
    public void doFinalize_returnsEmptyArray_whenZeroProvided() {
        Blake3 instance = Blake3.initHash();
        byte[] result = instance.doFinalize(0);

        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void reset_returnsFreshInstance() {
        Blake3 instance = Blake3.initHash();
        instance.update("test data".getBytes());

        instance = instance.reset();

        byte[] result = instance.doFinalize(32);

        assertNotNull(result);
        assertEquals(32, result.length);
    }

    @Test
    public void reset_returnsSameInstance_whenCalledMultipleTimes() {
        Blake3 instance = Blake3.initHash();
        instance.update("test data".getBytes());

        instance = instance.reset();
        instance = instance.reset();

        byte[] result = instance.doFinalize(32);

        assertNotNull(result);
        assertEquals(32, result.length);
    }

    @Test
    public void reset_doesNotAffectOtherInstances() {
        Blake3 instance1 = Blake3.initHash();
        instance1.update("test data".getBytes());

        Blake3 instance2 = Blake3.initHash();
        instance2.update("other data".getBytes());

        instance1 = instance1.reset();

        byte[] result1 = instance1.doFinalize(32);
        byte[] result2 = instance2.doFinalize(32);

        assertNotNull(result1);
        assertEquals(32, result1.length);
        assertNotNull(result2);
        assertEquals(32, result2.length);
        assertNotEquals(result1, result2);
    }

    @Test
    public void update_withByteArray_returnsBlake3Instance() {
        byte[] data = "test data".getBytes();
        Blake3 instance = Blake3.initHash();
        Blake3 result = instance.update(data);

        assertNotNull(result);
        assertNotEquals(instance, result);
    }

    @Test
    public void update_withByteArray_throwsNullPointerException_whenNullProvided() {
        byte[] data = null;
        Blake3 instance = Blake3.initHash();

        assertThrows(NullPointerException.class, () -> instance.update(data));
    }

    @Test
    public void update_withByteArray_returnsBlake3Instance_whenEmptyArrayProvided() {
        byte[] data = new byte[0];
        Blake3 instance = Blake3.initHash();
        Blake3 result = instance.update(data);

        assertNotNull(result);
        assertNotEquals(instance, result);
    }

    @Test
    public void update_withByteArrayOffsetLength_returnsBlake3Instance_whenValidParametersProvided() {
        byte[] data = "test data".getBytes();
        Blake3 instance = Blake3.initHash();
        Blake3 result = instance.update(data, 0, data.length);

        assertNotNull(result);
        assertNotEquals(instance, result);
    }

    @Test
    public void update_withByteArrayOffsetLength_throwsNullPointerException_whenNullProvided() {
        byte[] data = null;
        Blake3 instance = Blake3.initHash();

        assertThrows(NullPointerException.class, () -> instance.update(data, 0, 0));
    }

    @Test
    public void update_withByteArrayOffsetLength_throwsIndexOutOfBoundsException_whenInvalidOffsetProvided() {
        byte[] data = "test data".getBytes();
        Blake3 instance = Blake3.initHash();

        assertThrows(IndexOutOfBoundsException.class, () -> instance.update(data, -1, data.length));
        assertThrows(IndexOutOfBoundsException.class, () -> instance.update(data, data.length + 1, data.length));
    }

    @Test
    public void update_withByteArrayOffsetLength_throwsIndexOutOfBoundsException_whenInvalidLengthProvided() {
        byte[] data = "test data".getBytes();
        Blake3 instance = Blake3.initHash();

        assertThrows(IndexOutOfBoundsException.class, () -> instance.update(data, 0, -1));
        assertThrows(IndexOutOfBoundsException.class, () -> instance.update(data, 0, data.length + 1));
    }
}
