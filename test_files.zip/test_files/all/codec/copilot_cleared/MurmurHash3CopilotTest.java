package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MurmurHash3CopilotTest {

    @Test
    public void end_returnsExpectedHashAfterAddingData() {
        MurmurHash3.IncrementalHash32x86 hasher = new MurmurHash3.IncrementalHash32x86();
        hasher.add(new byte[]{1, 2, 3, 4}, 0, 4);
        int result = hasher.end();
        assertNotNull(result);
    }

    @Test
    public void end_returnsSameHashOnConsecutiveCallsWithoutAddingData() {
        MurmurHash3.IncrementalHash32x86 hasher = new MurmurHash3.IncrementalHash32x86();
        hasher.add(new byte[]{1, 2, 3, 4}, 0, 4);
        int result1 = hasher.end();
        int result2 = hasher.end();
        assertEquals(result1, result2);
    }

    @Test
    public void end_returnsDifferentHashesForDifferentData() {
        MurmurHash3.IncrementalHash32x86 hasher1 = new MurmurHash3.IncrementalHash32x86();
        hasher1.add(new byte[]{1, 2, 3, 4}, 0, 4);
        int result1 = hasher1.end();

        MurmurHash3.IncrementalHash32x86 hasher2 = new MurmurHash3.IncrementalHash32x86();
        hasher2.add(new byte[]{5, 6, 7, 8}, 0, 4);
        int result2 = hasher2.end();

        assertNotEquals(result1, result2);
    }

    @Test
    public void hash128_withValidData_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        long[] result = MurmurHash3.hash128(data);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128_withEmptyData_returnsExpectedHash() {
        byte[] data = new byte[]{};
        long[] result = MurmurHash3.hash128(data);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128x64_withValidData_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        long[] result = MurmurHash3.hash128x64(data);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128x64_withEmptyData_returnsExpectedHash() {
        byte[] data = new byte[]{};
        long[] result = MurmurHash3.hash128x64(data);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128x64_withNullData_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash3.hash128x64(null));
    }

    @Test
    public void hash128x64_withValidDataAndParameters_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int offset = 0;
        int length = data.length;
        int seed = 0;
        long[] result = MurmurHash3.hash128x64(data, offset, length, seed);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128x64_withInvalidOffset_throwsException() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int offset = -1;
        int length = data.length;
        int seed = 0;
        assertThrows(IndexOutOfBoundsException.class, () -> MurmurHash3.hash128x64(data, offset, length, seed));
    }

    @Test
    public void hash128x64_withInvalidLength_throwsException() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int offset = 0;
        int length = data.length + 1;
        int seed = 0;
        assertThrows(IndexOutOfBoundsException.class, () -> MurmurHash3.hash128x64(data, offset, length, seed));
    }

    @Test
    public void hash32_withPositiveLong_returnsExpectedHash() {
        long data = 123456789L;
        int result = MurmurHash3.hash32(data);
        assertNotNull(result);
    }

    @Test
    public void hash32_withNegativeLong_returnsExpectedHash() {
        long data = -123456789L;
        int result = MurmurHash3.hash32(data);
        assertNotNull(result);
    }

    @Test
    public void hash32_withZeroLong_returnsExpectedHash() {
        long data = 0L;
        int result = MurmurHash3.hash32(data);
        assertNotNull(result);
    }

    @Test
    public void hash32_withSeedAndPositiveLong_returnsExpectedHash() {
        long data = 123456789L;
        int seed = 42;
        int result = MurmurHash3.hash32(data, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withSeedAndNegativeLong_returnsExpectedHash() {
        long data = -123456789L;
        int seed = 42;
        int result = MurmurHash3.hash32(data, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withSeedAndZeroLong_returnsExpectedHash() {
        long data = 0L;
        int seed = 42;
        int result = MurmurHash3.hash32(data, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withTwoPositiveLongs_returnsExpectedHash() {
        long data1 = 123456789L;
        long data2 = 987654321L;
        int result = MurmurHash3.hash32(data1, data2);
        assertNotNull(result);
    }

    @Test
    public void hash32_withTwoNegativeLongs_returnsExpectedHash() {
        long data1 = -123456789L;
        long data2 = -987654321L;
        int result = MurmurHash3.hash32(data1, data2);
        assertNotNull(result);
    }

    @Test
    public void hash32_withZeroLongs_returnsExpectedHash() {
        long data1 = 0L;
        long data2 = 0L;
        int result = MurmurHash3.hash32(data1, data2);
        assertNotNull(result);
    }

    @Test
    public void hash32_withSeedAndTwoPositiveLongs_returnsExpectedHash() {
        long data1 = 123456789L;
        long data2 = 987654321L;
        int seed = 42;
        int result = MurmurHash3.hash32(data1, data2, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withSeedAndTwoNegativeLongs_returnsExpectedHash() {
        long data1 = -123456789L;
        long data2 = -987654321L;
        int seed = 42;
        int result = MurmurHash3.hash32(data1, data2, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withSeedAndZeroLongs_returnsExpectedHash() {
        long data1 = 0L;
        long data2 = 0L;
        int seed = 42;
        int result = MurmurHash3.hash32(data1, data2, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32x86_withValidData_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int result = MurmurHash3.hash32x86(data);
        assertNotNull(result);
    }

    @Test
    public void hash32x86_withEmptyData_returnsExpectedHash() {
        byte[] data = new byte[]{};
        int result = MurmurHash3.hash32x86(data);
        assertNotNull(result);
    }

    @Test
    public void hash32x86_withNullData_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash3.hash32x86(null));
    }

    @Test
    public void hash32x86_withValidDataAndParameters_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int offset = 0;
        int length = data.length;
        int seed = 0;
        int result = MurmurHash3.hash32x86(data, offset, length, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32x86_withInvalidOffset_throwsException() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int offset = -1;
        int length = data.length;
        int seed = 0;
        assertThrows(IndexOutOfBoundsException.class, () -> MurmurHash3.hash32x86(data, offset, length, seed));
    }

    @Test
    public void hash32x86_withInvalidLength_throwsException() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int offset = 0;
        int length = data.length + 1;
        int seed = 0;
        assertThrows(IndexOutOfBoundsException.class, () -> MurmurHash3.hash32x86(data, offset, length, seed));
    }

    @Test
    public void hash128_withValidDataAndPositiveSeed_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int offset = 0;
        int length = data.length;
        int seed = 42;
        long[] result = MurmurHash3.hash128(data, offset, length, seed);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128_withEmptyDataAndPositiveSeed_returnsExpectedHash() {
        byte[] data = new byte[]{};
        int offset = 0;
        int length = data.length;
        int seed = 42;
        long[] result = MurmurHash3.hash128(data, offset, length, seed);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128_withValidDataAndNegativeSeed_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int offset = 0;
        int length = data.length;
        int seed = -42;
        long[] result = MurmurHash3.hash128(data, offset, length, seed);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128_withValidString_returnsExpectedHash() {
        String data = "Test Data";
        long[] result = MurmurHash3.hash128(data);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash128_withEmptyString_returnsExpectedHash() {
        String data = "";
        long[] result = MurmurHash3.hash128(data);
        assertNotNull(result);
        assertEquals(2, result.length);
    }

    @Test
    public void hash32_withValidData_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int result = MurmurHash3.hash32(data);
        assertNotNull(result);
    }

    @Test
    public void hash32_withEmptyData_returnsExpectedHash() {
        byte[] data = new byte[]{};
        int result = MurmurHash3.hash32(data);
        assertNotNull(result);
    }

    @Test
    public void hash32_withValidDataAndLength_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        int result = MurmurHash3.hash32(data, data.length);
        assertNotNull(result);
    }

    @Test
    public void hash32_withEmptyDataAndLength_returnsExpectedHash() {
        byte[] data = new byte[]{};
        int result = MurmurHash3.hash32(data, data.length);
        assertNotNull(result);
    }

    @Test
    public void hash32_withNullDataAndLength_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash3.hash32(null, 0));
    }

    @Test
    public void hash32_withNullData_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash3.hash32(null, 0, 42));
    }

    @Test
    public void hash32_withOffsetAndValidData_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4, 5, 6};
        int seed = 42;
        int result = MurmurHash3.hash32(data, 2, 2, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withOffsetAndEmptyData_returnsExpectedHash() {
        byte[] data = new byte[]{};
        int seed = 42;
        int result = MurmurHash3.hash32(data, 0, 0, seed);
        assertNotNull(result);
    }

    @Test
    public void hash32_withOffsetAndNullData_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash3.hash32(null, 0, 0, 42));
    }

    @Test
    public void hash32_withValidString_returnsExpectedHash() {
        String data = "Test Data";
        int result = MurmurHash3.hash32(data);
        assertNotNull(result);
    }

    @Test
    public void hash32_withEmptyString_returnsExpectedHash() {
        String data = "";
        int result = MurmurHash3.hash32(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withValidData_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4};
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withEmptyData_returnsExpectedHash() {
        byte[] data = new byte[]{};
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withNullData_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash3.hash64(null));
    }

    @Test
    public void hash64_withOffsetAndValidData_returnsExpectedHash() {
        byte[] data = new byte[]{1, 2, 3, 4, 5, 6};
        long result = MurmurHash3.hash64(data, 2, 2);
        assertNotNull(result);
    }

    @Test
    public void hash64_withOffsetAndEmptyData_returnsExpectedHash() {
        byte[] data = new byte[]{};
        long result = MurmurHash3.hash64(data, 0, 0);
        assertNotNull(result);
    }

    @Test
    public void hash64_withOffsetAndNullData_throwsException() {
        assertThrows(NullPointerException.class, () -> MurmurHash3.hash64(null, 0, 0));
    }

    @Test
    public void hash64_withValidInt_returnsExpectedHash() {
        int data = 123456789;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withZeroInt_returnsExpectedHash() {
        int data = 0;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withNegativeInt_returnsExpectedHash() {
        int data = -123456789;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withPositiveLong_returnsExpectedHash() {
        long data = 123456789L;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withNegativeLong_returnsExpectedHash() {
        long data = -123456789L;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withZeroLong_returnsExpectedHash() {
        long data = 0L;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withPositiveShort_returnsExpectedHash() {
        short data = 12345;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withNegativeShort_returnsExpectedHash() {
        short data = -12345;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }

    @Test
    public void hash64_withZeroShort_returnsExpectedHash() {
        short data = 0;
        long result = MurmurHash3.hash64(data);
        assertNotNull(result);
    }
}
