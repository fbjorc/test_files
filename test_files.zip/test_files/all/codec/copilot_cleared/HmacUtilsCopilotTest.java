package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;

import javax.crypto.Mac;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.security.NoSuchAlgorithmException;

import static org.junit.jupiter.api.Assertions.*;

public class HmacUtilsCopilotTest {

    @Test
    public void getInitializedMac_withValidAlgorithmAndKey_returnsMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        Mac mac = HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_256, key);
        assertNotNull(mac);
    }

    @Test
    public void getInitializedMac_withNullKey_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getInitializedMac(HmacAlgorithms.HMAC_SHA_256, null));
    }

    @Test
    public void getInitializedMac_withInvalidAlgorithm_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getInitializedMac("InvalidAlgorithm", key));
    }

    @Test
    public void getInitializedMac_withValidAlgorithmNameAndKey_returnsMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        Mac mac = HmacUtils.getInitializedMac("HmacSHA256", key);
        assertNotNull(mac);
    }

    @Test
    public void getInitializedMac_withNullKeyAndAlgorithmName_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getInitializedMac("HmacSHA256", null));
    }

    @Test
    public void getInitializedMac_withInvalidAlgorithmName_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getInitializedMac("InvalidAlgorithm", key));
    }

    @Test
    public void isAvailable_withValidHmacAlgorithm_returnsTrue() {
        assertTrue(HmacUtils.isAvailable(HmacAlgorithms.HMAC_SHA_256));
    }

    @Test
    public void isAvailable_withInvalidHmacAlgorithm_returnsFalse() {
        assertFalse(HmacUtils.isAvailable(HmacAlgorithms.valueOf("INVALID_ALGORITHM")));
    }

    @Test
    public void isAvailable_withNullHmacAlgorithm_returnsFalse() {
        assertFalse(HmacUtils.isAvailable((HmacAlgorithms) null));
    }

    @Test
    public void isAvailable_withValidAlgorithmName_returnsTrue() {
        assertTrue(HmacUtils.isAvailable("HmacSHA256"));
    }

    @Test
    public void isAvailable_withInvalidAlgorithmName_returnsFalse() {
        assertFalse(HmacUtils.isAvailable("InvalidAlgorithm"));
    }

    @Test
    public void isAvailable_withNullAlgorithmName_returnsFalse() {
        assertFalse(HmacUtils.isAvailable((String) null));
    }

    @Test
    public void updateHmac_withValidMacAndByteArray_returnsUpdatedMac() throws NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        byte[] valueToDigest = new byte[]{1, 2, 3, 4};
        Mac updatedMac = HmacUtils.updateHmac(mac, valueToDigest);
        assertNotNull(updatedMac);
    }

    @Test
    public void updateHmac_withNullMacAndByteArray_throwsException() {
        byte[] valueToDigest = new byte[]{1, 2, 3, 4};
        assertThrows(NullPointerException.class, () -> HmacUtils.updateHmac(null, valueToDigest));
    }

    @Test
    public void updateHmac_withValidMacAndNullByteArray_throwsException() throws NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        assertThrows(NullPointerException.class, () -> HmacUtils.updateHmac(mac, (byte[]) null));
    }

    @Test
    public void updateHmac_withValidMacAndInputStream_returnsUpdatedMac() throws IOException, NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{1, 2, 3, 4});
        Mac updatedMac = HmacUtils.updateHmac(mac, valueToDigest);
        assertNotNull(updatedMac);
    }

    @Test
    public void updateHmac_withNullMacAndInputStream_throwsException() {
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{1, 2, 3, 4});
        assertThrows(NullPointerException.class, () -> HmacUtils.updateHmac(null, valueToDigest));
    }

    @Test
    public void updateHmac_withValidMacAndNullInputStream_throwsException() throws NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        assertThrows(NullPointerException.class, () -> HmacUtils.updateHmac(mac, (InputStream) null));
    }

    @Test
    public void updateHmac_withValidMacAndString_returnsUpdatedMac() throws NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        String valueToDigest = "Test String";
        Mac updatedMac = HmacUtils.updateHmac(mac, valueToDigest);
        assertNotNull(updatedMac);
    }

    @Test
    public void updateHmac_withNullMacAndString_throwsException() {
        String valueToDigest = "Test String";
        assertThrows(NullPointerException.class, () -> HmacUtils.updateHmac(null, valueToDigest));
    }

    @Test
    public void updateHmac_withValidMacAndNullString_throwsException() throws NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        assertThrows(NullPointerException.class, () -> HmacUtils.updateHmac(mac, (String) null));
    }

    @Test
    public void hmacUtils_withValidAlgorithmAndByteArrayKey_returnsHmacUtils() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key);
        assertNotNull(hmacUtils);
    }

    @Test
    public void hmacUtils_withValidAlgorithmAndStringKey_returnsHmacUtils() {
        String key = "Test Key";
        HmacUtils hmacUtils = new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key);
        assertNotNull(hmacUtils);
    }

    @Test
    public void hmacUtils_withValidAlgorithmAndNullStringKey_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> new HmacUtils(HmacAlgorithms.HMAC_SHA_256, (String) null));
    }

    @Test
    public void hmacUtils_withValidAlgorithmAndNullByteArrayKey_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> new HmacUtils("HmacSHA256", (byte[]) null));
    }

	@Test
	public void hmac_withValidByteArray_returnsExpectedDigest() {
		byte[] key = new byte[]{1, 2, 3, 4};
		HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
		byte[] valueToDigest = new byte[]{5, 6, 7, 8};
		byte[] result = hmacUtils.hmac(valueToDigest);
		assertNotNull(result);
	}

    @Test
    public void hmac_withEmptyByteArray_returnsExpectedDigest() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        byte[] valueToDigest = new byte[]{};
        byte[] result = hmacUtils.hmac(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmac_withNullByteArray_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        assertThrows(NullPointerException.class, () -> hmacUtils.hmac((byte[]) null));
    }

    @Test
    public void hmac_withValidByteBuffer_returnsExpectedDigest() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        ByteBuffer valueToDigest = ByteBuffer.wrap(new byte[]{5, 6, 7, 8});
        byte[] result = hmacUtils.hmac(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmac_withEmptyByteBuffer_returnsExpectedDigest() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        ByteBuffer valueToDigest = ByteBuffer.wrap(new byte[]{});
        byte[] result = hmacUtils.hmac(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmac_withNullByteBuffer_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        assertThrows(NullPointerException.class, () -> hmacUtils.hmac((ByteBuffer) null));
    }

    @Test
    public void hmac_withValidFile_returnsExpectedDigest() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        File valueToDigest = new File("src/test/resources/testFile.txt");
        byte[] result = hmacUtils.hmac(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmac_withNonExistentFile_throwsIOException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        File valueToDigest = new File("src/test/resources/nonExistentFile.txt");
        assertThrows(IOException.class, () -> hmacUtils.hmac(valueToDigest));
    }

    @Test
    public void hmac_withEmptyFile_returnsExpectedDigest() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        File valueToDigest = new File("src/test/resources/emptyFile.txt");
        byte[] result = hmacUtils.hmac(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmac_withValidInputStream_returnsExpectedDigest() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        byte[] result = hmacUtils.hmac(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmac_withEmptyInputStream_returnsExpectedDigest() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        byte[] result = hmacUtils.hmac(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmac_withNullInputStream_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        assertThrows(NullPointerException.class, () -> hmacUtils.hmac((InputStream) null));
    }

    @Test
    public void hmac_withValidString_returnsExpectedDigest() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        byte[] result = hmacUtils.hmac("test");
        assertNotNull(result);
    }

    @Test
    public void hmac_withEmptyString_returnsExpectedDigest() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        byte[] result = hmacUtils.hmac("");
        assertNotNull(result);
    }

    @Test
    public void hmac_withNullString_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        assertThrows(NullPointerException.class, () -> hmacUtils.hmac((String) null));
    }

    @Test
    public void hmacHex_withValidByteArray_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        String result = hmacUtils.hmacHex(new byte[]{5, 6, 7, 8});
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withEmptyByteArray_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        String result = hmacUtils.hmacHex(new byte[]{});
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withNullByteArray_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        assertThrows(NullPointerException.class, () -> hmacUtils.hmacHex((byte[]) null));
    }

    @Test
    public void hmacHex_withValidByteBuffer_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        ByteBuffer valueToDigest = ByteBuffer.wrap(new byte[]{5, 6, 7, 8});
        String result = hmacUtils.hmacHex(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withEmptyByteBuffer_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        ByteBuffer valueToDigest = ByteBuffer.wrap(new byte[]{});
        String result = hmacUtils.hmacHex(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withNullByteBuffer_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        assertThrows(NullPointerException.class, () -> hmacUtils.hmacHex((ByteBuffer) null));
    }

    @Test
    public void hmacHex_withValidFile_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        File valueToDigest = new File("src/test/resources/testFile.txt");
        String result = hmacUtils.hmacHex(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withNonExistentFile_throwsIOException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        File valueToDigest = new File("src/test/resources/nonExistentFile.txt");
        assertThrows(IOException.class, () -> hmacUtils.hmacHex(valueToDigest));
    }

    @Test
    public void hmacHex_withEmptyFile_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        File valueToDigest = new File("src/test/resources/emptyFile.txt");
        String result = hmacUtils.hmacHex(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withValidInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        String result = hmacUtils.hmacHex(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withEmptyInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        String result = hmacUtils.hmacHex(valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withNullInputStream_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        assertThrows(NullPointerException.class, () -> hmacUtils.hmacHex((InputStream) null));
    }

    @Test
    public void hmacHex_withValidString_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        String result = hmacUtils.hmacHex("test");
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withEmptyString_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        String result = hmacUtils.hmacHex("");
        assertNotNull(result);
    }

    @Test
    public void hmacHex_withNullString_throwsException() {
        byte[] key = new byte[]{1, 2, 3, 4};
        HmacUtils hmacUtils = new HmacUtils("HmacSHA256", key);
        assertThrows(NullPointerException.class, () -> hmacUtils.hmacHex((String) null));
    }

    @Test
    public void getHmacMd5_withValidKey_returnsMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        Mac mac = HmacUtils.getHmacMd5(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacMd5_withEmptyKey_returnsMac() {
        byte[] key = new byte[]{};
        Mac mac = HmacUtils.getHmacMd5(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacMd5_withNullKey_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getHmacMd5(null));
    }

    @Test
    public void getHmacSha1_withValidKey_returnsMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        Mac mac = HmacUtils.getHmacSha1(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacSha1_withEmptyKey_returnsMac() {
        byte[] key = new byte[]{};
        Mac mac = HmacUtils.getHmacSha1(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacSha1_withNullKey_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getHmacSha1(null));
    }

    @Test
    public void getHmacSha256_withValidKey_returnsMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        Mac mac = HmacUtils.getHmacSha256(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacSha256_withEmptyKey_returnsMac() {
        byte[] key = new byte[]{};
        Mac mac = HmacUtils.getHmacSha256(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacSha256_withNullKey_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getHmacSha256(null));
    }

    @Test
    public void getHmacSha384_withValidKey_returnsMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        Mac mac = HmacUtils.getHmacSha384(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacSha384_withEmptyKey_returnsMac() {
        byte[] key = new byte[]{};
        Mac mac = HmacUtils.getHmacSha384(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacSha384_withNullKey_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getHmacSha384(null));
    }

    @Test
    public void getHmacSha512_withValidKey_returnsMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        Mac mac = HmacUtils.getHmacSha512(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacSha512_withEmptyKey_returnsMac() {
        byte[] key = new byte[]{};
        Mac mac = HmacUtils.getHmacSha512(key);
        assertNotNull(mac);
    }

    @Test
    public void getHmacSha512_withNullKey_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.getHmacSha512(null));
    }

    @Test
    public void hmacMd5_withValidKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] data = new byte[]{5, 6, 7, 8};
        byte[] result = HmacUtils.hmacMd5(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5_withEmptyKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{};
        byte[] data = new byte[]{};
        byte[] result = HmacUtils.hmacMd5(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5_withNullKey_throwsException() {
        byte[] data = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacMd5(null, data));
    }

    @Test
    public void hmacMd5_withValidKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream data = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        byte[] result = HmacUtils.hmacMd5(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5_withEmptyKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{};
        InputStream data = new ByteArrayInputStream(new byte[]{});
        byte[] result = HmacUtils.hmacMd5(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5_withNullKeyAndInputStream_throwsException() {
        InputStream data = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacMd5(null, data));
    }

    @Test
    public void hmacMd5_withValidKeyAndValue_returnsExpectedMac() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        byte[] result = HmacUtils.hmacMd5(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5_withEmptyKeyAndValue_returnsExpectedMac() {
        String key = "";
        String valueToDigest = "";
        byte[] result = HmacUtils.hmacMd5(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5Hex_withValidKeyAndValue_returnsExpectedMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        String result = HmacUtils.hmacMd5Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5Hex_withEmptyKeyAndValue_returnsExpectedMac() {
        byte[] key = new byte[]{};
        byte[] valueToDigest = new byte[]{};
        String result = HmacUtils.hmacMd5Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5Hex_withNullKey_throwsException() {
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacMd5Hex(null, valueToDigest));
    }

    @Test
    public void hmacMd5Hex_withValidKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        String result = HmacUtils.hmacMd5Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5Hex_withEmptyKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        String result = HmacUtils.hmacMd5Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5Hex_withNullKeyAndInputStream_throwsException() {
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacMd5Hex(null, valueToDigest));
    }

    @Test
    public void hmacMd5Hex_withValidKeyAndString_returnsExpectedHex() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        String result = HmacUtils.hmacMd5Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5Hex_withEmptyKeyAndString_returnsExpectedHex() {
        String key = "";
        String valueToDigest = "";
        String result = HmacUtils.hmacMd5Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacMd5Hex_withNullKeyAndString_throwsException() {
        String valueToDigest = "Test Value";
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacMd5Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha1_withValidKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] data = new byte[]{5, 6, 7, 8};
        byte[] result = HmacUtils.hmacSha1(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1_withEmptyKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{};
        byte[] data = new byte[]{};
        byte[] result = HmacUtils.hmacSha1(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1_withNullKey_throwsException() {
        byte[] data = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha1(null, data));
    }

    @Test
    public void hmacSha1_withValidKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream data = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        byte[] result = HmacUtils.hmacSha1(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1_withEmptyKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{};
        InputStream data = new ByteArrayInputStream(new byte[]{});
        byte[] result = HmacUtils.hmacSha1(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1_withNullKeyAndInputStream_throwsException() {
        InputStream data = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha1(null, data));
    }

    @Test
    public void hmacSha1_withValidKeyAndValue_returnsExpectedMac() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        byte[] result = HmacUtils.hmacSha1(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1_withEmptyKeyAndValue_returnsExpectedMac() {
        String key = "";
        String valueToDigest = "";
        byte[] result = HmacUtils.hmacSha1(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1Hex_withValidKeyAndValue_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        String result = HmacUtils.hmacSha1Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1Hex_withEmptyKeyAndValue_returnsExpectedHex() {
        byte[] key = new byte[]{};
        byte[] valueToDigest = new byte[]{};
        String result = HmacUtils.hmacSha1Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1Hex_withNullKey_throwsException() {
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha1Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha1Hex_withValidKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        String result = HmacUtils.hmacSha1Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1Hex_withEmptyKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        String result = HmacUtils.hmacSha1Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1Hex_withNullKeyAndInputStream_throwsException() {
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha1Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha1Hex_withValidKeyAndString_returnsExpectedHex() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        String result = HmacUtils.hmacSha1Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1Hex_withEmptyKeyAndString_returnsExpectedHex() {
        String key = "";
        String valueToDigest = "";
        String result = HmacUtils.hmacSha1Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha1Hex_withNullKeyAndString_throwsException() {
        String valueToDigest = "Test Value";
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha1Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha256_withValidKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] data = new byte[]{5, 6, 7, 8};
        byte[] result = HmacUtils.hmacSha256(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256_withEmptyKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{};
        byte[] data = new byte[]{};
        byte[] result = HmacUtils.hmacSha256(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256_withNullKey_throwsException() {
        byte[] data = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha256(null, data));
    }

    @Test
    public void hmacSha256_withValidKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream data = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        byte[] result = HmacUtils.hmacSha256(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256_withEmptyKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{};
        InputStream data = new ByteArrayInputStream(new byte[]{});
        byte[] result = HmacUtils.hmacSha256(key, data);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256_withNullKeyAndInputStream_throwsException() {
        InputStream data = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha256(null, data));
    }

    @Test
    public void hmacSha256_withValidKeyAndValue_returnsExpectedMac() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        byte[] result = HmacUtils.hmacSha256(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256_withEmptyKeyAndValue_returnsExpectedMac() {
        String key = "";
        String valueToDigest = "";
        byte[] result = HmacUtils.hmacSha256(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256Hex_withValidKeyAndValue_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        String result = HmacUtils.hmacSha256Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256Hex_withEmptyKeyAndValue_returnsExpectedHex() {
        byte[] key = new byte[]{};
        byte[] valueToDigest = new byte[]{};
        String result = HmacUtils.hmacSha256Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256Hex_withNullKey_throwsException() {
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha256Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha256Hex_withValidKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        String result = HmacUtils.hmacSha256Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256Hex_withEmptyKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        String result = HmacUtils.hmacSha256Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256Hex_withNullKeyAndInputStream_throwsException() {
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha256Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha256Hex_withValidKeyAndString_returnsExpectedHex() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        String result = HmacUtils.hmacSha256Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256Hex_withEmptyKeyAndString_returnsExpectedHex() {
        String key = "";
        String valueToDigest = "";
        String result = HmacUtils.hmacSha256Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha256Hex_withNullKeyAndString_throwsException() {
        String valueToDigest = "Test Value";
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha256Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha384_withValidKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        byte[] result = HmacUtils.hmacSha384(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384_withEmptyKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{};
        byte[] valueToDigest = new byte[]{};
        byte[] result = HmacUtils.hmacSha384(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384_withNullKey_throwsException() {
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha384(null, valueToDigest));
    }

    @Test
    public void hmacSha384_withValidKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        byte[] result = HmacUtils.hmacSha384(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384_withEmptyKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        byte[] result = HmacUtils.hmacSha384(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384_withNullKeyAndInputStream_throwsException() {
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha384(null, valueToDigest));
    }

    @Test
    public void hmacSha384_withValidKeyAndValue_returnsExpectedMac() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        byte[] result = HmacUtils.hmacSha384(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384_withEmptyKeyAndValue_returnsExpectedMac() {
        String key = "";
        String valueToDigest = "";
        byte[] result = HmacUtils.hmacSha384(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384Hex_withValidKeyAndValue_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        String result = HmacUtils.hmacSha384Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384Hex_withEmptyKeyAndValue_returnsExpectedHex() {
        byte[] key = new byte[]{};
        byte[] valueToDigest = new byte[]{};
        String result = HmacUtils.hmacSha384Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384Hex_withNullKey_throwsException() {
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha384Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha384Hex_withValidKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        String result = HmacUtils.hmacSha384Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384Hex_withEmptyKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        String result = HmacUtils.hmacSha384Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384Hex_withNullKeyAndInputStream_throwsException() {
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha384Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha384Hex_withValidKeyAndString_returnsExpectedHex() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        String result = HmacUtils.hmacSha384Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384Hex_withEmptyKeyAndString_returnsExpectedHex() {
        String key = "";
        String valueToDigest = "";
        String result = HmacUtils.hmacSha384Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha384Hex_withNullKeyAndString_throwsException() {
        String valueToDigest = "Test Value";
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha384Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha512_withValidKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        byte[] result = HmacUtils.hmacSha512(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512_withEmptyKeyAndData_returnsExpectedMac() {
        byte[] key = new byte[]{};
        byte[] valueToDigest = new byte[]{};
        byte[] result = HmacUtils.hmacSha512(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512_withNullKey_throwsException() {
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha512(null, valueToDigest));
    }

    @Test
    public void hmacSha512_withValidKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        byte[] result = HmacUtils.hmacSha512(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512_withEmptyKeyAndInputStream_returnsExpectedMac() throws IOException {
        byte[] key = new byte[]{};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        byte[] result = HmacUtils.hmacSha512(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512_withNullKeyAndInputStream_throwsException() {
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha512(null, valueToDigest));
    }

    @Test
    public void hmacSha512_withValidKeyAndValue_returnsExpectedMac() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        byte[] result = HmacUtils.hmacSha512(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512_withEmptyKeyAndValue_returnsExpectedMac() {
        String key = "";
        String valueToDigest = "";
        byte[] result = HmacUtils.hmacSha512(key, valueToDigest);
        assertNotNull(result);
    }

	@Test
    public void hmacSha512Hex_withValidKeyAndValue_returnsExpectedHex() {
        byte[] key = new byte[]{1, 2, 3, 4};
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        String result = HmacUtils.hmacSha512Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512Hex_withEmptyKeyAndValue_returnsExpectedHex() {
        byte[] key = new byte[]{};
        byte[] valueToDigest = new byte[]{};
        String result = HmacUtils.hmacSha512Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512Hex_withNullKey_throwsException() {
        byte[] valueToDigest = new byte[]{5, 6, 7, 8};
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha512Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha512Hex_withValidKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{1, 2, 3, 4};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        String result = HmacUtils.hmacSha512Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512Hex_withEmptyKeyAndInputStream_returnsExpectedHex() throws IOException {
        byte[] key = new byte[]{};
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{});
        String result = HmacUtils.hmacSha512Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512Hex_withNullKeyAndInputStream_throwsException() {
        InputStream valueToDigest = new ByteArrayInputStream(new byte[]{5, 6, 7, 8});
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha512Hex(null, valueToDigest));
    }

    @Test
    public void hmacSha512Hex_withValidKeyAndString_returnsExpectedHex() {
        String key = "Test Key";
        String valueToDigest = "Test Value";
        String result = HmacUtils.hmacSha512Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512Hex_withEmptyKeyAndString_returnsExpectedHex() {
        String key = "";
        String valueToDigest = "";
        String result = HmacUtils.hmacSha512Hex(key, valueToDigest);
        assertNotNull(result);
    }

    @Test
    public void hmacSha512Hex_withNullKeyAndString_throwsException() {
        String valueToDigest = "Test Value";
        assertThrows(IllegalArgumentException.class, () -> HmacUtils.hmacSha512Hex(null, valueToDigest));
    }
}
