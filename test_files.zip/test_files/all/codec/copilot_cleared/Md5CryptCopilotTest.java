package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;

import java.security.SecureRandom;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class Md5CryptCopilotTest {

    @Test
    public void apr1Crypt_withValidBytes_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{1, 2, 3, 4};
        String result = Md5Crypt.apr1Crypt(keyBytes);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withEmptyBytes_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{};
        String result = Md5Crypt.apr1Crypt(keyBytes);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withNullBytes_throwsException() {
        assertThrows(NullPointerException.class, () -> Md5Crypt.apr1Crypt((byte[]) null));
    }

    @Test
    public void apr1Crypt_withValidBytesAndRandom_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{1, 2, 3, 4};
        Random random = new SecureRandom();
        String result = Md5Crypt.apr1Crypt(keyBytes, random);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withEmptyBytesAndRandom_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{};
        Random random = new SecureRandom();
        String result = Md5Crypt.apr1Crypt(keyBytes, random);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withNullBytesAndRandom_throwsException() {
        Random random = new SecureRandom();
        assertThrows(NullPointerException.class, () -> Md5Crypt.apr1Crypt((byte[]) null, random));
    }

    @Test
    public void apr1Crypt_withValidBytesAndSalt_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{1, 2, 3, 4};
        String salt = "salt";
        String result = Md5Crypt.apr1Crypt(keyBytes, salt);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withNullBytesAndSalt_throwsException() {
        String salt = "salt";
        assertThrows(NullPointerException.class, () -> Md5Crypt.apr1Crypt((byte[]) null, salt));
    }

    @Test
    public void apr1Crypt_withValidString_returnsExpectedHash() {
        String keyString = "test";
        String result = Md5Crypt.apr1Crypt(keyString);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withEmptyString_returnsExpectedHash() {
        String keyString = "";
        String result = Md5Crypt.apr1Crypt(keyString);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withNullString_throwsException() {
        assertThrows(NullPointerException.class, () -> Md5Crypt.apr1Crypt((String) null));
    }

    @Test
    public void apr1Crypt_withValidStringAndSalt_returnsExpectedHash() {
        String keyString = "test";
        String salt = "salt";
        String result = Md5Crypt.apr1Crypt(keyString, salt);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withEmptyStringAndSalt_returnsExpectedHash() {
        String keyString = "";
        String salt = "salt";
        String result = Md5Crypt.apr1Crypt(keyString, salt);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.APR1_PREFIX));
    }

    @Test
    public void apr1Crypt_withNullStringAndSalt_throwsException() {
        String salt = "salt";
        assertThrows(NullPointerException.class, () -> Md5Crypt.apr1Crypt((String) null, salt));
    }

    @Test
    public void md5Crypt_withValidBytes_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{1, 2, 3, 4};
        String result = Md5Crypt.md5Crypt(keyBytes);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withEmptyBytes_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{};
        String result = Md5Crypt.md5Crypt(keyBytes);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withNullBytes_throwsException() {
        assertThrows(NullPointerException.class, () -> Md5Crypt.md5Crypt((byte[]) null));
    }

    @Test
    public void md5Crypt_withValidBytesAndRandom_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{1, 2, 3, 4};
        Random random = new SecureRandom();
        String result = Md5Crypt.md5Crypt(keyBytes, random);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withEmptyBytesAndRandom_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{};
        Random random = new SecureRandom();
        String result = Md5Crypt.md5Crypt(keyBytes, random);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withNullBytesAndRandom_throwsException() {
        Random random = new SecureRandom();
        assertThrows(NullPointerException.class, () -> Md5Crypt.md5Crypt((byte[]) null, random));
    }

    @Test
    public void md5Crypt_withValidBytesAndSalt_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{1, 2, 3, 4};
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        String result = Md5Crypt.md5Crypt(keyBytes, salt);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withEmptyBytesAndSalt_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{};
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        String result = Md5Crypt.md5Crypt(keyBytes, salt);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withNullBytesAndSalt_throwsException() {
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        assertThrows(NullPointerException.class, () -> Md5Crypt.md5Crypt((byte[]) null, salt));
    }

    @Test
    public void md5Crypt_withValidBytesSaltAndPrefix_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{1, 2, 3, 4};
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        String prefix = Md5Crypt.MD5_PREFIX;
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withEmptyBytesSaltAndPrefix_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{};
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        String prefix = Md5Crypt.MD5_PREFIX;
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withNullBytesSaltAndPrefix_throwsException() {
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        String prefix = Md5Crypt.MD5_PREFIX;
        assertThrows(NullPointerException.class, () -> Md5Crypt.md5Crypt((byte[]) null, salt, prefix));
    }

    @Test
    public void md5Crypt_withValidBytesSaltPrefixAndRandom_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{1, 2, 3, 4};
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        String prefix = Md5Crypt.MD5_PREFIX;
        Random random = new SecureRandom();
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix, random);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withEmptyBytesSaltPrefixAndRandom_returnsExpectedHash() {
        byte[] keyBytes = new byte[]{};
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        String prefix = Md5Crypt.MD5_PREFIX;
        Random random = new SecureRandom();
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix, random);
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    public void md5Crypt_withNullBytesSaltPrefixAndRandom_throwsException() {
        String salt = Md5Crypt.MD5_PREFIX + "salt";
        String prefix = Md5Crypt.MD5_PREFIX;
        Random random = new SecureRandom();
        assertThrows(NullPointerException.class, () -> Md5Crypt.md5Crypt((byte[]) null, salt, prefix, random));
    }

}
