package org.apache.commons.codec.digest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PureJavaCrc32CopilotTest {
    private PureJavaCrc32 crc32;

    @BeforeEach
    public void setUp() {
        crc32 = new PureJavaCrc32();
    }

    @Test
    public void getValue_initialValue() {
        long expected = 0xffffffffL;
        long actual = crc32.getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void getValue_afterUpdate() {
        crc32.update(1);
        long expected = 0x77073096L;
        long actual = crc32.getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void updatesCrcWithByteArray() {
        byte[] input = new byte[] {1, 2, 3, 4, 5, 6, 7, 8};
        crc32.update(input, 0, input.length);
        long result = crc32.getValue();
        assertEquals(0x4E416A60L, result);
    }

    @Test
    public void updatesCrcWithByteArrayAndOffset() {
        byte[] input = new byte[] {0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8};
        crc32.update(input, 4, 8);
        long result = crc32.getValue();
        assertEquals(0x4E416A60L, result);
    }

    @Test
    public void updatesCrcWithByteArrayAndShortLength() {
        byte[] input = new byte[] {1, 2, 3, 4, 5, 6, 7, 8};
        crc32.update(input, 0, 4);
        long result = crc32.getValue();
        assertEquals(0x9AE0DAFBL, result);
    }

    @Test
    public void updatesCrcWithSingleByte() {
        crc32.update(1);
        long result = crc32.getValue();
        assertEquals(0x76F7BC83L, result);
    }

    @Test
    public void updatesCrcWithMultipleSingleBytes() {
        for (int i = 1; i <= 8; i++) {
            crc32.update(i);
        }
        long result = crc32.getValue();
        assertEquals(0x4E416A60L, result);
    }

    @Test
    public void updatesCrcWithZeroByte() {
        crc32.update(0);
        long result = crc32.getValue();
        assertEquals(0x76F7BC83L, result);
    }
}
