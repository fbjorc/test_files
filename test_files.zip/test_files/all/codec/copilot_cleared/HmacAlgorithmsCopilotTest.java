package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HmacAlgorithmsCopilotTest {
    @Test
    public void getName_returnsCorrectName() {
        HmacAlgorithms hmacAlgorithms = HmacAlgorithms.HMAC_SHA_512;
        assertEquals("HmacSHA512", hmacAlgorithms.getName());
    }

    @Test
    public void getName_returnsDifferentName() {
        HmacAlgorithms hmacAlgorithms = HmacAlgorithms.HMAC_MD5;
        assertNotEquals("HmacSHA512", hmacAlgorithms.getName());
    }

    @Test
    public void getName_returnsNonNullName() {
        for (HmacAlgorithms hmacAlgorithms : HmacAlgorithms.values()) {
            assertNotNull(hmacAlgorithms.getName());
        }
    }

    @Test
    public void toString_returnsCorrectName() {
        HmacAlgorithms hmacAlgorithms = HmacAlgorithms.HMAC_SHA_512;
        assertEquals("HmacSHA512", hmacAlgorithms.toString());
    }

    @Test
    public void toString_returnsDifferentName() {
        HmacAlgorithms hmacAlgorithms = HmacAlgorithms.HMAC_MD5;
        assertNotEquals("HmacSHA512", hmacAlgorithms.toString());
    }

    @Test
    public void toString_returnsNonNullName() {
        for (HmacAlgorithms hmacAlgorithms : HmacAlgorithms.values()) {
            assertNotNull(hmacAlgorithms.toString());
        }
    }
}
