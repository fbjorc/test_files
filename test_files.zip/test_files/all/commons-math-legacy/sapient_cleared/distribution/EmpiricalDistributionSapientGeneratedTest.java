package org.apache.commons.math4.legacy.distribution;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.stat.descriptive.StatisticalSummary;

import java.util.List;

import org.apache.commons.math4.legacy.exception.NotStrictlyPositiveException;

import java.util.function.Function;

import org.apache.commons.math4.legacy.exception.OutOfRangeException;
import org.apache.commons.math4.legacy.stat.descriptive.SummaryStatistics;
import org.mockito.MockedStatic;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.mock;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import static org.hamcrest.Matchers.closeTo;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class EmpiricalDistributionSapientGeneratedTest {

    private final Function functionMock = mock(Function.class);

    //Sapient generated method id: ${5d0b5a67-281d-302a-b5f1-da68f011e88f}, hash: CEE6E609315243F871949AEE19CD052D
    @Test()
    void fromWhenDefaultBranchThrowsNotStrictlyPositiveException() {
        /* Branches:* (branch expression (line 120)) : false  #  inside <init> method*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{};
        //Act Statement(s)
        final NotStrictlyPositiveException result = assertThrows(NotStrictlyPositiveException.class, () -> {
            EmpiricalDistribution.from(-1, doubleArray, functionMock);
        });
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
}
