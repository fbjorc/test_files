package org.apache.commons.math4.legacy.distribution;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.apache.commons.math4.legacy.exception.MathArithmeticException;
import org.apache.commons.math4.legacy.exception.NotFiniteNumberException;
import org.apache.commons.math4.legacy.exception.NotANumberException;
import java.util.List;
import org.apache.commons.rng.core.source32.JDKRandom;
import java.util.ArrayList;
import org.apache.commons.math4.legacy.core.Pair;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.mock;
import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;
import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class EnumeratedDistributionSapientGeneratedTest {

    private final Pair pairMock = mock(Pair.class);

    //Sapient generated method id: ${createSamplerTest}, hash: 833512787E6A6C81872467CE9EA55309
    @Test()
    void createSamplerTest() throws NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        //List<Pair<Object, Double>> pairObjectDoubleList = new ArrayList<>();
        //pairObjectDoubleList.add(pairMock);
        //EnumeratedDistribution<Object> target = new EnumeratedDistribution(pairObjectDoubleList);
        //JDKRandom jDKRandom = new JDKRandom(0L);
        //Act Statement(s)
        //EnumeratedDistribution result = target.createSampler(jDKRandom);
        //Assert statement(s)
        //assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
}
