package org.apache.commons.math4.legacy.distribution;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.apache.commons.math4.legacy.exception.MathArithmeticException;
import org.apache.commons.math4.legacy.exception.NotFiniteNumberException;
import org.apache.commons.math4.legacy.exception.NotANumberException;
import org.apache.commons.math4.legacy.exception.OutOfRangeException;
import org.apache.commons.rng.core.source32.JDKRandom;
import org.apache.commons.statistics.distribution.ContinuousDistribution;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class EnumeratedRealDistributionSapientGeneratedTest {

    //Sapient generated method id: ${be94a1bd-32c4-3b73-85dd-ac5b915d99cf}, hash: 001025D15A1140AE40E27B3FD8751E84
    @Test()
    void inverseCumulativeProbabilityWhenPGreaterThan1_0ThrowsOutOfRangeException() throws OutOfRangeException, DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        /* Branches:* (p < 0.0) : false* (p > 1.0) : true*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("2.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("2.0")};
        EnumeratedRealDistribution target = new EnumeratedRealDistribution(doubleArray, doubleArray2);
        //Act Statement(s)
        final OutOfRangeException result = assertThrows(OutOfRangeException.class, () -> {
            target.inverseCumulativeProbability(Double.parseDouble("2.0"));
        });
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${404ff3cc-b575-3211-af26-2b1903caea4e}, hash: 871C5387C544DFD6D51D2A238B5F3325
    @Test()
    void inverseCumulativeProbabilityWhenProbabilityGreaterThanOrEqualsToP() throws OutOfRangeException, DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        /* Branches:* (p < 0.0) : false* (p > 1.0) : false* (for-each(innerDistribution.getPmf())) : true* (sample.getValue() == 0.0) : false* (probability >= p) : true** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: innerDistribution*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0.5")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.5")};
        EnumeratedRealDistribution target = spy(new EnumeratedRealDistribution(doubleArray, doubleArray2));
        doReturn(Double.parseDouble("0.0")).when(target).getSupportLowerBound();
        //Act Statement(s)
        double result = target.inverseCumulativeProbability(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, closeTo(Double.parseDouble("0.5"), 0.00001));
            verify(target).getSupportLowerBound();
        });
    }

    //Sapient generated method id: ${209e8341-72a3-3d16-9182-8127b2808df3}, hash: A4408511E63E4EECA376F782DC67BFD9
    @Test()
    void getMeanWhenInnerDistributionGetPmfIsNotEmpty() throws DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        /* Branches:* (for-each(innerDistribution.getPmf())) : true** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: innerDistribution*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("1.0")};
        EnumeratedRealDistribution target = new EnumeratedRealDistribution(doubleArray, doubleArray2);
        //Act Statement(s)
        double result = target.getMean();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("1.0"), 0.00001)));
    }

    //Sapient generated method id: ${21cb9d01-f7c8-3e81-a8c7-813542bd3b47}, hash: CE3C0DB777DA32D74FEE4CC14469C5D0
    @Test()
    void getVarianceWhenInnerDistributionGetPmfIsNotEmpty() throws DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        /* Branches:* (for-each(innerDistribution.getPmf())) : true** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: innerDistribution*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("1.0")};
        EnumeratedRealDistribution target = new EnumeratedRealDistribution(doubleArray, doubleArray2);
        //Act Statement(s)
        double result = target.getVariance();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("0.0"), 0.00001)));
    }

    //Sapient generated method id: ${df3f0920-d34e-3bdb-8d79-a0d9536df624}, hash: 6999464A461173E84500A78105F1C91D
    @Test()
    void createSamplerTest() throws DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0.5")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.5")};
        EnumeratedRealDistribution target = new EnumeratedRealDistribution(doubleArray, doubleArray2);
        JDKRandom jDKRandom = new JDKRandom(0L);
        //Act Statement(s)
        ContinuousDistribution.Sampler result = target.createSampler(jDKRandom);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
}
