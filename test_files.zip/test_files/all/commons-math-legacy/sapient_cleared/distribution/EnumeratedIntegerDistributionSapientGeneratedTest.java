package org.apache.commons.math4.legacy.distribution;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.apache.commons.math4.legacy.exception.MathArithmeticException;
import org.apache.commons.math4.legacy.exception.NotFiniteNumberException;
import org.apache.commons.math4.legacy.exception.NotANumberException;
import org.apache.commons.rng.core.source32.JDKRandom;
import org.apache.commons.statistics.distribution.DiscreteDistribution;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class EnumeratedIntegerDistributionSapientGeneratedTest {

    //Sapient generated method id: ${8f0b3262-7d22-3e4e-8f91-f22d93910e46}, hash: 9896DFC9B78E23306ACE0E5DB2097453
    @Test()
    void cumulativeProbabilityWhenSampleGetKeyLessThanOrEqualsToX() throws DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        /* Branches:* (for-each(innerDistribution.getPmf())) : true* (sample.getKey() <= x) : true** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: innerDistribution*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        int[] intArray = new int[]{0};
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        EnumeratedIntegerDistribution target = new EnumeratedIntegerDistribution(intArray, doubleArray);
        //Act Statement(s)
        double result = target.cumulativeProbability(0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("1.0"), 0.00001)));
    }

    //Sapient generated method id: ${4a205b87-b82e-3f38-975a-27f7577a90b7}, hash: 3CC1F2C6CB2E8DA0E12AB1239053B143
    @Test()
    void getSupportLowerBoundWhenSampleGetValueGreaterThan0() throws DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        /* Branches:* (for-each(innerDistribution.getPmf())) : true* (sample.getKey() < min) : true* (sample.getValue() > 0) : true** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: innerDistribution*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        int[] intArray = new int[]{0};
        double[] doubleArray = new double[]{Double.parseDouble("0.5")};
        EnumeratedIntegerDistribution target = new EnumeratedIntegerDistribution(intArray, doubleArray);
        //Act Statement(s)
        int result = target.getSupportLowerBound();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(0)));
    }

    //Sapient generated method id: ${aa800360-0ef1-3086-ba59-2b88e3e6900d}, hash: B60F02C06A8578885F390ACB277D0A52
    @Test()
    void getSupportUpperBoundWhenSampleGetValueGreaterThan0() throws DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        /* Branches:* (for-each(innerDistribution.getPmf())) : true* (sample.getKey() > max) : true* (sample.getValue() > 0) : true** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: innerDistribution*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        int[] intArray = new int[]{0};
        double[] doubleArray = new double[]{Double.parseDouble("0.5")};
        EnumeratedIntegerDistribution target = new EnumeratedIntegerDistribution(intArray, doubleArray);
        //Act Statement(s)
        int result = target.getSupportUpperBound();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(0)));
    }

    //Sapient generated method id: ${df3f0920-d34e-3bdb-8d79-a0d9536df624}, hash: 6A234D87B17F5A9A43FECAE056098295
    @Test()
    void createSamplerTest() throws DimensionMismatchException, NotPositiveException, MathArithmeticException, NotFiniteNumberException, NotANumberException {
        //Arrange Statement(s)
        int[] intArray = new int[]{0};
        double[] doubleArray = new double[]{Double.parseDouble("0.5")};
        EnumeratedIntegerDistribution target = new EnumeratedIntegerDistribution(intArray, doubleArray);
        JDKRandom jDKRandom = new JDKRandom(0L);
        //Act Statement(s)
        DiscreteDistribution.Sampler result = target.createSampler(jDKRandom);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
}
