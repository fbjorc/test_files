package org.apache.commons.math4.legacy.analysis.differentiation;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.core.dfp.DfpField;
import org.apache.commons.math4.legacy.core.Field;
import org.mockito.MockedStatic;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import static org.hamcrest.Matchers.closeTo;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class SparseGradientSapientGeneratedTest {

    //Sapient generated method id: ${f2090172-770e-32fb-9c43-e7fb0f373bbc}, hash: 113C4420F2C59CDB6869E17137B6BD12
    @Test()
    void createConstantWhenDefaultBranch() {
        /* Branches:* (branch expression (line 58)) : false  #  inside <init> method*/
        //Act Statement(s)
        SparseGradient result = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${46fe7753-ce00-35b2-8a8d-e6c21c7b022e}, hash: 352EA316A08CC0F677921E733F7F64E2
    @Test()
    void createVariableWhenDefaultBranch() {
        /* Branches:* (branch expression (line 58)) : false  #  inside <init> method*/
        //Act Statement(s)
        SparseGradient result = SparseGradient.createVariable(1, Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${3034781c-25fc-309f-b79a-f03e1e940ece}, hash: F1E6CAF00076BC7A75AFF2942F7FE776
    @Test()
    void numVarsTest() {
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("0.0"));
        //Act Statement(s)
        int result = target.numVars();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(1)));
    }

    //Sapient generated method id: ${06ae59bd-caec-34ae-9780-7fb0825e653e}, hash: 95A7982C8D0ED70BA6702FA7420D24FE
    @Test()
    void getDerivativeWhenOutIsNotNull() {
        /* Branches:* (out == null) : false*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        double result = target.getDerivative(0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("1.0"), 0.00001)));
    }

    //Sapient generated method id: ${7ab44501-1f8e-3b69-b188-58facba79292}, hash: A1A1E11508D933352D44A11BCAEBAA7D
    @Test()
    void add1WhenDefaultBranch() {
        /* Branches:* (branch expression (line 58)) : false  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.add(Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${05820df5-7cd1-322b-a9cf-1f2157a2229a}, hash: 3085861762A708D2970ADE93F24B9AA4
    @Test()
    void subtract1WhenDefaultBranch() {
        /* Branches:* (branch expression (line 58)) : false  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.subtract(Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${dd17f7e2-4916-3029-aec4-74690a0a1b55}, hash: 9B4A615002BE02FE602BDF84A0738FA5
    @Test()
    void multiply1WhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.multiply(Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${ff78e403-7f9a-3886-82b6-5bb7df70997e}, hash: B651ECEA04FC8D61AD041E40E6522558
    @Test()
    void multiply2WhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.multiply(0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${c4dac8ad-acb9-306e-b501-f64f4d189fa3}, hash: F31E8036FD210D452F03382F0D33DBBB
    @Test()
    void divide1WhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("-1.0"));
        //Act Statement(s)
        SparseGradient result = target.divide(Double.parseDouble("-1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${fce80dac-f6bf-385c-a222-34b5bd323561}, hash: AD26EBD709C68C7B6E7B010FE3D7080C
    @Test()
    void negateWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.negate();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${cae61e6e-2bde-3bd3-ab99-f0aabebeb150}, hash: 8B4AA9CF1F1E81A638186A1EEB813088
    @Test()
    void getFieldTest() {
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("0.0"));
        //Act Statement(s)
        Field<SparseGradient> result = target.getField();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${89aceca9-465d-3c57-afd6-6486de5f9d83}, hash: 6410BC4DF61B0F4021D8A85A708881F7
    @Test()
    void remainderWhenDefaultBranch() {
        /* Branches:* (branch expression (line 58)) : false  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.remainder(Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${5a0a6cc7-f50f-39ea-b236-8958df42886f}, hash: 2295A0CBA5BBB202AFB7A589E88FD33D
    @Test()
    void remainder1Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        SparseGradient target = spy(SparseGradient.createVariable(5, Double.parseDouble("10.0")));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        doReturn(sparseGradient).when(target).subtract((SparseGradient) any());
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.remainder(sparseGradient2);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(sparseGradient));
            verify(target).subtract((SparseGradient) any());
        });
    }

    //Sapient generated method id: ${2c9494a2-0456-3881-bb9e-695a27b4fdbe}, hash: C13C1286465887FEC052C8B902869FF6
    @Test()
    void absWhenDoubleDoubleToLongBitsValueLessThan0() {
        /* Branches:* (Double.doubleToLongBits(value) < 0) : true*/
        //Arrange Statement(s)
        SparseGradient target = spy(SparseGradient.createVariable(1, Double.parseDouble("-3.14")));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        doReturn(sparseGradient).when(target).negate();
        //Act Statement(s)
        SparseGradient result = target.abs();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(sparseGradient));
            verify(target).negate();
        });
    }

    //Sapient generated method id: ${43d5e9f0-2d3f-3432-85c1-8c65466581d8}, hash: 0A9D3D74E08DD079112C257178B540C5
    @Test()
    void absWhenDoubleDoubleToLongBitsValueNotLessThan0() {
        /* Branches:* (Double.doubleToLongBits(value) < 0) : false*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.abs();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${c8339ec0-9423-3dee-b096-914e8f9040a4}, hash: A3B70C3074433218852C41621A06DD92
    @Test()
    void roundTest() {
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        long result = target.round();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(1L)));
    }

    //Sapient generated method id: ${bf582e42-8a2b-3405-b7a5-05b71d41d888}, hash: CF1BEF16DEBAD30C5A471692F7CCAEA1
    @Test()
    void copySignWhenSLessThan0() {
        /* Branches:* (m >= 0) : true* (s >= 0) : false* (m < 0) : true* (s < 0) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.copySign(sparseGradient);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${e0fe71de-fedf-38f0-82dc-b8e9df3dad42}, hash: E803C9F22A1B818C568AFC59CE0A0505
    @Test()
    void copySign1WhenSLessThan0() {
        /* Branches:* (m >= 0) : true* (s >= 0) : false* (m < 0) : true* (s < 0) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.copySign(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${3529da7e-8fdb-3d9b-87f9-6f58698f85b3}, hash: 109223BEF995C146FC7315B4B2FFDA8D
    @Disabled()
    @Test()
    void copySign1WhenSNotLessThan0() {
        /* Branches:* (m >= 0) : true* (s >= 0) : false* (m < 0) : true* (s < 0) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        SparseGradient target = spy(SparseGradient.createVariable(0, Double.parseDouble("0.0")));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        doReturn(sparseGradient).when(target).negate();
        //Act Statement(s)
        SparseGradient result = target.copySign(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(sparseGradient));
            verify(target).negate();
        });
    }

    //Sapient generated method id: ${051fe1c7-d086-3b09-af04-382558efa13a}, hash: 179E05B1EED9DF291B08F4657564BECE
    @Test()
    void scalbWhenDerivativesEntrySetIsEmpty() {
        /* Branches:* (branch expression (line 58)) : false  #  inside <init> method* (for-each(derivatives.entrySet())) : false*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.scalb(1);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${b0a12569-f222-300c-87be-55d4fb8927ba}, hash: 58BC942E4546D36DCF61D81C37459A87
    @Test()
    void hypot1Test() {
        //Arrange Statement(s)
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = SparseGradient.hypot(sparseGradient, sparseGradient2);
        SparseGradient sparseGradient3 = sparseGradient.hypot(sparseGradient2);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient3)));
    }

    //Sapient generated method id: ${9941a8f0-d147-3e5e-90ae-80c2364831cf}, hash: 6961EE3260EE53747F997B9FDE7BDBD5
    @Test()
    void reciprocalWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("-1.0"));
        //Act Statement(s)
        SparseGradient result = target.reciprocal();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${c3d8a59c-f37c-37b8-8acd-073c24e772bb}, hash: 9F66395A9AF678367129B129E0702596
    @Test()
    void sqrtWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("-0.5"));
        //Act Statement(s)
        SparseGradient result = target.sqrt();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${decb7255-cb6e-356f-9783-cae79d82f8d2}, hash: 4BC3F6AAF4C40B1D3DD032EFE822CC5C
    @Test()
    void cbrtWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.cbrt();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${6ed99c90-13fd-365e-860c-383676813868}, hash: 43A4AC63CF934648E8944B20DFB75CC5
    @Test()
    void rootNWhenNEquals2() {
        /* Branches:* (n == 2) : true*/
        //Arrange Statement(s)
        SparseGradient target = spy(SparseGradient.createVariable(2, Double.parseDouble("0.0")));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        doReturn(sparseGradient).when(target).sqrt();
        //Act Statement(s)
        SparseGradient result = target.rootN(2);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(sparseGradient));
            verify(target).sqrt();
        });
    }

    //Sapient generated method id: ${8a9eb057-1c30-3498-966f-0650b9971148}, hash: E4E41CF529E9E742EBC53092EDBAB8B0
    @Test()
    void rootNWhenNEquals3() {
        /* Branches:* (n == 2) : false* (n == 3) : true*/
        //Arrange Statement(s)
        SparseGradient target = spy(SparseGradient.createVariable(1, Double.parseDouble("0.0")));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        doReturn(sparseGradient).when(target).cbrt();
        //Act Statement(s)
        SparseGradient result = target.rootN(3);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(sparseGradient));
            verify(target).cbrt();
        });
    }

    //Sapient generated method id: ${3989d365-cd52-341a-a0dd-0605b7c18889}, hash: 5FB794FD080D45A9E376B87154D59A5F
    @Test()
    void rootNWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (n == 2) : false* (n == 3) : false* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.rootN(0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${2e84b360-a1ce-3d4e-b01d-2b5fd9300eb1}, hash: C36F15646417F39F983F918240BD418C
    @Test()
    void powWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.pow(Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${9857e10e-9343-36fd-9712-bc29e2a7cc2a}, hash: 2962F003B5F19690B653FC84B0C7F13E
    @Disabled()
    @Test()
    void pow1WhenNEquals0() {
        /* Branches:* (n == 0) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        SparseGradient target = spy(SparseGradient.createVariable(1, Double.parseDouble("2.5")));
        DfpField dfpField = new DfpField(0);
        doReturn(dfpField).when(target).getField();
        //Act Statement(s)
        SparseGradient result = target.pow(0);
        SparseGradient sparseGradient = (SparseGradient) SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(sparseGradient));
            verify(target).getField();
        });
    }

    //Sapient generated method id: ${275c6fc6-82b7-33d0-a184-8221240a8cce}, hash: 927104B3A9B6E4BD61C7AE271A776BA0
    @Test()
    void pow1WhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (n == 0) : false* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(2, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.pow(2);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${266d4283-d2a5-3196-9427-a2230c122db1}, hash: E3546E61C78C7A15C9F34CE99585081D
    @Disabled()
    @Test()
    void pow2Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        SparseGradient target = spy(SparseGradient.createVariable(5, Double.parseDouble("3.0")));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        doReturn(sparseGradient).when(target).log();
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("2.0"));
        //Act Statement(s)
        SparseGradient result = target.pow(sparseGradient2);
        SparseGradient sparseGradient3 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(sparseGradient3));
            verify(target).log();
        });
    }

    //Sapient generated method id: ${1f921c65-16af-3971-a978-704b32a2cfdc}, hash: 0C7A8692D0ADBE2474DF4C15ADC0FDEF
    @Test()
    void pow3WhenXValueEquals0() {
        /* Branches:* (a == 0) : true* (x.value == 0) : true*/
        //Arrange Statement(s)
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = SparseGradient.pow(Double.parseDouble("0.0"), sparseGradient);
        SparseGradient sparseGradient2 = sparseGradient.compose(Double.parseDouble("1.0"), Double.parseDouble("-Infinity"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient2)));
    }

    //Sapient generated method id: ${eafb1aa6-8250-3020-b7a2-6398f1cac0cc}, hash: 395703DED9BD81118530AB647243C572
    @Test()
    void pow3WhenDefaultBranch() {
        /* Branches:* (a == 0) : false* (branch expression (line 74)) : false  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("-1.0"));
        //Act Statement(s)
        SparseGradient result = SparseGradient.pow(Double.parseDouble("-1.0"), sparseGradient);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${2a767564-393f-3c2b-9213-bee7cac832c5}, hash: C090B63D15C9A51811118E5B190509D3
    @Test()
    void expWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.exp();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${6042a4da-ebc3-398c-80a0-9b0982a93106}, hash: 0E8F845A9C080FE0AD137AC78646C6D0
    @Test()
    void expm1WhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.expm1();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${e771d722-c025-3312-b251-598d7574721a}, hash: EEBA61471FCFDD7C38BC90F02844EC3F
    @Test()
    void logWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("-1.0"));
        //Act Statement(s)
        SparseGradient result = target.log();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${b50b5b94-2602-360b-b367-b05a0dac7c8c}, hash: 651C4FC0216596BEABFF15F78C47F120
    @Test()
    void log10WhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("-0.605586213128"));
        //Act Statement(s)
        SparseGradient result = target.log10();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${b00ae1d9-1745-3568-8013-909eced7cc48}, hash: 0B41046BFE0B08B81744004020E2DBB4
    @Test()
    void log1pWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.log1p();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${43915065-9818-331c-b627-dae87f97295c}, hash: 764A6B202093B5EF69875C1E653D514B
    @Test()
    void cosWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.cos();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${1c9e61fd-f8ca-3674-9fb5-0d25c82d3ba2}, hash: 8372D4C1C6FDEECDA30FEFA32B7672D4
    @Test()
    void sinWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.sin();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${0b60605a-bbca-3757-bd08-b6e55cda1c69}, hash: E58B02921664DC74BC8F8CC7DC6049D9
    @Test()
    void tanWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.tan();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${2d1e57c7-59a7-3f3d-9533-23e1866d1c21}, hash: 327E4A9808D6BD0C384EF0148A27C9AE
    @Test()
    void acosWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.acos();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${b58203bb-7d11-3edc-9371-9e239806f4d0}, hash: A2D51DB6B1EDA07E70C1D4942502583F
    @Test()
    void asinWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.asin();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${5c391d15-837c-3b2d-9bee-d032c3309d77}, hash: 6021B72ABF16045FEA612F8E812B7886
    @Test()
    void atanWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.125"));
        //Act Statement(s)
        SparseGradient result = target.atan();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${0d06a53a-5c00-3642-98b7-69ae74dc6bd4}, hash: 2CAE922D91AED3D7017A9B743E06701E
    @Test()
    void atan21Test() {
        //Arrange Statement(s)
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = SparseGradient.atan2(sparseGradient, sparseGradient2);
        SparseGradient sparseGradient3 = sparseGradient.atan2(sparseGradient2);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient3)));
    }

    //Sapient generated method id: ${61252436-f843-3068-a1e7-10cb5ef1177c}, hash: BA50A9043D791FB2EF27FA3E62B5C88A
    @Test()
    void coshWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.cosh();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${2697f3b4-5cc9-30ae-9ea2-67439ff53eb4}, hash: 6FF70B718A0C419225CBC81D076DC46C
    @Test()
    void sinhWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.sinh();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${b650bdfa-75c3-36d1-900a-41fe31639d12}, hash: 3F15A602EC408AC2B9DBBB70415B195E
    @Test()
    void tanhWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.tanh();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${0995c0d5-7509-3a29-ae2f-a2efe1e5cba0}, hash: D82953F10D11996C0B920E255460F3D2
    @Test()
    void acoshWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.acosh();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${69019160-ae0b-3073-b2b1-96e372f7ead3}, hash: 1496CF37FBA56F7F09B983B817E01C87
    @Test()
    void asinhWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("-1.0"));
        //Act Statement(s)
        SparseGradient result = target.asinh();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${46ef02be-7f83-35a7-910b-7043b171dc05}, hash: 403CC3A2E307835A7CFDBDA08DE0A980
    @Test()
    void atanhWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("-2.0"));
        //Act Statement(s)
        SparseGradient result = target.atanh();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${dcf987ac-ee68-34f1-9c57-2edfc103331e}, hash: F424E49539EFFB7E487FDF07D1068A49
    @Test()
    void toDegreesWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.toDegrees();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${1281dd7d-a0bd-319c-82e3-ec218f1ce074}, hash: AB4E3757A26094DE076D9435DD9E21D0
    @Test()
    void toRadiansWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("1.0"));
        //Act Statement(s)
        SparseGradient result = target.toRadians();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${67ec8d08-d510-3669-a4bc-587266d34fa4}, hash: EAD1FBCD6C7360CCA396BB544ECD3911
    @Test()
    void taylorWhenILessThanDeltaLength() {
        /* Branches:* (i < delta.length) : true*/
        //Arrange Statement(s)
        SparseGradient target = spy(SparseGradient.createVariable(1, Double.parseDouble("1.0")));
        doReturn(Double.parseDouble("1.0")).when(target).getDerivative(0);
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        //Act Statement(s)
        double result = target.taylor(doubleArray);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, closeTo(Double.parseDouble("2.0"), 0.00001));
            verify(target).getDerivative(0);
        });
    }

    //Sapient generated method id: ${9a918149-7c78-35b0-9c61-0d522cd87cf2}, hash: 84482D2FFB6D2EA1A7CB725294A5FA71
    @Test()
    void composeWhenDefaultBranchAndDefaultBranch() {
        /* Branches:* (branch expression (line 74)) : false  #  inside <init> method* (branch expression (line 75)) : true  #  inside <init> method*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.compose(Double.parseDouble("0.0"), Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${e5c4f276-295c-37b4-bbf9-0f0f5c4e73f7}, hash: D8886935BF45167343CF3C9D1E89523B
    @Test()
    void linearCombinationWhenILessThanBLength() {
        /* Branches:* (i < a.length) : true* (i < a.length) : true* (i < b.length) : true*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient[] sparseGradientArray = new SparseGradient[]{sparseGradient};
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("0"));
        SparseGradient[] sparseGradientArray2 = new SparseGradient[]{sparseGradient2};
        //Act Statement(s)
        SparseGradient result = target.linearCombination(sparseGradientArray, sparseGradientArray2);
        Field<SparseGradient> field = sparseGradient.getField();
        SparseGradient sparseGradient3 = (SparseGradient) field.getZero();
        SparseGradient sparseGradient5 = sparseGradient.multiply(sparseGradient2);
        SparseGradient sparseGradient4 = sparseGradient3.add(sparseGradient5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient4)));
    }

    //Sapient generated method id: ${1f096fa7-ec87-3580-9732-064f3214d624}, hash: C26910A8E5DA5839E3AB590D080CD6FD
    @Test()
    void linearCombination1WhenILessThanBLength() {
        /* Branches:* (i < a.length) : true* (i < b.length) : true*/
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        double[] doubleArray = new double[]{Double.parseDouble("0")};
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient[] sparseGradientArray = new SparseGradient[]{sparseGradient};
        //Act Statement(s)
        SparseGradient result = target.linearCombination(doubleArray, sparseGradientArray);
        Field<SparseGradient> field = sparseGradient.getField();
        SparseGradient sparseGradient2 = (SparseGradient) field.getZero();
        SparseGradient sparseGradient4 = sparseGradient.multiply(Double.parseDouble("0"));
        SparseGradient sparseGradient3 = sparseGradient2.add(sparseGradient4);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient3)));
    }

    //Sapient generated method id: ${b6466172-cfa2-3de1-ba5e-f63b546b26c1}, hash: A28A5BE8D1735F49C920F53889298905
    @Test()
    void linearCombination2Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("6.0"));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("2.0"));
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("3.0"));
        SparseGradient sparseGradient3 = SparseGradient.createConstant(Double.parseDouble("4.0"));
        SparseGradient sparseGradient4 = SparseGradient.createConstant(Double.parseDouble("5.0"));
        //Act Statement(s)
        SparseGradient result = target.linearCombination(sparseGradient, sparseGradient2, sparseGradient3, sparseGradient4);
        SparseGradient sparseGradient5 = sparseGradient.multiply(sparseGradient2);
        SparseGradient sparseGradient7 = sparseGradient3.multiply(sparseGradient4);
        SparseGradient sparseGradient6 = sparseGradient5.add(sparseGradient7);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient6)));
    }

    //Sapient generated method id: ${cba01cc6-8f05-338f-a719-ba1e5686d26b}, hash: 19D3346C1AD58663862E6C6D84AE37F8
    @Test()
    void linearCombination3Test() {
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.linearCombination(Double.parseDouble("1.0"), sparseGradient, Double.parseDouble("0.5"), sparseGradient2);
        SparseGradient sparseGradient3 = sparseGradient.multiply(Double.parseDouble("1.0"));
        SparseGradient sparseGradient5 = sparseGradient2.multiply(Double.parseDouble("0.5"));
        SparseGradient sparseGradient4 = sparseGradient3.add(sparseGradient5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient4)));
    }

    //Sapient generated method id: ${3caa15f3-9bd7-36bb-9b2f-0cb37088cfb8}, hash: CA1154498A6144C45694DB4B6EEAA3CB
    @Test()
    void linearCombination4Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(1, Double.parseDouble("8.0"));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("2.0"));
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("3.0"));
        SparseGradient sparseGradient3 = SparseGradient.createConstant(Double.parseDouble("4.0"));
        SparseGradient sparseGradient4 = SparseGradient.createConstant(Double.parseDouble("5.0"));
        SparseGradient sparseGradient5 = SparseGradient.createConstant(Double.parseDouble("6.0"));
        SparseGradient sparseGradient6 = SparseGradient.createConstant(Double.parseDouble("7.0"));
        //Act Statement(s)
        SparseGradient result = target.linearCombination(sparseGradient, sparseGradient2, sparseGradient3, sparseGradient4, sparseGradient5, sparseGradient6);
        SparseGradient sparseGradient7 = sparseGradient.multiply(sparseGradient2);
        SparseGradient sparseGradient9 = sparseGradient3.multiply(sparseGradient4);
        SparseGradient sparseGradient8 = sparseGradient7.add(sparseGradient9);
        SparseGradient sparseGradient11 = sparseGradient5.multiply(sparseGradient6);
        SparseGradient sparseGradient10 = sparseGradient8.add(sparseGradient11);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient10)));
    }

    //Sapient generated method id: ${65183676-aa38-340f-a9d6-9d8695bf7c90}, hash: ED6262814A2700580501AB564378BEF6
    @Test()
    void linearCombination5Test() {
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient sparseGradient3 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.linearCombination(Double.parseDouble("1.0"), sparseGradient, Double.parseDouble("0.5"), sparseGradient2, Double.parseDouble("0.25"), sparseGradient3);
        SparseGradient sparseGradient4 = sparseGradient.multiply(Double.parseDouble("1.0"));
        SparseGradient sparseGradient6 = sparseGradient2.multiply(Double.parseDouble("0.5"));
        SparseGradient sparseGradient5 = sparseGradient4.add(sparseGradient6);
        SparseGradient sparseGradient8 = sparseGradient3.multiply(Double.parseDouble("0.25"));
        SparseGradient sparseGradient7 = sparseGradient5.add(sparseGradient8);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient7)));
    }

    //Sapient generated method id: ${34bda76f-d65d-3230-9cd6-a32df1776a0a}, hash: 735190D9127504679E0777A8A8451B7C
    @Test()
    void linearCombination6Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(10, Double.parseDouble("11.0"));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("2.0"));
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("3.0"));
        SparseGradient sparseGradient3 = SparseGradient.createConstant(Double.parseDouble("4.0"));
        SparseGradient sparseGradient4 = SparseGradient.createConstant(Double.parseDouble("5.0"));
        SparseGradient sparseGradient5 = SparseGradient.createConstant(Double.parseDouble("6.0"));
        SparseGradient sparseGradient6 = SparseGradient.createConstant(Double.parseDouble("7.0"));
        SparseGradient sparseGradient7 = SparseGradient.createConstant(Double.parseDouble("8.0"));
        SparseGradient sparseGradient8 = SparseGradient.createConstant(Double.parseDouble("9.0"));
        //Act Statement(s)
        SparseGradient result = target.linearCombination(sparseGradient, sparseGradient2, sparseGradient3, sparseGradient4, sparseGradient5, sparseGradient6, sparseGradient7, sparseGradient8);
        SparseGradient sparseGradient9 = sparseGradient.multiply(sparseGradient2);
        SparseGradient sparseGradient11 = sparseGradient3.multiply(sparseGradient4);
        SparseGradient sparseGradient10 = sparseGradient9.add(sparseGradient11);
        SparseGradient sparseGradient13 = sparseGradient5.multiply(sparseGradient6);
        SparseGradient sparseGradient12 = sparseGradient10.add(sparseGradient13);
        SparseGradient sparseGradient15 = sparseGradient7.multiply(sparseGradient8);
        SparseGradient sparseGradient14 = sparseGradient12.add(sparseGradient15);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient14)));
    }

    //Sapient generated method id: ${a7b87d7d-b07b-3753-a377-56dfcf1b1338}, hash: 99C382F87E7748A9701DC145C7CADDFF
    @Test()
    void linearCombination7Test() {
        //Arrange Statement(s)
        SparseGradient target = SparseGradient.createVariable(0, Double.parseDouble("0.0"));
        SparseGradient sparseGradient = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient sparseGradient2 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient sparseGradient3 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        SparseGradient sparseGradient4 = SparseGradient.createConstant(Double.parseDouble("0.0"));
        //Act Statement(s)
        SparseGradient result = target.linearCombination(Double.parseDouble("1.0"), sparseGradient, Double.parseDouble("0.5"), sparseGradient2, Double.parseDouble("0.25"), sparseGradient3, Double.parseDouble("0.125"), sparseGradient4);
        SparseGradient sparseGradient5 = sparseGradient.multiply(Double.parseDouble("1.0"));
        SparseGradient sparseGradient7 = sparseGradient2.multiply(Double.parseDouble("0.5"));
        SparseGradient sparseGradient6 = sparseGradient5.add(sparseGradient7);
        SparseGradient sparseGradient9 = sparseGradient3.multiply(Double.parseDouble("0.25"));
        SparseGradient sparseGradient8 = sparseGradient6.add(sparseGradient9);
        SparseGradient sparseGradient11 = sparseGradient4.multiply(Double.parseDouble("0.125"));
        SparseGradient sparseGradient10 = sparseGradient8.add(sparseGradient11);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(sparseGradient10)));
    }
}
