package org.apache.commons.math4.legacy.analysis.differentiation;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.apache.commons.math4.legacy.exception.NumberIsTooSmallException;
import org.apache.commons.math4.legacy.exception.NumberIsTooLargeException;
import org.apache.commons.math4.legacy.analysis.UnivariateVectorFunction;
import org.apache.commons.math4.legacy.analysis.UnivariateFunction;
import org.apache.commons.math4.legacy.analysis.function.Abs;
import org.apache.commons.math4.legacy.analysis.UnivariateMatrixFunction;
import org.apache.commons.math4.legacy.analysis.interpolation.HermiteInterpolator;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.mock;
import static org.hamcrest.Matchers.is;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class FiniteDifferencesDifferentiatorSapientGeneratedTest {

    //Sapient generated method id: ${6b310fc7-c261-30b9-af52-7a81d2acf43f}, hash: 20B75EF9EF149229CC376E6F8FE3DE92
    @Test()
    void differentiateTest() throws NotPositiveException, NumberIsTooSmallException, NumberIsTooLargeException {
        //Arrange Statement(s)
        FiniteDifferencesDifferentiator target = new FiniteDifferencesDifferentiator(3, Double.parseDouble("1.0"), Double.parseDouble("0.0"), Double.parseDouble("3.0"));
        Abs abs = new Abs();

        //Act Statement(s)
        UnivariateDifferentiableFunction result = target.differentiate((UnivariateFunction) abs);

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${c3546cdf-9cb3-31da-9c07-c35e7a3481b2}, hash: 1855FD09DDCE481746FA2F2E8697B2D8
    @Test()
    void differentiate1Test() throws NotPositiveException, NumberIsTooSmallException, NumberIsTooLargeException {
        //Arrange Statement(s)
        FiniteDifferencesDifferentiator target = new FiniteDifferencesDifferentiator(3, Double.parseDouble("1.0"), Double.parseDouble("0.0"), Double.parseDouble("3.0"));
        HermiteInterpolator hermiteInterpolator = new HermiteInterpolator();

        //Act Statement(s)
        UnivariateDifferentiableVectorFunction result = target.differentiate((UnivariateVectorFunction) hermiteInterpolator);

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${768506c8-5cd3-3dfc-b9f1-7e38e5bfdc03}, hash: 96C4F814EB9726200E017F621CDBEE09
    @Test()
    void differentiate2Test() throws NotPositiveException, NumberIsTooSmallException, NumberIsTooLargeException {
        //Arrange Statement(s)
        FiniteDifferencesDifferentiator target = new FiniteDifferencesDifferentiator(5, Double.parseDouble("0.1"), Double.parseDouble("-1.0"), Double.parseDouble("1.0"));
        UnivariateMatrixFunction univariateMatrixFunctionMock = mock(UnivariateMatrixFunction.class, "some_function");

        //Act Statement(s)
        UnivariateDifferentiableMatrixFunction result = target.differentiate(univariateMatrixFunctionMock);

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
}
