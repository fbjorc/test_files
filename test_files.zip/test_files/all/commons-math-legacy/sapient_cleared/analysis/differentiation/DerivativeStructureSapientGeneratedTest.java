package org.apache.commons.math4.legacy.analysis.differentiation;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.core.Field;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;
import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class DerivativeStructureSapientGeneratedTest {

    //Sapient generated method id: ${getFreeParametersTest}, hash: FFC771F263BD886DF88FEF6F0A4926A1
    @Test()
    void getFreeParametersTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        int result = target.getFreeParameters();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(0)));
    }

    //Sapient generated method id: ${getOrderTest}, hash: B8617AB2FC12D8730121B70ADF7E25B5
    @Test()
    void getOrderTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        int result = target.getOrder();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(0)));
    }

    //Sapient generated method id: ${createConstantTest}, hash: 5358914C53CE0F7A47D8AC02461DFA26
    @Disabled()
    @Test()
    void createConstantTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        DerivativeStructure result = target.createConstant(Double.parseDouble("0"));
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(1, 1, Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(derivativeStructure5)));
    }

    //Sapient generated method id: ${getRealTest}, hash: 07CE81CEDC162A050F2A8305E02A775E
    @Test()
    void getRealTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        double result = target.getReal();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("0.0"), 0.00001)));
    }

    //Sapient generated method id: ${getValueTest}, hash: 53394C76DEFA653FE548E5ED47B131F5
    @Test()
    void getValueTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        double result = target.getValue();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("0.0"), 0.00001)));
    }

    //Sapient generated method id: ${getPartialDerivativeTest}, hash: AC7ED934DC89757A8ACCC522A65254B3
    @Test()
    void getPartialDerivativeTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        int[] intArray = new int[] {};
        //Act Statement(s)
        double result = target.getPartialDerivative(intArray);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("0.0"), 0.00001)));
    }

    //Sapient generated method id: ${addTest}, hash: 69DA578F6C8EBC14B72E66E22B6C1D4F
    @Test()
    void addTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        DerivativeStructure result = target.add(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${add1Test}, hash: F611DC2A7EC907D6CFA40C4BC1972593
    @Test()
    void add1Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.add(derivativeStructure5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

   
    //Sapient generated method id: ${subtract1Test}, hash: 09E33083CB74632E2F3404EF4013C1B6
    @Test()
    void subtract1Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.subtract(derivativeStructure5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${multiplyTest}, hash: DB055163C36E87B22DD4E9233D3ABF19
    @Test()
    void multiplyTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = spy(new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4));
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        doReturn(derivativeStructure5).when(target).multiply(Double.parseDouble("0.0"));
        //Act Statement(s)
        DerivativeStructure result = target.multiply(0);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(derivativeStructure5));
            verify(target).multiply(Double.parseDouble("0.0"));
        });
    }

    //Sapient generated method id: ${multiply1WhenILessThanDsDataLength}, hash: E10CA33EFAC8B6BD64C1DAFC3425BB8D
    @Test()
    void multiply1WhenILessThanDsDataLength() {
        /* Branches:
         * (i < ds.data.length) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        DerivativeStructure result = target.multiply(Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${multiply2Test}, hash: 2627901FDB5018BC88623EB06773089E
    @Test()
    void multiply2Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.multiply(derivativeStructure5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${divideWhenILessThanDsDataLength}, hash: 8C58867770A0D5F02AD17DEAA99643BD
    @Test()
    void divideWhenILessThanDsDataLength() {
        /* Branches:
         * (i < ds.data.length) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        DerivativeStructure result = target.divide(Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${divide1Test}, hash: 00B534B0565C052306F801C9DC28BCA6
    @Test()
    void divide1Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.divide(derivativeStructure5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${remainderTest}, hash: FCEA4081877EA04863CE6A0654DD6C4C
    @Test()
    void remainderTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        DerivativeStructure result = target.remainder(Double.parseDouble("1.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${remainder1Test}, hash: 87B6DCD5599F217242BA56600BF82A99
    @Test()
    void remainder1Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.remainder(derivativeStructure5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
    
    //Sapient generated method id: ${absWhenDoubleDoubleToLongBits0IndexOfDataNotLessThan0}, hash: 786848E5E069C94E29DA84D8E2829CF5
    @Test()
    void absWhenDoubleDoubleToLongBits0IndexOfDataNotLessThan0() {
        /* Branches:
         * (Double.doubleToLongBits(data[0]) < 0) : false
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        DerivativeStructure result = target.abs();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${copySignWhenSLessThan0}, hash: 333CC46BAA23E100AF7BC08F3461B161
    @Test()
    void copySignWhenSLessThan0() {
        /* Branches:
         * (m >= 0) : true
         * (s >= 0) : false
         * (m < 0) : true
         * (s < 0) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.copySign(derivativeStructure5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${copySign1WhenSLessThan0}, hash: 725A2836BC9F8FB552047930C5452F49
    @Test()
    void copySign1WhenSLessThan0() {
        /* Branches:
         * (m >= 0) : true
         * (s >= 0) : false
         * (m < 0) : true
         * (s < 0) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        DerivativeStructure result = target.copySign(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${hypotWhenExpYGreaterThanExpXPlus27}, hash: 78BFE9B47C93878BA8DC94108E6DC430
    @Test()
    void hypotWhenExpYGreaterThanExpXPlus27() {
        /* Branches:
         * (Double.isInfinite(data[0])) : false
         * (Double.isInfinite(y.data[0])) : false
         * (Double.isNaN(data[0])) : false
         * (Double.isNaN(y.data[0])) : false
         * (expX > expY + 27) : false
         * (expY > expX + 27) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.hypot(derivativeStructure5);
        DerivativeStructure derivativeStructure6 = new DerivativeStructure(0, 0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(derivativeStructure6)));
    }

    //Sapient generated method id: ${hypot1Test}, hash: 1A0DC665F3CC79C4F8FE553440FE7554
    @Test()
    void hypot1Test() {
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = DerivativeStructure.hypot(derivativeStructure, derivativeStructure2);
        DerivativeStructure derivativeStructure3 = derivativeStructure.hypot(derivativeStructure2);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(derivativeStructure3)));
    }

    //Sapient generated method id: ${composeWhenFLengthNotEqualsGetOrderPlus1ThrowsDimensionMismatchException}, hash: 0B210474261D093116459169027ECEB8
    @Test()
    void composeWhenFLengthNotEqualsGetOrderPlus1ThrowsDimensionMismatchException() {
        /* Branches:
         * (f.length != getOrder() + 1) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        double[] doubleArray = new double[] {};
        //Act Statement(s)
        final DimensionMismatchException result = assertThrows(DimensionMismatchException.class, () -> {
            target.compose(doubleArray);
        });
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${sqrtTest}, hash: C1F49CB7A7F30BF9603BF2EBCE981CAB
    @Test()
    void sqrtTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = spy(new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4));
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        doReturn(derivativeStructure5).when(target).rootN(2);
        //Act Statement(s)
        DerivativeStructure result = target.sqrt();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(derivativeStructure5));
            verify(target).rootN(2);
        });
    }

    //Sapient generated method id: ${cbrtTest}, hash: 3DA5EB8F8FF1E9A8E8C5584C558253EF
    @Test()
    void cbrtTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = spy(new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4));
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        doReturn(derivativeStructure5).when(target).rootN(3);
        //Act Statement(s)
        DerivativeStructure result = target.cbrt();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(derivativeStructure5));
            verify(target).rootN(3);
        });
    }

    //Sapient generated method id: ${getFieldTest}, hash: 321B89532403712C1919B8B52E430B8B
    @Test()
    void getFieldTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        //Act Statement(s)
        Field<DerivativeStructure> result = target.getField();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${pow3Test}, hash: D0749AE6B7DE26E5AC8DF28DBEC14620
    @Test()
    void pow3Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.pow(derivativeStructure5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${atan2Test}, hash: A2D4A62E6223E48F1B656C4E07212A60
    @Test()
    void atan2Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        DerivativeStructure derivativeStructure5 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.atan2(derivativeStructure5);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${atan21Test}, hash: 70B0B0397205F10443A45EBF1EA686EC
    @Test()
    void atan21Test() {
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = DerivativeStructure.atan2(derivativeStructure, derivativeStructure2);
        DerivativeStructure derivativeStructure3 = derivativeStructure.atan2(derivativeStructure2);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(derivativeStructure3)));
    }

    //Sapient generated method id: ${taylorTest}, hash: 4BA7FC45422DA34080945771BA44FB4D
    @Test()
    void taylorTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure3 = new DerivativeStructure(0, 0);
        DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0);
        DerivativeStructure target = new DerivativeStructure(Double.parseDouble("0.0"), derivativeStructure, Double.parseDouble("0.0"), derivativeStructure2, Double.parseDouble("0.0"), derivativeStructure3, Double.parseDouble("0.0"), derivativeStructure4);
        double[] doubleArray = new double[] {};
        //Act Statement(s)
        double result = target.taylor(doubleArray);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("0.0"), 0.00001)));
    }
}
