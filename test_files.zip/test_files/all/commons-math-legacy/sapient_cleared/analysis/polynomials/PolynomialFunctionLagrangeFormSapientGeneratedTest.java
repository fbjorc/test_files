package org.apache.commons.math4.legacy.analysis.polynomials;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NumberIsTooSmallException;
import org.apache.commons.math4.legacy.exception.NonMonotonicSequenceException;
import org.junit.jupiter.api.Disabled;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.hamcrest.Matchers.closeTo;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class PolynomialFunctionLagrangeFormSapientGeneratedTest {

    //Sapient generated method id: ${f46ed5c5-0372-3ef9-8026-8ae3311e4fe2}, hash: 37D29C2E7CFF414AB8696955A3D496AE
    @Test()
    void valueWhenJLessThanNMinusIAndNearestLessThan0_5MultipliedByNMinusIPlus1() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        /* Branches:* (i < n) : true  #  inside evaluateInternal method* (dist < minDist) : true  #  inside evaluateInternal method* (i < n) : true  #  inside evaluateInternal method* (j < n - i) : true  #  inside evaluateInternal method* (nearest < 0.5 * (n - i + 1)) : true  #  inside evaluateInternal method*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("1")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0"), Double.parseDouble("1")};
        PolynomialFunctionLagrangeForm target = new PolynomialFunctionLagrangeForm(doubleArray, doubleArray2);

        //Act Statement(s)
        double result = target.value(Double.parseDouble("0.5"));

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("0.5"), 0.00001)));
    }
}
