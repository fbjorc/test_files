package org.apache.commons.math4.legacy.analysis.polynomials;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.exception.NullArgumentException;
import org.apache.commons.math4.legacy.exception.NoDataException;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.mockito.MockedStatic;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import static org.hamcrest.Matchers.closeTo;

import org.mockito.stubbing.Answer;
import org.apache.commons.math4.legacy.analysis.differentiation.DerivativeStructure;

import static org.hamcrest.Matchers.equalTo;

import org.junit.jupiter.api.Disabled;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.spy;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class PolynomialFunctionNewtonFormSapientGeneratedTest {

    //Sapient generated method id: ${52f8c495-dd1f-3640-b180-04a7f65fff2e}, hash: 0C2FB8E277F214A47CCAE8328913BE9C
    @Test()
    void valueTest() throws NullArgumentException, NoDataException, DimensionMismatchException {
        //Arrange Statement(s)
        try (MockedStatic<PolynomialFunctionNewtonForm> polynomialFunctionNewtonForm = mockStatic(PolynomialFunctionNewtonForm.class, CALLS_REAL_METHODS)) {
            double[] doubleArray = new double[]{Double.parseDouble("0.0"), Double.parseDouble("0.0")};
            double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
            polynomialFunctionNewtonForm.when(() -> PolynomialFunctionNewtonForm.evaluate(doubleArray, doubleArray2, Double.parseDouble("0.0"))).thenReturn(Double.parseDouble("0.0"));
            double[] doubleArray3 = new double[]{Double.parseDouble("0"), Double.parseDouble("1")};
            double[] doubleArray4 = new double[]{Double.parseDouble("0")};
            PolynomialFunctionNewtonForm target = new PolynomialFunctionNewtonForm(doubleArray3, doubleArray4);
            //Act Statement(s)
            double result = target.value(Double.parseDouble("0.0"));
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, closeTo(Double.parseDouble("0.0"), 0.00001));
                polynomialFunctionNewtonForm.verify(() -> PolynomialFunctionNewtonForm.evaluate(doubleArray, doubleArray2, Double.parseDouble("0.0")), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${302e9b28-1ed5-32ff-9ed3-bee40ece24ad}, hash: 3B4BEE8FB5EEE8E1F277B3974F6ACF3A
    @Test()
    void value1WhenIGreaterThanOrEqualsTo0() throws NullArgumentException, NoDataException, DimensionMismatchException {
        /* Branches:* (i >= 0) : true*/
        //Arrange Statement(s)
        try (MockedStatic<PolynomialFunctionNewtonForm> polynomialFunctionNewtonForm = mockStatic(PolynomialFunctionNewtonForm.class, CALLS_REAL_METHODS)) {
            double[] doubleArray = new double[]{Double.parseDouble("0.0"), Double.parseDouble("1.0")};
            double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
            polynomialFunctionNewtonForm.when(() -> PolynomialFunctionNewtonForm.verifyInputArray(doubleArray, doubleArray2)).thenAnswer((Answer<Void>) invocation -> null);
            double[] doubleArray3 = new double[]{Double.parseDouble("0"), Double.parseDouble("1")};
            double[] doubleArray4 = new double[]{Double.parseDouble("0")};
            PolynomialFunctionNewtonForm target = new PolynomialFunctionNewtonForm(doubleArray3, doubleArray4);
            DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
            //Act Statement(s)
            DerivativeStructure result = target.value(derivativeStructure);
            DerivativeStructure derivativeStructure2 = derivativeStructure.subtract(Double.parseDouble("0.0"));
            DerivativeStructure derivativeStructure4 = new DerivativeStructure(0, 0, Double.parseDouble("1.0"));
            DerivativeStructure derivativeStructure3 = derivativeStructure2.multiply(derivativeStructure4);
            DerivativeStructure derivativeStructure5 = derivativeStructure3.add(Double.parseDouble("0.0"));
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(derivativeStructure5));
                polynomialFunctionNewtonForm.verify(() -> PolynomialFunctionNewtonForm.verifyInputArray(doubleArray, doubleArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${170e0adf-c86d-3b9d-ab4f-06a645465a38}, hash: 4837A44F055E32FCFA55EB50CFAF12BA
    @Test()
    void degreeTest() throws NullArgumentException, NoDataException, DimensionMismatchException {
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("1")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0")};
        PolynomialFunctionNewtonForm target = new PolynomialFunctionNewtonForm(doubleArray, doubleArray2);
        //Act Statement(s)
        int result = target.degree();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(1)));
    }

    //Sapient generated method id: ${86752ef5-9e20-3eb8-839c-da9c23db010b}, hash: B57410C72CA9C917A60812AA387B2DD2
    @Test()
    void getCentersTest() throws NullArgumentException, NoDataException, DimensionMismatchException {
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("1")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0")};
        PolynomialFunctionNewtonForm target = new PolynomialFunctionNewtonForm(doubleArray, doubleArray2);
        //Act Statement(s)
        double[] result = target.getCenters();
        double[] doubleResultArray = new double[]{Double.parseDouble("0.0")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(doubleResultArray)));
    }

    //Sapient generated method id: ${0ef30587-7324-3a35-97a8-4c73ff7bf281}, hash: 1245101AA4CAC822F223B37C235951C4
    @Test()
    void evaluateWhenIGreaterThanOrEqualsTo0() throws NullArgumentException, DimensionMismatchException, NoDataException {
        /* Branches:* (i >= 0) : true*/
        //Arrange Statement(s)
        try (MockedStatic<PolynomialFunctionNewtonForm> polynomialFunctionNewtonForm = mockStatic(PolynomialFunctionNewtonForm.class, CALLS_REAL_METHODS)) {
            double[] doubleArray = new double[]{Double.parseDouble("1.0"), Double.parseDouble("1.0")};
            double[] doubleArray2 = new double[]{Double.parseDouble("1.0")};
            polynomialFunctionNewtonForm.when(() -> PolynomialFunctionNewtonForm.verifyInputArray(doubleArray, doubleArray2)).thenAnswer((Answer<Void>) invocation -> null);
            //Act Statement(s)
            double result = PolynomialFunctionNewtonForm.evaluate(doubleArray, doubleArray2, Double.parseDouble("1.0"));
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, closeTo(Double.parseDouble("1.0"), 0.00001));
                polynomialFunctionNewtonForm.verify(() -> PolynomialFunctionNewtonForm.verifyInputArray(doubleArray, doubleArray2), atLeast(1));
            });
        }
    }
}
