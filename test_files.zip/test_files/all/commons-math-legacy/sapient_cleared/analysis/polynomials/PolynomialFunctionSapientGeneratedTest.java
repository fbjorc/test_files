package org.apache.commons.math4.legacy.analysis.polynomials;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.exception.NullArgumentException;
import org.apache.commons.math4.legacy.exception.NoDataException;
import org.mockito.MockedStatic;
import org.apache.commons.math4.legacy.analysis.differentiation.DerivativeStructure;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class PolynomialFunctionSapientGeneratedTest {

    //Sapient generated method id: ${52f8c495-dd1f-3640-b180-04a7f65fff2e}, hash: 2B102EB70D7B8992E5E88BE9371DE69F
    @Test()
    void valueTest() throws NullArgumentException, NoDataException {
        //Arrange Statement(s)
        try (MockedStatic<PolynomialFunction> polynomialFunction = mockStatic(PolynomialFunction.class)) {
            double[] doubleArray = new double[]{Double.parseDouble("0.0")};
            polynomialFunction.when(() -> PolynomialFunction.evaluate(doubleArray, Double.parseDouble("0.0"))).thenReturn(Double.parseDouble("0.0"));
            double[] doubleArray2 = new double[]{Double.parseDouble("0"), Double.parseDouble("0.0")};
            PolynomialFunction target = new PolynomialFunction(doubleArray2);
            //Act Statement(s)
            double result = target.value(Double.parseDouble("0.0"));
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, closeTo(Double.parseDouble("0.0"), 0.00001));
                polynomialFunction.verify(() -> PolynomialFunction.evaluate(doubleArray, Double.parseDouble("0.0")), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${170e0adf-c86d-3b9d-ab4f-06a645465a38}, hash: C8F91762E28B585CAF4DF5A28FD398BD
    @Test()
    void degreeTest() throws NullArgumentException, NoDataException {
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("0.0")};
        PolynomialFunction target = new PolynomialFunction(doubleArray);
        //Act Statement(s)
        int result = target.degree();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(0)));
    }

    //Sapient generated method id: ${d1fd6cac-ebd8-39fb-aa4d-7da91d5e9038}, hash: 14AECB10412E2CCBDEBAEA0042178865
    @Test()
    void getCoefficientsTest() throws NullArgumentException, NoDataException {
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("0.0")};
        PolynomialFunction target = new PolynomialFunction(doubleArray);
        //Act Statement(s)
        double[] result = target.getCoefficients();
        double[] doubleResultArray = new double[]{Double.parseDouble("0.0")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(doubleResultArray)));
    }

    //Sapient generated method id: ${9004b7fc-bb70-3695-b000-6c4052a8fe32}, hash: F2FCA43D8B4CA00B9E56D3C99875CAA1
    @Test()
    void evaluateWhenNEquals0ThrowsNoDataException() throws NullArgumentException, NoDataException {
        /* Branches:* (n == 0) : true*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{};
        //Act Statement(s)
        final NoDataException result = assertThrows(NoDataException.class, () -> {
            PolynomialFunction.evaluate(doubleArray, Double.parseDouble("0.0"));
        });
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${616bcb05-650c-3682-a2c8-74b6dca3fff7}, hash: F39E072B83A903ABA6DF7249EF7ED9F5
    @Test()
    void evaluateWhenJGreaterThanOrEqualsTo0() throws NullArgumentException, NoDataException {
        /* Branches:* (n == 0) : false* (j >= 0) : true*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0.0"), Double.parseDouble("1.0")};
        //Act Statement(s)
        double result = PolynomialFunction.evaluate(doubleArray, Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, closeTo(Double.parseDouble("0.0"), 0.00001)));
    }

    //Sapient generated method id: ${3a2be1d1-bab5-38d3-a57c-efc0f0971151}, hash: 7CD056137EBB828B604900E91C71A605
    @Disabled()
    @Test()
    void value1WhenNEquals0ThrowsNoDataException() throws NullArgumentException, NoDataException {
        /* Branches:* (n == 0) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{};
        PolynomialFunction target = new PolynomialFunction(doubleArray);
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        //Act Statement(s)
        final NoDataException result = assertThrows(NoDataException.class, () -> {
            target.value(derivativeStructure);
        });
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${9eb7becc-61af-3272-9d5e-a8bcff259a90}, hash: D62A0E642C7BC766C74621051E37D6BA
    @Test()
    void value1WhenJGreaterThanOrEqualsTo0() throws NullArgumentException, NoDataException {
        /* Branches:* (n == 0) : false* (j >= 0) : true*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("1"), Double.parseDouble("0.0")};
        PolynomialFunction target = new PolynomialFunction(doubleArray);
        DerivativeStructure derivativeStructure = new DerivativeStructure(0, 0);
        //Act Statement(s)
        DerivativeStructure result = target.value(derivativeStructure);
        DerivativeStructure derivativeStructure2 = new DerivativeStructure(0, 0, Double.parseDouble("1.0"));
        DerivativeStructure derivativeStructure3 = derivativeStructure2.multiply(derivativeStructure);
        DerivativeStructure derivativeStructure4 = derivativeStructure3.add(Double.parseDouble("0.0"));
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(derivativeStructure4)));
    }

    //Sapient generated method id: ${f9a2ee3a-5ef3-3fb6-8347-782d7c578d86}, hash: 13CE4A4023AACBDFFFF60319FBDB0262
    @Test()
    void negateWhenDefaultBranch() throws NullArgumentException, NoDataException {
        /* Branches:* (i < coefficients.length) : true* (branch expression (line 63)) : true  #  inside <init> method* (branch expression (line 66)) : false  #  inside <init> method*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("1"), Double.parseDouble("0.0")};
        PolynomialFunction target = new PolynomialFunction(doubleArray);
        //Act Statement(s)
        PolynomialFunction result = target.negate();
        double[] doubleArray2 = new double[]{Double.parseDouble("-0.0"), Double.parseDouble("-1.0")};
        PolynomialFunction polynomialFunction = new PolynomialFunction(doubleArray2);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(polynomialFunction)));
    }

    //Sapient generated method id: ${909bf3aa-9651-3ba2-99c9-721ab8a14c5a}, hash: 86451D3753E3FFDD5C340CD2B82B5C63
    @Test()
    void differentiateWhenNEquals0ThrowsNoDataException() throws NullArgumentException, NoDataException {
        /* Branches:* (n == 0) : true*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{};
        //Act Statement(s)
        final NoDataException result = assertThrows(NoDataException.class, () -> {
            PolynomialFunction.differentiate(doubleArray);
        });
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${be070852-f623-3ab2-848e-beb6568ff25a}, hash: E817BB8C339B4019245FB8FAA56583BF
    @Test()
    void differentiateWhenNEquals1() throws NullArgumentException, NoDataException {
        /* Branches:* (n == 0) : false* (n == 1) : true*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0")};
        //Act Statement(s)
        double[] result = PolynomialFunction.differentiate(doubleArray);
        double[] doubleResultArray = new double[]{Double.parseDouble("0.0")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(doubleResultArray)));
    }

    //Sapient generated method id: ${b50e613d-7911-397a-8655-9f49e8e622f9}, hash: 5D93C59047ACECC99F07DB965A8E6697
    @Test()
    void differentiateWhenIGreaterThan0() throws NullArgumentException, NoDataException {
        /* Branches:* (n == 0) : false* (n == 1) : false* (i > 0) : true*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("1.0")};
        //Act Statement(s)
        double[] result = PolynomialFunction.differentiate(doubleArray);
        double[] doubleResultArray = new double[]{Double.parseDouble("1.0")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(doubleResultArray)));
    }

    //Sapient generated method id: ${59785edc-54ac-36c2-851b-70f5a367ccbd}, hash: 036F949ED445DD83D1F292FD51CDB96C
    @Test()
    void polynomialDerivativeWhenDefaultBranchThrowsNoDataException() throws NullArgumentException, NoDataException {
        /* Branches:* (branch expression (line 63)) : false  #  inside <init> method*/
        //Arrange Statement(s)
        try (MockedStatic<PolynomialFunction> polynomialFunction = mockStatic(PolynomialFunction.class)) {
            double[] doubleArray = new double[]{};
            double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
            polynomialFunction.when(() -> PolynomialFunction.differentiate(doubleArray2)).thenReturn(doubleArray);
            double[] doubleArray3 = new double[]{Double.parseDouble("0"), Double.parseDouble("0.0")};
            PolynomialFunction target = new PolynomialFunction(doubleArray3);
            //Act Statement(s)
            final NoDataException result = assertThrows(NoDataException.class, () -> {
                target.polynomialDerivative();
            });
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                polynomialFunction.verify(() -> PolynomialFunction.differentiate(doubleArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${714ba5ba-16c2-3cb0-96d1-2d9c5d8a9ba3}, hash: 6F13FDA647A92E6F97B307DC747302F8
    @Test()
    void polynomialDerivativeWhenDefaultBranch() throws NullArgumentException, NoDataException {
        /* Branches:* (branch expression (line 63)) : true  #  inside <init> method* (branch expression (line 66)) : false  #  inside <init> method*/
        //Arrange Statement(s)
        try (MockedStatic<PolynomialFunction> polynomialFunction = mockStatic(PolynomialFunction.class)) {
            double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("0.0")};
            double[] doubleArray2 = new double[]{Double.parseDouble("1.0"), Double.parseDouble("2.0"), Double.parseDouble("3.0")};
            polynomialFunction.when(() -> PolynomialFunction.differentiate(doubleArray2)).thenReturn(doubleArray);
            double[] doubleArray3 = new double[]{Double.parseDouble("1.0"), Double.parseDouble("2.0"), Double.parseDouble("3.0")};
            PolynomialFunction target = new PolynomialFunction(doubleArray3);
            //Act Statement(s)
            PolynomialFunction result = target.polynomialDerivative();
            PolynomialFunction polynomialFunction2 = new PolynomialFunction(doubleArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(polynomialFunction2));
                polynomialFunction.verify(() -> PolynomialFunction.differentiate(doubleArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${81243e3a-de21-35bb-acb2-f7960708263d}, hash: 081085F90DE8FA31EDFBC2B2A09BFD3B
    @Test()
    void toStringWhenCoefficientsLengthEquals1() throws NullArgumentException, NoDataException {
        /* Branches:* (coefficients[0] == 0.0) : true* (coefficients.length == 1) : true*/
        //Arrange Statement(s)
        double[] doubleArray = new double[]{Double.parseDouble("0"), Double.parseDouble("0.0")};
        PolynomialFunction target = new PolynomialFunction(doubleArray);
        //Act Statement(s)
        String result = target.toString();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("0")));
    }
}
