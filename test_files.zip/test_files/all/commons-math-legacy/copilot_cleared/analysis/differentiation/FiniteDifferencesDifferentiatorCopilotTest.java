package org.apache.commons.math4.legacy.analysis.differentiation;

import org.apache.commons.math4.legacy.analysis.UnivariateFunction;
import org.apache.commons.math4.legacy.analysis.UnivariateMatrixFunction;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.apache.commons.math4.legacy.exception.NumberIsTooLargeException;
import org.apache.commons.math4.legacy.exception.NumberIsTooSmallException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FiniteDifferencesDifferentiatorCopilotTest {

    @Test
    public void finiteDifferencesDifferentiatorReturnsCorrectValuesForPositiveInputs() {
        FiniteDifferencesDifferentiator fdd = new FiniteDifferencesDifferentiator(5, 0.1, -1.0, 1.0);
        assertEquals(5, fdd.getNbPoints());
        assertEquals(0.1, fdd.getStepSize(), 1e-10);
    }

    @Test
    public void finiteDifferencesDifferentiatorThrowsExceptionForZeroStepSize() {
        assertThrows(NotPositiveException.class, () -> new FiniteDifferencesDifferentiator(5, 0.0, -1.0, 1.0));
    }

    @Test
    public void finiteDifferencesDifferentiatorThrowsExceptionForNegativeStepSize() {
        assertThrows(NotPositiveException.class, () -> new FiniteDifferencesDifferentiator(5, -0.1, -1.0, 1.0));
    }

    @Test
    public void finiteDifferencesDifferentiatorThrowsExceptionForOnePoint() {
        assertThrows(NumberIsTooSmallException.class, () -> new FiniteDifferencesDifferentiator(1, 0.1, -1.0, 1.0));
    }

    @Test
    public void finiteDifferencesDifferentiatorThrowsExceptionForZeroPoints() {
        assertThrows(NumberIsTooSmallException.class, () -> new FiniteDifferencesDifferentiator(0, 0.1, -1.0, 1.0));
    }

    @Test
    public void finiteDifferencesDifferentiatorThrowsExceptionForNegativePoints() {
        assertThrows(NumberIsTooSmallException.class, () -> new FiniteDifferencesDifferentiator(-1, 0.1, -1.0, 1.0));
    }

    @Test
    public void finiteDifferencesDifferentiatorThrowsExceptionForInvalidBounds() {
        assertThrows(NumberIsTooLargeException.class, () -> new FiniteDifferencesDifferentiator(5, 0.1, -1.0, 0.5));
    }

    @Test
    public void getNbPointsReturnsCorrectValueForFivePoints() {
        FiniteDifferencesDifferentiator fdd = new FiniteDifferencesDifferentiator(5, 0.1);
        assertEquals(5, fdd.getNbPoints());
    }

    @Test
    public void getNbPointsReturnsCorrectValueForSevenPoints() {
        FiniteDifferencesDifferentiator fdd = new FiniteDifferencesDifferentiator(7, 0.1);
        assertEquals(7, fdd.getNbPoints());
    }

    @Test
    public void getNbPointsReturnsCorrectValueForOnePoint() {
        FiniteDifferencesDifferentiator fdd = new FiniteDifferencesDifferentiator(1, 0.1);
        assertEquals(1, fdd.getNbPoints());
    }

    @Test
    public void getStepSizeReturnsCorrectValueForPointOneStep() {
        FiniteDifferencesDifferentiator fdd = new FiniteDifferencesDifferentiator(5, 0.1);
        assertEquals(0.1, fdd.getStepSize(), 1e-10);
    }

    @Test
    public void getStepSizeReturnsCorrectValueForPointTwoStep() {
        FiniteDifferencesDifferentiator fdd = new FiniteDifferencesDifferentiator(7, 0.2);
        assertEquals(0.2, fdd.getStepSize(), 1e-10);
    }

    @Test
    public void getStepSizeReturnsCorrectValueForOneStep() {
        FiniteDifferencesDifferentiator fdd = new FiniteDifferencesDifferentiator(1, 1.0);
        assertEquals(1.0, fdd.getStepSize(), 1e-10);
    }
}
