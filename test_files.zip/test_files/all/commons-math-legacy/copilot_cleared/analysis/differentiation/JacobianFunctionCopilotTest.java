package org.apache.commons.math4.legacy.analysis.differentiation;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class JacobianFunctionCopilotTest {

    @Test
    public void jacobianFunctionConstructorHandlesNullFunction() {
        assertThrows(NullPointerException.class, () -> new JacobianFunction(null));
    }
}
