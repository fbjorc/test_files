package org.apache.commons.math4.legacy.analysis.differentiation;

import org.apache.commons.math4.legacy.analysis.differentiation.DerivativeStructure;
import org.apache.commons.math4.legacy.core.Field;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NumberIsTooLargeException;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.apache.commons.numbers.core.Precision.EPSILON;

public class DerivativeStructureCopilotTest {

    @Test
    public void constructorSetsCorrectValueForConstant() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        Assertions.assertEquals(3.0, ds.getValue());
    }

    @Test
    public void constructorSetsCorrectDerivativeForVariable() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1, 3.0);
        Assertions.assertEquals(1.0, ds.getPartialDerivative(1, 0));
    }

    @Test
    public void constructorThrowsForInvalidVariableIndex() {
        Assertions.assertThrows(NumberIsTooLargeException.class, () -> new DerivativeStructure(2, 2, 2, 3.0));
    }

    @Test
    public void constructorSetsZeroDerivativeForConstant() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        Assertions.assertEquals(0.0, ds.getPartialDerivative(1, 0));
    }

    @Test
    public void constructorSetsZeroDerivativeForNonInvolvedVariable() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0, 3.0);
        Assertions.assertEquals(0.0, ds.getPartialDerivative(0, 1));
    }

    @Test
    public void linearCombinationTwoParametersProducesCorrectResult() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0, 2.0);
        DerivativeStructure result = new DerivativeStructure(2.0, ds1, 3.0, ds2);
        Assert.assertEquals(10.0, result.getValue(), EPSILON);
    }

    @Test
    public void linearCombinationThreeParametersProducesCorrectResult() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0, 2.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, 0, 1.0);
        DerivativeStructure result = new DerivativeStructure(2.0, ds1, 3.0, ds2, 4.0, ds3);
        Assert.assertEquals(14.0, result.getValue(), EPSILON);
    }

    @Test
    public void linearCombinationFourParametersProducesCorrectResult() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0, 2.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, 0, 1.0);
        DerivativeStructure ds4 = new DerivativeStructure(2, 2, 0, 0.5);
        DerivativeStructure result = new DerivativeStructure(2.0, ds1, 3.0, ds2, 4.0, ds3, 5.0, ds4);
        Assert.assertEquals(16.5, result.getValue(), EPSILON);
    }

    @Test
    public void constructorHandlesCorrectDerivativesSize() {
        int parameters = 2;
        int order = 2;
        double[] derivatives = new double[DSCompiler.getCompiler(parameters, order).getSize()];
        DerivativeStructure ds = new DerivativeStructure(parameters, order, derivatives);
        Assert.assertEquals(derivatives.length, ds.getAllDerivatives().length);
    }

    @Test
    public void constructorThrowsForIncorrectDerivativesSize() {
        int parameters = 2;
        int order = 2;
        double[] derivatives = new double[DSCompiler.getCompiler(parameters, order).getSize() + 1];
        Assert.assertThrows(DimensionMismatchException.class, () -> new DerivativeStructure(parameters, order, derivatives));
    }

    @Test
    public void constructorCorrectlyCopiesDerivatives() {
        int parameters = 2;
        int order = 2;
        double[] derivatives = new double[DSCompiler.getCompiler(parameters, order).getSize()];
        Arrays.fill(derivatives, 1.0);
        DerivativeStructure ds = new DerivativeStructure(parameters, order, derivatives);
        Assert.assertArrayEquals(derivatives, ds.getAllDerivatives(), EPSILON);
    }

    @Test
    public void getFreeParametersReturnsCorrectValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        Assertions.assertEquals(2, ds.getFreeParameters());
    }

    @Test
    public void getOrderReturnsCorrectValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        Assertions.assertEquals(2, ds.getOrder());
    }

    @Test
    public void createConstantCreatesCorrectDerivativeStructure() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure constant = ds.createConstant(5.0);
        Assertions.assertEquals(5.0, constant.getValue());
        Assertions.assertEquals(2, constant.getFreeParameters());
        Assertions.assertEquals(2, constant.getOrder());
    }

    @Test
    public void getValueReturnsCorrectValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        Assertions.assertEquals(3.0, ds.getValue());
    }

    @Test
    public void getRealReturnsCorrectValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        Assertions.assertEquals(3.0, ds.getReal());
    }

    @Test
    public void getValueReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        Assertions.assertEquals(0.0, ds.getValue());
    }

    @Test
    public void getRealReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        Assertions.assertEquals(0.0, ds.getReal());
    }

    @Test
    public void partialDerivativeReturnsCorrectValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1, 3.0);
        Assertions.assertEquals(1.0, ds.getPartialDerivative(1, 0));
    }

    @Test
    public void partialDerivativeThrowsForInvalidOrder() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1, 3.0);
        Assertions.assertThrows(NumberIsTooLargeException.class, () -> ds.getPartialDerivative(2, 2));
    }

    @Test
    public void allDerivativesReturnsCorrectArray() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1, 3.0);
        double[] derivatives = ds.getAllDerivatives();
        Assertions.assertEquals(6, derivatives.length);
        Assertions.assertEquals(3.0, derivatives[0]);
        Assertions.assertEquals(1.0, derivatives[1]);
        Assertions.assertEquals(0.0, derivatives[2]);
        Assertions.assertEquals(0.0, derivatives[3]);
        Assertions.assertEquals(0.0, derivatives[4]);
        Assertions.assertEquals(0.0, derivatives[5]);
    }

    @Test
    public void allDerivativesReturnsFreshCopy() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1, 3.0);
        double[] derivatives1 = ds.getAllDerivatives();
        double[] derivatives2 = ds.getAllDerivatives();
        Assertions.assertNotSame(derivatives1, derivatives2);
    }

    @Test
    public void addDoubleIncreasesValueByOperand() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.add(2.0);
        Assertions.assertEquals(5.0, result.getValue());
    }

    @Test
    public void addDoubleKeepsDerivativesUnchanged() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1, 3.0);
        DerivativeStructure result = ds.add(2.0);
        Assertions.assertEquals(1.0, result.getPartialDerivative(1, 0));
    }

    @Test
    public void addDerivativeStructureIncreasesValueByOperandValue() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds1.add(ds2);
        Assertions.assertEquals(5.0, result.getValue());
    }

    @Test
    public void addDerivativeStructureAddsDerivatives() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 1, 2.0);
        DerivativeStructure result = ds1.add(ds2);
        Assertions.assertEquals(2.0, result.getPartialDerivative(1, 0));
    }

    @Test
    public void subtractDoubleDecreasesValueByOperand() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.subtract(2.0);
        Assertions.assertEquals(1.0, result.getValue());
    }

    @Test
    public void subtractDoubleKeepsDerivativesUnchanged() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1, 3.0);
        DerivativeStructure result = ds.subtract(2.0);
        Assertions.assertEquals(1.0, result.getPartialDerivative(1, 0));
    }

    @Test
    public void subtractDoubleResultZeroForEqualValues() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.subtract(3.0);
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void subtractDerivativeStructureDecreasesValueByOperandValue() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds1.subtract(ds2);
        Assertions.assertEquals(1.0, result.getValue());
    }

    @Test
    public void subtractDerivativeStructureSubtractsDerivatives() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 1, 2.0);
        DerivativeStructure result = ds1.subtract(ds2);
        Assertions.assertEquals(0.0, result.getPartialDerivative(1, 0));
    }

    @Test
    public void subtractDerivativeStructureThrowsForIncompatibleParameters() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(3, 2, 2.0);
        Assertions.assertThrows(DimensionMismatchException.class, () -> ds1.subtract(ds2));
    }

    @Test
    public void multiplyByIntegerIncreasesValueByFactor() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.multiply(2);
        Assertions.assertEquals(6.0, result.getValue());
    }

    @Test
    public void multiplyByZeroReturnsZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.multiply(0);
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void multiplyByNegativeIntegerDecreasesValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.multiply(-2);
        Assertions.assertEquals(-6.0, result.getValue());
    }

    @Test
    public void multiplyByDoubleIncreasesValueByFactor() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.multiply(2.5);
        Assertions.assertEquals(7.5, result.getValue());
    }

    @Test
    public void multiplyByZeroDoubleReturnsZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.multiply(0.0);
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void multiplyByNegativeDoubleDecreasesValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.multiply(-2.5);
        Assertions.assertEquals(-7.5, result.getValue());
    }

    @Test
    public void multiplyDerivativeStructureIncreasesValueByFactor() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds1.multiply(ds2);
        Assertions.assertEquals(6.0, result.getValue());
    }

    @Test
    public void multiplyDerivativeStructureKeepsDerivativesUnchanged() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 1, 2.0);
        DerivativeStructure result = ds1.multiply(ds2);
        Assertions.assertEquals(1.0, result.getPartialDerivative(1, 0));
    }

    @Test
    public void multiplyDerivativeStructureThrowsForIncompatibleParameters() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(3, 2, 2.0);
        Assertions.assertThrows(DimensionMismatchException.class, () -> ds1.multiply(ds2));
    }

    @Test
    public void divideByDoubleDecreasesValueByFactor() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.divide(2.0);
        Assertions.assertEquals(1.5, result.getValue());
    }

    @Test
    public void divideByZeroDoubleThrowsException() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        Assertions.assertThrows(ArithmeticException.class, () -> ds.divide(0.0));
    }

    @Test
    public void divideByNegativeDoubleDecreasesValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.divide(-2.0);
        Assertions.assertEquals(-1.5, result.getValue());
    }

    @Test
    public void divideDerivativeStructureReturnsCorrectQuotient() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 6.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds1.divide(ds2);
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void divideDerivativeStructureThrowsForZeroDivisor() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0.0);
        Assertions.assertThrows(ArithmeticException.class, () -> ds1.divide(ds2));
    }

    @Test
    public void divideDerivativeStructureReturnsNegativeForNegativeDivisor() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, -2.0);
        DerivativeStructure result = ds1.divide(ds2);
        Assertions.assertEquals(-1.5, result.getValue());
    }

    @Test
    public void remainderDoubleReturnsCorrectRemainder() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 7.0);
        DerivativeStructure result = ds.remainder(3.0);
        Assertions.assertEquals(1.0, result.getValue());
    }

    @Test
    public void remainderDoubleThrowsForZeroDivisor() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        Assertions.assertThrows(ArithmeticException.class, () -> ds.remainder(0.0));
    }

    @Test
    public void remainderDoubleReturnsNegativeForNegativeDivisor() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 7.0);
        DerivativeStructure result = ds.remainder(-3.0);
        Assertions.assertEquals(1.0, result.getValue());
    }

    @Test
    public void remainderDerivativeStructureReturnsCorrectRemainder() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 7.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds1.remainder(ds2);
        Assertions.assertEquals(1.0, result.getValue());
    }

    @Test
    public void remainderDerivativeStructureThrowsForZeroDivisor() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0.0);
        Assertions.assertThrows(ArithmeticException.class, () -> ds1.remainder(ds2));
    }

    @Test
    public void remainderDerivativeStructureReturnsNegativeForNegativeDivisor() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 7.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, -3.0);
        DerivativeStructure result = ds1.remainder(ds2);
        Assertions.assertEquals(1.0, result.getValue());
    }

    @Test
    public void negateReturnsNegativeOfValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.negate();
        Assertions.assertEquals(-3.0, result.getValue());
    }

    @Test
    public void negateReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.negate();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void negateReturnsPositiveForNegativeValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -3.0);
        DerivativeStructure result = ds.negate();
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void absReturnsPositiveForNegativeValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -3.0);
        DerivativeStructure result = ds.abs();
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void absReturnsPositiveForPositiveValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.abs();
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void absReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.abs();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void ceilReturnsNextHighestWholeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.5);
        DerivativeStructure result = ds.ceil();
        Assertions.assertEquals(4.0, result.getValue());
    }

    @Test
    public void ceilReturnsSameNumberForWholeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.ceil();
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void ceilReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.ceil();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void floorReturnsCorrectFloorValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.5);
        DerivativeStructure result = ds.floor();
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void floorReturnsSameForWholeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.floor();
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void floorReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.floor();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void rintReturnsCorrectRoundedValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.5);
        DerivativeStructure result = ds.rint();
        Assertions.assertEquals(4.0, result.getValue());
    }

    @Test
    public void rintReturnsSameForWholeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.rint();
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void rintReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.rint();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void roundReturnsCorrectRoundedValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.5);
        long result = ds.round();
        Assertions.assertEquals(4, result);
    }

    @Test
    public void roundReturnsSameForWholeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        long result = ds.round();
        Assertions.assertEquals(3, result);
    }

    @Test
    public void roundReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        long result = ds.round();
        Assertions.assertEquals(0, result);
    }

    @Test
    public void signumReturnsPositiveForPositiveValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.signum();
        Assertions.assertEquals(1.0, result.getValue());
    }

    @Test
    public void signumReturnsNegativeForNegativeValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -3.0);
        DerivativeStructure result = ds.signum();
        Assertions.assertEquals(-1.0, result.getValue());
    }

    @Test
    public void signumReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.signum();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void copySignReturnsPositiveForPositiveSign() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -3.0);
        DerivativeStructure sign = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.copySign(sign);
        Assertions.assertTrue(result.getValue() > 0);
    }

    @Test
    public void copySignReturnsNegativeForNegativeSign() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure sign = new DerivativeStructure(2, 2, -2.0);
        DerivativeStructure result = ds.copySign(sign);
        Assertions.assertTrue(result.getValue() < 0);
    }

    @Test
    public void copySignReturnsZeroForZeroSign() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure sign = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.copySign(sign);
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void copySignWithDoubleReturnsPositiveForPositiveSign() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -3.0);
        DerivativeStructure result = ds.copySign(2.0);
        Assertions.assertTrue(result.getValue() > 0);
    }

    @Test
    public void copySignWithDoubleReturnsNegativeForNegativeSign() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.copySign(-2.0);
        Assertions.assertTrue(result.getValue() < 0);
    }

    @Test
    public void copySignWithDoubleReturnsZeroForZeroSign() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.copySign(0.0);
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void getExponentReturnsCorrectExponentForPositiveValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 8.0); // 8.0 is 2^3
        int result = ds.getExponent();
        Assertions.assertEquals(3, result);
    }

    @Test
    public void getExponentReturnsCorrectExponentForNegativeValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -8.0); // -8.0 is -2^3
        int result = ds.getExponent();
        Assertions.assertEquals(3, result);
    }

    @Test
    public void getExponentReturnsZeroForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        int result = ds.getExponent();
        Assertions.assertEquals(0, result);
    }

    @Test
    public void scalbMultipliesByPowerOfTwoForPositiveN() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.scalb(2); // 3.0 * 2^2 = 12.0
        Assertions.assertEquals(12.0, result.getValue());
    }

    @Test
    public void scalbDividesByPowerOfTwoForNegativeN() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.scalb(-2); // 3.0 / 2^2 = 0.75
        Assertions.assertEquals(0.75, result.getValue());
    }

    @Test
    public void scalbReturnsSameValueForZeroN() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds.scalb(0); // 3.0 * 2^0 = 3.0
        Assertions.assertEquals(3.0, result.getValue());
    }

    @Test
    public void hypotReturnsPositiveInfinityForInfiniteInputs() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, Double.POSITIVE_INFINITY);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds1.hypot(ds2);
        Assertions.assertEquals(Double.POSITIVE_INFINITY, result.getValue());

        ds1 = new DerivativeStructure(2, 2, 3.0);
        ds2 = new DerivativeStructure(2, 2, Double.POSITIVE_INFINITY);
        result = ds1.hypot(ds2);
        Assertions.assertEquals(Double.POSITIVE_INFINITY, result.getValue());
    }

    @Test
    public void hypotReturnsNaNForNaNInputs() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, Double.NaN);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds1.hypot(ds2);
        Assertions.assertEquals(Double.NaN, result.getValue());

        ds1 = new DerivativeStructure(2, 2, 3.0);
        ds2 = new DerivativeStructure(2, 2, Double.NaN);
        result = ds1.hypot(ds2);
        Assertions.assertEquals(Double.NaN, result.getValue());
    }

    @Test
    public void hypotReturnsAbsValueWhenOneInputIsNegligible() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, Math.pow(2, 28));
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds1.hypot(ds2);
        Assertions.assertEquals(ds1.abs().getValue(), result.getValue(), 1e-10);

        result = ds2.hypot(ds1);
        Assertions.assertEquals(ds1.abs().getValue(), result.getValue(), 1e-10);
    }

    @Test
    public void hypotReturnsCorrectValueForNonNegligibleInputs() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 4.0);
        DerivativeStructure result = ds1.hypot(ds2);
        Assertions.assertEquals(5.0, result.getValue(), 1e-10);
    }

    @Test
    public void composeReturnsCorrectValueForNonNegligibleInputs() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        double[] f = new double[]{2.0, 3.0, 4.0};
        DerivativeStructure result = ds.compose(f);
        Assertions.assertEquals(2.0, result.getValue());
    }

    @Test
    public void composeThrowsForInvalidOrder() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 3.0);
        double[] f = new double[]{2.0, 3.0};
        Assertions.assertThrows(DimensionMismatchException.class, () -> ds.compose(f));
    }

    @Test
    public void composeReturnsCorrectValueForZeroValue() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        double[] f = new double[]{2.0, 3.0, 4.0};
        DerivativeStructure result = ds.compose(f);
        Assertions.assertEquals(2.0, result.getValue());
    }

    @Test
    public void reciprocalOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.reciprocal();
        Assertions.assertEquals(0.5, result.getValue(), 1e-10);
    }

    @Test
    public void reciprocalOfNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -2.0);
        DerivativeStructure result = ds.reciprocal();
        Assertions.assertEquals(-0.5, result.getValue(), 1e-10);
    }

    @Test
    public void reciprocalOfZeroThrowsException() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        Assertions.assertThrows(ArithmeticException.class, ds::reciprocal);
    }

    @Test
    public void sqrtOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 4.0);
        DerivativeStructure result = ds.sqrt();
        Assertions.assertEquals(2.0, result.getValue(), 1e-10);
    }

    @Test
    public void sqrtOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.sqrt();
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void sqrtOfNegativeNumberThrowsException() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -4.0);
        Assertions.assertThrows(ArithmeticException.class, ds::sqrt);
    }

    @Test
    public void cbrtOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 8.0);
        DerivativeStructure result = ds.cbrt();
        Assertions.assertEquals(2.0, result.getValue(), 1e-10);
    }

    @Test
    public void cbrtOfNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -8.0);
        DerivativeStructure result = ds.cbrt();
        Assertions.assertEquals(-2.0, result.getValue(), 1e-10);
    }

    @Test
    public void cbrtOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.cbrt();
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void rootNOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 8.0);
        DerivativeStructure result = ds.rootN(3);
        Assertions.assertEquals(2.0, result.getValue(), 1e-10);
    }

    @Test
    public void rootNOfNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -8.0);
        DerivativeStructure result = ds.rootN(3);
        Assertions.assertEquals(-2.0, result.getValue(), 1e-10);
    }

    @Test
    public void rootNOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.rootN(3);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void getFieldReturnsCorrectField() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        Field<DerivativeStructure> field = ds.getField();
        Assertions.assertNotNull(field);
        Assertions.assertEquals(DerivativeStructure.class, field.getOne().getClass());
    }

    @Test
    public void getFieldZeroReturnsZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        Field<DerivativeStructure> field = ds.getField();
        Assertions.assertEquals(0.0, field.getZero().getValue(), 1e-10);
    }

    @Test
    public void getFieldOneReturnsOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        Field<DerivativeStructure> field = ds.getField();
        Assertions.assertEquals(1.0, field.getOne().getValue(), 1e-10);
    }

    @Test
    public void powReturnsCorrectValueForPositiveBaseAndExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = DerivativeStructure.pow(2.0, ds);
        Assertions.assertEquals(4.0, result.getValue(), 1e-10);
    }

    @Test
    public void powReturnsOneForZeroExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = DerivativeStructure.pow(2.0, ds);
        Assertions.assertEquals(1.0, result.getValue(), 1e-10);
    }

    @Test
    public void powReturnsZeroForZeroBaseAndPositiveExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = DerivativeStructure.pow(0.0, ds);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void powWithPositiveDoubleExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.pow(2.0);
        Assertions.assertEquals(4.0, result.getValue(), 1e-10);
    }

    @Test
    public void powWithZeroDoubleExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.pow(0.0);
        Assertions.assertEquals(1.0, result.getValue(), 1e-10);
    }

    @Test
    public void powWithNegativeDoubleExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.pow(-1.0);
        Assertions.assertEquals(0.5, result.getValue(), 1e-10);
    }

    @Test
    public void powWithPositiveIntegerExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.pow(2);
        Assertions.assertEquals(4.0, result.getValue(), 1e-10);
    }

    @Test
    public void powWithZeroIntegerExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.pow(0);
        Assertions.assertEquals(1.0, result.getValue(), 1e-10);
    }

    @Test
    public void powWithNegativeIntegerExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.pow(-1);
        Assertions.assertEquals(0.5, result.getValue(), 1e-10);
    }

    @Test
    public void powWithPositiveExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure exponent = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.pow(exponent);
        Assertions.assertEquals(4.0, result.getValue(), 1e-10);
    }

    @Test
    public void powWithZeroExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure exponent = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.pow(exponent);
        Assertions.assertEquals(1.0, result.getValue(), 1e-10);
    }

    @Test
    public void powWithNegativeExponent() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure exponent = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = ds.pow(exponent);
        Assertions.assertEquals(0.5, result.getValue(), 1e-10);
    }

    @Test
    public void expOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.exp();
        Assertions.assertEquals(Math.exp(2.0), result.getValue(), 1e-10);
    }

    @Test
    public void expOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.exp();
        Assertions.assertEquals(1.0, result.getValue(), 1e-10);
    }

    @Test
    public void expOfNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -2.0);
        DerivativeStructure result = ds.exp();
        Assertions.assertEquals(Math.exp(-2.0), result.getValue(), 1e-10);
    }

    @Test
    public void expm1ForPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.expm1();
        Assertions.assertEquals(Math.expm1(2.0), result.getValue(), 1e-10);
    }

    @Test
    public void expm1ForZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.expm1();
        Assertions.assertEquals(Math.expm1(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void expm1ForNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -2.0);
        DerivativeStructure result = ds.expm1();
        Assertions.assertEquals(Math.expm1(-2.0), result.getValue(), 1e-10);
    }

    @Test
    public void logForPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.log();
        Assertions.assertEquals(Math.log(2.0), result.getValue(), 1e-10);
    }

    @Test
    public void logForOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds.log();
        Assertions.assertEquals(Math.log(1.0), result.getValue(), 1e-10);
    }

    @Test
    public void logForLessThanOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.5);
        DerivativeStructure result = ds.log();
        Assertions.assertEquals(Math.log(0.5), result.getValue(), 1e-10);
    }

    @Test
    public void log1pOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.log1p();
        Assertions.assertEquals(Math.log1p(2.0), result.getValue(), 1e-10);
    }

    @Test
    public void log1pOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.log1p();
        Assertions.assertEquals(Math.log1p(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void log1pOfNegativeFraction() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -0.5);
        DerivativeStructure result = ds.log1p();
        Assertions.assertEquals(Math.log1p(-0.5), result.getValue(), 1e-10);
    }

    @Test
    public void log10OfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds.log10();
        Assertions.assertEquals(Math.log10(2.0), result.getValue(), 1e-10);
    }

    @Test
    public void log10OfOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds.log10();
        Assertions.assertEquals(Math.log10(1.0), result.getValue(), 1e-10);
    }

    @Test
    public void log10OfFraction() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.5);
        DerivativeStructure result = ds.log10();
        Assertions.assertEquals(Math.log10(0.5), result.getValue(), 1e-10);
    }

    @Test
    public void cosOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.cos();
        Assertions.assertEquals(Math.cos(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void cosOfPiOverTwo() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, Math.PI / 2);
        DerivativeStructure result = ds.cos();
        Assertions.assertEquals(Math.cos(Math.PI / 2), result.getValue(), 1e-10);
    }

    @Test
    public void cosOfPi() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, Math.PI);
        DerivativeStructure result = ds.cos();
        Assertions.assertEquals(Math.cos(Math.PI), result.getValue(), 1e-10);
    }

    @Test
    public void sinOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.sin();
        Assertions.assertEquals(Math.sin(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void sinOfPiOverTwo() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, Math.PI / 2);
        DerivativeStructure result = ds.sin();
        Assertions.assertEquals(Math.sin(Math.PI / 2), result.getValue(), 1e-10);
    }

    @Test
    public void sinOfPi() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, Math.PI);
        DerivativeStructure result = ds.sin();
        Assertions.assertEquals(Math.sin(Math.PI), result.getValue(), 1e-10);
    }

    @Test
    public void tanOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.tan();
        Assertions.assertEquals(Math.tan(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void tanOfPiOverFour() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, Math.PI / 4);
        DerivativeStructure result = ds.tan();
        Assertions.assertEquals(Math.tan(Math.PI / 4), result.getValue(), 1e-10);
    }

    @Test
    public void tanOfPiOverTwo() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, Math.PI / 2);
        DerivativeStructure result = ds.tan();
        Assertions.assertEquals(Math.tan(Math.PI / 2), result.getValue(), 1e-10);
    }

    @Test
    public void acosOfOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds.acos();
        Assertions.assertEquals(Math.acos(1.0), result.getValue(), 1e-10);
    }

    @Test
    public void acosOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.acos();
        Assertions.assertEquals(Math.acos(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void acosOfNegativeOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = ds.acos();
        Assertions.assertEquals(Math.acos(-1.0), result.getValue(), 1e-10);
    }

    @Test
    public void asinOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.asin();
        Assertions.assertEquals(Math.asin(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void asinOfOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds.asin();
        Assertions.assertEquals(Math.asin(1.0), result.getValue(), 1e-10);
    }

    @Test
    public void asinOfNegativeOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = ds.asin();
        Assertions.assertEquals(Math.asin(-1.0), result.getValue(), 1e-10);
    }

    @Test
    public void atanOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.atan();
        Assertions.assertEquals(Math.atan(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void atanOfOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds.atan();
        Assertions.assertEquals(Math.atan(1.0), result.getValue(), 1e-10);
    }

    @Test
    public void atanOfNegativeOne() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = ds.atan();
        Assertions.assertEquals(Math.atan(-1.0), result.getValue(), 1e-10);
    }

    @Test
    public void atan2WithPositiveArguments() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = DerivativeStructure.atan2(ds1, ds2);
        Assertions.assertEquals(Math.atan2(1.0, 1.0), result.getValue(), 1e-10);
    }

    @Test
    public void atan2WithNegativeArguments() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = DerivativeStructure.atan2(ds1, ds2);
        Assertions.assertEquals(Math.atan2(-1.0, -1.0), result.getValue(), 1e-10);
    }

    @Test
    public void atan2WithZeroArguments() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = DerivativeStructure.atan2(ds1, ds2);
        Assertions.assertEquals(Math.atan2(0.0, 0.0), result.getValue(), 1e-10);
    }

    @Test
    public void atan2InstanceMethodWithPositiveArguments() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds1.atan2(ds2);
        Assertions.assertEquals(Math.atan2(1.0, 1.0), result.getValue(), 1e-10);
    }

    @Test
    public void atan2InstanceMethodWithNegativeArguments() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = ds1.atan2(ds2);
        Assertions.assertEquals(Math.atan2(-1.0, -1.0), result.getValue(), 1e-10);
    }

    @Test
    public void atan2InstanceMethodWithZeroArguments() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds1.atan2(ds2);
        Assertions.assertEquals(Math.atan2(0.0, 0.0), result.getValue(), 1e-10);
    }

    @Test
    public void coshOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.cosh();
        Assertions.assertEquals(Math.cosh(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void coshOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds.cosh();
        Assertions.assertEquals(Math.cosh(1.0), result.getValue(), 1e-10);
    }

    @Test
    public void coshOfNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = ds.cosh();
        Assertions.assertEquals(Math.cosh(-1.0), result.getValue(), 1e-10);
    }

    @Test
    public void sinhOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.sinh();
        Assertions.assertEquals(Math.sinh(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void sinhOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds.sinh();
        Assertions.assertEquals(Math.sinh(1.0), result.getValue(), 1e-10);
    }

    @Test
    public void sinhOfNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = ds.sinh();
        Assertions.assertEquals(Math.sinh(-1.0), result.getValue(), 1e-10);
    }

    @Test
    public void tanhOfZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.tanh();
        Assertions.assertEquals(Math.tanh(0.0), result.getValue(), 1e-10);
    }

    @Test
    public void tanhOfPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure result = ds.tanh();
        Assertions.assertEquals(Math.tanh(1.0), result.getValue(), 1e-10);
    }

    @Test
    public void tanhOfNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure result = ds.tanh();
        Assertions.assertEquals(Math.tanh(-1.0), result.getValue(), 1e-10);
    }

    @Test
    public void conversionToDegreesWithZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.toDegrees();
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void conversionToDegreesWithPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, Math.PI);
        DerivativeStructure result = ds.toDegrees();
        Assertions.assertEquals(180.0, result.getValue(), 1e-10);
    }

    @Test
    public void conversionToDegreesWithNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -Math.PI);
        DerivativeStructure result = ds.toDegrees();
        Assertions.assertEquals(-180.0, result.getValue(), 1e-10);
    }

    @Test
    public void conversionToRadiansWithZero() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds.toRadians();
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void conversionToRadiansWithPositiveNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, 180.0);
        DerivativeStructure result = ds.toRadians();
        Assertions.assertEquals(Math.PI, result.getValue(), 1e-10);
    }

    @Test
    public void conversionToRadiansWithNegativeNumber() {
        DerivativeStructure ds = new DerivativeStructure(2, 2, -180.0);
        DerivativeStructure result = ds.toRadians();
        Assertions.assertEquals(-Math.PI, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationWithPositiveValues() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds1.linearCombination(new DerivativeStructure[]{ds1, ds2}, new DerivativeStructure[]{ds1, ds2});
        Assertions.assertEquals(ds1.getValue() * ds1.getValue() + ds2.getValue() * ds2.getValue(), result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationWithZeroValues() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds1.linearCombination(new DerivativeStructure[]{ds1, ds2}, new DerivativeStructure[]{ds1, ds2});
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationWithNegativeValues() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, -2.0);
        DerivativeStructure result = ds1.linearCombination(new DerivativeStructure[]{ds1, ds2}, new DerivativeStructure[]{ds1, ds2});
        Assertions.assertEquals(ds1.getValue() * ds1.getValue() + ds2.getValue() * ds2.getValue(), result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationProducesCorrectResult() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure ds4 = new DerivativeStructure(2, 2, 4.0);
        DerivativeStructure result = ds1.linearCombination(ds1, ds2, ds3, ds4);
        Assertions.assertEquals(14.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationWithZeroValuesProducesZeroResult() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure ds4 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds1.linearCombination(ds1, ds2, ds3, ds4);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationWithNegativeValuesProducesCorrectResult() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, -2.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, -3.0);
        DerivativeStructure ds4 = new DerivativeStructure(2, 2, -4.0);
        DerivativeStructure result = ds1.linearCombination(ds1, ds2, ds3, ds4);
        Assertions.assertEquals(14.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationWithZeroCoefficientsProducesZeroResult() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds1.linearCombination(0.0, ds1, 0.0, ds2);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationWithNegativeCoefficientsProducesCorrectResult() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure result = ds1.linearCombination(-1.0, ds1, -2.0, ds2);
        Assertions.assertEquals(-5.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationProducesAccurateValue() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds1.linearCombination(ds1, ds2, ds1, ds3, ds2, ds3);
        Assertions.assertEquals(14.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationProducesAccurateValueWithPositiveInputs() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, 3.0);
        DerivativeStructure result = ds1.linearCombination(1.0, ds1, 2.0, ds2, 3.0, ds3);
        Assertions.assertEquals(14.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationProducesZeroWithZeroInputs() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, 0.0);
        DerivativeStructure result = ds1.linearCombination(0.0, ds1, 0.0, ds2, 0.0, ds3);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
    }

    @Test
    public void linearCombinationProducesAccurateValueWithNegativeInputs() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, -1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, -2.0);
        DerivativeStructure ds3 = new DerivativeStructure(2, 2, -3.0);
        DerivativeStructure result = ds1.linearCombination(-1.0, ds1, -2.0, ds2, -3.0, ds3);
        Assertions.assertEquals(-14.0, result.getValue(), 1e-10);
    }

    @Test
    public void equalsReturnsTrueForSameInstance() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        Assertions.assertTrue(ds1.equals(ds1));
    }

    @Test
    public void equalsReturnsFalseForDifferentInstance() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        Assertions.assertFalse(ds1.equals(ds2));
    }

    @Test
    public void equalsReturnsFalseForNonDerivativeStructure() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        Assertions.assertFalse(ds1.equals(new Object()));
    }

    @Test
    public void hashCodeIsConsistentWithEquals() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 1.0);
        Assertions.assertEquals(ds1.hashCode(), ds2.hashCode());
    }

    @Test
    public void hashCodeIsDifferentForDifferentValues() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 2, 2.0);
        Assertions.assertNotEquals(ds1.hashCode(), ds2.hashCode());
    }

    @Test
    public void hashCodeIsDifferentForDifferentOrders() {
        DerivativeStructure ds1 = new DerivativeStructure(2, 2, 1.0);
        DerivativeStructure ds2 = new DerivativeStructure(2, 3, 1.0);
        Assertions.assertNotEquals(ds1.hashCode(), ds2.hashCode());
    }
}


