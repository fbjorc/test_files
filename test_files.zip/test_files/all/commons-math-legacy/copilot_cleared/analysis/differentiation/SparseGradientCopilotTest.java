package org.apache.commons.math4.legacy.analysis.differentiation;

import org.apache.commons.math4.core.jdkmath.JdkMath;
import org.apache.commons.math4.legacy.analysis.differentiation.SparseGradient;
import org.apache.commons.math4.legacy.core.Field;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class SparseGradientCopilotTest {

    @Test
    public void numVarsReturnsCorrectNumberForConstant() {
        SparseGradient result = SparseGradient.createConstant(5.0);
        Assertions.assertEquals(0, result.numVars());
    }

    @Test
    public void numVarsReturnsCorrectNumberForSingleVariable() {
        SparseGradient result = SparseGradient.createVariable(1, 5.0);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void numVarsReturnsCorrectNumberForSumOfVariables() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.add(b);
        Assertions.assertEquals(2, result.numVars());
    }

    @Test
    public void getDerivativeReturnsCorrectForExistingIndex() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        Assertions.assertEquals(1.0, a.getDerivative(1));
    }

    @Test
    public void getDerivativeReturnsZeroForNonExistingIndex() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        Assertions.assertEquals(0.0, a.getDerivative(2));
    }

    @Test
    public void getValueReturnsCorrectForConstant() {
        SparseGradient result = SparseGradient.createConstant(5.0);
        Assertions.assertEquals(5.0, result.getValue());
    }

    @Test
    public void getValueReturnsCorrectForVariable() {
        SparseGradient result = SparseGradient.createVariable(1, 5.0);
        Assertions.assertEquals(5.0, result.getValue());
    }

    @Test
    public void getValueReturnsCorrectForSumOfVariables() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.add(b);
        Assertions.assertEquals(8.0, result.getValue());
    }

    @Test
    public void getRealReturnsCorrectForConstant() {
        SparseGradient result = SparseGradient.createConstant(5.0);
        Assertions.assertEquals(5.0, result.getReal());
    }

    @Test
    public void getRealReturnsCorrectForVariable() {
        SparseGradient result = SparseGradient.createVariable(1, 5.0);
        Assertions.assertEquals(5.0, result.getReal());
    }

    @Test
    public void getRealReturnsCorrectForSumOfVariables() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.add(b);
        Assertions.assertEquals(8.0, result.getReal());
    }

    @Test
    public void additionOfSparseGradientsReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.add(b);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
        Assertions.assertEquals(1.0, result.getDerivative(2));
    }

    @Test
    public void additionOfSparseGradientsWithNoCommonDerivativesReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.add(b);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
        Assertions.assertEquals(1.0, result.getDerivative(2));
    }

    @Test
    public void additionOfSparseGradientsWithCommonDerivativesReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(1, 3.0);
        SparseGradient result = a.add(b);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(2.0, result.getDerivative(1));
    }

    @Test
    public void addInPlaceCorrectlyAddsValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        a.addInPlace(b);
        Assertions.assertEquals(8.0, a.getValue());
        Assertions.assertEquals(1.0, a.getDerivative(1));
        Assertions.assertEquals(1.0, a.getDerivative(2));
    }

    @Test
    public void addInPlaceCorrectlyAddsWhenDerivativesAreNull() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createConstant(3.0);
        a.addInPlace(b);
        Assertions.assertEquals(8.0, a.getValue());
        Assertions.assertEquals(1.0, a.getDerivative(1));
    }

    @Test
    public void addInPlaceCorrectlyAddsWhenDerivativesExist() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(1, 3.0);
        a.addInPlace(b);
        Assertions.assertEquals(8.0, a.getValue());
        Assertions.assertEquals(2.0, a.getDerivative(1));
    }

    @Test
    public void addWithConstantIncreasesValueAndPreservesDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.add(3.0);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void addWithZeroDoesNotChangeValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.add(0.0);
        Assertions.assertEquals(5.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void addWithNegativeConstantDecreasesValueAndPreservesDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.add(-3.0);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void subtractSparseGradientsReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.subtract(b);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
        Assertions.assertEquals(-1.0, result.getDerivative(2));
    }

    @Test
    public void subtractSparseGradientsWithCommonDerivativesReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(1, 3.0);
        SparseGradient result = a.subtract(b);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void subtractSparseGradientsWithNoCommonDerivativesReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createConstant(3.0);
        SparseGradient result = a.subtract(b);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void subtractConstantDecreasesValueAndPreservesDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.subtract(3.0);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void subtractZeroLeavesValueAndDerivativesUnchanged() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.subtract(0.0);
        Assertions.assertEquals(5.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void subtractNegativeConstantIncreasesValueAndPreservesDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.subtract(-3.0);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void multiplySparseGradientsReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient b = SparseGradient.createVariable(2, 2.0);
        SparseGradient result = a.multiply(b);
        Assertions.assertEquals(6.0, result.getValue());
        Assertions.assertEquals(2.0, result.getDerivative(1));
        Assertions.assertEquals(3.0, result.getDerivative(2));
    }

    @Test
    public void multiplySparseGradientsWithCommonDerivativesReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient b = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.multiply(b);
        Assertions.assertEquals(6.0, result.getValue());
        Assertions.assertEquals(4.0, result.getDerivative(1));
    }

    @Test
    public void multiplySparseGradientsWithNoCommonDerivativesReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient b = SparseGradient.createConstant(2.0);
        SparseGradient result = a.multiply(b);
        Assertions.assertEquals(6.0, result.getValue());
        Assertions.assertEquals(2.0, result.getDerivative(1));
    }

    @Test
    public void multiplyInPlaceWithVariableIncreasesValueAndChangesDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        a.multiplyInPlace(b);
        Assertions.assertEquals(15.0, a.getValue());
        Assertions.assertEquals(3.0, a.getDerivative(1));
        Assertions.assertEquals(5.0, a.getDerivative(2));
    }

    @Test
    public void multiplyInPlaceWithConstantIncreasesValueAndPreservesDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createConstant(3.0);
        a.multiplyInPlace(b);
        Assertions.assertEquals(15.0, a.getValue());
        Assertions.assertEquals(3.0, a.getDerivative(1));
    }

    @Test
    public void multiplyInPlaceWithZeroSetsValueToZeroAndPreservesDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createConstant(0.0);
        a.multiplyInPlace(b);
        Assertions.assertEquals(0.0, a.getValue());
        Assertions.assertEquals(0.0, a.getDerivative(1));
    }

    @Test
    public void multiplyWithPositiveConstantReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient result = a.multiply(2.0);
        Assertions.assertEquals(6.0, result.getValue());
        Assertions.assertEquals(2.0, result.getDerivative(1));
    }

    @Test
    public void multiplyWithZeroConstantReturnsZeroValueAndZeroDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient result = a.multiply(0.0);
        Assertions.assertEquals(0.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void multiplyWithNegativeConstantReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient result = a.multiply(-2.0);
        Assertions.assertEquals(-6.0, result.getValue());
        Assertions.assertEquals(-2.0, result.getDerivative(1));
    }

    @Test
    public void multiplyWithPositiveIntegerReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient result = a.multiply(2);
        Assertions.assertEquals(6.0, result.getValue());
        Assertions.assertEquals(2.0, result.getDerivative(1));
    }

    @Test
    public void multiplyWithZeroIntegerReturnsZeroValueAndZeroDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient result = a.multiply(0);
        Assertions.assertEquals(0.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void multiplyWithNegativeIntegerReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 3.0);
        SparseGradient result = a.multiply(-2);
        Assertions.assertEquals(-6.0, result.getValue());
        Assertions.assertEquals(-2.0, result.getDerivative(1));
    }

    @Test
    public void divideByPositiveSparseGradientReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 6.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.divide(b);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0 / 3.0, result.getDerivative(1));
        Assertions.assertEquals(-2.0 / 3.0, result.getDerivative(2));
    }

    @Test
    public void divideByNegativeSparseGradientReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 6.0);
        SparseGradient b = SparseGradient.createVariable(2, -3.0);
        SparseGradient result = a.divide(b);
        Assertions.assertEquals(-2.0, result.getValue());
        Assertions.assertEquals(-1.0 / 3.0, result.getDerivative(1));
        Assertions.assertEquals(2.0 / 3.0, result.getDerivative(2));
    }

    @Test
    public void divideByZeroSparseGradientThrowsException() {
        SparseGradient a = SparseGradient.createVariable(1, 6.0);
        SparseGradient b = SparseGradient.createVariable(2, 0.0);
        Assertions.assertThrows(ArithmeticException.class, () -> a.divide(b));
    }

    @Test
    public void divideByPositiveDoubleReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 6.0);
        SparseGradient result = a.divide(3.0);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0 / 3.0, result.getDerivative(1));
    }

    @Test
    public void divideByZeroDoubleThrowsException() {
        SparseGradient a = SparseGradient.createVariable(1, 6.0);
        Assertions.assertThrows(ArithmeticException.class, () -> a.divide(0.0));
    }

    @Test
    public void divideByNegativeDoubleReturnsCorrectValueAndDerivatives() {
        SparseGradient a = SparseGradient.createVariable(1, 6.0);
        SparseGradient result = a.divide(-3.0);
        Assertions.assertEquals(-2.0, result.getValue());
        Assertions.assertEquals(-1.0 / 3.0, result.getDerivative(1));
    }

    @Test
    public void negatePositiveSparseGradientReturnsNegativeSparseGradient() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.negate();
        Assertions.assertEquals(-5.0, result.getValue());
        Assertions.assertEquals(-1.0, result.getDerivative(1));
    }

    @Test
    public void negateNegativeSparseGradientReturnsPositiveSparseGradient() {
        SparseGradient a = SparseGradient.createVariable(1, -5.0);
        SparseGradient result = a.negate();
        Assertions.assertEquals(5.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void negateZeroSparseGradientReturnsZeroSparseGradient() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.negate();
        Assertions.assertEquals(0.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void getFieldReturnsFieldWithCorrectZeroAndOne() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        Field<SparseGradient> field = a.getField();
        Assertions.assertEquals(0.0, field.getZero().getValue());
        Assertions.assertEquals(1.0, field.getOne().getValue());
    }

    @Test
    public void getFieldReturnsFieldWithCorrectRuntimeClass() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        Field<SparseGradient> field = a.getField();
        Assertions.assertEquals(SparseGradient.class, field.getRuntimeClass());
    }

    @Test
    public void remainderWithPositiveDoubleReturnsCorrectRemainder() {
        SparseGradient a = SparseGradient.createVariable(1, 10.0);
        SparseGradient result = a.remainder(3.0);
        Assertions.assertEquals(JdkMath.IEEEremainder(10.0, 3.0), result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void remainderWithNegativeDoubleReturnsCorrectRemainder() {
        SparseGradient a = SparseGradient.createVariable(1, 10.0);
        SparseGradient result = a.remainder(-3.0);
        Assertions.assertEquals(JdkMath.IEEEremainder(10.0, -3.0), result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void remainderWithZeroDoubleReturnsNaN() {
        SparseGradient a = SparseGradient.createVariable(1, 10.0);
        SparseGradient result = a.remainder(0.0);
        Assertions.assertTrue(Double.isNaN(result.getValue()));
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void remainderWithPositiveSparseGradientReturnsCorrectRemainder() {
        SparseGradient a = SparseGradient.createVariable(1, 10.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.remainder(b);
        Assertions.assertEquals(JdkMath.IEEEremainder(10.0, 3.0), result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void remainderWithNegativeSparseGradientReturnsCorrectRemainder() {
        SparseGradient a = SparseGradient.createVariable(1, 10.0);
        SparseGradient b = SparseGradient.createVariable(2, -3.0);
        SparseGradient result = a.remainder(b);
        Assertions.assertEquals(JdkMath.IEEEremainder(10.0, -3.0), result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void remainderWithZeroSparseGradientReturnsNaN() {
        SparseGradient a = SparseGradient.createVariable(1, 10.0);
        SparseGradient b = SparseGradient.createVariable(2, 0.0);
        SparseGradient result = a.remainder(b);
        Assertions.assertTrue(Double.isNaN(result.getValue()));
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void absReturnsPositiveSparseGradientForNegativeInput() {
        SparseGradient a = SparseGradient.createVariable(1, -5.0);
        SparseGradient result = a.abs();
        Assertions.assertEquals(5.0, result.getValue());
        Assertions.assertEquals(-1.0, result.getDerivative(1));
    }

    @Test
    public void absReturnsSameSparseGradientForPositiveInput() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.abs();
        Assertions.assertEquals(5.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void absReturnsPositiveSparseGradientForZeroInput() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.abs();
        Assertions.assertEquals(0.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void ceilRoundsUpToNearestIntegerForPositiveFraction() {
        SparseGradient a = SparseGradient.createVariable(1, 5.4);
        SparseGradient result = a.ceil();
        Assertions.assertEquals(6.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void ceilRoundsUpToNearestIntegerForNegativeFraction() {
        SparseGradient a = SparseGradient.createVariable(1, -5.4);
        SparseGradient result = a.ceil();
        Assertions.assertEquals(-5.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void ceilReturnsSameValueForPositiveInteger() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.ceil();
        Assertions.assertEquals(5.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void ceilReturnsSameValueForNegativeInteger() {
        SparseGradient a = SparseGradient.createVariable(1, -5.0);
        SparseGradient result = a.ceil();
        Assertions.assertEquals(-5.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void floorRoundsDownToNearestIntegerForPositiveFraction() {
        SparseGradient a = SparseGradient.createVariable(1, 5.4);
        SparseGradient result = a.floor();
        Assertions.assertEquals(5.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void floorRoundsDownToNearestIntegerForNegativeFraction() {
        SparseGradient a = SparseGradient.createVariable(1, -5.4);
        SparseGradient result = a.floor();
        Assertions.assertEquals(-6.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void floorReturnsSameValueForPositiveInteger() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.floor();
        Assertions.assertEquals(5.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void floorReturnsSameValueForNegativeInteger() {
        SparseGradient a = SparseGradient.createVariable(1, -5.0);
        SparseGradient result = a.floor();
        Assertions.assertEquals(-5.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void rintRoundsToNearestIntegerForPositiveFraction() {
        SparseGradient a = SparseGradient.createVariable(1, 5.4);
        SparseGradient result = a.rint();
        Assertions.assertEquals(5.0, result.getValue());
    }

    @Test
    public void rintRoundsToNearestIntegerForNegativeFraction() {
        SparseGradient a = SparseGradient.createVariable(1, -5.4);
        SparseGradient result = a.rint();
        Assertions.assertEquals(-5.0, result.getValue());
    }

    @Test
    public void rintReturnsSameValueForPositiveInteger() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.rint();
        Assertions.assertEquals(5.0, result.getValue());
    }

    @Test
    public void rintReturnsSameValueForNegativeInteger() {
        SparseGradient a = SparseGradient.createVariable(1, -5.0);
        SparseGradient result = a.rint();
        Assertions.assertEquals(-5.0, result.getValue());
    }

    @Test
    public void roundRoundsToNearestLongForPositiveFraction() {
        SparseGradient a = SparseGradient.createVariable(1, 5.4);
        long result = a.round();
        Assertions.assertEquals(5L, result);
    }

    @Test
    public void roundRoundsToNearestLongForNegativeFraction() {
        SparseGradient a = SparseGradient.createVariable(1, -5.4);
        long result = a.round();
        Assertions.assertEquals(-5L, result);
    }

    @Test
    public void roundReturnsSameValueForPositiveInteger() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        long result = a.round();
        Assertions.assertEquals(5L, result);
    }

    @Test
    public void roundReturnsSameValueForNegativeInteger() {
        SparseGradient a = SparseGradient.createVariable(1, -5.0);
        long result = a.round();
        Assertions.assertEquals(-5L, result);
    }

    @Test
    public void signumReturnsPositiveOneForPositiveValue() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.signum();
        Assertions.assertEquals(1.0, result.getValue());
    }

    @Test
    public void signumReturnsNegativeOneForNegativeValue() {
        SparseGradient a = SparseGradient.createVariable(1, -5.0);
        SparseGradient result = a.signum();
        Assertions.assertEquals(-1.0, result.getValue());
    }

    @Test
    public void signumReturnsZeroForZeroValue() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.signum();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void copySignReturnsSameInstanceWhenSignIsSame() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.copySign(b);
        Assertions.assertSame(a, result);
    }

    @Test
    public void copySignReturnsNegatedInstanceWhenSignIsDifferent() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient b = SparseGradient.createVariable(2, -3.0);
        SparseGradient result = a.copySign(b);
        Assertions.assertEquals(-5.0, result.getValue());
    }

    @Test
    public void copySignReturnsSameInstanceWhenBothValuesAreZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient b = SparseGradient.createVariable(2, 0.0);
        SparseGradient result = a.copySign(b);
        Assertions.assertSame(a, result);
    }

    @Test
    public void copySignReturnsNegatedInstanceWhenValueIsZeroAndSignIsNegative() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient b = SparseGradient.createVariable(2, -3.0);
        SparseGradient result = a.copySign(b);
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void copySignReturnsSameInstanceWhenSignIsPositive() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.copySign(3.0);
        Assertions.assertSame(a, result);
    }

    @Test
    public void copySignReturnsNegatedInstanceWhenSignIsNegative() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.copySign(-3.0);
        Assertions.assertEquals(-5.0, result.getValue());
    }

    @Test
    public void copySignReturnsSameInstanceWhenValueIsZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.copySign(3.0);
        Assertions.assertSame(a, result);
    }

    @Test
    public void copySignReturnsSameInstanceWhenSignIsZero() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.copySign(0.0);
        Assertions.assertSame(a, result);
    }

    @Test
    public void scalbScalesValueAndDerivativesByPowerOfTwo() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.scalb(2);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(4.0, result.getDerivative(1));
    }

    @Test
    public void scalbScalesValueAndDerivativesByZero() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.scalb(0);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void scalbScalesValueAndDerivativesByNegativePowerOfTwo() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.scalb(-2);
        Assertions.assertEquals(0.5, result.getValue());
        Assertions.assertEquals(0.25, result.getDerivative(1));
    }

    @Test
    public void hypotReturnsPositiveInfinityWhenOneValueIsInfinite() {
        SparseGradient a = SparseGradient.createVariable(1, Double.POSITIVE_INFINITY);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.hypot(b);
        Assertions.assertEquals(Double.POSITIVE_INFINITY, result.getValue());
    }

    @Test
    public void hypotReturnsNaNWhenOneValueIsNaN() {
        SparseGradient a = SparseGradient.createVariable(1, Double.NaN);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.hypot(b);
        Assertions.assertEquals(Double.NaN, result.getValue());
    }

    @Test
    public void hypotReturnsAbsWhenYIsNegligible() {
        SparseGradient a = SparseGradient.createVariable(1, Math.pow(2, 30));
        SparseGradient b = SparseGradient.createVariable(2, 1.0);
        SparseGradient result = a.hypot(b);
        Assertions.assertEquals(a.abs().getValue(), result.getValue());
    }

    @Test
    public void hypotReturnsAbsWhenXIsNegligible() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient b = SparseGradient.createVariable(2, Math.pow(2, 30));
        SparseGradient result = a.hypot(b);
        Assertions.assertEquals(b.abs().getValue(), result.getValue());
    }

    @Test
    public void reciprocalReturnsCorrectValueForPositiveInput() {
        SparseGradient a = SparseGradient.createVariable(1, 5.0);
        SparseGradient result = a.reciprocal();
        Assertions.assertEquals(0.2, result.getValue());
    }

    @Test
    public void reciprocalReturnsCorrectValueForNegativeInput() {
        SparseGradient a = SparseGradient.createVariable(1, -5.0);
        SparseGradient result = a.reciprocal();
        Assertions.assertEquals(-0.2, result.getValue());
    }

    @Test
    public void reciprocalReturnsPositiveInfinityForZeroInput() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.reciprocal();
        Assertions.assertEquals(Double.POSITIVE_INFINITY, result.getValue());
    }

    @Test
    public void reciprocalReturnsNaNForInfiniteInput() {
        SparseGradient a = SparseGradient.createVariable(1, Double.POSITIVE_INFINITY);
        SparseGradient result = a.reciprocal();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void sqrtCalculatesSquareRootCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 4.0);
        SparseGradient result = a.sqrt();
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(0.25, result.getDerivative(1));
    }

    @Test
    public void sqrtReturnsNaNForNegativeInput() {
        SparseGradient a = SparseGradient.createVariable(1, -4.0);
        SparseGradient result = a.sqrt();
        Assertions.assertEquals(Double.NaN, result.getValue());
    }

    @Test
    public void sqrtReturnsZeroForZeroInput() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.sqrt();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void cbrtCalculatesCubeRootCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 8.0);
        SparseGradient result = a.cbrt();
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0 / 12.0, result.getDerivative(1));
    }

    @Test
    public void cbrtCalculatesCubeRootForNegativeInput() {
        SparseGradient a = SparseGradient.createVariable(1, -8.0);
        SparseGradient result = a.cbrt();
        Assertions.assertEquals(-2.0, result.getValue());
        Assertions.assertEquals(1.0 / 12.0, result.getDerivative(1));
    }

    @Test
    public void cbrtReturnsZeroForZeroInput() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.cbrt();
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void rootNCalculatesSquareRootCorrectlyForNEqualToTwo() {
        SparseGradient a = SparseGradient.createVariable(1, 4.0);
        SparseGradient result = a.rootN(2);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(0.25, result.getDerivative(1));
    }

    @Test
    public void rootNCalculatesCubeRootCorrectlyForNEqualToThree() {
        SparseGradient a = SparseGradient.createVariable(1, 8.0);
        SparseGradient result = a.rootN(3);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0 / 12.0, result.getDerivative(1));
    }

    @Test
    public void rootNCalculatesFourthRootCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 16.0);
        SparseGradient result = a.rootN(4);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(0.0625, result.getDerivative(1));
    }

    @Test
    public void powCalculatesPowerCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.pow(3.0);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(12.0, result.getDerivative(1));
    }

    @Test
    public void powCalculatesSquareRootCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 4.0);
        SparseGradient result = a.pow(0.5);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(0.25, result.getDerivative(1));
    }

    @Test
    public void powCalculatesCubeRootCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 8.0);
        SparseGradient result = a.pow(1.0/3.0);
        Assertions.assertEquals(2.0, result.getValue());
        Assertions.assertEquals(1.0 / 12.0, result.getDerivative(1));
    }

    @Test
    public void powCalculatesPowerCorrectlyForPositiveIntegers() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.pow(3);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(12.0, result.getDerivative(1));
    }

    @Test
    public void powReturnsOneForZeroExponent() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.pow(0);
        Assertions.assertEquals(1.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void powCalculatesPowerCorrectlyForNegativeIntegers() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.pow(-3);
        Assertions.assertEquals(0.125, result.getValue());
        Assertions.assertEquals(-0.75, result.getDerivative(1));
    }

    @Test
    public void powCalculatesPowerCorrectlyForSparseGradientExponent() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient b = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = a.pow(b);
        Assertions.assertEquals(8.0, result.getValue());
        Assertions.assertEquals(12.0, result.getDerivative(1));
        Assertions.assertEquals(5.545177444479562, result.getDerivative(2));
    }

    @Test
    public void powCalculatesPowerCorrectlyForPositiveBaseAndExponent() {
        SparseGradient x = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = SparseGradient.pow(3.0, x);
        Assertions.assertEquals(9.0, result.getValue());
        Assertions.assertEquals(9.0 * Math.log(3.0), result.getDerivative(1));
    }

    @Test
    public void powReturnsZeroForZeroBaseAndPositiveExponent() {
        SparseGradient x = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = SparseGradient.pow(0.0, x);
        Assertions.assertEquals(0.0, result.getValue());
    }

    @Test
    public void powReturnsNaNForZeroBaseAndNegativeExponent() {
        SparseGradient x = SparseGradient.createVariable(1, -2.0);
        SparseGradient result = SparseGradient.pow(0.0, x);
        Assertions.assertEquals(Double.NaN, result.getValue());
    }

    @Test
    public void powReturnsOneForZeroBaseAndZeroExponent() {
        SparseGradient x = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = SparseGradient.pow(0.0, x);
        Assertions.assertEquals(1.0, result.getValue());
        Assertions.assertEquals(Double.NEGATIVE_INFINITY, result.getDerivative(1));
    }

    @Test
    public void expCalculatesExponentialCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.exp();
        Assertions.assertEquals(Math.exp(2.0), result.getValue());
        Assertions.assertEquals(Math.exp(2.0), result.getDerivative(1));
    }

    @Test
    public void expm1CalculatesExponentialMinusOneCorrectlyForPositiveValue() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.expm1();
        Assertions.assertEquals(Math.expm1(2.0), result.getValue());
        Assertions.assertEquals(Math.exp(2.0), result.getDerivative(1));
    }

    @Test
    public void expm1CalculatesExponentialMinusOneCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.expm1();
        Assertions.assertEquals(Math.expm1(0.0), result.getValue());
        Assertions.assertEquals(Math.exp(0.0), result.getDerivative(1));
    }

    @Test
    public void logCalculatesNaturalLogarithmCorrectlyForPositiveValue() {
        SparseGradient a = SparseGradient.createVariable(1, Math.E);
        SparseGradient result = a.log();
        Assertions.assertEquals(Math.log(Math.E), result.getValue());
        Assertions.assertEquals(1.0 / Math.E, result.getDerivative(1));
    }

    @Test
    public void logCalculatesNaturalLogarithmCorrectlyForOne() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient result = a.log();
        Assertions.assertEquals(Math.log(1.0), result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void logReturnsNaNForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.log();
        Assertions.assertEquals(Double.NEGATIVE_INFINITY, result.getValue());
    }

    @Test
    public void log10CalculatesBase10LogarithmCorrectlyForPositiveValue() {
        SparseGradient a = SparseGradient.createVariable(1, 10.0);
        SparseGradient result = a.log10();
        Assertions.assertEquals(1.0, result.getValue());
        Assertions.assertEquals(0.04342944819032517, result.getDerivative(1));
    }

    @Test
    public void log10ReturnsNaNForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.log10();
        Assertions.assertEquals(Double.NEGATIVE_INFINITY, result.getValue());
    }

    @Test
    public void log1pCalculatesLogarithmOfOnePlusValueCorrectlyForPositiveValue() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.log1p();
        Assertions.assertEquals(Math.log1p(2.0), result.getValue());
        Assertions.assertEquals(1.0 / (1.0 + 2.0), result.getDerivative(1));
    }

    @Test
    public void log1pCalculatesLogarithmOfOnePlusValueCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.log1p();
        Assertions.assertEquals(Math.log1p(0.0), result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void cosCalculatesCosineCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.cos();
        Assertions.assertEquals(1.0, result.getValue());
        Assertions.assertEquals(0.0, result.getDerivative(1));
    }

    @Test
    public void cosCalculatesCosineCorrectlyForPiOverTwo() {
        SparseGradient a = SparseGradient.createVariable(1, Math.PI / 2);
        SparseGradient result = a.cos();
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(-1.0, result.getDerivative(1), 1e-10);
    }

    @Test
    public void sinCalculatesSineCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.sin();
        Assertions.assertEquals(0.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void sinCalculatesSineCorrectlyForPiOverTwo() {
        SparseGradient a = SparseGradient.createVariable(1, Math.PI / 2);
        SparseGradient result = a.sin();
        Assertions.assertEquals(1.0, result.getValue(), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(1), 1e-10);
    }

    @Test
    public void tanCalculatesTangentCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.tan();
        Assertions.assertEquals(0.0, result.getValue());
        Assertions.assertEquals(1.0, result.getDerivative(1));
    }

    @Test
    public void tanCalculatesTangentCorrectlyForPiOverFour() {
        SparseGradient a = SparseGradient.createVariable(1, Math.PI / 4);
        SparseGradient result = a.tan();
        Assertions.assertEquals(1.0, result.getValue(), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(1), 1e-10);
    }

    @Test
    public void acosCalculatesArcCosineCorrectlyForOne() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient result = a.acos();
        Assertions.assertEquals(0.0, result.getValue());
        Assertions.assertEquals(-1.0, result.getDerivative(1));
    }

    @Test
    public void acosCalculatesArcCosineCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.acos();
        Assertions.assertEquals(Math.PI / 2, result.getValue(), 1e-10);
        Assertions.assertEquals(-1.0, result.getDerivative(1));
    }

    @Test
    public void asinCalculatesArcSineCorrectlyForHalf() {
        SparseGradient a = SparseGradient.createVariable(1, 0.5);
        SparseGradient result = a.asin();
        Assertions.assertEquals(Math.asin(0.5), result.getValue(), 1e-10);
        Assertions.assertEquals(1.0 / Math.sqrt(1 - 0.5 * 0.5), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void asinCalculatesArcSineCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.asin();
        Assertions.assertEquals(Math.asin(0.0), result.getValue(), 1e-10);
        Assertions.assertEquals(1.0 / Math.sqrt(1 - 0.0 * 0.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void atanCalculatesArcTangentCorrectlyForOne() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient result = a.atan();
        Assertions.assertEquals(Math.atan(1.0), result.getValue(), 1e-10);
        Assertions.assertEquals(1.0 / (1 + 1.0 * 1.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void atanCalculatesArcTangentCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.atan();
        Assertions.assertEquals(Math.atan(0.0), result.getValue(), 1e-10);
        Assertions.assertEquals(1.0 / (1 + 0.0 * 0.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void atan2CalculatesCorrectlyForPositiveX() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient b = SparseGradient.createVariable(2, 1.0);
        SparseGradient result = a.atan2(b);
        Assertions.assertEquals(Math.atan2(1.0, 1.0), result.getValue(), 1e-10);
        Assertions.assertEquals(-1.0 / (1.0 + 1.0 * 1.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1.0 / (1.0 + 1.0 * 1.0), result.getDerivative(2), 1e-10);
        Assertions.assertEquals(2, result.numVars());
    }

    @Test
    public void atan2CalculatesCorrectlyForNegativeX() {
        SparseGradient a = SparseGradient.createVariable(1, -1.0);
        SparseGradient b = SparseGradient.createVariable(2, 1.0);
        SparseGradient result = a.atan2(b);
        Assertions.assertEquals(Math.atan2(-1.0, 1.0), result.getValue(), 1e-10);
        Assertions.assertEquals(1.0 / (1.0 + 1.0 * 1.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(-1.0 / (1.0 + 1.0 * 1.0), result.getDerivative(2), 1e-10);
        Assertions.assertEquals(2, result.numVars());
    }

    @Test
    public void staticAtan2CalculatesCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient b = SparseGradient.createVariable(2, 1.0);
        SparseGradient result = SparseGradient.atan2(a, b);
        Assertions.assertEquals(Math.atan2(1.0, 1.0), result.getValue(), 1e-10);
        Assertions.assertEquals(-1.0 / (1.0 + 1.0 * 1.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1.0 / (1.0 + 1.0 * 1.0), result.getDerivative(2), 1e-10);
        Assertions.assertEquals(2, result.numVars());
    }

    @Test
    public void coshCalculatesHyperbolicCosineCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient result = a.cosh();
        Assertions.assertEquals(Math.cosh(1.0), result.getValue(), 1e-10);
        Assertions.assertEquals(Math.sinh(1.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void sinhCalculatesHyperbolicSineCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient result = a.sinh();
        Assertions.assertEquals(Math.sinh(1.0), result.getValue(), 1e-10);
        Assertions.assertEquals(Math.cosh(1.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void tanhCalculatesHyperbolicTangentCorrectlyForPositiveValue() {
        SparseGradient a = SparseGradient.createVariable(1, 1.0);
        SparseGradient result = a.tanh();
        Assertions.assertEquals(Math.tanh(1.0), result.getValue(), 1e-10);
        Assertions.assertEquals(1 - Math.tanh(1.0) * Math.tanh(1.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void tanhCalculatesHyperbolicTangentCorrectlyForNegativeValue() {
        SparseGradient a = SparseGradient.createVariable(1, -1.0);
        SparseGradient result = a.tanh();
        Assertions.assertEquals(Math.tanh(-1.0), result.getValue(), 1e-10);
        Assertions.assertEquals(1 - Math.tanh(-1.0) * Math.tanh(-1.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void tanhCalculatesHyperbolicTangentCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.tanh();
        Assertions.assertEquals(Math.tanh(0.0), result.getValue(), 1e-10);
        Assertions.assertEquals(1 - Math.tanh(0.0) * Math.tanh(0.0), result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void acoshCalculatesInverseHyperbolicCosineCorrectlyForZero() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.acosh();
        Assertions.assertEquals(Double.NaN, result.getValue(), 1e-10);
        Assertions.assertEquals(Double.NaN, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void acoshCalculatesInverseHyperbolicCosineCorrectlyForNegativeValue() {
        SparseGradient a = SparseGradient.createVariable(1, -2.0);
        SparseGradient result = a.acosh();
        Assertions.assertEquals(Double.NaN, result.getValue(), 1e-10);
        Assertions.assertEquals(Double.NaN, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void toDegreesConvertsRadiansToDegreesCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, Math.PI);
        SparseGradient result = a.toDegrees();
        Assertions.assertEquals(180.0, result.getValue(), 1e-10);
        Assertions.assertEquals(180.0 / Math.PI, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void toDegreesConvertsZeroRadiansToZeroDegrees() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.toDegrees();
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void toRadiansConvertsDegreesToRadiansCorrectly() {
        SparseGradient a = SparseGradient.createVariable(1, 180.0);
        SparseGradient result = a.toRadians();
        Assertions.assertEquals(Math.PI, result.getValue(), 1e-10);
        Assertions.assertEquals(Math.PI / 180.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void toRadiansConvertsZeroDegreesToZeroRadians() {
        SparseGradient a = SparseGradient.createVariable(1, 0.0);
        SparseGradient result = a.toRadians();
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void taylorEvaluatesCorrectlyForPositiveValues() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        double result = a.taylor(3.0, 4.0);
        Assertions.assertEquals(2.0 + 3.0 + 4.0, result, 1e-10);
    }

    @Test
    public void taylorEvaluatesCorrectlyForNegativeValues() {
        SparseGradient a = SparseGradient.createVariable(1, -2.0);
        double result = a.taylor(-3.0, -4.0);
        Assertions.assertEquals(-2.0 - 3.0 - 4.0, result, 1e-10);
    }

    @Test
    public void composeComputesCorrectlyForPositiveValues() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient result = a.compose(3.0, 4.0);
        Assertions.assertEquals(3.0, result.getValue(), 1e-10);
        Assertions.assertEquals(4.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void composeComputesCorrectlyForNegativeValues() {
        SparseGradient a = SparseGradient.createVariable(1, -2.0);
        SparseGradient result = a.compose(-3.0, -4.0);
        Assertions.assertEquals(-3.0, result.getValue(), 1e-10);
        Assertions.assertEquals(-4.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(1, result.numVars());
    }

    @Test
    public void linearCombinationComputesCorrectlyForPositiveValues() {
        SparseGradient a1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient a2 = SparseGradient.createVariable(2, 3.0);
        SparseGradient b1 = SparseGradient.createVariable(3, 4.0);
        SparseGradient b2 = SparseGradient.createVariable(4, 5.0);
        SparseGradient result = a1.linearCombination(new SparseGradient[]{a1, a2}, new SparseGradient[]{b1, b2});
        Assertions.assertEquals(23.0, result.getValue(), 1e-10);
        Assertions.assertEquals(4.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(5.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(3.0, result.getDerivative(4), 1e-10);
    }

    @Test
    public void linearCombinationComputesCorrectlyForZeroValues() {
        SparseGradient a1 = SparseGradient.createVariable(1, 0.0);
        SparseGradient a2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient b1 = SparseGradient.createVariable(3, 0.0);
        SparseGradient b2 = SparseGradient.createVariable(4, 0.0);
        SparseGradient result = a1.linearCombination(new SparseGradient[]{a1, a2}, new SparseGradient[]{b1, b2});
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(4), 1e-10);
    }

    @Test
    public void linearCombinationComputesCorrectlyForMixedValues() {
        SparseGradient a1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient a2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient b1 = SparseGradient.createVariable(3, 0.0);
        SparseGradient b2 = SparseGradient.createVariable(4, 5.0);
        SparseGradient result = a1.linearCombination(new SparseGradient[]{a1, a2}, new SparseGradient[]{b1, b2});
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(4), 1e-10);
    }

    @Test
    public void linearCombinationWithArrayHandlesPositiveValues() {
        SparseGradient a1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient a2 = SparseGradient.createVariable(2, 3.0);
        SparseGradient[] array = {a1, a2};
        double[] coefficients = {1.0, 2.0};
        SparseGradient result = a1.linearCombination(coefficients, array);
        Assertions.assertEquals(8.0, result.getValue(), 1e-10);
        Assertions.assertEquals(1.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
    }

    @Test
    public void linearCombinationWithArrayHandlesZeroValues() {
        SparseGradient a1 = SparseGradient.createVariable(1, 0.0);
        SparseGradient a2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient[] array = {a1, a2};
        double[] coefficients = {1.0, 2.0};
        SparseGradient result = a1.linearCombination(coefficients, array);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(1.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
    }

    @Test
    public void linearCombinationWithFourArgsHandlesPositiveValues() {
        SparseGradient a1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient a2 = SparseGradient.createVariable(2, 3.0);
        SparseGradient b1 = SparseGradient.createVariable(3, 4.0);
        SparseGradient b2 = SparseGradient.createVariable(4, 5.0);
        SparseGradient result = a1.linearCombination(a1, b1, a2, b2);
        Assertions.assertEquals(23.0, result.getValue(), 1e-10);
        Assertions.assertEquals(4.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(5.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(3.0, result.getDerivative(4), 1e-10);
    }

    @Test
    public void linearCombinationWithFourArgsHandlesZeroValues() {
        SparseGradient a1 = SparseGradient.createVariable(1, 0.0);
        SparseGradient a2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient b1 = SparseGradient.createVariable(3, 0.0);
        SparseGradient b2 = SparseGradient.createVariable(4, 0.0);
        SparseGradient result = a1.linearCombination(a1, b1, a2, b2);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(4), 1e-10);
    }

    @Test
    public void linearCombinationTwoArgsHandlesPositiveValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 3.0);
        SparseGradient result = b1.linearCombination(1.0, b1, 2.0, b2);
        Assertions.assertEquals(8.0, result.getValue(), 1e-10);
        Assertions.assertEquals(1.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
    }

    @Test
    public void linearCombinationTwoArgsHandlesZeroValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 0.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient result = b1.linearCombination(1.0, b1, 2.0, b2);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(1.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
    }

    @Test
    public void linearCombinationThreeArgsHandlesPositiveValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 3.0);
        SparseGradient b3 = SparseGradient.createVariable(3, 4.0);
        SparseGradient result = b1.linearCombination(b1, b2, b2, b1, b3, b3);
        Assertions.assertEquals(14.0, result.getValue(), 1e-10);
        Assertions.assertEquals(3.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(4.0, result.getDerivative(3), 1e-10);
    }

    @Test
    public void linearCombinationThreeArgsHandlesZeroValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 0.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient b3 = SparseGradient.createVariable(3, 0.0);
        SparseGradient result = b1.linearCombination(b1, b2, b2, b1, b3, b3);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(3), 1e-10);
    }

    @Test
    public void linearCombinationThreeArgsWithDoublesHandlesPositiveValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 3.0);
        SparseGradient b3 = SparseGradient.createVariable(3, 4.0);
        SparseGradient result = b1.linearCombination(1.0, b1, 2.0, b2, 3.0, b3);
        Assertions.assertEquals(14.0, result.getValue(), 1e-10);
        Assertions.assertEquals(1.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(3.0, result.getDerivative(3), 1e-10);
    }

    @Test
    public void linearCombinationThreeArgsWithDoublesHandlesZeroValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 0.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient b3 = SparseGradient.createVariable(3, 0.0);
        SparseGradient result = b1.linearCombination(1.0, b1, 2.0, b2, 3.0, b3);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(1.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(3.0, result.getDerivative(3), 1e-10);
    }

    @Test
    public void linearCombinationFourArgsHandlesPositiveValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 3.0);
        SparseGradient b3 = SparseGradient.createVariable(3, 4.0);
        SparseGradient b4 = SparseGradient.createVariable(4, 5.0);
        SparseGradient result = b1.linearCombination(b1, b2, b2, b1, b3, b4, b4, b3);
        Assertions.assertEquals(23.0, result.getValue(), 1e-10);
        Assertions.assertEquals(3.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(5.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(4.0, result.getDerivative(4), 1e-10);
    }

    @Test
    public void linearCombinationFourArgsHandlesZeroValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 0.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient b3 = SparseGradient.createVariable(3, 0.0);
        SparseGradient b4 = SparseGradient.createVariable(4, 0.0);
        SparseGradient result = b1.linearCombination(b1, b2, b2, b1, b3, b4, b4, b3);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(0.0, result.getDerivative(4), 1e-10);
    }

    @Test
    public void linearCombinationFourArgsWithDoublesHandlesPositiveValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 2.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 3.0);
        SparseGradient b3 = SparseGradient.createVariable(3, 4.0);
        SparseGradient b4 = SparseGradient.createVariable(4, 5.0);
        SparseGradient result = b1.linearCombination(1.0, b1, 2.0, b2, 3.0, b3, 4.0, b4);
        Assertions.assertEquals(26.0, result.getValue(), 1e-10);
        Assertions.assertEquals(1.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(3.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(4.0, result.getDerivative(4), 1e-10);
    }

    @Test
    public void linearCombinationFourArgsWithDoublesHandlesZeroValues() {
        SparseGradient b1 = SparseGradient.createVariable(1, 0.0);
        SparseGradient b2 = SparseGradient.createVariable(2, 0.0);
        SparseGradient b3 = SparseGradient.createVariable(3, 0.0);
        SparseGradient b4 = SparseGradient.createVariable(4, 0.0);
        SparseGradient result = b1.linearCombination(1.0, b1, 2.0, b2, 3.0, b3, 4.0, b4);
        Assertions.assertEquals(0.0, result.getValue(), 1e-10);
        Assertions.assertEquals(1.0, result.getDerivative(1), 1e-10);
        Assertions.assertEquals(2.0, result.getDerivative(2), 1e-10);
        Assertions.assertEquals(3.0, result.getDerivative(3), 1e-10);
        Assertions.assertEquals(4.0, result.getDerivative(4), 1e-10);
    }

    @Test
    @DisplayName("equalsReturnsTrueForIdenticalSparseGradients")
    public void equalsReturnsTrueForIdenticalSparseGradients() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        Assertions.assertTrue(a.equals(a));
    }

    @Test
    @DisplayName("equalsReturnsFalseForDifferentSparseGradients")
    public void equalsReturnsFalseForDifferentSparseGradients() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient b = SparseGradient.createVariable(1, 3.0);
        Assertions.assertFalse(a.equals(b));
    }

    @Test
    @DisplayName("equalsReturnsTrueForEqualSparseGradients")
    public void equalsReturnsTrueForEqualSparseGradients() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient b = SparseGradient.createVariable(1, 2.0);
        Assertions.assertTrue(a.equals(b));
    }

    @Test
    @DisplayName("hashCodeIsConsistentWithEquals")
    public void hashCodeIsConsistentWithEquals() {
        SparseGradient a = SparseGradient.createVariable(1, 2.0);
        SparseGradient b = SparseGradient.createVariable(1, 2.0);
        Assertions.assertEquals(a.hashCode(), b.hashCode());
    }
}
