package org.apache.commons.math4.legacy.analysis.differentiation;

import org.apache.commons.math4.legacy.analysis.differentiation.DSCompiler;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NumberIsTooLargeException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DSCompilerCopilotTest {

    @Test
    public void getCompilerShouldReturnExistingCompilerWhenCached() {
        DSCompiler compiler1 = DSCompiler.getCompiler(3, 2);
        DSCompiler compiler2 = DSCompiler.getCompiler(3, 2);
        assertSame(compiler1, compiler2);
    }

    @Test
    public void getCompilerShouldCreateNewCompilerWhenNotCached() {
        DSCompiler compiler1 = DSCompiler.getCompiler(3, 2);
        DSCompiler compiler2 = DSCompiler.getCompiler(4, 3);
        assertNotSame(compiler1, compiler2);
    }

    @Test
    public void getCompilerShouldThrowExceptionWhenOrderIsTooLarge() {
        assertThrows(NumberIsTooLargeException.class, () -> DSCompiler.getCompiler(3, Integer.MAX_VALUE));
    }

    @Test
    public void getPartialDerivativeIndexShouldReturnCorrectIndex() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        int index = compiler.getPartialDerivativeIndex(1, 0, 0);
        Assertions.assertEquals(1, index);
    }

    @Test
    public void getPartialDerivativeIndexShouldThrowExceptionForMismatchedParameters() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        Assertions.assertThrows(DimensionMismatchException.class, () -> compiler.getPartialDerivativeIndex(1, 0));
    }

    @Test
    public void getPartialDerivativeIndexShouldThrowExceptionForExcessiveOrder() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        Assertions.assertThrows(NumberIsTooLargeException.class, () -> compiler.getPartialDerivativeIndex(3, 3, 3));
    }

    @Test
    public void getPartialDerivativeOrdersShouldReturnCorrectOrders() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        int[] orders = compiler.getPartialDerivativeOrders(2);
        Assertions.assertArrayEquals(new int[]{0, 1, 0}, orders);
    }

    @Test
    public void getFreeParametersShouldReturnCorrectNumber() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        Assertions.assertEquals(3, compiler.getFreeParameters());
    }

    @Test
    public void getOrderShouldReturnCorrectOrder() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        Assertions.assertEquals(2, compiler.getOrder());
    }

    @Test
    public void getSizeShouldReturnCorrectSize() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        Assertions.assertEquals(10, compiler.getSize());
    }

    @Test
    public void linearCombinationTwoComponentsShouldComputeCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] c1 = {1.0, 2.0, 3.0};
        double[] c2 = {4.0, 5.0, 6.0};
        double[] result = new double[3];
        compiler.linearCombination(2.0, c1, 0, 3.0, c2, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{14.0, 19.0, 24.0}, result);
    }

    @Test
    public void linearCombinationThreeComponentsShouldComputeCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] c1 = {1.0, 2.0, 3.0};
        double[] c2 = {4.0, 5.0, 6.0};
        double[] c3 = {7.0, 8.0, 9.0};
        double[] result = new double[3];
        compiler.linearCombination(2.0, c1, 0, 3.0, c2, 0, 4.0, c3, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{42.0, 50.0, 58.0}, result);
    }

    @Test
    public void linearCombinationShouldComputeCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] c1 = {1.0, 2.0, 3.0};
        double[] c2 = {4.0, 5.0, 6.0};
        double[] c3 = {7.0, 8.0, 9.0};
        double[] c4 = {10.0, 11.0, 12.0};
        double[] result = new double[3];
        compiler.linearCombination(2.0, c1, 0, 3.0, c2, 0, 4.0, c3, 0, 5.0, c4, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{98.0, 112.0, 126.0}, result);
    }

    @Test
    public void additionOfTwoPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {1.0, 2.0, 3.0};
        double[] rhs = {4.0, 5.0, 6.0};
        double[] result = new double[3];
        compiler.add(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{5.0, 7.0, 9.0}, result);
    }

    @Test
    public void additionOfPositiveAndNegativeNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {1.0, 2.0, 3.0};
        double[] rhs = {-4.0, -5.0, -6.0};
        double[] result = new double[3];
        compiler.add(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-3.0, -3.0, -3.0}, result);
    }

    @Test
    public void additionOfZeroShouldReturnSameNumber() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {1.0, 2.0, 3.0};
        double[] rhs = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.add(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 2.0, 3.0}, result);
    }

    @Test
    public void subtractionOfTwoPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {10.0, 20.0, 30.0};
        double[] rhs = {2.0, 2.0, 2.0};
        double[] result = new double[3];
        compiler.subtract(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{8.0, 18.0, 28.0}, result);
    }

    @Test
    public void subtractionOfTwoNegativeNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {-10.0, -20.0, -30.0};
        double[] rhs = {-2.0, -2.0, -2.0};
        double[] result = new double[3];
        compiler.subtract(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-8.0, -18.0, -28.0}, result);
    }

    @Test
    public void subtractionOfPositiveAndNegativeNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {10.0, 20.0, 30.0};
        double[] rhs = {-2.0, -2.0, -2.0};
        double[] result = new double[3];
        compiler.subtract(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{12.0, 22.0, 32.0}, result);
    }

    @Test
    public void subtractionOfZeroShouldReturnSameNumber() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {10.0, 20.0, 30.0};
        double[] rhs = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.subtract(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{10.0, 20.0, 30.0}, result);
    }

    @Test
    public void multiplicationOfTwoPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {1.0, 2.0, 3.0};
        double[] rhs = {4.0, 5.0, 6.0};
        double[] result = new double[3];
        compiler.multiply(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{4.0, 10.0, 18.0}, result);
    }

    @Test
    public void multiplicationWithZeroShouldBeZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {1.0, 2.0, 3.0};
        double[] rhs = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.multiply(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void multiplicationOfTwoNegativeNumbersShouldBePositive() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {-1.0, -2.0, -3.0};
        double[] rhs = {-4.0, -5.0, -6.0};
        double[] result = new double[3];
        compiler.multiply(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{4.0, 10.0, 18.0}, result);
    }

    @Test
    public void divisionOfTwoPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {10.0, 20.0, 30.0};
        double[] rhs = {2.0, 2.0, 2.0};
        double[] result = new double[3];
        compiler.divide(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{5.0, 10.0, 15.0}, result);
    }

    @Test
    public void divisionByZeroShouldBeInfinity() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {10.0, 20.0, 30.0};
        double[] rhs = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.divide(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY}, result);
    }

    @Test
    public void divisionOfZeroByAnyNumberShouldBeZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {0.0, 0.0, 0.0};
        double[] rhs = {2.0, 2.0, 2.0};
        double[] result = new double[3];
        compiler.divide(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void remainderOfTwoPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {10.0, 20.0, 30.0};
        double[] rhs = {3.0, 3.0, 3.0};
        double[] result = new double[3];
        compiler.remainder(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 2.0, 0.0}, result);
    }

    @Test
    public void remainderOfTwoNegativeNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {-10.0, -20.0, -30.0};
        double[] rhs = {-3.0, -3.0, -3.0};
        double[] result = new double[3];
        compiler.remainder(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-1.0, -2.0, 0.0}, result);
    }

    @Test
    public void remainderOfPositiveAndNegativeNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {10.0, 20.0, 30.0};
        double[] rhs = {-3.0, -3.0, -3.0};
        double[] result = new double[3];
        compiler.remainder(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 2.0, 0.0}, result);
    }

    @Test
    public void remainderOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] lhs = {0.0, 0.0, 0.0};
        double[] rhs = {3.0, 3.0, 3.0};
        double[] result = new double[3];
        compiler.remainder(lhs, 0, rhs, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void powerOfPositiveNumberAndPositiveOperandShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {2.0, 3.0, 4.0};
        double[] result = new double[3];
        compiler.pow(2.0, operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{4.0, 9.0, 16.0}, result);
    }

    @Test
    public void powerOfZeroAndZeroOperandShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.pow(0.0, operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void powerOfZeroAndNegativeOperandShouldReturnNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -2.0, -3.0};
        double[] result = new double[3];
        compiler.pow(0.0, operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void powerOfPositiveNumberAndZeroOperandShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.pow(2.0, operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void powerOfZeroAndAnyNumberShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 5.0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void powerOfAnyNumberAndZeroShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {2.0, 3.0, 4.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 0.0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void powerOfZeroAndZeroShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 0.0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void powerOfPositiveNumberAndPositivePowerShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {2.0, 3.0, 4.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 2.0, result, 0);
        Assertions.assertArrayEquals(new double[]{4.0, 9.0, 16.0}, result);
    }

    @Test
    public void powerOfNegativeNumberAndEvenPowerShouldBePositive() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-2.0, -3.0, -4.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 2.0, result, 0);
        Assertions.assertArrayEquals(new double[]{4.0, 9.0, 16.0}, result);
    }

    @Test
    public void powerOfNegativeNumberAndOddPowerShouldBeNegative() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-2.0, -3.0, -4.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 3.0, result, 0);
        Assertions.assertArrayEquals(new double[]{-8.0, -27.0, -64.0}, result);
    }

    @Test
    public void powerOfPositiveNumberAndPositiveIntShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {2.0, 3.0, 4.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 2, result, 0);
        Assertions.assertArrayEquals(new double[]{4.0, 9.0, 16.0}, result);
    }

    @Test
    public void powerOfZeroAndZeroIntShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void powerOfZeroAndNegativeIntShouldReturnInfinity() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, -1, result, 0);
        Assertions.assertTrue(Double.isInfinite(result[0]));
        Assertions.assertTrue(Double.isInfinite(result[1]));
        Assertions.assertTrue(Double.isInfinite(result[2]));
    }

    @Test
    public void powerOfPositiveNumberAndZeroIntShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {2.0, 3.0, 4.0};
        double[] result = new double[3];
        compiler.pow(operand, 0, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void powerOfPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] x = {2.0, 3.0, 4.0};
        double[] y = {2.0, 2.0, 2.0};
        double[] result = new double[3];
        compiler.pow(x, 0, y, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{4.0, 9.0, 16.0}, result);
    }

    @Test
    public void powerOfZeroAndPositiveNumberShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] x = {0.0, 0.0, 0.0};
        double[] y = {2.0, 3.0, 4.0};
        double[] result = new double[3];
        compiler.pow(x, 0, y, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void powerOfPositiveNumberAndZeroShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] x = {2.0, 3.0, 4.0};
        double[] y = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.pow(x, 0, y, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void powerOfNegativeNumberAndEvenNumberShouldBePositive() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] x = {-2.0, -3.0, -4.0};
        double[] y = {2.0, 2.0, 2.0};
        double[] result = new double[3];
        compiler.pow(x, 0, y, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{4.0, 9.0, 16.0}, result);
    }

    @Test
    public void powerOfNegativeNumberAndOddNumberShouldBeNegative() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] x = {-2.0, -3.0, -4.0};
        double[] y = {3.0, 3.0, 3.0};
        double[] result = new double[3];
        compiler.pow(x, 0, y, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-8.0, -27.0, -64.0}, result);
    }

    @Test
    public void rootNOfPositiveNumberAndEvenNShouldBePositive() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {4.0, 16.0, 64.0};
        double[] result = new double[3];
        compiler.rootN(operand, 0, 2, result, 0);
        Assertions.assertArrayEquals(new double[]{2.0, 4.0, 8.0}, result);
    }

    @Test
    public void rootNOfPositiveNumberAndOddNShouldBePositive() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {8.0, 27.0, 64.0};
        double[] result = new double[3];
        compiler.rootN(operand, 0, 3, result, 0);
        Assertions.assertArrayEquals(new double[]{2.0, 3.0, 4.0}, result);
    }

    @Test
    public void rootNOfNegativeNumberAndOddNShouldBeNegative() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-8.0, -27.0, -64.0};
        double[] result = new double[3];
        compiler.rootN(operand, 0, 3, result, 0);
        Assertions.assertArrayEquals(new double[]{-2.0, -3.0, -4.0}, result);
    }

    @Test
    public void rootNOfZeroAndAnyNShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.rootN(operand, 0, 3, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void rootNOfNegativeNumberAndEvenNShouldReturnNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-4.0, -16.0, -64.0};
        double[] result = new double[3];
        compiler.rootN(operand, 0, 2, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void exponentialOfZeroShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.exp(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void exponentialOfPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 2.0, 3.0};
        double[] result = new double[3];
        compiler.exp(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.exp(1.0), Math.exp(2.0), Math.exp(3.0)}, result);
    }

    @Test
    public void exponentialOfNegativeNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -2.0, -3.0};
        double[] result = new double[3];
        compiler.exp(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.exp(-1.0), Math.exp(-2.0), Math.exp(-3.0)}, result);
    }

    @Test
    public void expm1OfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.expm1(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void expm1OfPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 2.0, 3.0};
        double[] result = new double[3];
        compiler.expm1(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.expm1(1.0), Math.expm1(2.0), Math.expm1(3.0)}, result);
    }

    @Test
    public void expm1OfNegativeNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -2.0, -3.0};
        double[] result = new double[3];
        compiler.expm1(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.expm1(-1.0), Math.expm1(-2.0), Math.expm1(-3.0)}, result);
    }

    @Test
    public void logOfPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 2.0, 3.0};
        double[] result = new double[3];
        compiler.log(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.log(1.0), Math.log(2.0), Math.log(3.0)}, result);
    }

    @Test
    public void logOfZeroShouldReturnNegativeInfinity() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.log(operand, 0, result, 0);
        Assertions.assertTrue(Double.isInfinite(result[0]) && result[0] < 0);
        Assertions.assertTrue(Double.isInfinite(result[1]) && result[1] < 0);
        Assertions.assertTrue(Double.isInfinite(result[2]) && result[2] < 0);
    }

    @Test
    public void logOfNegativeNumbersShouldReturnNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -2.0, -3.0};
        double[] result = new double[3];
        compiler.log(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void log1pOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.log1p(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void log1pOfPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 2.0, 3.0};
        double[] result = new double[3];
        compiler.log1p(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.log1p(1.0), Math.log1p(2.0), Math.log1p(3.0)}, result);
    }

    @Test
    public void log1pOfNegativeFractionShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-0.5, -0.2, -0.1};
        double[] result = new double[3];
        compiler.log1p(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.log1p(-0.5), Math.log1p(-0.2), Math.log1p(-0.1)}, result);
    }

    @Test
    public void log1pOfNegativeOneShouldReturnNegativeInfinity() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -1.0, -1.0};
        double[] result = new double[3];
        compiler.log1p(operand, 0, result, 0);
        Assertions.assertTrue(Double.isInfinite(result[0]) && result[0] < 0);
        Assertions.assertTrue(Double.isInfinite(result[1]) && result[1] < 0);
        Assertions.assertTrue(Double.isInfinite(result[2]) && result[2] < 0);
    }

    @Test
    public void log1pOfLessThanNegativeOneShouldReturnNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.1, -2.0, -3.0};
        double[] result = new double[3];
        compiler.log1p(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void log10OfPositiveNumbersShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 10.0, 100.0};
        double[] result = new double[3];
        compiler.log10(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 1.0, 2.0}, result);
    }

    @Test
    public void log10OfOneShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 1.0, 1.0};
        double[] result = new double[3];
        compiler.log10(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void log10OfZeroShouldReturnNegativeInfinity() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.log10(operand, 0, result, 0);
        Assertions.assertTrue(Double.isInfinite(result[0]) && result[0] < 0);
        Assertions.assertTrue(Double.isInfinite(result[1]) && result[1] < 0);
        Assertions.assertTrue(Double.isInfinite(result[2]) && result[2] < 0);
    }

    @Test
    public void log10OfNegativeNumbersShouldReturnNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -2.0, -3.0};
        double[] result = new double[3];
        compiler.log10(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void cosineOfZeroShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.cos(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void cosineOfPiShouldReturnNegativeOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {Math.PI, Math.PI, Math.PI};
        double[] result = new double[3];
        compiler.cos(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-1.0, -1.0, -1.0}, result);
    }

    @Test
    public void cosineOfHalfPiShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {Math.PI / 2, Math.PI / 2, Math.PI / 2};
        double[] result = new double[3];
        compiler.cos(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void cosineOfNegativeValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-Math.PI / 2, -Math.PI, -3 * Math.PI / 2};
        double[] result = new double[3];
        compiler.cos(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, -1.0, 0.0}, result);
    }

    @Test
    public void sineOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.sin(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void sineOfPiShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {Math.PI, Math.PI, Math.PI};
        double[] result = new double[3];
        compiler.sin(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void sineOfHalfPiShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {Math.PI / 2, Math.PI / 2, Math.PI / 2};
        double[] result = new double[3];
        compiler.sin(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void sineOfNegativeValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-Math.PI / 2, -Math.PI, -3 * Math.PI / 2};
        double[] result = new double[3];
        compiler.sin(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-1.0, 0.0, 1.0}, result);
    }

    @Test
    public void tangentOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.tan(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void tangentOfPiOverFourShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {Math.PI / 4, Math.PI / 4, Math.PI / 4};
        double[] result = new double[3];
        compiler.tan(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void tangentOfPiOverTwoShouldReturnInfinity() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {Math.PI / 2, Math.PI / 2, Math.PI / 2};
        double[] result = new double[3];
        compiler.tan(operand, 0, result, 0);
        Assertions.assertTrue(Double.isInfinite(result[0]));
        Assertions.assertTrue(Double.isInfinite(result[1]));
        Assertions.assertTrue(Double.isInfinite(result[2]));
    }

    @Test
    public void tangentOfNegativeValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-Math.PI / 4, -Math.PI / 2, -3 * Math.PI / 4};
        double[] result = new double[3];
        compiler.tan(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-1.0, Double.NEGATIVE_INFINITY, 1.0}, result);
    }

    @Test
    public void acosOfZeroShouldReturnPiOverTwo() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.acos(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.PI / 2, Math.PI / 2, Math.PI / 2}, result);
    }

    @Test
    public void acosOfOneShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 1.0, 1.0};
        double[] result = new double[3];
        compiler.acos(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void acosOfNegativeOneShouldReturnPi() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -1.0, -1.0};
        double[] result = new double[3];
        compiler.acos(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.PI, Math.PI, Math.PI}, result);
    }

    @Test
    public void acosOfValuesGreaterThanOneShouldBeNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.5, 2.0, 2.5};
        double[] result = new double[3];
        compiler.acos(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void acosOfValuesLessThanNegativeOneShouldBeNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.5, -2.0, -2.5};
        double[] result = new double[3];
        compiler.acos(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void asinOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.asin(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void asinOfOneShouldReturnPiOverTwo() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 1.0, 1.0};
        double[] result = new double[3];
        compiler.asin(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.PI / 2, Math.PI / 2, Math.PI / 2}, result);
    }

    @Test
    public void asinOfNegativeOneShouldReturnNegativePiOverTwo() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -1.0, -1.0};
        double[] result = new double[3];
        compiler.asin(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-Math.PI / 2, -Math.PI / 2, -Math.PI / 2}, result);
    }

    @Test
    public void asinOfValuesGreaterThanOneShouldBeNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.5, 2.0, 2.5};
        double[] result = new double[3];
        compiler.asin(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void asinOfValuesLessThanNegativeOneShouldBeNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.5, -2.0, -2.5};
        double[] result = new double[3];
        compiler.asin(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void atanOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.atan(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void atanOfPositiveValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, Math.sqrt(3), Double.POSITIVE_INFINITY};
        double[] result = new double[3];
        compiler.atan(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.PI / 4, Math.PI / 3, Math.PI / 2}, result);
    }

    @Test
    public void atanOfNegativeValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -Math.sqrt(3), Double.NEGATIVE_INFINITY};
        double[] result = new double[3];
        compiler.atan(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{-Math.PI / 4, -Math.PI / 3, -Math.PI / 2}, result);
    }

    @Test
    public void atan2WithPositiveXShouldComputeCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] y = {1.0, 2.0, 3.0};
        double[] x = {1.0, 2.0, 3.0};
        double[] result = new double[3];
        compiler.atan2(y, 0, x, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.atan2(1.0, 1.0), Math.atan2(2.0, 2.0), Math.atan2(3.0, 3.0)}, result);
    }

    @Test
    public void atan2WithNegativeXShouldComputeCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] y = {1.0, 2.0, 3.0};
        double[] x = {-1.0, -2.0, -3.0};
        double[] result = new double[3];
        compiler.atan2(y, 0, x, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.atan2(1.0, -1.0), Math.atan2(2.0, -2.0), Math.atan2(3.0, -3.0)}, result);
    }

    @Test
    public void atan2WithZeroYShouldComputeCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] y = {0.0, 0.0, 0.0};
        double[] x = {1.0, 2.0, 3.0};
        double[] result = new double[3];
        compiler.atan2(y, 0, x, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.atan2(0.0, 1.0), Math.atan2(0.0, 2.0), Math.atan2(0.0, 3.0)}, result);
    }

    @Test
    public void atan2WithZeroXShouldComputeCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] y = {1.0, 2.0, 3.0};
        double[] x = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.atan2(y, 0, x, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.atan2(1.0, 0.0), Math.atan2(2.0, 0.0), Math.atan2(3.0, 0.0)}, result);
    }

    @Test
    public void atan2WithZeroYAndXShouldComputeCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] y = {0.0, 0.0, 0.0};
        double[] x = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.atan2(y, 0, x, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.atan2(0.0, 0.0), Math.atan2(0.0, 0.0), Math.atan2(0.0, 0.0)}, result);
    }

    @Test
    public void coshOfZeroShouldReturnOne() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.cosh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result);
    }

    @Test
    public void coshOfPositiveValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, Math.E, Math.PI};
        double[] result = new double[3];
        compiler.cosh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.cosh(1.0), Math.cosh(Math.E), Math.cosh(Math.PI)}, result);
    }

    @Test
    public void coshOfNegativeValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -Math.E, -Math.PI};
        double[] result = new double[3];
        compiler.cosh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.cosh(-1.0), Math.cosh(-Math.E), Math.cosh(-Math.PI)}, result);
    }

    @Test
    public void sinhOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.sinh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void sinhOfPositiveValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, Math.E, Math.PI};
        double[] result = new double[3];
        compiler.sinh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.sinh(1.0), Math.sinh(Math.E), Math.sinh(Math.PI)}, result);
    }

    @Test
    public void sinhOfNegativeValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -Math.E, -Math.PI};
        double[] result = new double[3];
        compiler.sinh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.sinh(-1.0), Math.sinh(-Math.E), Math.sinh(-Math.PI)}, result);
    }

    @Test
    public void tanhOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.tanh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void tanhOfPositiveValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, Math.E, Math.PI};
        double[] result = new double[3];
        compiler.tanh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.tanh(1.0), Math.tanh(Math.E), Math.tanh(Math.PI)}, result);
    }

    @Test
    public void tanhOfNegativeValuesShouldBeCorrect() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -Math.E, -Math.PI};
        double[] result = new double[3];
        compiler.tanh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{Math.tanh(-1.0), Math.tanh(-Math.E), Math.tanh(-Math.PI)}, result);
    }

    @Test
    public void acoshOfOneShouldBeZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, 1.0, 1.0};
        double[] result = new double[3];
        compiler.acosh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result, 1e-10);
    }

    @Test
    public void acoshOfValuesLessThanOneShouldBeNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.5, 0.0, -0.5};
        double[] result = new double[3];
        compiler.acosh(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void asinhOfZeroShouldReturnZero() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.asinh(operand, 0, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void atanhOfValuesGreaterThanOneShouldBeNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.5, 2.0, 2.5};
        double[] result = new double[3];
        compiler.atanh(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void atanhOfValuesLessThanNegativeOneShouldBeNaN() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.5, -2.0, -2.5};
        double[] result = new double[3];
        compiler.atanh(operand, 0, result, 0);
        Assertions.assertTrue(Double.isNaN(result[0]));
        Assertions.assertTrue(Double.isNaN(result[1]));
        Assertions.assertTrue(Double.isNaN(result[2]));
    }

    @Test
    public void composeShouldHandleZeroesCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {0.0, 0.0, 0.0};
        double[] f = {0.0, 0.0, 0.0};
        double[] result = new double[3];
        compiler.compose(operand, 0, f, result, 0);
        Assertions.assertArrayEquals(new double[]{0.0, 0.0, 0.0}, result);
    }

    @Test
    public void composeShouldHandlePositiveValuesCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {1.0, Math.E, Math.PI};
        double[] f = {1.0, Math.E, Math.PI};
        double[] result = new double[3];
        compiler.compose(operand, 0, f, result, 0);
        // The expected result here depends on the specific implementation of your compose method
        // and the size of the derivative structure. This is just a placeholder.
        double[] expected = new double[3];
        Assertions.assertArrayEquals(expected, result);
    }

    @Test
    public void composeShouldHandleNegativeValuesCorrectly() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] operand = {-1.0, -Math.E, -Math.PI};
        double[] f = {-1.0, -Math.E, -Math.PI};
        double[] result = new double[3];
        compiler.compose(operand, 0, f, result, 0);
        // The expected result here depends on the specific implementation of your compose method
        // and the size of the derivative structure. This is just a placeholder.
        double[] expected = new double[3];
        Assertions.assertArrayEquals(expected, result);
    }

    @Test
    public void taylorExpansionAtZeroShouldReturnFunctionValue() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] ds = {1.0, 2.0, 3.0};
        double[] delta = {0.0, 0.0, 0.0};
        double result = compiler.taylor(ds, 0, delta);
        Assertions.assertEquals(1.0, result);
    }

    @Test
    public void taylorExpansionAtSmallDeltaShouldBeCloseToFunctionValue() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] ds = {1.0, 2.0, 3.0};
        double[] delta = {0.1, 0.1, 0.1};
        double result = compiler.taylor(ds, 0, delta);
        Assertions.assertEquals(1.0, result, 0.01);
    }

    @Test
    public void taylorExpansionAtLargeDeltaShouldDivergeFromFunctionValue() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] ds = {1.0, 2.0, 3.0};
        double[] delta = {1.0, 1.0, 1.0};
        double result = compiler.taylor(ds, 0, delta);
        Assertions.assertNotEquals(1.0, result);
    }

    @Test
    public void taylorExpansionWithNegativeDeltaShouldBeCloseToFunctionValue() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] ds = {1.0, 2.0, 3.0};
        double[] delta = {-0.1, -0.1, -0.1};
        double result = compiler.taylor(ds, 0, delta);
        Assertions.assertEquals(1.0, result, 0.01);
    }

    @Test
    public void taylorExpansionWithZeroDerivativesShouldReturnFunctionValue() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 2);
        double[] ds = {1.0, 0.0, 0.0};
        double[] delta = {0.1, 0.1, 0.1};
        double result = compiler.taylor(ds, 0, delta);
        Assertions.assertEquals(1.0, result);
    }

    @Test
    public void checkCompatibilityShouldPassWithSameParametersAndOrder() {
        DSCompiler compiler1 = DSCompiler.getCompiler(3, 2);
        DSCompiler compiler2 = DSCompiler.getCompiler(3, 2);
        compiler1.checkCompatibility(compiler2);
    }

    @Test
    public void checkCompatibilityShouldThrowExceptionWithDifferentParameters() {
        DSCompiler compiler1 = DSCompiler.getCompiler(3, 2);
        DSCompiler compiler2 = DSCompiler.getCompiler(4, 2);
        assertThrows(DimensionMismatchException.class, () -> compiler1.checkCompatibility(compiler2));
    }

    @Test
    public void checkCompatibilityShouldThrowExceptionWithDifferentOrder() {
        DSCompiler compiler1 = DSCompiler.getCompiler(3, 2);
        DSCompiler compiler2 = DSCompiler.getCompiler(3, 3);
        assertThrows(DimensionMismatchException.class, () -> compiler1.checkCompatibility(compiler2));
    }

}
