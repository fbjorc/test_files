package org.apache.commons.math4.legacy.analysis.differentiation;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class GradientFunctionCopilotTest {
    @Test
    public void gradientFunctionConstructorHandlesNullFunction() {
        assertThrows(NullPointerException.class, () -> new GradientFunction(null));
    }
}
