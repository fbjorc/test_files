package org.apache.commons.math4.legacy.analysis.polynomials;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import static org.apache.commons.numbers.core.Precision.EPSILON;

public class PolynomialsUtilsCopilotTest {
    @Test
    public void createChebyshevPolynomialReturnsCorrectPolynomialForDegreeZero() {
        PolynomialFunction chebyshev = PolynomialsUtils.createChebyshevPolynomial(0);
        Assert.assertArrayEquals(new double[]{1}, chebyshev.getCoefficients(), EPSILON);
    }

    @Test
    public void createChebyshevPolynomialReturnsCorrectPolynomialForDegreeOne() {
        PolynomialFunction chebyshev = PolynomialsUtils.createChebyshevPolynomial(1);
        Assert.assertArrayEquals(new double[]{0, 1}, chebyshev.getCoefficients(), EPSILON);
    }

    @Test
    public void createChebyshevPolynomialReturnsCorrectPolynomialForDegreeTwo() {
        PolynomialFunction chebyshev = PolynomialsUtils.createChebyshevPolynomial(2);
        Assert.assertArrayEquals(new double[]{0, -1, 2}, chebyshev.getCoefficients(), EPSILON);
    }

    @Test
    public void createChebyshevPolynomialReturnsCorrectPolynomialForDegreeThree() {
        PolynomialFunction chebyshev = PolynomialsUtils.createChebyshevPolynomial(3);
        Assert.assertArrayEquals(new double[]{0, 0, -3, 4}, chebyshev.getCoefficients(), EPSILON);
    }

    @Test
    public void hermitePolynomialReturnsCorrectPolynomialForDegreeZero() {
        PolynomialFunction hermite = PolynomialsUtils.createHermitePolynomial(0);
        Assert.assertArrayEquals(new double[]{1}, hermite.getCoefficients(), EPSILON);
    }

    @Test
    public void hermitePolynomialReturnsCorrectPolynomialForDegreeOne() {
        PolynomialFunction hermite = PolynomialsUtils.createHermitePolynomial(1);
        Assert.assertArrayEquals(new double[]{0, 2}, hermite.getCoefficients(), EPSILON);
    }

    @Test
    public void hermitePolynomialReturnsCorrectPolynomialForDegreeTwo() {
        PolynomialFunction hermite = PolynomialsUtils.createHermitePolynomial(2);
        Assert.assertArrayEquals(new double[]{0, 0, 4}, hermite.getCoefficients(), EPSILON);
    }

    @Test
    public void hermitePolynomialReturnsCorrectPolynomialForDegreeThree() {
        PolynomialFunction hermite = PolynomialsUtils.createHermitePolynomial(3);
        Assert.assertArrayEquals(new double[]{0, 0, 0, 8}, hermite.getCoefficients(), EPSILON);
    }

    @Test
    public void laguerrePolynomialReturnsCorrectPolynomialForDegreeZero() {
        PolynomialFunction laguerre = PolynomialsUtils.createLaguerrePolynomial(0);
        Assert.assertArrayEquals(new double[]{1}, laguerre.getCoefficients(), EPSILON);
    }

    @Test
    public void laguerrePolynomialReturnsCorrectPolynomialForDegreeOne() {
        PolynomialFunction laguerre = PolynomialsUtils.createLaguerrePolynomial(1);
        Assert.assertArrayEquals(new double[]{1, -1}, laguerre.getCoefficients(), EPSILON);
    }

    @Test
    public void laguerrePolynomialReturnsCorrectPolynomialForDegreeTwo() {
        PolynomialFunction laguerre = PolynomialsUtils.createLaguerrePolynomial(2);
        Assert.assertArrayEquals(new double[]{2, -4, 1}, laguerre.getCoefficients(), EPSILON);
    }

    @Test
    public void laguerrePolynomialReturnsCorrectPolynomialForDegreeThree() {
        PolynomialFunction laguerre = PolynomialsUtils.createLaguerrePolynomial(3);
        Assert.assertArrayEquals(new double[]{6, -18, 9, -1}, laguerre.getCoefficients(), EPSILON);
    }

    @Test
    public void legendrePolynomialReturnsCorrectPolynomialForDegreeZero() {
        PolynomialFunction legendre = PolynomialsUtils.createLegendrePolynomial(0);
        Assert.assertArrayEquals(new double[]{1}, legendre.getCoefficients(), EPSILON);
    }

    @Test
    public void legendrePolynomialReturnsCorrectPolynomialForDegreeOne() {
        PolynomialFunction legendre = PolynomialsUtils.createLegendrePolynomial(1);
        Assert.assertArrayEquals(new double[]{0, 1}, legendre.getCoefficients(), EPSILON);
    }

    @Test
    public void legendrePolynomialReturnsCorrectPolynomialForDegreeTwo() {
        PolynomialFunction legendre = PolynomialsUtils.createLegendrePolynomial(2);
        Assert.assertArrayEquals(new double[]{0, 0, 3}, legendre.getCoefficients(), EPSILON);
    }

    @Test
    public void legendrePolynomialReturnsCorrectPolynomialForDegreeThree() {
        PolynomialFunction legendre = PolynomialsUtils.createLegendrePolynomial(3);
        Assert.assertArrayEquals(new double[]{0, 0, 0, 5}, legendre.getCoefficients(), EPSILON);
    }

    @Test
    public void jacobiPolynomialReturnsCorrectPolynomialForDegreeZero() {
        PolynomialFunction jacobi = PolynomialsUtils.createJacobiPolynomial(0, 1, 1);
        Assert.assertArrayEquals(new double[]{1}, jacobi.getCoefficients(), EPSILON);
    }

    @Test
    public void jacobiPolynomialReturnsCorrectPolynomialForDegreeOne() {
        PolynomialFunction jacobi = PolynomialsUtils.createJacobiPolynomial(1, 1, 1);
        Assert.assertArrayEquals(new double[]{0.5, 1.5}, jacobi.getCoefficients(), EPSILON);
    }

    @Test
    public void jacobiPolynomialReturnsCorrectPolynomialForDegreeTwo() {
        PolynomialFunction jacobi = PolynomialsUtils.createJacobiPolynomial(2, 1, 1);
        Assert.assertArrayEquals(new double[]{0.375, 0, 2.25}, jacobi.getCoefficients(), EPSILON);
    }

    @Test
    public void jacobiPolynomialReturnsCorrectPolynomialForDegreeThree() {
        PolynomialFunction jacobi = PolynomialsUtils.createJacobiPolynomial(3, 1, 1);
        Assert.assertArrayEquals(new double[]{0.3125, 0, 3.375, 0}, jacobi.getCoefficients(), EPSILON);
    }

    @Test
    public void shiftReturnsCorrectCoefficientsForPositiveShift() {
        double[] coefficients = {1, 2, 3};
        double[] shifted = PolynomialsUtils.shift(coefficients, 1);
        Assert.assertArrayEquals(new double[]{1, 3, 6}, shifted, EPSILON);
    }

    @Test
    public void shiftReturnsCorrectCoefficientsForNegativeShift() {
        double[] coefficients = {1, 2, 3};
        double[] shifted = PolynomialsUtils.shift(coefficients, -1);
        Assert.assertArrayEquals(new double[]{1, 1, 0}, shifted, EPSILON);
    }

    @Test
    public void shiftReturnsCorrectCoefficientsForZeroShift() {
        double[] coefficients = {1, 2, 3};
        double[] shifted = PolynomialsUtils.shift(coefficients, 0);
        Assert.assertArrayEquals(coefficients, shifted, EPSILON);
    }

    @Test
    public void shiftReturnsCorrectCoefficientsForEmptyCoefficients() {
        double[] coefficients = {};
        double[] shifted = PolynomialsUtils.shift(coefficients, 1);
        Assert.assertArrayEquals(coefficients, shifted, EPSILON);
    }
}
