package org.apache.commons.math4.legacy.analysis.polynomials;

import org.apache.commons.math4.legacy.analysis.differentiation.DerivativeStructureCopilotTest;
import org.apache.commons.math4.legacy.exception.NoDataException;
import org.apache.commons.math4.legacy.exception.NullArgumentException;
import org.junit.Assert;
import org.junit.Test;

public class PolynomialFunctionCopilotTest {

    private static final double EPSILON = 1E-10;

    @Test
    public void polynomialFunctionConstructorCreatesCorrectObjectForValidInput() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertArrayEquals(coefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void polynomialFunctionConstructorHandlesZeroCoefficientsAtEnd() {
        double[] inputCoefficients = {1, 2, 0};
        double[] expectedCoefficients = {1, 2};
        PolynomialFunction function = new PolynomialFunction(inputCoefficients);
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test(expected = NoDataException.class)
    public void polynomialFunctionConstructorThrowsExceptionForEmptyInput() {
        double[] coefficients = {};
        new PolynomialFunction(coefficients);
    }

    @Test(expected = NullArgumentException.class)
    public void polynomialFunctionConstructorThrowsExceptionForNullInput() {
        double[] coefficients = null;
        new PolynomialFunction(coefficients);
    }

    @Test
    public void valueCalculatesCorrectlyForPositiveInput() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertEquals(6, function.value(1), EPSILON);
    }

    @Test
    public void valueCalculatesCorrectlyForZeroInput() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertEquals(1, function.value(0), EPSILON);
    }

    @Test
    public void valueCalculatesCorrectlyForNegativeInput() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertEquals(0, function.value(-1), EPSILON);
    }

    @Test
    public void degreeReturnsCorrectlyForZeroDegreePolynomial() {
        double[] coefficients = {1};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertEquals(0, function.degree());
    }

    @Test
    public void degreeReturnsCorrectlyForFirstDegreePolynomial() {
        double[] coefficients = {1, 2};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertEquals(1, function.degree());
    }

    @Test
    public void degreeReturnsCorrectlyForSecondDegreePolynomial() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertEquals(2, function.degree());
    }

    @Test
    public void getCoefficientsReturnsCorrectlyForNonEmptyCoefficients() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertArrayEquals(coefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void getCoefficientsReturnsCorrectlyForEmptyCoefficients() {
        double[] coefficients = {};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertArrayEquals(coefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void getCoefficientsReturnsNewArrayOnEachCall() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        Assert.assertNotSame(function.getCoefficients(), function.getCoefficients());
    }

    @Test
    public void evaluateReturnsCorrectValueForNonZeroCoefficientsAndPositiveArgument() {
        double[] coefficients = {1, 2, 3};
        double argument = 2;
        double result = PolynomialFunction.evaluate(coefficients, argument);
        Assert.assertEquals(17.0, result, EPSILON);
    }

    @Test
    public void evaluateReturnsCorrectValueForNonZeroCoefficientsAndZeroArgument() {
        double[] coefficients = {1, 2, 3};
        double argument = 0;
        double result = PolynomialFunction.evaluate(coefficients, argument);
        Assert.assertEquals(3.0, result, EPSILON);
    }

    @Test
    public void evaluateReturnsCorrectValueForZeroCoefficients() {
        double[] coefficients = {0, 0, 0};
        double argument = 2;
        double result = PolynomialFunction.evaluate(coefficients, argument);
        Assert.assertEquals(0.0, result, EPSILON);
    }

    @Test(expected = NoDataException.class)
    public void evaluateThrowsNoDataExceptionForEmptyCoefficients() {
        double[] coefficients = {};
        double argument = 2;
        PolynomialFunction.evaluate(coefficients, argument);
    }

    @Test(expected = NullArgumentException.class)
    public void evaluateThrowsNullArgumentExceptionForNullCoefficients() {
        double[] coefficients = null;
        double argument = 2;
        PolynomialFunction.evaluate(coefficients, argument);
    }

    @Test
    public void addReturnsCorrectResultForPolynomialsOfSameDegree() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {4, 5, 6};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.add(function2);
        double[] expectedCoefficients = {5, 7, 9};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void addReturnsCorrectResultForPolynomialsOfDifferentDegrees() {
        double[] coefficients1 = {1, 2};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {3, 4, 5};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.add(function2);
        double[] expectedCoefficients = {4, 6, 5};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void addReturnsCorrectResultForAddingZeroPolynomial() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {0, 0, 0};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.add(function2);
        Assert.assertArrayEquals(coefficients1, result.getCoefficients(), EPSILON);
    }

    @Test
    public void subtractReturnsCorrectResultForPolynomialsOfSameDegree() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {4, 5, 6};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.subtract(function2);
        double[] expectedCoefficients = {-3, -3, -3};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void subtractReturnsCorrectResultForPolynomialsOfDifferentDegrees() {
        double[] coefficients1 = {1, 2};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {3, 4, 5};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.subtract(function2);
        double[] expectedCoefficients = {-2, -2, -5};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void subtractReturnsCorrectResultForSubtractingZeroPolynomial() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {0, 0, 0};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.subtract(function2);
        Assert.assertArrayEquals(coefficients1, result.getCoefficients(), EPSILON);
    }

    @Test
    public void negateReturnsCorrectResultForPositiveCoefficients() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        PolynomialFunction result = function.negate();
        double[] expectedCoefficients = {-1, -2, -3};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void negateReturnsCorrectResultForNegativeCoefficients() {
        double[] coefficients = {-1, -2, -3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        PolynomialFunction result = function.negate();
        double[] expectedCoefficients = {1, 2, 3};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void negateReturnsCorrectResultForZeroCoefficients() {
        double[] coefficients = {0, 0, 0};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        PolynomialFunction result = function.negate();
        Assert.assertArrayEquals(coefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void multiplyReturnsCorrectResultForPolynomialsOfSameDegree() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {4, 5, 6};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.multiply(function2);
        double[] expectedCoefficients = {4, 13, 28, 27, 18};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void multiplyReturnsCorrectResultForPolynomialsOfDifferentDegrees() {
        double[] coefficients1 = {1, 2};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {3, 4, 5};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.multiply(function2);
        double[] expectedCoefficients = {3, 10, 16, 14, 10};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void multiplyReturnsZeroPolynomialForMultiplyingByZeroPolynomial() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {0, 0, 0};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        PolynomialFunction result = function1.multiply(function2);
        double[] expectedCoefficients = {0, 0, 0, 0, 0};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void differentiateReturnsCorrectResultForPolynomialOfDegreeTwo() {
        double[] coefficients = {1, 2, 3};
        double[] result = PolynomialFunction.differentiate(coefficients);
        double[] expectedCoefficients = {2, 6};
        Assert.assertArrayEquals(expectedCoefficients, result, EPSILON);
    }

    @Test
    public void differentiateReturnsCorrectResultForPolynomialOfDegreeOne() {
        double[] coefficients = {1, 2};
        double[] result = PolynomialFunction.differentiate(coefficients);
        double[] expectedCoefficients = {2};
        Assert.assertArrayEquals(expectedCoefficients, result, EPSILON);
    }

    @Test
    public void differentiateReturnsZeroForConstantPolynomial() {
        double[] coefficients = {1};
        double[] result = PolynomialFunction.differentiate(coefficients);
        double[] expectedCoefficients = {0};
        Assert.assertArrayEquals(expectedCoefficients, result, EPSILON);
    }

    @Test(expected = NoDataException.class)
    public void differentiateThrowsNoDataExceptionForEmptyCoefficients() {
        double[] coefficients = {};
        PolynomialFunction.differentiate(coefficients);
    }

    @Test(expected = NullArgumentException.class)
    public void differentiateThrowsNullArgumentExceptionForNullCoefficients() {
        double[] coefficients = null;
        PolynomialFunction.differentiate(coefficients);
    }

    @Test
    public void polynomialDerivativeReturnsCorrectCoefficientsForDegreeThree() {
        double[] coefficients = {1, 2, 3, 4};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        PolynomialFunction result = function.polynomialDerivative();
        double[] expectedCoefficients = {2, 6, 12};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void polynomialDerivativeReturnsCorrectCoefficientsForDegreeTwo() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        PolynomialFunction result = function.polynomialDerivative();
        double[] expectedCoefficients = {2, 6};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void polynomialDerivativeReturnsCorrectCoefficientsForDegreeOne() {
        double[] coefficients = {1, 2};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        PolynomialFunction result = function.polynomialDerivative();
        double[] expectedCoefficients = {2};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void polynomialDerivativeReturnsZeroForConstantPolynomial() {
        double[] coefficients = {1};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        PolynomialFunction result = function.polynomialDerivative();
        double[] expectedCoefficients = {0};
        Assert.assertArrayEquals(expectedCoefficients, result.getCoefficients(), EPSILON);
    }

    @Test
    public void toStringReturnsCorrectFormatForPositiveCoefficients() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        String result = function.toString();
        Assert.assertEquals("1.0 + 2.0x + 3.0x^2", result);
    }

    @Test
    public void toStringReturnsCorrectFormatForNegativeCoefficients() {
        double[] coefficients = {-1, -2, -3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        String result = function.toString();
        Assert.assertEquals("-1.0 - 2.0x - 3.0x^2", result);
    }

    @Test
    public void toStringReturnsCorrectFormatForMixedCoefficients() {
        double[] coefficients = {1, -2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        String result = function.toString();
        Assert.assertEquals("1.0 - 2.0x + 3.0x^2", result);
    }

    @Test
    public void toStringReturnsZeroForZeroPolynomial() {
        double[] coefficients = {0};
        PolynomialFunction function = new PolynomialFunction(coefficients);
        String result = function.toString();
        Assert.assertEquals("0", result);
    }

    @Test
    public void hashCodeReturnsSameValueForSameCoefficients() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {1, 2, 3};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        Assert.assertEquals(function1.hashCode(), function2.hashCode());
    }

    @Test
    public void hashCodeReturnsDifferentValuesForDifferentCoefficients() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {4, 5, 6};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        Assert.assertNotEquals(function1.hashCode(), function2.hashCode());
    }

    @Test
    public void equalsReturnsTrueForSameObject() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);

        Assert.assertTrue(function.equals(function));
    }

    @Test
    public void equalsReturnsTrueForDifferentObjectsWithSameCoefficients() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {1, 2, 3};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        Assert.assertTrue(function1.equals(function2));
    }

    @Test
    public void equalsReturnsFalseForDifferentObjectsWithDifferentCoefficients() {
        double[] coefficients1 = {1, 2, 3};
        PolynomialFunction function1 = new PolynomialFunction(coefficients1);

        double[] coefficients2 = {4, 5, 6};
        PolynomialFunction function2 = new PolynomialFunction(coefficients2);

        Assert.assertFalse(function1.equals(function2));
    }

    @Test
    public void equalsReturnsFalseForDifferentTypes() {
        double[] coefficients = {1, 2, 3};
        PolynomialFunction function = new PolynomialFunction(coefficients);

        Assert.assertFalse(function.equals(new Object()));
    }

    @Test
    public void gradientReturnsCorrectValuesForGivenParameters() {
        double x = 2.0;
        double[] parameters = {1, 2, 3};
        PolynomialFunction.Parametric parametric = new PolynomialFunction.Parametric();
        double[] result = parametric.gradient(x, parameters);
        double[] expectedGradient = {1, 2, 4};
        Assert.assertArrayEquals(expectedGradient, result, EPSILON);
    }

    @Test
    public void gradientReturnsCorrectValuesForSingleParameter() {
        double x = 2.0;
        double[] parameters = {1};
        PolynomialFunction.Parametric parametric = new PolynomialFunction.Parametric();
        double[] result = parametric.gradient(x, parameters);
        double[] expectedGradient = {1};
        Assert.assertArrayEquals(expectedGradient, result, EPSILON);
    }

    @Test
    public void valueReturnsCorrectResultForGivenParameters() throws NoDataException {
        double x = 2.0;
        double[] parameters = {1, 2, 3};
        PolynomialFunction.Parametric parametric = new PolynomialFunction.Parametric();
        double result = parametric.value(x, parameters);
        double expectedValue = 17.0;
        Assert.assertEquals(expectedValue, result, EPSILON);
    }

    @Test(expected = NoDataException.class)
    public void valueThrowsNoDataExceptionForEmptyParameters() throws NoDataException {
        double x = 2.0;
        double[] parameters = {};
        PolynomialFunction.Parametric parametric = new PolynomialFunction.Parametric();
        parametric.value(x, parameters);
    }
}
