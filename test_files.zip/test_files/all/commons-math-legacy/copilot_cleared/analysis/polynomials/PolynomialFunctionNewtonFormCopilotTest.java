package org.apache.commons.math4.legacy.analysis.polynomials;

import org.apache.commons.math4.legacy.analysis.differentiation.DerivativeStructureCopilotTest;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NoDataException;
import org.apache.commons.math4.legacy.exception.NullArgumentException;
import org.junit.Assert;
import org.junit.Test;

import static org.apache.commons.numbers.core.Precision.EPSILON;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class PolynomialFunctionNewtonFormCopilotTest {

    @Test
    public void polynomialFunctionNewtonFormConstructorSetsValuesCorrectly() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        assertArrayEquals(a, function.getNewtonCoefficients(), EPSILON);
        assertArrayEquals(c, function.getCenters(), EPSILON);
    }

    @Test
    public void polynomialFunctionNewtonFormConstructorHandlesNullA() {
        double[] a = null;
        double[] c = {1, 2};
        assertThrows(NullArgumentException.class, () -> new PolynomialFunctionNewtonForm(a, c));
    }

    @Test
    public void polynomialFunctionNewtonFormConstructorHandlesNullC() {
        double[] a = {1, 2, 3};
        double[] c = null;
        assertThrows(NullArgumentException.class, () -> new PolynomialFunctionNewtonForm(a, c));
    }

    @Test
    public void polynomialFunctionNewtonFormConstructorHandlesEmptyA() {
        double[] a = {};
        double[] c = {1, 2};
        assertThrows(NoDataException.class, () -> new PolynomialFunctionNewtonForm(a, c));
    }

    @Test
    public void polynomialFunctionNewtonFormConstructorHandlesEmptyC() {
        double[] a = {1, 2, 3};
        double[] c = {};
        assertThrows(NoDataException.class, () -> new PolynomialFunctionNewtonForm(a, c));
    }

    @Test
    public void polynomialFunctionNewtonFormConstructorHandlesMismatchedDimensions() {
        double[] a = {1, 2};
        double[] c = {1, 2, 3};
        assertThrows(DimensionMismatchException.class, () -> new PolynomialFunctionNewtonForm(a, c));
    }

    @Test
    public void valueReturnsCorrectValueForGivenZ() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        double z = 2.0;
        double expectedValue = 7.0;
        Assert.assertEquals(expectedValue, function.value(z), EPSILON);
    }

    @Test
    public void degreeReturnsCorrectValue() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        Assert.assertEquals(2, function.degree());
    }

    @Test
    public void getNewtonCoefficientsReturnsCorrectValues() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        Assert.assertArrayEquals(a, function.getNewtonCoefficients(), EPSILON);
    }

    @Test
    public void getNewtonCoefficientsReturnsNewArray() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        double[] result = function.getNewtonCoefficients();
        result[0] = 10;
        Assert.assertNotEquals(function.getNewtonCoefficients()[0], result[0], EPSILON);
    }

    @Test
    public void getCentersReturnsCorrectValues() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        Assert.assertArrayEquals(c, function.getCenters(), EPSILON);
    }

    @Test
    public void getCentersReturnsNewArray() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        double[] result = function.getCenters();
        result[0] = 10;
        Assert.assertNotEquals(function.getCenters()[0], result[0], EPSILON);
    }

    @Test
    public void getCoefficientsReturnsCorrectValuesAfterComputation() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        function.computeCoefficients();
        Assert.assertArrayEquals(a, function.getCoefficients(), EPSILON);
    }

    @Test
    public void getCoefficientsReturnsNewArrayAfterComputation() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        function.computeCoefficients();
        double[] result = function.getCoefficients();
        result[0] = 10;
        Assert.assertNotEquals(function.getCoefficients()[0], result[0], EPSILON);
    }

    @Test
    public void evaluateReturnsCorrectValueForGivenInput() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        double z = 2.0;
        double expectedValue = 7.0;
        Assert.assertEquals(expectedValue, PolynomialFunctionNewtonForm.evaluate(a, c, z), EPSILON);
    }

    @Test(expected = DimensionMismatchException.class)
    public void evaluateThrowsExceptionForMismatchedDimensions() {
        double[] a = {1, 2};
        double[] c = {1, 2, 3};
        double z = 2.0;
        PolynomialFunctionNewtonForm.evaluate(a, c, z);
    }

    @Test(expected = NoDataException.class)
    public void evaluateThrowsExceptionForEmptyInputArrays() {
        double[] a = {};
        double[] c = {};
        double z = 2.0;
        PolynomialFunctionNewtonForm.evaluate(a, c, z);
    }

    @Test(expected = NullArgumentException.class)
    public void evaluateThrowsExceptionForNullInputArrays() {
        double[] a = null;
        double[] c = null;
        double z = 2.0;
        PolynomialFunctionNewtonForm.evaluate(a, c, z);
    }

    @Test
    public void computeCoefficientsSetsCorrectValues() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        function.computeCoefficients();
        double[] expectedCoefficients = {1, 0, 3};
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void computeCoefficientsHandlesZeroDegreePolynomial() {
        double[] a = {1};
        double[] c = {};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        function.computeCoefficients();
        double[] expectedCoefficients = {1};
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void computeCoefficientsHandlesFirstDegreePolynomial() {
        double[] a = {1, 2};
        double[] c = {1};
        PolynomialFunctionNewtonForm function = new PolynomialFunctionNewtonForm(a, c);
        function.computeCoefficients();
        double[] expectedCoefficients = {1, 1};
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void verifyInputArrayHandlesValidInput() {
        double[] a = {1, 2, 3};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm.verifyInputArray(a, c);
    }

    @Test(expected = NullArgumentException.class)
    public void verifyInputArrayThrowsExceptionForNullA() {
        double[] a = null;
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm.verifyInputArray(a, c);
    }

    @Test(expected = NullArgumentException.class)
    public void verifyInputArrayThrowsExceptionForNullC() {
        double[] a = {1, 2, 3};
        double[] c = null;
        PolynomialFunctionNewtonForm.verifyInputArray(a, c);
    }

    @Test(expected = NoDataException.class)
    public void verifyInputArrayThrowsExceptionForEmptyA() {
        double[] a = {};
        double[] c = {1, 2};
        PolynomialFunctionNewtonForm.verifyInputArray(a, c);
    }

    @Test(expected = NoDataException.class)
    public void verifyInputArrayThrowsExceptionForEmptyC() {
        double[] a = {1, 2, 3};
        double[] c = {};
        PolynomialFunctionNewtonForm.verifyInputArray(a, c);
    }

    @Test(expected = DimensionMismatchException.class)
    public void verifyInputArrayThrowsExceptionForMismatchedDimensions() {
        double[] a = {1, 2};
        double[] c = {1, 2, 3};
        PolynomialFunctionNewtonForm.verifyInputArray(a, c);
    }

}
