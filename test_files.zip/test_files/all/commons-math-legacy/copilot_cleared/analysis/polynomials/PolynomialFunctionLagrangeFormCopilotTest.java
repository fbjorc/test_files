package org.apache.commons.math4.legacy.analysis.polynomials;

import org.apache.commons.math4.legacy.analysis.polynomials.PolynomialFunctionLagrangeForm;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NonMonotonicSequenceException;
import org.apache.commons.math4.legacy.exception.NumberIsTooSmallException;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class PolynomialFunctionLagrangeFormCopilotTest {

    private static final double EPSILON = 1e-10;

    @Test
    public void polynomialFunctionLagrangeFormConstructorSetsValuesCorrectly() throws Exception {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        assertArrayEquals(x, function.getInterpolatingPoints(), EPSILON);
        assertArrayEquals(y, function.getInterpolatingValues(), EPSILON);
    }

    @Test
    public void polynomialFunctionLagrangeFormConstructorSortsUnsortedInputs() throws Exception {
        double[] x = {3, 1, 2};
        double[] y = {9, 1, 4};
        double[] sortedX = {1, 2, 3};
        double[] sortedY = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        assertArrayEquals(sortedX, function.getInterpolatingPoints(), EPSILON);
        assertArrayEquals(sortedY, function.getInterpolatingValues(), EPSILON);
    }

    @Test(expected = DimensionMismatchException.class)
    public void polynomialFunctionLagrangeFormConstructorThrowsExceptionForMismatchedInputLengths() throws Exception {
        double[] x = {1, 2};
        double[] y = {1, 4, 9};
        new PolynomialFunctionLagrangeForm(x, y);
    }

    @Test(expected = NumberIsTooSmallException.class)
    public void polynomialFunctionLagrangeFormConstructorThrowsExceptionForTooFewPoints() throws Exception {
        double[] x = {1};
        double[] y = {1};
        new PolynomialFunctionLagrangeForm(x, y);
    }

    @Test(expected = NonMonotonicSequenceException.class)
    public void polynomialFunctionLagrangeFormConstructorThrowsExceptionForDuplicateXValues() throws Exception {
        double[] x = {1, 2, 2};
        double[] y = {1, 4, 9};
        new PolynomialFunctionLagrangeForm(x, y);
    }

    @Test
    public void valueReturnsCorrectResultForGivenZ() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        double z = 2.0;
        double expectedValue = 4.0;
        Assert.assertEquals(expectedValue, function.value(z), EPSILON);
    }

    @Test
    public void valueReturnsCorrectResultForEdgeCaseZ() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        double z = 1.0;
        double expectedValue = 1.0;
        Assert.assertEquals(expectedValue, function.value(z), EPSILON);
    }

    @Test
    public void degreeReturnsCorrectDegree() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        int expectedDegree = 2;
        Assert.assertEquals(expectedDegree, function.degree());
    }

    @Test
    public void degreeReturnsCorrectDegreeForSinglePoint() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1};
        double[] y = {1};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        int expectedDegree = 0;
        Assert.assertEquals(expectedDegree, function.degree());
    }

    @Test
    public void getInterpolatingPointsReturnsCorrectValues() {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        double[] result = function.getInterpolatingPoints();
        Assert.assertArrayEquals(x, result, 0);
    }

    @Test
    public void getInterpolatingValuesReturnsCorrectValues() {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        double[] result = function.getInterpolatingValues();
        Assert.assertArrayEquals(y, result, 0);
    }

    @Test
    public void getInterpolatingPointsReturnsNewArray() {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        double[] result = function.getInterpolatingPoints();
        result[0] = 10;
        Assert.assertNotEquals(x[0], result[0], 0);
    }

    @Test
    public void getInterpolatingValuesReturnsNewArray() {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        double[] result = function.getInterpolatingValues();
        result[0] = 10;
        Assert.assertNotEquals(y[0], result[0], 0);
    }

    @Test
    public void getCoefficientsReturnsCorrectValuesAfterComputation() {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        double[] expectedCoefficients = {0, 0, 1}; // Coefficients for x^2
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void getCoefficientsReturnsCorrectValuesWithoutComputation() {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        function.computeCoefficients(); // Force computation of coefficients
        double[] expectedCoefficients = {0, 0, 1}; // Coefficients for x^2
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void getCoefficientsReturnsNewArray() {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        double[] result = function.getCoefficients();
        result[0] = 10;
        Assert.assertNotEquals(function.getCoefficients()[0], result[0], EPSILON);
    }

    @Test
    public void evaluateReturnsCorrectValueForSortedInput() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        double z = 2.0;
        double expectedValue = 4.0;
        Assert.assertEquals(expectedValue, PolynomialFunctionLagrangeForm.evaluate(x, y, z), EPSILON);
    }

    @Test
    public void evaluateReturnsCorrectValueForUnsortedInput() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {3, 1, 2};
        double[] y = {9, 1, 4};
        double z = 2.0;
        double expectedValue = 4.0;
        Assert.assertEquals(expectedValue, PolynomialFunctionLagrangeForm.evaluate(x, y, z), EPSILON);
    }

    @Test(expected = NonMonotonicSequenceException.class)
    public void evaluateThrowsExceptionForDuplicateXValues() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1, 2, 2};
        double[] y = {1, 4, 9};
        double z = 2.0;
        PolynomialFunctionLagrangeForm.evaluate(x, y, z);
    }

    @Test(expected = DimensionMismatchException.class)
    public void evaluateThrowsExceptionForMismatchedInputLengths() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1, 2};
        double[] y = {1, 4, 9};
        double z = 2.0;
        PolynomialFunctionLagrangeForm.evaluate(x, y, z);
    }

    @Test(expected = NumberIsTooSmallException.class)
    public void evaluateThrowsExceptionForTooFewPoints() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1};
        double[] y = {1};
        double z = 2.0;
        PolynomialFunctionLagrangeForm.evaluate(x, y, z);
    }

    @Test
    public void computeCoefficientsComputesCorrectlyForQuadratic() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        function.computeCoefficients();
        double[] expectedCoefficients = {0, 0, 1}; // Coefficients for x^2
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void computeCoefficientsComputesCorrectlyForLinear() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1, 2};
        double[] y = {1, 2};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        function.computeCoefficients();
        double[] expectedCoefficients = {0, 1}; // Coefficients for x
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void computeCoefficientsComputesCorrectlyForConstant() throws DimensionMismatchException, NumberIsTooSmallException, NonMonotonicSequenceException {
        double[] x = {1};
        double[] y = {1};
        PolynomialFunctionLagrangeForm function = new PolynomialFunctionLagrangeForm(x, y);
        function.computeCoefficients();
        double[] expectedCoefficients = {1}; // Coefficients for constant function
        Assert.assertArrayEquals(expectedCoefficients, function.getCoefficients(), EPSILON);
    }

    @Test
    public void verifyInterpolationArrayReturnsTrueForValidInput() {
        double[] x = {1, 2, 3};
        double[] y = {1, 4, 9};
        boolean abort = true;
        Assert.assertTrue(PolynomialFunctionLagrangeForm.verifyInterpolationArray(x, y, abort));
    }

    @Test(expected = DimensionMismatchException.class)
    public void verifyInterpolationArrayThrowsExceptionForMismatchedDimensions() {
        double[] x = {1, 2};
        double[] y = {1, 4, 9};
        boolean abort = true;
        PolynomialFunctionLagrangeForm.verifyInterpolationArray(x, y, abort);
    }

    @Test(expected = NumberIsTooSmallException.class)
    public void verifyInterpolationArrayThrowsExceptionForTooFewPoints() {
        double[] x = {1};
        double[] y = {1};
        boolean abort = true;
        PolynomialFunctionLagrangeForm.verifyInterpolationArray(x, y, abort);
    }

    @Test
    public void verifyInterpolationArrayReturnsFalseForNonIncreasingOrder() {
        double[] x = {1, 3, 2};
        double[] y = {1, 9, 4};
        boolean abort = false;
        Assert.assertFalse(PolynomialFunctionLagrangeForm.verifyInterpolationArray(x, y, abort));
    }

    @Test(expected = NonMonotonicSequenceException.class)
    public void verifyInterpolationArrayThrowsExceptionForNonIncreasingOrderWhenAbortIsTrue() {
        double[] x = {1, 3, 2};
        double[] y = {1, 9, 4};
        boolean abort = true;
        PolynomialFunctionLagrangeForm.verifyInterpolationArray(x, y, abort);
    }
}
