package org.apache.commons.math4.legacy.analysis.polynomials;

import org.apache.commons.math4.legacy.analysis.differentiation.DerivativeStructureCopilotTest;
import org.apache.commons.math4.legacy.exception.*;
import org.junit.Assert;
import org.junit.Test;

import static org.apache.commons.numbers.core.Precision.EPSILON;
import static org.junit.jupiter.api.Assertions.*;

public class PolynomialSplineFunctionCopilotTest {

    @Test
    public void polynomialSplineFunctionConstructorSetsValuesCorrectly() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        assertArrayEquals(knots, function.getKnots(), EPSILON);
        assertEquals(polynomials.length, function.getPolynomials().length);
    }

    @Test
    public void polynomialSplineFunctionConstructorHandlesNullKnots() {
        double[] knots = null;
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        assertThrows(NullArgumentException.class, () -> new PolynomialSplineFunction(knots, polynomials));
    }

    @Test
    public void polynomialSplineFunctionConstructorHandlesNullPolynomials() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = null;
        assertThrows(NullArgumentException.class, () -> new PolynomialSplineFunction(knots, polynomials));
    }

    @Test
    public void polynomialSplineFunctionConstructorHandlesTooFewKnots() {
        double[] knots = {1};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        assertThrows(NumberIsTooSmallException.class, () -> new PolynomialSplineFunction(knots, polynomials));
    }

    @Test
    public void polynomialSplineFunctionConstructorHandlesMismatchedDimensions() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2})
        };
        assertThrows(DimensionMismatchException.class, () -> new PolynomialSplineFunction(knots, polynomials));
    }

    @Test
    public void polynomialSplineFunctionConstructorHandlesUnorderedKnots() {
        double[] knots = {1, 3, 2};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        assertThrows(NonMonotonicSequenceException.class, () -> new PolynomialSplineFunction(knots, polynomials));
    }

    @Test
    public void valueReturnsCorrectValueForGivenInput() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        Assert.assertEquals(2, function.value(2), EPSILON);
    }

    @Test(expected = OutOfRangeException.class)
    public void valueThrowsExceptionForOutOfRange() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        function.value(4);
    }

    @Test
    public void valueReturnsCorrectValueForLastKnot() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        Assert.assertEquals(3, function.value(3), EPSILON);
    }

    @Test
    public void polynomialSplineDerivativeReturnsCorrectDerivatives() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1, 2}),
                new PolynomialFunction(new double[]{2, 3}),
                new PolynomialFunction(new double[]{3, 4})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        PolynomialSplineFunction derivative = function.polynomialSplineDerivative();

        Assert.assertEquals(2, derivative.value(1), EPSILON);
        Assert.assertEquals(3, derivative.value(2), EPSILON);
        Assert.assertEquals(4, derivative.value(3), EPSILON);
    }

    @Test
    public void polynomialSplineDerivativeReturnsCorrectNumberOfPolynomials() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1, 2}),
                new PolynomialFunction(new double[]{2, 3}),
                new PolynomialFunction(new double[]{3, 4})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        PolynomialSplineFunction derivative = function.polynomialSplineDerivative();

        Assert.assertEquals(function.getN(), derivative.getN());
    }

    @Test
    public void polynomialSplineDerivativeReturnsCorrectKnots() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1, 2}),
                new PolynomialFunction(new double[]{2, 3}),
                new PolynomialFunction(new double[]{3, 4})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        PolynomialSplineFunction derivative = function.polynomialSplineDerivative();

        Assert.assertArrayEquals(function.getKnots(), derivative.getKnots(), EPSILON);
    }

    @Test
    public void getNReturnsCorrectValue() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        Assert.assertEquals(2, function.getN());
    }

    @Test
    public void getPolynomialsReturnsCorrectPolynomials() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        PolynomialFunction[] result = function.getPolynomials();
        Assert.assertEquals(polynomials.length, result.length);
        for (int i = 0; i < polynomials.length; i++) {
            Assert.assertArrayEquals(polynomials[i].getCoefficients(), result[i].getCoefficients(), EPSILON);
        }
    }

    @Test
    public void getKnotsReturnsCorrectKnots() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        Assert.assertArrayEquals(knots, function.getKnots(), EPSILON);
    }

    @Test
    public void isValidPointReturnsTrueForValidPoint() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        Assert.assertTrue(function.isValidPoint(2));
    }

    @Test
    public void isValidPointReturnsFalseForInvalidPoint() {
        double[] knots = {1, 2, 3};
        PolynomialFunction[] polynomials = {
                new PolynomialFunction(new double[]{1}),
                new PolynomialFunction(new double[]{2}),
                new PolynomialFunction(new double[]{3})
        };
        PolynomialSplineFunction function = new PolynomialSplineFunction(knots, polynomials);
        Assert.assertFalse(function.isValidPoint(4));
    }
}
