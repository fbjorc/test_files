package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math3.random.JDKRandomGenerator;
import org.apache.commons.math4.legacy.core.Pair;
import org.apache.commons.math4.legacy.exception.NotANumberException;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.apache.commons.rng.UniformRandomProvider;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EnumeratedDistributionCopilotTest {
    @Test
    public void constructorAssignsProbabilitiesCorrectly() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", 0.1));
        pmf.add(new Pair<>("B", 0.2));
        pmf.add(new Pair<>("C", 0.7));
        EnumeratedDistribution<String> distribution = new EnumeratedDistribution<>(pmf);
        assertEquals(0.1, distribution.probability("A"), 1e-10);
        assertEquals(0.2, distribution.probability("B"), 1e-10);
        assertEquals(0.7, distribution.probability("C"), 1e-10);
    }

    @Test
    public void constructorThrowsExceptionForNegativeProbability() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", -0.1));
        assertThrows(NotPositiveException.class, () -> new EnumeratedDistribution<>(pmf));
    }

    @Test
    public void constructorThrowsExceptionForNaNProbability() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", Double.NaN));
        assertThrows(NotANumberException.class, () -> new EnumeratedDistribution<>(pmf));
    }

    @Test
    public void probabilityReturnsCorrectValueForExistingElement() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", 0.1));
        pmf.add(new Pair<>("B", 0.2));
        pmf.add(new Pair<>("C", 0.7));
        EnumeratedDistribution<String> distribution = new EnumeratedDistribution<>(pmf);
        assertEquals(0.2, distribution.probability("B"), 1e-10);
    }

    @Test
    public void probabilityReturnsZeroForNonExistingElement() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", 0.1));
        pmf.add(new Pair<>("B", 0.2));
        pmf.add(new Pair<>("C", 0.7));
        EnumeratedDistribution<String> distribution = new EnumeratedDistribution<>(pmf);
        assertEquals(0.0, distribution.probability("D"), 1e-10);
    }

    @Test
    public void probabilityCombinesProbabilitiesForDuplicateElements() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", 0.1));
        pmf.add(new Pair<>("B", 0.2));
        pmf.add(new Pair<>("A", 0.3));
        EnumeratedDistribution<String> distribution = new EnumeratedDistribution<>(pmf);
        assertEquals(0.4, distribution.probability("A"), 1e-10);
    }

    @Test
    public void getPmfReturnsCorrectProbabilities() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", 0.1));
        pmf.add(new Pair<>("B", 0.2));
        pmf.add(new Pair<>("C", 0.7));
        EnumeratedDistribution<String> distribution = new EnumeratedDistribution<>(pmf);
        List<Pair<String, Double>> resultPmf = distribution.getPmf();
        assertEquals(pmf, resultPmf);
    }

    @Test
    public void getPmfReturnsEmptyListForEmptyDistribution() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        EnumeratedDistribution<String> distribution = new EnumeratedDistribution<>(pmf);
        List<Pair<String, Double>> resultPmf = distribution.getPmf();
        assertTrue(resultPmf.isEmpty());
    }

    @Test
    public void getPmfReturnsCombinedProbabilitiesForDuplicateElements() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", 0.1));
        pmf.add(new Pair<>("A", 0.2));
        EnumeratedDistribution<String> distribution = new EnumeratedDistribution<>(pmf);
        List<Pair<String, Double>> resultPmf = distribution.getPmf();
        assertEquals(1, resultPmf.size());
        assertEquals("A", resultPmf.get(0).getKey());
        assertEquals(0.3, resultPmf.get(0).getValue(), 1e-10);
    }

    @Test
    public void createSamplerThrowsExceptionForNullRng() {
        List<Pair<String, Double>> pmf = new ArrayList<>();
        pmf.add(new Pair<>("A", 0.1));
        EnumeratedDistribution<String> distribution = new EnumeratedDistribution<>(pmf);
        assertThrows(NullPointerException.class, () -> distribution.createSampler(null));
    }
}
