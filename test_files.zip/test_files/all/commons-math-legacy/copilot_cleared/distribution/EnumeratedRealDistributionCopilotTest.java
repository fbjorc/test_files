package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.apache.commons.math4.legacy.exception.OutOfRangeException;
import org.apache.commons.rng.simple.RandomSource;
import org.apache.commons.statistics.distribution.ContinuousDistribution;
import org.junit.jupiter.api.Test;

import static org.apache.commons.numbers.core.Precision.EPSILON;
import static org.junit.jupiter.api.Assertions.*;

public class EnumeratedRealDistributionCopilotTest {

    @Test
    public void enumeratedRealDistributionConstructorSetsValuesCorrectly() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(3.0, distribution.getSupportUpperBound(), EPSILON);
        assertEquals(1.0, distribution.getSupportLowerBound(), EPSILON);
    }

    @Test
    public void enumeratedRealDistributionConstructorHandlesMismatchedDimensions() {
        double[] singletons = {1.0, 2.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        assertThrows(DimensionMismatchException.class, () -> new EnumeratedRealDistribution(singletons, probabilities));
    }

    @Test
    public void enumeratedRealDistributionConstructorHandlesNegativeProbabilities() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, -0.3, 0.6};
        assertThrows(NotPositiveException.class, () -> new EnumeratedRealDistribution(singletons, probabilities));
    }

    @Test
    public void enumeratedRealDistributionConstructorFromDataSetsValuesCorrectly() {
        double[] data = {1.0, 2.0, 2.0, 3.0, 3.0, 3.0};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(data);
        assertEquals(3.0, distribution.getSupportUpperBound(), EPSILON);
        assertEquals(1.0, distribution.getSupportLowerBound(), EPSILON);
    }

    @Test
    public void densityReturnsCorrectProbabilityForValueInDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(0.3, distribution.density(2.0), EPSILON);
    }

    @Test
    public void densityReturnsZeroForValueNotInDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.density(4.0), EPSILON);
    }

    @Test
    public void densityReturnsZeroForEmptyDistribution() {
        double[] singletons = {};
        double[] probabilities = {};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.density(1.0), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsCorrectValueForUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.333, 0.333, 0.334};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(0.666, distribution.cumulativeProbability(2.0), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsCorrectValueForNonUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(0.4, distribution.cumulativeProbability(2.0), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsZeroForValueLessThanSupportLowerBound() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.cumulativeProbability(0.5), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsOneForValueGreaterThanSupportUpperBound() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(1.0, distribution.cumulativeProbability(4.0), EPSILON);
    }

    @Test
    public void inverseCumulativeProbabilityReturnsCorrectValueForUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.333, 0.333, 0.334};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(2.0, distribution.inverseCumulativeProbability(0.666), EPSILON);
    }

    @Test
    public void inverseCumulativeProbabilityReturnsCorrectValueForNonUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(2.0, distribution.inverseCumulativeProbability(0.4), EPSILON);
    }

    @Test
    public void inverseCumulativeProbabilityThrowsForValueLessThanZero() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertThrows(OutOfRangeException.class, () -> distribution.inverseCumulativeProbability(-0.1));
    }

    @Test
    public void inverseCumulativeProbabilityThrowsForValueGreaterThanOne() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertThrows(OutOfRangeException.class, () -> distribution.inverseCumulativeProbability(1.1));
    }

    @Test
    public void meanCalculationReturnsCorrectValueForNonUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(2.5, distribution.getMean(), EPSILON);
    }

    @Test
    public void meanCalculationReturnsZeroForEmptyDistribution() {
        double[] singletons = {};
        double[] probabilities = {};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.getMean(), EPSILON);
    }

    @Test
    public void varianceCalculationReturnsZeroForSingleValueDistribution() {
        double[] singletons = {1.0};
        double[] probabilities = {1.0};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.getVariance(), EPSILON);
    }

    @Test
    public void supportLowerBoundReturnsMinimumForNonUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(1.0, distribution.getSupportLowerBound(), EPSILON);
    }

    @Test
    public void supportLowerBoundReturnsMinimumForUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.333, 0.333, 0.334};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(1.0, distribution.getSupportLowerBound(), EPSILON);
    }

    @Test
    public void supportLowerBoundReturnsPositiveInfinityForEmptyDistribution() {
        double[] singletons = {};
        double[] probabilities = {};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(Double.POSITIVE_INFINITY, distribution.getSupportLowerBound(), EPSILON);
    }

    @Test
    public void supportLowerBoundIgnoresZeroProbabilityValues() {
        double[] singletons = {1.0, 2.0, 3.0, 4.0};
        double[] probabilities = {0.0, 0.3, 0.6, 0.1};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(2.0, distribution.getSupportLowerBound(), EPSILON);
    }

    @Test
    public void supportUpperBoundReturnsMaximumForNonUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(3.0, distribution.getSupportUpperBound(), EPSILON);
    }

    @Test
    public void supportUpperBoundReturnsMaximumForUniformDistribution() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.333, 0.333, 0.334};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(3.0, distribution.getSupportUpperBound(), EPSILON);
    }

    @Test
    public void supportUpperBoundReturnsNegativeInfinityForEmptyDistribution() {
        double[] singletons = {};
        double[] probabilities = {};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(Double.NEGATIVE_INFINITY, distribution.getSupportUpperBound(), EPSILON);
    }

    @Test
    public void supportUpperBoundIgnoresZeroProbabilityValues() {
        double[] singletons = {1.0, 2.0, 3.0, 4.0};
        double[] probabilities = {0.1, 0.3, 0.0, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        assertEquals(4.0, distribution.getSupportUpperBound(), EPSILON);
    }

    @Test
    public void samplerReturnsValueWithinDistributionSupport() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        ContinuousDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        double sample = sampler.sample();
        assertTrue(sample >= 1.0 && sample <= 3.0);
    }

    @Test
    public void samplerReturnsValueWithinUniformDistributionSupport() {
        double[] singletons = {1.0, 2.0, 3.0};
        double[] probabilities = {0.333, 0.333, 0.334};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        ContinuousDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        double sample = sampler.sample();
        assertTrue(sample >= 1.0 && sample <= 3.0);
    }

    @Test
    public void samplerReturnsNaNForEmptyDistribution() {
        double[] singletons = {};
        double[] probabilities = {};
        EnumeratedRealDistribution distribution = new EnumeratedRealDistribution(singletons, probabilities);
        ContinuousDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        double sample = sampler.sample();
        assertTrue(Double.isNaN(sample));
    }

}
