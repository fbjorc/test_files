package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math3.random.JDKRandomGenerator;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.apache.commons.statistics.distribution.DiscreteDistribution;
import org.junit.jupiter.api.Test;

import static org.apache.commons.numbers.core.Precision.EPSILON;
import static org.junit.jupiter.api.Assertions.*;

public class EnumeratedIntegerDistributionCopilotTest {

    @Test
    public void enumeratedIntegerDistributionConstructorSetsValuesCorrectly() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(3, distribution.getSupportUpperBound());
        assertEquals(1, distribution.getSupportLowerBound());
    }

    @Test
    public void enumeratedIntegerDistributionConstructorHandlesMismatchedDimensions() {
        int[] singletons = {1, 2};
        double[] probabilities = {0.1, 0.3, 0.6};
        assertThrows(DimensionMismatchException.class, () -> new EnumeratedIntegerDistribution(singletons, probabilities));
    }

    @Test
    public void enumeratedIntegerDistributionConstructorHandlesNegativeProbabilities() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, -0.3, 0.6};
        assertThrows(NotPositiveException.class, () -> new EnumeratedIntegerDistribution(singletons, probabilities));
    }

    @Test
    public void enumeratedIntegerDistributionConstructorFromDataSetsValuesCorrectly() {
        int[] data = {1, 2, 2, 3, 3, 3};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(data);
        assertEquals(3, distribution.getSupportUpperBound());
        assertEquals(1, distribution.getSupportLowerBound());
    }

    @Test
    public void probabilityReturnsCorrectValueForSingletonInDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(0.3, distribution.probability(2), EPSILON);
    }

    @Test
    public void probabilityReturnsZeroForSingletonNotInDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.probability(4), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsZeroForValueLessThanSupportLowerBound() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.cumulativeProbability(0), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsOneForValueGreaterThanSupportUpperBound() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(1.0, distribution.cumulativeProbability(4), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsCorrectValueForValueInDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(0.4, distribution.cumulativeProbability(2), EPSILON);
    }

    @Test
    public void meanReturnsCorrectValueForUniformDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.333, 0.333, 0.334};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(2.0, distribution.getMean(), EPSILON);
    }

    @Test
    public void meanReturnsCorrectValueForNonUniformDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(2.5, distribution.getMean(), EPSILON);
    }

    @Test
    public void meanReturnsZeroForDistributionWithNoElements() {
        int[] singletons = {};
        double[] probabilities = {};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.getMean(), EPSILON);
    }

    @Test
    public void varianceReturnsCorrectValueForUniformDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.333, 0.333, 0.334};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(0.667, distribution.getVariance(), EPSILON);
    }

    @Test
    public void varianceReturnsCorrectValueForNonUniformDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(0.65, distribution.getVariance(), EPSILON);
    }

    @Test
    public void varianceReturnsZeroForDistributionWithSingleElement() {
        int[] singletons = {1};
        double[] probabilities = {1.0};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(0.0, distribution.getVariance(), EPSILON);
    }

    @Test
    public void supportLowerBoundReturnsMinimumValueForNonEmptyDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(1, distribution.getSupportLowerBound());
    }

    @Test
    public void supportLowerBoundReturnsMaxIntegerForEmptyDistribution() {
        int[] singletons = {};
        double[] probabilities = {};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(Integer.MAX_VALUE, distribution.getSupportLowerBound());
    }

    @Test
    public void supportLowerBoundIgnoresZeroProbabilityValues() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.0, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(2, distribution.getSupportLowerBound());
    }

    @Test
    public void supportUpperBoundReturnsMaximumValueForNonEmptyDistribution() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.1, 0.3, 0.6};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(3, distribution.getSupportUpperBound());
    }

    @Test
    public void supportUpperBoundReturnsMinIntegerForEmptyDistribution() {
        int[] singletons = {};
        double[] probabilities = {};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(Integer.MIN_VALUE, distribution.getSupportUpperBound());
    }

    @Test
    public void supportUpperBoundIgnoresZeroProbabilityValues() {
        int[] singletons = {1, 2, 3};
        double[] probabilities = {0.6, 0.3, 0.0};
        EnumeratedIntegerDistribution distribution = new EnumeratedIntegerDistribution(singletons, probabilities);
        assertEquals(2, distribution.getSupportUpperBound());
    }
}
