package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.random.JDKRandomGenerator;
import org.apache.commons.math4.legacy.core.Pair;
import org.apache.commons.rng.UniformRandomProvider;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MixtureMultivariateRealDistributionCopilotTest {
    @Test
    public void densityReturnsZeroForEmptyDistribution() {
        List<Pair<Double, MultivariateRealDistribution>> components = new ArrayList<>();
        MixtureMultivariateRealDistribution<MultivariateRealDistribution> distribution =
                new MixtureMultivariateRealDistribution<>(components);
        double[] values = {0.5};
        assertEquals(0.0, distribution.density(values), 1e-10);
    }

    @Test
    public void getComponentsReturnsEmptyListForEmptyDistribution() {
        List<Pair<Double, MultivariateRealDistribution>> components = new ArrayList<>();
        MixtureMultivariateRealDistribution<MultivariateRealDistribution> distribution =
                new MixtureMultivariateRealDistribution<>(components);
        List<Pair<Double, MultivariateRealDistribution>> resultComponents = distribution.getComponents();
        assertTrue(resultComponents.isEmpty());
    }
}
