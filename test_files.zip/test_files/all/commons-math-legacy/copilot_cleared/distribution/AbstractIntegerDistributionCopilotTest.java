package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math4.legacy.distribution.AbstractIntegerDistribution;
import org.apache.commons.math4.legacy.exception.NumberIsTooLargeException;
import org.apache.commons.math4.legacy.exception.OutOfRangeException;
import org.apache.commons.rng.UniformRandomProvider;
import org.apache.commons.rng.simple.RandomSource;
import org.apache.commons.statistics.distribution.DiscreteDistribution;
import org.junit.Assert;
import org.junit.Test;

import static org.apache.commons.numbers.core.Precision.EPSILON;

public class AbstractIntegerDistributionCopilotTest {

    @Test
    public void probabilityReturnsCorrectValueForValidRange() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(0.5, distribution.probability(0, 1), EPSILON);
    }

    @Test(expected = NumberIsTooLargeException.class)
    public void probabilityThrowsExceptionForInvalidRange() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        distribution.probability(2, 1);
    }

    @Test
    public void inverseCumulativeProbabilityReturnsLowerBoundForZero() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(distribution.getSupportLowerBound(), distribution.inverseCumulativeProbability(0.0));
    }

    @Test
    public void inverseCumulativeProbabilityReturnsUpperBoundForOne() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(distribution.getSupportUpperBound(), distribution.inverseCumulativeProbability(1.0));
    }

    @Test(expected = OutOfRangeException.class)
    public void inverseCumulativeProbabilityThrowsExceptionForNegative() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        distribution.inverseCumulativeProbability(-0.1);
    }

    @Test(expected = OutOfRangeException.class)
    public void inverseCumulativeProbabilityThrowsExceptionForGreaterThanOne() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        distribution.inverseCumulativeProbability(1.1);
    }

    @Test
    public void inverseCumulativeProbabilityReturnsCorrectValueForValidRange() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(1, distribution.inverseCumulativeProbability(0.75));
    }

    @Test
    public void solveInverseCumulativeProbabilityReturnsUpperBoundForMidRange() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(1, distribution.solveInverseCumulativeProbability(0.5, 0, 1));
    }

    @Test
    public void solveInverseCumulativeProbabilityReturnsUpperBoundForUpperRange() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(1, distribution.solveInverseCumulativeProbability(0.75, 0, 1));
    }

    @Test
    public void solveInverseCumulativeProbabilityReturnsLowerBoundForLowerRange() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(0, distribution.solveInverseCumulativeProbability(0.25, 0, 1));
    }

    @Test
    public void solveInverseCumulativeProbabilityHandlesLargeRange() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(500000, distribution.solveInverseCumulativeProbability(0.5, 0, 1000000));
    }

    @Test
    public void solveInverseCumulativeProbabilityHandlesNegativeRange() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(-1, distribution.solveInverseCumulativeProbability(0.75, -2, 0));
    }

    @Test
    public void logProbabilityReturnsCorrectValueForValidInput() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        Assert.assertEquals(-Math.log(2), distribution.logProbability(1), EPSILON);
    }

    @Test
    public void logProbabilityReturnsNegativeInfinityForZeroProbability() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution() {
            @Override
            public double probability(int x) {
                return 0;
            }
        };
        Assert.assertEquals(Double.NEGATIVE_INFINITY, distribution.logProbability(1), EPSILON);
    }

    @Test
    public void sampleReturnsArrayWithCorrectSize() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        DiscreteDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        int[] samples = AbstractIntegerDistribution.sample(5, sampler);
        Assert.assertEquals(5, samples.length);
    }

    @Test
    public void sampleReturnsArrayWithValidValues() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        DiscreteDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        int[] samples = AbstractIntegerDistribution.sample(5, sampler);
        for (int sample : samples) {
            Assert.assertTrue(sample == 0 || sample == 1);
        }
    }

    @Test
    public void createSamplerReturnsCorrectSampler() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        UniformRandomProvider rng = RandomSource.create(RandomSource.MT);
        DiscreteDistribution.Sampler sampler = distribution.createSampler(rng);
        Assert.assertNotNull(sampler);
        Assert.assertTrue(sampler.sample() == 0 || sampler.sample() == 1);
    }

    @Test
    public void createSamplerHandlesDifferentRandomSources() {
        AbstractIntegerDistribution distribution = new DummyIntegerDistribution();
        for (RandomSource source : RandomSource.values()) {
            UniformRandomProvider rng = RandomSource.create(source);
            DiscreteDistribution.Sampler sampler = distribution.createSampler(rng);
            Assert.assertNotNull(sampler);
            Assert.assertTrue(sampler.sample() == 0 || sampler.sample() == 1);
        }
    }

    private static class DummyIntegerDistribution extends AbstractIntegerDistribution {

        @Override
        public double probability(int x) {
            return 0.5;
        }

        @Override
        public double cumulativeProbability(int x) {
            return x == 0 ? 0.5 : 1.0;
        }

        @Override
        public int getSupportLowerBound() {
            return 0;
        }

        @Override
        public int getSupportUpperBound() {
            return 1;
        }

        @Override
        public double getMean() {
            return 0.5;
        }

        @Override
        public double getVariance() {
            return 0.25;
        }

        public boolean isSupportConnected() {
            return true;
        }
    }

}
