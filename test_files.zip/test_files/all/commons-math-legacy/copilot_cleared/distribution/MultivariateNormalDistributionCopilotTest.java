package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math4.legacy.distribution.MultivariateNormalDistribution;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.linear.Array2DRowRealMatrix;
import org.apache.commons.math4.legacy.linear.NonPositiveDefiniteMatrixException;
import org.apache.commons.math4.legacy.linear.RealMatrix;
import org.apache.commons.rng.simple.RandomSource;
import org.junit.jupiter.api.Test;

import static org.apache.commons.numbers.core.Precision.EPSILON;
import static org.junit.jupiter.api.Assertions.*;

public class MultivariateNormalDistributionCopilotTest {

    @Test
    public void multivariateNormalDistributionConstructorSetsValuesCorrectly() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        assertDoesNotThrow(() -> new MultivariateNormalDistribution(means, covariances));
    }

    @Test
    public void multivariateNormalDistributionConstructorHandlesMismatchedDimensions() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}};
        assertThrows(DimensionMismatchException.class, () -> new MultivariateNormalDistribution(means, covariances));
    }

    @Test
    public void multivariateNormalDistributionConstructorHandlesNonPositiveDefiniteMatrix() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{-1.0, 0.0}, {0.0, -1.0}};
        assertThrows(NonPositiveDefiniteMatrixException.class, () -> new MultivariateNormalDistribution(means, covariances));
    }

    @Test
    public void getMeansReturnsCorrectValues() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        assertArrayEquals(means, distribution.getMeans());
    }

    @Test
    public void getCovariancesReturnsCorrectValues() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        assertArrayEquals(covariances, distribution.getCovariances().getData());
    }

    @Test
    public void densityReturnsCorrectValueForGivenInput() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        double[] vals = {0.0, 1.0};
        assertEquals(0.09653235263005393, distribution.density(vals), EPSILON);
    }

    @Test
    public void densityThrowsExceptionForMismatchedDimensions() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        double[] vals = {0.0};
        assertThrows(DimensionMismatchException.class, () -> distribution.density(vals));
    }

    @Test
    public void getStandardDeviationsReturnsCorrectValues() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        assertArrayEquals(new double[]{1.0, 1.0}, distribution.getStandardDeviations(), EPSILON);
    }

    @Test
    public void getStandardDeviationsHandlesZeroCovariance() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{0.0, 0.0}, {0.0, 0.0}};
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        assertArrayEquals(new double[]{0.0, 0.0}, distribution.getStandardDeviations(), EPSILON);
    }

    @Test
    public void createSamplerReturnsCorrectSampler() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        MultivariateRealDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));

        double[] sample = sampler.sample();
        assertEquals(2, sample.length);
    }

    @Test
    public void createSamplerReturnsConsistentSamples() {
        double[] means = {0.0, 1.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        MultivariateRealDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));

        double[] sample1 = sampler.sample();
        double[] sample2 = sampler.sample();
        assertNotEquals(sample1, sample2);
    }
}
