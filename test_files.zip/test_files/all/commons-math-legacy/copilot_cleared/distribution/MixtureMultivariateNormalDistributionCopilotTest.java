package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math4.legacy.distribution.MultivariateNormalDistribution;
import org.apache.commons.math4.legacy.distribution.MixtureMultivariateNormalDistribution;
import org.apache.commons.math4.legacy.core.Pair;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.NotPositiveException;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MixtureMultivariateNormalDistributionCopilotTest {

    @Test
    public void mixtureMultivariateNormalDistributionConstructorWithComponentsSetsValuesCorrectly() {
        List<Pair<Double, MultivariateNormalDistribution>> components = new ArrayList<>();
        components.add(new Pair<>(0.5, new MultivariateNormalDistribution(new double[]{0.0}, new double[][]{{1.0}})));
        components.add(new Pair<>(0.5, new MultivariateNormalDistribution(new double[]{1.0}, new double[][]{{1.0}})));

        MixtureMultivariateNormalDistribution distribution = new MixtureMultivariateNormalDistribution(components);
        assertEquals(2, distribution.getComponents().size());
    }

    @Test
    public void mixtureMultivariateNormalDistributionConstructorWithWeightsMeansCovariancesSetsValuesCorrectly() {
        double[] weights = {0.5, 0.5};
        double[][] means = {{0.0}, {1.0}};
        double[][][] covariances = {{{1.0}}, {{1.0}}};

        MixtureMultivariateNormalDistribution distribution = new MixtureMultivariateNormalDistribution(weights, means, covariances);
        assertEquals(2, distribution.getComponents().size());
    }

    @Test
    public void mixtureMultivariateNormalDistributionConstructorHandlesMismatchedDimensions() {
        double[] weights = {0.5, 0.5, 0.5};
        double[][] means = {{0.0}, {1.0}};
        double[][][] covariances = {{{1.0}}, {{1.0}}};

        assertThrows(DimensionMismatchException.class, () -> new MixtureMultivariateNormalDistribution(weights, means, covariances));
    }

    @Test
    public void mixtureMultivariateNormalDistributionConstructorHandlesNegativeWeights() {
        double[] weights = {0.5, -0.5};
        double[][] means = {{0.0}, {1.0}};
        double[][][] covariances = {{{1.0}}, {{1.0}}};

        assertThrows(NotPositiveException.class, () -> new MixtureMultivariateNormalDistribution(weights, means, covariances));
    }
}
