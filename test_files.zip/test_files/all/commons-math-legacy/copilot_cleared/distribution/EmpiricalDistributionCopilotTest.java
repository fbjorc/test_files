package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math4.legacy.distribution.EmpiricalDistribution;
import org.apache.commons.math4.legacy.exception.NotStrictlyPositiveException;
import org.apache.commons.math4.legacy.exception.OutOfRangeException;
import org.apache.commons.math4.legacy.stat.descriptive.StatisticalSummary;
import org.apache.commons.math4.legacy.stat.descriptive.SummaryStatistics;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.apache.commons.numbers.core.Precision.EPSILON;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class EmpiricalDistributionCopilotTest {

    @Test
    public void fromMethodReturnsCorrectInstanceWithoutKernelFactory() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        Assertions.assertNotNull(distribution);
        assertEquals(5, distribution.getBinCount());
    }

    @Test
    public void fromMethodThrowsExceptionForNonPositiveBinCount() {
        double[] input = {1, 2, 3, 4, 5};
        assertThrows(NotStrictlyPositiveException.class, () -> EmpiricalDistribution.from(0, input));
    }

    @Test
    public void getSampleStatsReturnsCorrectStats() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        StatisticalSummary stats = distribution.getSampleStats();
        assertEquals(5, stats.getN());
        assertEquals(3.0, stats.getMean(), EPSILON);
        assertEquals(2.5, stats.getVariance(), EPSILON);
    }

    @Test
    public void getBinCountReturnsCorrectValue() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(5, distribution.getBinCount());
    }

    @Test
    public void getBinCountReturnsCorrectValueForDifferentBinCount() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(3, input);
        assertEquals(3, distribution.getBinCount());
    }

    @Test
    public void getBinStatsReturnsCorrectStats() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        List<SummaryStatistics> binStats = distribution.getBinStats();
        assertEquals(5, binStats.size());
        for (SummaryStatistics stats : binStats) {
            assertEquals(1, stats.getN());
        }
    }

    @Test
    public void getUpperBoundsReturnsCorrectBounds() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        double[] upperBounds = distribution.getUpperBounds();
        assertEquals(5, upperBounds.length);
        assertEquals(1.0, upperBounds[0], EPSILON);
        assertEquals(2.0, upperBounds[1], EPSILON);
        assertEquals(3.0, upperBounds[2], EPSILON);
        assertEquals(4.0, upperBounds[3], EPSILON);
        assertEquals(5.0, upperBounds[4], EPSILON);
    }

    @Test
    public void getUpperBoundsReturnsCorrectBoundsForDifferentBinCount() {
        double[] input = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        double[] upperBounds = distribution.getUpperBounds();
        assertEquals(5, upperBounds.length);
        assertEquals(2.0, upperBounds[0], EPSILON);
        assertEquals(4.0, upperBounds[1], EPSILON);
        assertEquals(6.0, upperBounds[2], EPSILON);
        assertEquals(8.0, upperBounds[3], EPSILON);
        assertEquals(10.0, upperBounds[4], EPSILON);
    }

    @Test
    public void getGeneratorUpperBoundsReturnsCorrectValues() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        double[] upperBounds = distribution.getGeneratorUpperBounds();
        assertEquals(5, upperBounds.length);
        Assertions.assertArrayEquals(distribution.getUpperBounds(), upperBounds, EPSILON);
    }

    @Test
    public void getGeneratorUpperBoundsReturnsEmptyForNoBins() {
        double[] input = {};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(0, input);
        double[] upperBounds = distribution.getGeneratorUpperBounds();
        assertEquals(0, upperBounds.length);
    }

    @Test
    public void densityReturnsZeroForValueLessThanMin() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(0.0, distribution.density(0.5), EPSILON);
    }

    @Test
    public void densityReturnsZeroForValueGreaterThanMax() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(0.0, distribution.density(5.5), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsZeroForValueLessThanMin() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(0.0, distribution.cumulativeProbability(0.5), EPSILON);
    }

    @Test
    public void cumulativeProbabilityReturnsOneForValueGreaterThanMax() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(1.0, distribution.cumulativeProbability(5.5), EPSILON);
    }

    @Test
    public void inverseCumulativeProbabilityReturnsLowerBoundForZero() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(1.0, distribution.inverseCumulativeProbability(0), EPSILON);
    }

    @Test
    public void inverseCumulativeProbabilityReturnsUpperBoundForOne() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(5.0, distribution.inverseCumulativeProbability(1), EPSILON);
    }

    @Test
    public void inverseCumulativeProbabilityThrowsForNegative() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertThrows(OutOfRangeException.class, () -> distribution.inverseCumulativeProbability(-0.1));
    }

    @Test
    public void inverseCumulativeProbabilityThrowsForGreaterThanOne() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertThrows(OutOfRangeException.class, () -> distribution.inverseCumulativeProbability(1.1));
    }

    @Test
    public void meanReturnsCorrectValueForUniformDistribution() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(3.0, distribution.getMean(), EPSILON);
    }

    @Test
    public void meanReturnsCorrectValueForNonUniformDistribution() {
        double[] input = {1, 2, 2, 3, 3, 3, 4, 4, 4, 4};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(3.0, distribution.getMean(), EPSILON);
    }

    @Test
    public void varianceReturnsZeroForSingleValue() {
        double[] input = {1};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(1, input);
        assertEquals(0.0, distribution.getVariance(), EPSILON);
    }

    @Test
    public void varianceReturnsCorrectValueForUniformDistribution() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        double expectedVariance = 2.5; // calculate expected variance based on your input
        assertEquals(expectedVariance, distribution.getVariance(), EPSILON);
    }

    @Test
    public void varianceReturnsCorrectValueForNonUniformDistribution() {
        double[] input = {1, 2, 2, 3, 3, 3, 4, 4, 4, 4};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        double expectedVariance = 1.0; // calculate expected variance based on your input
        assertEquals(expectedVariance, distribution.getVariance(), EPSILON);
    }

    @Test
    public void supportLowerBoundReturnsMinValue() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(1.0, distribution.getSupportLowerBound(), EPSILON);
    }

    @Test
    public void supportLowerBoundReturnsMinValueForSingleElement() {
        double[] input = {1};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(1, input);
        assertEquals(1.0, distribution.getSupportLowerBound(), EPSILON);
    }

    @Test
    public void supportUpperBoundReturnsMaxValue() {
        double[] input = {1, 2, 3, 4, 5};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(5, input);
        assertEquals(5.0, distribution.getSupportUpperBound(), EPSILON);
    }

    @Test
    public void supportUpperBoundReturnsMaxValueForSingleElement() {
        double[] input = {1};
        EmpiricalDistribution distribution = EmpiricalDistribution.from(1, input);
        assertEquals(1.0, distribution.getSupportUpperBound(), EPSILON);
    }
}
