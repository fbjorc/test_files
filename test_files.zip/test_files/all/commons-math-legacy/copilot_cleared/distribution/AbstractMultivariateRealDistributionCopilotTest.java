package org.apache.commons.math4.legacy.distribution;

import org.apache.commons.math4.legacy.exception.NotStrictlyPositiveException;
import org.apache.commons.rng.UniformRandomProvider;
import org.apache.commons.rng.simple.RandomSource;
import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;

public class AbstractMultivariateRealDistributionCopilotTest {

    @Test
    public void constructorSetsCorrectDimension() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(3);
        Assert.assertEquals(3, distribution.getDimension());
    }

    @Test
    public void constructorSetsCorrectDimensionForZero() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(0);
        Assert.assertEquals(0, distribution.getDimension());
    }

    @Test
    public void constructorSetsCorrectDimensionForNegative() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(-3);
        Assert.assertEquals(-3, distribution.getDimension());
    }

    @Test
    public void getDimensionReturnsCorrectValueForPositiveInput() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(5);
        Assert.assertEquals(5, distribution.getDimension());
    }

    @Test
    public void getDimensionReturnsCorrectValueForZeroInput() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(0);
        Assert.assertEquals(0, distribution.getDimension());
    }

    @Test
    public void createSamplerReturnsNonNullValue() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(3);
        UniformRandomProvider rng = RandomSource.create(RandomSource.MT);
        MultivariateRealDistribution.Sampler sampler = distribution.createSampler(rng);
        Assert.assertNotNull(sampler);
    }

    @Test
    public void createSamplerReturnsCorrectSampler() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(3);
        UniformRandomProvider rng = RandomSource.create(RandomSource.MT);
        MultivariateRealDistribution.Sampler sampler = distribution.createSampler(rng);
        Assert.assertTrue(Arrays.equals(new double[3], sampler.sample()));
    }

    @Test
    public void sampleReturnsCorrectNumberOfSamples() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(3);
        MultivariateRealDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        double[][] samples = AbstractMultivariateRealDistribution.sample(5, sampler);
        Assert.assertEquals(5, samples.length);
    }

    @Test
    public void sampleReturnsCorrectSampleSize() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(3);
        MultivariateRealDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        double[][] samples = AbstractMultivariateRealDistribution.sample(5, sampler);
        for (double[] sample : samples) {
            Assert.assertEquals(3, sample.length);
        }
    }

    @Test(expected = NotStrictlyPositiveException.class)
    public void sampleThrowsExceptionForZeroSampleSize() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(3);
        MultivariateRealDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        AbstractMultivariateRealDistribution.sample(0, sampler);
    }

    @Test(expected = NotStrictlyPositiveException.class)
    public void sampleThrowsExceptionForNegativeSampleSize() {
        AbstractMultivariateRealDistribution distribution = new DummyMultivariateRealDistribution(3);
        MultivariateRealDistribution.Sampler sampler = distribution.createSampler(RandomSource.create(RandomSource.MT));
        AbstractMultivariateRealDistribution.sample(-1, sampler);
    }

    private static class DummyMultivariateRealDistribution extends AbstractMultivariateRealDistribution {
        public DummyMultivariateRealDistribution(int n) {
            super(n);
        }

        @Override
        public double density(double[] x) {
            return 0;
        }

        @Override
        public Sampler createSampler(UniformRandomProvider rng) {
            return null;
        }
    }

}
