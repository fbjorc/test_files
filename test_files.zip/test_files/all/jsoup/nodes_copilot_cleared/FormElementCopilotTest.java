package org.jsoup.nodes;

import org.jsoup.Connection;
import org.jsoup.parser.Tag;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class FormElementCopilotTest {

    @Test
    public void addElementAddsElementToForm() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element input = new Element(Tag.valueOf("input"), "");
        form.addElement(input);

        assertTrue(form.elements().contains(input));
    }

    @Test
    public void addElementReturnsFormElement() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element input = new Element(Tag.valueOf("input"), "");

        FormElement returnedForm = form.addElement(input);

        assertSame(form, returnedForm);
    }

    @Test
    public void elementsReturnsCorrectElements() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element input1 = new Element(Tag.valueOf("input"), "");
        Element input2 = new Element(Tag.valueOf("input"), "");
        form.addElement(input1);
        form.addElement(input2);

        Elements elements = form.elements();

        assertEquals(2, elements.size());
        assertTrue(elements.contains(input1));
        assertTrue(elements.contains(input2));
    }

    @Test
    public void elementsReturnsEmptyForNewForm() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());

        Elements elements = form.elements();

        assertTrue(elements.isEmpty());
    }

    @Test
    public void removeChildRemovesElementFromForm() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element input = new Element(Tag.valueOf("input"), "");
        form.addElement(input);

        form.removeChild(input);

        assertFalse(form.elements().contains(input));
    }

    @Test
    public void submitReturnsConnectionWithCorrectMethod() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        form.attr("method", "POST");

        Connection connection = form.submit();

        assertEquals(Connection.Method.POST, connection.request().method());
    }

    @Test
    public void submitReturnsConnectionWithCorrectUrl() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        form.attr("action", "http://example.com");

        Connection connection = form.submit();

        assertEquals("http://example.com", connection.request().url().toString());
    }

    @Test
    public void submitThrowsExceptionWhenActionUrlCannotBeDetermined() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());

        assertThrows(IllegalArgumentException.class, form::submit);
    }

    @Test
    public void formDataReturnsCorrectDataForTextInput() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element input = new Element(Tag.valueOf("input"), "");
        input.attr("name", "test");
        input.val("value");
        form.addElement(input);

        List<Connection.KeyVal> data = form.formData();

        assertEquals(1, data.size());
        assertEquals("test", data.get(0).key());
        assertEquals("value", data.get(0).value());
    }

    @Test
    public void formDataReturnsCorrectDataForSelectedOption() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element select = new Element(Tag.valueOf("select"), "");
        select.attr("name", "test");
        Element option = new Element(Tag.valueOf("option"), "");
        option.attr("selected", "selected");
        option.val("value");
        select.appendChild(option);
        form.addElement(select);

        List<Connection.KeyVal> data = form.formData();

        assertEquals(1, data.size());
        assertEquals("test", data.get(0).key());
        assertEquals("value", data.get(0).value());
    }

    @Test
    public void formDataReturnsCorrectDataForCheckedCheckbox() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element input = new Element(Tag.valueOf("input"), "");
        input.attr("type", "checkbox");
        input.attr("name", "test");
        input.attr("checked", "checked");
        input.val("value");
        form.addElement(input);

        List<Connection.KeyVal> data = form.formData();

        assertEquals(1, data.size());
        assertEquals("test", data.get(0).key());
        assertEquals("value", data.get(0).value());
    }

    @Test
    public void formDataReturnsNoDataForUncheckedCheckbox() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element input = new Element(Tag.valueOf("input"), "");
        input.attr("type", "checkbox");
        input.attr("name", "test");
        input.val("value");
        form.addElement(input);

        List<Connection.KeyVal> data = form.formData();

        assertTrue(data.isEmpty());
    }

    @Test
    public void cloneReturnsIdenticalForm() {
        FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
        Element input = new Element(Tag.valueOf("input"), "");
        input.attr("name", "test");
        input.val("value");
        form.addElement(input);

        FormElement clonedForm = form.clone();

        assertEquals(form.outerHtml(), clonedForm.outerHtml());
    }
}
