package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class CommentCopilotTest {

    @Test
    public void commentConstructorSetsData() {
        String data = "sample comment";
        Comment comment = new Comment(data);
        assertEquals(data, comment.getData());
    }

    @Test
    public void commentConstructorHandlesNullData() {
        Comment comment = new Comment(null);
        assertEquals("", comment.getData());
    }

    @Test
    public void commentConstructorHandlesEmptyData() {
        Comment comment = new Comment("");
        assertEquals("", comment.getData());
    }

    @Test
    public void nodeNameReturnsCorrectValue() {
        Comment comment = new Comment("data");
        assertEquals("#comment", comment.nodeName());
    }

    @Test
    public void getDataReturnsCommentContent() {
        String data = "sample comment";
        Comment comment = new Comment(data);
        assertEquals(data, comment.getData());
    }

    @Test
    public void setDataChangesCommentData() {
        String initialData = "initial comment";
        String newData = "new comment";
        Comment comment = new Comment(initialData);
        comment.setData(newData);
        assertEquals(newData, comment.getData());
    }

    @Test
    public void setDataHandlesNullInput() {
        String initialData = "initial comment";
        Comment comment = new Comment(initialData);
        comment.setData(null);
        assertEquals("", comment.getData());
    }

    @Test
    public void outerHtmlHeadAppendsCommentSyntaxAndData() throws IOException {
        String data = "sample comment";
        Comment comment = new Comment(data);
        StringBuilder accum = new StringBuilder();
        comment.outerHtmlHead(accum, 0, new Document.OutputSettings());
        assertEquals("<!--" + data + "-->", accum.toString());
    }

    @Test
    public void outerHtmlTailDoesNotModifyAccumulator() throws IOException {
        StringBuilder accum = new StringBuilder("initial content");
        Comment comment = new Comment("data");
        comment.outerHtmlTail(accum, 0, new Document.OutputSettings());
        assertEquals("initial content", accum.toString());
    }

    @Test
    public void toStringReturnsOuterHtml() {
        String data = "sample comment";
        Comment comment = new Comment(data);
        assertEquals(comment.outerHtml(), comment.toString());
    }

    @Test
    public void cloneCreatesIdenticalComment() {
        String data = "sample comment";
        Comment comment = new Comment(data);
        Comment clone = comment.clone();
        assertEquals(comment.getData(), clone.getData());
        assertNotSame(comment, clone);
    }

    @Test
    public void cloneCreatesIndependentComment() {
        String data = "sample comment";
        Comment comment = new Comment(data);
        Comment clone = comment.clone();
        clone.setData("modified comment");
        assertNotEquals(comment.getData(), clone.getData());
    }

    @Test
    public void isXmlDeclarationReturnsTrueForXmlDeclaration() {
        String data = "?xml version=\"1.0\" encoding=\"UTF-8\"?";
        Comment comment = new Comment(data);
        assertTrue(comment.isXmlDeclaration());
    }

    @Test
    public void isXmlDeclarationReturnsFalseForRegularComment() {
        String data = "sample comment";
        Comment comment = new Comment(data);
        assertFalse(comment.isXmlDeclaration());
    }

    @Test
    public void asXmlDeclarationReturnsNullForNonXmlDeclaration() {
        String data = "sample comment";
        Comment comment = new Comment(data);
        assertNull(comment.asXmlDeclaration());
    }

    @Test
    public void asXmlDeclarationReturnsXmlDeclarationForValidXmlDeclaration() {
        String data = "?xml version=\"1.0\" encoding=\"UTF-8\"?";
        Comment comment = new Comment(data);
        XmlDeclaration xmlDeclaration = comment.asXmlDeclaration();
        assertNotNull(xmlDeclaration);
        assertEquals("xml", xmlDeclaration.name());
        assertEquals("1.0", xmlDeclaration.attr("version"));
        assertEquals("UTF-8", xmlDeclaration.attr("encoding"));
    }

    @Test
    public void asXmlDeclarationReturnsNullForBogusXmlDeclaration() {
        String data = "??xml version=\"1.0\" encoding=\"UTF-8\"??";
        Comment comment = new Comment(data);
        assertNull(comment.asXmlDeclaration());
    }

    @Test
    public void asXmlDeclarationReturnsNullForEmptyComment() {
        Comment comment = new Comment("");
        assertNull(comment.asXmlDeclaration());
    }
}
