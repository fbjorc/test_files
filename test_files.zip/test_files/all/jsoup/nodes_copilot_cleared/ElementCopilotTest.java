package org.jsoup.nodes;

import org.jsoup.parser.Tag;
import org.jsoup.select.Elements;
import org.jsoup.select.Evaluator;
import org.jsoup.select.NodeVisitor;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class ElementCopilotTest {

    @Test
    public void elementConstructorSetsTag() {
        Element element = new Element("div");
        assertEquals("div", element.tagName());
    }

    @Test
    public void elementConstructorSetsTagAndNamespace() {
        Element element = new Element("div", "http://www.w3.org/1999/xhtml");
        assertEquals("div", element.tagName());
        assertEquals("http://www.w3.org/1999/xhtml", element.baseUri());
    }

    @Test
    public void elementConstructorSetsTagBaseUriAndAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("class", "test");
        Element element = new Element(Tag.valueOf("div"), "http://www.w3.org/1999/xhtml", attributes);
        assertEquals("div", element.tagName());
        assertEquals("http://www.w3.org/1999/xhtml", element.baseUri());
        assertEquals("test", element.attr("class"));
    }

    @Test
    public void elementConstructorSetsTagAndBaseUri() {
        Element element = new Element(Tag.valueOf("div"), "http://www.w3.org/1999/xhtml");
        assertEquals("div", element.tagName());
        assertEquals("http://www.w3.org/1999/xhtml", element.baseUri());
    }

    @Test
    public void elementConstructorThrowsExceptionForNullTagWithAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("class", "test");
        assertThrows(IllegalArgumentException.class, () -> new Element(null, "http://www.w3.org/1999/xhtml", attributes));
    }

    @Test
    public void hasChildNodesReturnsFalseWhenEmpty() {
        Element element = new Element("div");
        assertFalse(element.hasChildNodes());
    }

    @Test
    public void hasChildNodesReturnsTrueWhenNotEmpty() {
        Element element = new Element("div");
        element.appendChild(new TextNode("test"));
        assertTrue(element.hasChildNodes());
    }

    @Test
    public void ensureChildNodesReturnsEmptyListWhenNoChildren() {
        Element element = new Element("div");
        List<Node> childNodes = element.ensureChildNodes();
        assertTrue(childNodes.isEmpty());
    }

    @Test
    public void ensureChildNodesReturnsListWithChildrenWhenNotEmpty() {
        Element element = new Element("div");
        element.appendChild(new TextNode("test"));
        List<Node> childNodes = element.ensureChildNodes();
        assertEquals(1, childNodes.size());
    }

    @Test
    public void hasAttributesReturnsFalseWhenNoAttributes() {
        Element element = new Element("div");
        assertFalse(element.hasAttributes());
    }

    @Test
    public void hasAttributesReturnsTrueWhenHasAttributes() {
        Element element = new Element("div");
        element.attr("test", "value");
        assertTrue(element.hasAttributes());
    }

    @Test
    public void attributesReturnsNonNullWhenAttributesIsNull() {
        Element element = new Element("div");
        Attributes attributes = element.attributes();
        assertNotNull(attributes);
    }

    @Test
    public void attributesReturnsSameInstanceWhenCalledMultipleTimes() {
        Element element = new Element("div");
        Attributes attributes1 = element.attributes();
        Attributes attributes2 = element.attributes();
        assertSame(attributes1, attributes2);
    }

    @Test
    public void baseUriReturnsEmptyStringWhenNoBaseUriSet() {
        Element element = new Element("div");
        String baseUri = element.baseUri();
        assertEquals("", baseUri);
    }

    @Test
    public void baseUriReturnsBaseUriWhenSet() {
        Element element = new Element("div");
        element.setBaseUri("http://example.com");
        String baseUri = element.baseUri();
        assertEquals("http://example.com", baseUri);
    }

    @Test
    public void baseUriReturnsParentBaseUriWhenNotSet() {
        Element parent = new Element("div");
        parent.setBaseUri("http://example.com");
        Element child = new Element("p");
        parent.appendChild(child);
        String baseUri = child.baseUri();
        assertEquals("http://example.com", baseUri);
    }

    @Test
    public void doSetBaseUriChangesBaseUri() {
        Element element = new Element("div");
        element.doSetBaseUri("http://example.com");
        assertEquals("http://example.com", element.baseUri());
    }

    @Test
    public void doSetBaseUriHandlesEmptyString() {
        Element element = new Element("div");
        element.doSetBaseUri("");
        assertEquals("", element.baseUri());
    }

    @Test
    public void childNodeSizeReturnsCorrectSize() {
        Element element = new Element("div");
        element.appendChild(new TextNode("test"));
        assertEquals(1, element.childNodeSize());
    }

    @Test
    public void childNodeSizeReturnsZeroForNoChildren() {
        Element element = new Element("div");
        assertEquals(0, element.childNodeSize());
    }

    @Test
    public void nodeNameReturnsCorrectName() {
        Element element = new Element("div");
        assertEquals("div", element.nodeName());
    }

    @Test
    public void nodeNameReturnsCorrectNameForDifferentTag() {
        Element element = new Element("span");
        assertEquals("span", element.nodeName());
    }

    @Test
    public void tagNameReturnsCorrectName() {
        Element element = new Element("div");
        assertEquals("div", element.tagName());
    }

    @Test
    public void tagNameReturnsCorrectNameForDifferentTag() {
        Element element = new Element("span");
        assertEquals("span", element.tagName());
    }

    @Test
    public void normalNameReturnsLowercaseTagName() {
        Element element = new Element("DIV");
        assertEquals("div", element.normalName());
    }

    @Test
    public void normalNameReturnsLowercaseTagNameForDifferentTag() {
        Element element = new Element("SPAN");
        assertEquals("span", element.normalName());
    }

    @Test
    public void elementIsReturnsTrueForMatchingNameAndNamespace() {
        Element element = new Element("div", "http://www.w3.org/1999/xhtml");
        assertTrue(element.elementIs("div", "http://www.w3.org/1999/xhtml"));
    }

    @Test
    public void elementIsReturnsFalseForNonMatchingName() {
        Element element = new Element("div", "http://www.w3.org/1999/xhtml");
        assertFalse(element.elementIs("span", "http://www.w3.org/1999/xhtml"));
    }

    @Test
    public void elementIsReturnsFalseForNonMatchingNamespace() {
        Element element = new Element("div", "http://www.w3.org/1999/xhtml");
        assertFalse(element.elementIs("div", "http://www.w3.org/2000/svg"));
    }

    @Test
    public void elementIsReturnsFalseForNonMatchingNameAndNamespace() {
        Element element = new Element("div", "http://www.w3.org/1999/xhtml");
        assertFalse(element.elementIs("span", "http://www.w3.org/2000/svg"));
    }

    @Test
    public void tagNameChangesElementTagName() {
        Element element = new Element("div");
        element.tagName("span");
        assertEquals("span", element.tagName());
    }

    @Test
    public void tagNameAndNamespaceChangesElementTagNameAndNamespace() {
        Element element = new Element("div", "http://www.w3.org/1999/xhtml");
        element.tagName("span", "http://www.w3.org/2000/svg");
        assertTrue(element.elementIs("span", "http://www.w3.org/2000/svg"));
    }

    @Test
    public void tagNameDoesNotChangeElementTagNameForEmptyTagName() {
        Element element = new Element("div");
        assertThrows(IllegalArgumentException.class, () -> element.tagName(""));
    }

    @Test
    public void tagNameAndNamespaceDoesNotChangeElementTagNameAndNamespaceForEmptyInputs() {
        Element element = new Element("div", "http://www.w3.org/1999/xhtml");
        assertThrows(IllegalArgumentException.class, () -> element.tagName("", ""));
    }

    @Test
    public void tagReturnsCorrectTag() {
        Element element = new Element("div");
        assertEquals("div", element.tag().getName());
    }

    @Test
    public void isBlockReturnsTrueForBlockElement() {
        Element element = new Element("div");
        assertTrue(element.isBlock());
    }

    @Test
    public void isBlockReturnsFalseForInlineElement() {
        Element element = new Element("span");
        assertFalse(element.isBlock());
    }

    @Test
    public void idReturnsEmptyStringWhenNoIdAttribute() {
        Element element = new Element("div");
        assertEquals("", element.id());
    }

    @Test
    public void idReturnsIdAttributeValue() {
        Element element = new Element("div");
        element.attr("id", "testId");
        assertEquals("testId", element.id());
    }

    @Test
    public void idSetsIdAttributeValue() {
        Element element = new Element("div");
        element.id("newId");
        assertEquals("newId", element.id());
    }

    @Test
    public void idThrowsExceptionForNullId() {
        Element element = new Element("div");
        assertThrows(IllegalArgumentException.class, () -> element.id(null));
    }

    @Test
    public void attributeKeyAndStringValueSetsAttribute() {
        Element element = new Element("div");
        element.attr("key", "value");
        assertEquals("value", element.attr("key"));
    }

    @Test
    public void attributeKeyAndBooleanValueSetsAttribute() {
        Element element = new Element("div");
        element.attr("key", true);
        assertEquals("", element.attr("key"));
    }

    @Test
    public void attributeKeyAndBooleanValueRemovesAttribute() {
        Element element = new Element("div");
        element.attr("key", "value");
        element.attr("key", false);
        assertEquals("", element.attr("key"));
    }

    @Test
    public void attributeReturnsAttributeByKey() {
        Element element = new Element("div");
        element.attr("key", "value");
        Attribute attribute = element.attribute("key");
        assertEquals("value", attribute.getValue());
    }

    @Test
    public void attributeReturnsNullIfNoAttribute() {
        Element element = new Element("div");
        Attribute attribute = element.attribute("key");
        assertNull(attribute);
    }

    @Test
    public void parentReturnsParentNodeAsElement() {
        Element parent = new Element("div");
        Element child = new Element("p");
        parent.appendChild(child);
        assertEquals(parent, child.parent());
    }

    @Test
    public void parentReturnsNullForRootElement() {
        Element root = new Element("div");
        assertNull(root.parent());
    }

    @Test
    public void parentsReturnsAllAncestors() {
        Element grandParent = new Element("div");
        Element parent = new Element("div");
        Element child = new Element("div");
        grandParent.appendChild(parent);
        parent.appendChild(child);
        Elements parents = child.parents();
        assertTrue(parents.contains(grandParent));
        assertTrue(parents.contains(parent));
    }

    @Test
    public void parentsReturnsEmptyForRootElement() {
        Element root = new Element("div");
        Elements parents = root.parents();
        assertTrue(parents.isEmpty());
    }

    @Test
    public void childReturnsCorrectElement() {
        Element parent = new Element("div");
        Element child1 = new Element("p");
        Element child2 = new Element("span");
        parent.appendChild(child1);
        parent.appendChild(child2);
        assertEquals(child1, parent.child(0));
        assertEquals(child2, parent.child(1));
    }

    @Test
    public void childThrowsExceptionForInvalidIndex() {
        Element parent = new Element("div");
        parent.appendChild(new Element("p"));
        assertThrows(IndexOutOfBoundsException.class, () -> parent.child(1));
    }

    @Test
    public void childrenSizeReturnsCorrectCount() {
        Element parent = new Element("div");
        parent.appendChild(new Element("p"));
        parent.appendChild(new Element("span"));
        assertEquals(2, parent.childrenSize());
    }

    @Test
    public void childrenSizeReturnsZeroForNoChildren() {
        Element parent = new Element("div");
        assertEquals(0, parent.childrenSize());
    }

    @Test
    public void childrenReturnsAllChildElements() {
        Element parent = new Element("div");
        Element child1 = new Element("p");
        Element child2 = new Element("span");
        parent.appendChild(child1);
        parent.appendChild(child2);
        Elements children = parent.children();
        assertTrue(children.contains(child1));
        assertTrue(children.contains(child2));
    }

    @Test
    public void childrenReturnsEmptyForNoChildren() {
        Element parent = new Element("div");
        Elements children = parent.children();
        assertTrue(children.isEmpty());
    }

    @Test
    public void childElementsListReturnsEmptyForNoChildren() {
        Element element = new Element("div");
        List<Element> children = element.childElementsList();
        assertTrue(children.isEmpty());
    }

    @Test
    public void childElementsListReturnsChildElements() {
        Element parent = new Element("div");
        Element child1 = new Element("p");
        Element child2 = new Element("span");
        parent.appendChild(child1);
        parent.appendChild(child2);
        List<Element> children = parent.childElementsList();
        assertEquals(2, children.size());
        assertTrue(children.contains(child1));
        assertTrue(children.contains(child2));
    }

    @Test
    public void childElementsListDoesNotReturnNonElementChildren() {
        Element parent = new Element("div");
        Comment comment = new Comment("comment");
        parent.appendChild(comment);
        List<Element> children = parent.childElementsList();
        assertTrue(children.isEmpty());
    }

    @Test
    public void nodelistChangedClearsShadowChildren() {
        Element parent = new Element("div");
        Element child = new Element("p");
        parent.appendChild(child);
        parent.childElementsList(); // create shadow children
        parent.nodelistChanged();
        List<Element> children = parent.childElementsList();
        assertTrue(children.isEmpty());
    }

    @Test
    public void streamReturnsElementStream() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        Stream<Element> elementStream = div.stream();
        List<Element> elements = elementStream.collect(Collectors.toList());

        assertEquals(3, elements.size());
        assertTrue(elements.contains(div));
        assertTrue(elements.contains(p1));
        assertTrue(elements.contains(p2));
    }

    @Test
    public void streamReturnsEmptyForNoChildren() {
        Element div = new Element("div");

        Stream<Element> elementStream = div.stream();
        List<Element> elements = elementStream.collect(Collectors.toList());

        assertEquals(1, elements.size());
        assertTrue(elements.contains(div));
    }

    @Test
    public void streamReturnsStreamWithNestedChildren() {
        Element div = new Element("div");
        Element p = new Element("p");
        Element span = new Element("span");
        p.appendChild(span);
        div.appendChild(p);

        Stream<Element> elementStream = div.stream();
        List<Element> elements = elementStream.collect(Collectors.toList());

        assertEquals(3, elements.size());
        assertTrue(elements.contains(div));
        assertTrue(elements.contains(p));
        assertTrue(elements.contains(span));
    }

    @Test
    public void textNodesReturnsOnlyTextNodes() {
        Element element = new Element("div");
        element.appendChild(new TextNode("text1"));
        element.appendChild(new DataNode("data1"));
        element.appendChild(new TextNode("text2"));

        List<TextNode> textNodes = element.textNodes();
        assertEquals(2, textNodes.size());
        assertEquals("text1", textNodes.get(0).getWholeText());
        assertEquals("text2", textNodes.get(1).getWholeText());
    }

    @Test
    public void textNodesReturnsEmptyForNoTextNodes() {
        Element element = new Element("div");
        element.appendChild(new DataNode("data1"));

        List<TextNode> textNodes = element.textNodes();
        assertTrue(textNodes.isEmpty());
    }

    @Test
    public void dataNodesReturnsOnlyDataNodes() {
        Element element = new Element("div");
        element.appendChild(new TextNode("text1"));
        element.appendChild(new DataNode("data1"));
        element.appendChild(new DataNode("data2"));

        List<DataNode> dataNodes = element.dataNodes();
        assertEquals(2, dataNodes.size());
        assertEquals("data1", dataNodes.get(0).getWholeData());
        assertEquals("data2", dataNodes.get(1).getWholeData());
    }

    @Test
    public void dataNodesReturnsEmptyForNoDataNodes() {
        Element element = new Element("div");
        element.appendChild(new TextNode("text1"));

        List<DataNode> dataNodes = element.dataNodes();
        assertTrue(dataNodes.isEmpty());
    }

    @Test
    public void selectReturnsMatchingElementsForCssQuery() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        Elements selected = div.select("p");
        assertEquals(2, selected.size());
        assertTrue(selected.contains(p1));
        assertTrue(selected.contains(p2));
    }

    @Test
    public void selectReturnsEmptyForNoMatchingCssQuery() {
        Element div = new Element("div");
        Elements selected = div.select("p");
        assertTrue(selected.isEmpty());
    }

    @Test
    public void selectReturnsMatchingElementsForEvaluator() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        Elements selected = div.select(new Evaluator.Tag("p"));
        assertEquals(2, selected.size());
        assertTrue(selected.contains(p1));
        assertTrue(selected.contains(p2));
    }

    @Test
    public void selectReturnsEmptyForNoMatchingEvaluator() {
        Element div = new Element("div");
        Elements selected = div.select(new Evaluator.Tag("p"));
        assertTrue(selected.isEmpty());
    }
    @Test
    public void selectFirstReturnsFirstMatchingElementForCssQuery() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        Element selected = div.selectFirst("p");
        assertSame(p1, selected);
    }

    @Test
    public void selectFirstReturnsNullForNoMatchingCssQuery() {
        Element div = new Element("div");
        Element selected = div.selectFirst("p");
        assertNull(selected);
    }

    @Test
    public void selectFirstReturnsFirstMatchingElementForEvaluator() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        Element selected = div.selectFirst(new Evaluator.Tag("p"));
        assertSame(p1, selected);
    }

    @Test
    public void selectFirstReturnsNullForNoMatchingEvaluator() {
        Element div = new Element("div");
        Element selected = div.selectFirst(new Evaluator.Tag("p"));
        assertNull(selected);
    }

    @Test
    public void expectFirstReturnsMatchingElementForCssQuery() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        Element selected = div.expectFirst("p");
        assertSame(p1, selected);
    }

    @Test
    public void expectFirstThrowsExceptionForNoMatchingCssQuery() {
        Element div = new Element("div");
        assertThrows(IllegalArgumentException.class, () -> div.expectFirst("p"));
    }

    @Test
    public void isReturnsTrueForMatchingCssQuery() {
        Element div = new Element("div");
        assertTrue(div.is("div"));
    }

    @Test
    public void isReturnsFalseForNoMatchingCssQuery() {
        Element div = new Element("div");
        assertFalse(div.is("p"));
    }

    @Test
    public void isReturnsTrueForMatchingEvaluator() {
        Element div = new Element("div");
        assertTrue(div.is(new Evaluator.Tag("div")));
    }

    @Test
    public void isReturnsFalseForNoMatchingEvaluator() {
        Element div = new Element("div");
        assertFalse(div.is(new Evaluator.Tag("p")));
    }

    @Test
    public void closestReturnsSelfWhenMatched() {
        Element div = new Element("div");
        Element p = new Element("p");
        div.appendChild(p);

        Element closest = p.closest("p");
        assertSame(p, closest);
    }

    @Test
    public void closestReturnsClosestAncestorWhenMatched() {
        Element div = new Element("div");
        Element p = new Element("p");
        div.appendChild(p);

        Element closest = p.closest("div");
        assertSame(div, closest);
    }

    @Test
    public void closestReturnsNullWhenNoMatch() {
        Element div = new Element("div");
        Element p = new Element("p");
        div.appendChild(p);

        Element closest = p.closest("span");
        assertNull(closest);
    }

    @Test
    public void closestWithEvaluatorReturnsSelfWhenMatched() {
        Element div = new Element("div");
        Element p = new Element("p");
        div.appendChild(p);

        Element closest = p.closest(new Evaluator.Tag("p"));
        assertSame(p, closest);
    }

    @Test
    public void closestWithEvaluatorReturnsClosestAncestorWhenMatched() {
        Element div = new Element("div");
        Element p = new Element("p");
        div.appendChild(p);

        Element closest = p.closest(new Evaluator.Tag("div"));
        assertSame(div, closest);
    }

    @Test
    public void closestWithEvaluatorReturnsNullWhenNoMatch() {
        Element div = new Element("div");
        Element p = new Element("p");
        div.appendChild(p);

        Element closest = p.closest(new Evaluator.Tag("span"));
        assertNull(closest);
    }

    @Test
    public void selectXpathReturnsElementsForMatchingXpath() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        Elements selected = div.selectXpath("//p");
        assertEquals(2, selected.size());
    }

    @Test
    public void selectXpathReturnsEmptyForNoMatchingXpath() {
        Element div = new Element("div");
        Elements selected = div.selectXpath("//p");
        assertTrue(selected.isEmpty());
    }

    @Test
    public void selectXpathWithTypeReturnsNodesForMatchingXpath() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        List<Node> selected = div.selectXpath("//p", Node.class);
        assertEquals(2, selected.size());
    }

    @Test
    public void selectXpathWithTypeReturnsEmptyForNoMatchingXpath() {
        Element div = new Element("div");
        List<Node> selected = div.selectXpath("//p", Node.class);
        assertTrue(selected.isEmpty());
    }

    @Test
    public void appendChildAddsNodeToElement() {
        Element div = new Element("div");
        Element p = new Element("p");

        div.appendChild(p);

        assertEquals(1, div.childrenSize());
        assertSame(p, div.child(0));
    }

    @Test
    public void appendChildThrowsExceptionForNullChild() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.appendChild(null));
    }

    @Test
    public void appendChildrenAddsMultipleNodesToElement() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");

        div.appendChildren(Arrays.asList(p1, p2));

        assertEquals(2, div.childrenSize());
        assertSame(p1, div.child(0));
        assertSame(p2, div.child(1));
    }

    @Test
    public void appendChildrenThrowsExceptionForNullChildren() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.appendChildren(null));
    }

    @Test
    public void appendToAddsElementToParent() {
        Element div = new Element("div");
        Element p = new Element("p");

        p.appendTo(div);

        assertEquals(1, div.childrenSize());
        assertSame(p, div.child(0));
    }

    @Test
    public void appendToThrowsExceptionForNullParent() {
        Element p = new Element("p");

        assertThrows(IllegalArgumentException.class, () -> p.appendTo(null));
    }

    @Test
    public void prependChildAddsNodeToStart() {
        Element div = new Element("div");
        Element p = new Element("p");

        div.prependChild(p);

        assertEquals(1, div.childrenSize());
        assertSame(p, div.child(0));
    }

    @Test
    public void prependChildThrowsExceptionForNullChild() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.prependChild(null));
    }

    @Test
    public void prependChildrenAddsMultipleNodesToStart() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");

        div.prependChildren(Arrays.asList(p1, p2));

        assertEquals(2, div.childrenSize());
        assertSame(p2, div.child(0));
        assertSame(p1, div.child(1));
    }

    @Test
    public void prependChildrenThrowsExceptionForNullChildren() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.prependChildren(null));
    }

    @Test
    public void insertChildrenAddsNodesAtCorrectIndex() {
        Element div = new Element("div");
        Element p1 = new Element("p");
        Element p2 = new Element("p");
        Element p3 = new Element("p");
        div.appendChild(p1);
        div.appendChild(p2);

        div.insertChildren(1, Arrays.asList(p3));

        assertEquals(3, div.childrenSize());
        assertSame(p1, div.child(0));
        assertSame(p3, div.child(1));
        assertSame(p2, div.child(2));
    }

    @Test
    public void insertChildrenThrowsExceptionForInvalidIndex() {
        Element div = new Element("div");
        Element p = new Element("p");

        assertThrows(IllegalArgumentException.class, () -> div.insertChildren(1, Arrays.asList(p)));
    }

    @Test
    public void appendElementAddsChildToElement() {
        Element div = new Element("div");

        Element child = div.appendElement("p");

        assertEquals(1, div.childrenSize());
        assertSame(child, div.child(0));
        assertEquals("p", child.tagName());
    }

    @Test
    public void prependElementAddsChildToStart() {
        Element div = new Element("div");
        Element child = div.prependElement("p");

        assertEquals(1, div.childrenSize());
        assertSame(child, div.child(0));
        assertEquals("p", child.tagName());
    }

    @Test
    public void appendTextThrowsExceptionForNullText() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.appendText(null));
    }

    @Test
    public void prependTextThrowsExceptionForNullText() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.prependText(null));
    }

    @Test
    public void appendAddsParsedHtmlToEnd() {
        Element div = new Element("div");
        div.append("<p>Hello, world!</p>");

        assertEquals(1, div.childrenSize());
        assertTrue(div.child(0) instanceof Element);
        assertEquals("p", ((Element) div.child(0)).tagName());
        assertEquals("Hello, world!", ((Element) div.child(0)).text());
    }

    @Test
    public void appendThrowsExceptionForNullHtml() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.append(null));
    }

    @Test
    public void prependAddsParsedHtmlToStart() {
        Element div = new Element("div");
        div.prepend("<p>Hello, world!</p>");

        assertEquals(1, div.childrenSize());
        assertTrue(div.child(0) instanceof Element);
        assertEquals("p", ((Element) div.child(0)).tagName());
        assertEquals("Hello, world!", ((Element) div.child(0)).text());
    }

    @Test
    public void prependThrowsExceptionForNullHtml() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.prepend(null));
    }

    @Test
    public void beforeStringInsertsHtmlBeforeElement() {
        Element div = new Element("div");
        div.before("<p>Hello</p>");

        assertEquals("<p>Hello</p>\n<div></div>", div.outerHtml());
    }

    @Test
    public void beforeNodeInsertsNodeBeforeElement() {
        Element div = new Element("div");
        Element p = new Element("p").text("Hello");
        div.before(p);

        assertEquals("<p>Hello</p>\n<div></div>", div.outerHtml());
    }

    @Test
    public void afterStringInsertsHtmlAfterElement() {
        Element div = new Element("div");
        div.after("<p>Hello</p>");

        assertEquals("<div></div>\n<p>Hello</p>", div.outerHtml());
    }

    @Test
    public void afterNodeInsertsNodeAfterElement() {
        Element div = new Element("div");
        Element p = new Element("p").text("Hello");
        div.after(p);

        assertEquals("<div></div>\n<p>Hello</p>", div.outerHtml());
    }

    @Test
    public void beforeStringThrowsExceptionForNullHtml() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.before((String) null));
    }

    @Test
    public void beforeNodeThrowsExceptionForNullNode() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.before((Node) null));
    }

    @Test
    public void afterStringThrowsExceptionForNullHtml() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.after((String) null));
    }

    @Test
    public void afterNodeThrowsExceptionForNullNode() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.after((Node) null));
    }

    @Test
    public void emptyRemovesAllChildNodes() {
        Element div = new Element("div");
        div.append("<p>Hello</p><p>World</p>");

        div.empty();

        assertEquals(0, div.childrenSize());
    }

    @Test
    public void wrapAddsHtmlAroundElement() {
        Element div = new Element("div");
        div.text("Hello, world!");

        div.wrap("<section></section>");

        assertEquals("<section><div>Hello, world!</div></section>", div.outerHtml());
    }

    @Test
    public void wrapThrowsExceptionForNullHtml() {
        Element div = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> div.wrap(null));
    }

    @Test
    public void cssSelectorReturnsIdSelectorWhenIdExists() {
        Element div = new Element("div");
        div.id("test");

        String selector = div.cssSelector();

        assertEquals("#test", selector);
    }

    @Test
    public void cssSelectorReturnsTagWhenNoId() {
        Element div = new Element("div");

        String selector = div.cssSelector();

        assertEquals("div", selector);
    }

    @Test
    public void cssSelectorReturnsComplexSelectorForNestedElements() {
        Element div = new Element("div");
        Element childDiv = div.appendElement("div");

        String selector = childDiv.cssSelector();

        assertEquals("div > div", selector);
    }

    @Test
    public void siblingElementsReturnsEmptyWhenNoParent() {
        Element element = new Element("div");
        Elements siblings = element.siblingElements();
        assertTrue(siblings.isEmpty());
    }

    @Test
    public void siblingElementsReturnsSiblings() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");
        Element child3 = parent.appendElement("p");

        Elements siblingsOfChild2 = child2.siblingElements();

        assertEquals(2, siblingsOfChild2.size());
        assertTrue(siblingsOfChild2.contains(child1));
        assertTrue(siblingsOfChild2.contains(child3));
    }

    @Test
    public void nextElementSiblingReturnsNullWhenLastChild() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertNull(child2.nextElementSibling());
    }

    @Test
    public void nextElementSiblingReturnsNextSibling() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertEquals(child2, child1.nextElementSibling());
    }

    @Test
    public void nextElementSiblingsReturnsEmptyWhenLastChild() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertTrue(child2.nextElementSiblings().isEmpty());
    }

    @Test
    public void nextElementSiblingsReturnsNextSiblings() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");
        Element child3 = parent.appendElement("p");

        Elements nextSiblingsOfChild1 = child1.nextElementSiblings();

        assertEquals(2, nextSiblingsOfChild1.size());
        assertTrue(nextSiblingsOfChild1.contains(child2));
        assertTrue(nextSiblingsOfChild1.contains(child3));
    }

    @Test
    public void previousElementSiblingReturnsNullWhenFirstChild() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertNull(child1.previousElementSibling());
    }

    @Test
    public void previousElementSiblingReturnsPreviousSibling() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertEquals(child1, child2.previousElementSibling());
    }

    @Test
    public void previousElementSiblingsReturnsEmptyWhenFirstChild() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertTrue(child1.previousElementSiblings().isEmpty());
    }

    @Test
    public void previousElementSiblingsReturnsPreviousSiblings() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");
        Element child3 = parent.appendElement("p");

        Elements previousSiblingsOfChild3 = child3.previousElementSiblings();

        assertEquals(2, previousSiblingsOfChild3.size());
        assertTrue(previousSiblingsOfChild3.contains(child1));
        assertTrue(previousSiblingsOfChild3.contains(child2));
    }

    @Test
    public void firstElementSiblingReturnsSelfWhenNoParent() {
        Element element = new Element("div");
        assertSame(element, element.firstElementSibling());
    }

    @Test
    public void firstElementSiblingReturnsFirstElementChildWhenParentExists() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertSame(child1, child2.firstElementSibling());
    }

    @Test
    public void elementSiblingIndexReturnsZeroWhenNoParent() {
        Element element = new Element("div");
        assertEquals(0, element.elementSiblingIndex());
    }

    @Test
    public void elementSiblingIndexReturnsCorrectIndexWhenParentExists() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertEquals(1, child2.elementSiblingIndex());
    }

    @Test
    public void lastElementSiblingReturnsSelfWhenNoParent() {
        Element element = new Element("div");
        assertSame(element, element.lastElementSibling());
    }

    @Test
    public void lastElementSiblingReturnsLastElementChildWhenParentExists() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertSame(child2, child1.lastElementSibling());
    }

    @Test
    public void firstElementChildReturnsNullWhenNoChildren() {
        Element parent = new Element("div");
        assertNull(parent.firstElementChild());
    }

    @Test
    public void firstElementChildReturnsFirstElementChild() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertSame(child1, parent.firstElementChild());
    }

    @Test
    public void lastElementChildReturnsNullWhenNoChildren() {
        Element parent = new Element("div");
        assertNull(parent.lastElementChild());
    }

    @Test
    public void lastElementChildReturnsLastElementChild() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        Element child2 = parent.appendElement("p");

        assertSame(child2, parent.lastElementChild());
    }

    @Test
    public void getElementsByTagReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.appendElement("p");

        assertTrue(parent.getElementsByTag("span").isEmpty());
    }

    @Test
    public void getElementsByTagReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.appendElement("p");
        parent.appendElement("p");
        parent.appendElement("span");

        assertEquals(2, parent.getElementsByTag("p").size());
    }

    @Test
    public void getElementByIdReturnsCorrectElement() {
        Element parent = new Element("div");
        Element child = parent.appendElement("p");
        child.id("testId");

        assertSame(child, parent.getElementById("testId"));
    }

    @Test
    public void getElementByIdReturnsNullWhenNoMatch() {
        Element parent = new Element("div");
        parent.appendElement("p");

        assertNull(parent.getElementById("testId"));
    }

    @Test
    public void getElementsByClassReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.appendElement("p").addClass("testClass");
        parent.appendElement("p").addClass("testClass");
        parent.appendElement("p");

        assertEquals(2, parent.getElementsByClass("testClass").size());
    }

    @Test
    public void getElementsByClassReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.appendElement("p");

        assertTrue(parent.getElementsByClass("testClass").isEmpty());
    }

    @Test
    public void getElementsByAttributeReturnsMatchingElements() {
        Element parent = new Element("div");
        Element child1 = parent.appendElement("p");
        child1.attr("testAttr", "value");
        Element child2 = parent.appendElement("p");
        child2.attr("testAttr", "value");

        assertEquals(2, parent.getElementsByAttribute("testAttr").size());
    }

    @Test
    public void getElementsByAttributeReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.appendElement("p");

        assertTrue(parent.getElementsByAttribute("testAttr").isEmpty());
    }

    @Test
    public void getElementsByAttributeStartingReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.attr("data-test", "value");
        parent.attr("data-test2", "value");

        assertEquals(2, parent.getElementsByAttributeStarting("data-").size());
    }

    @Test
    public void getElementsByAttributeStartingReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.attr("data-test", "value");

        assertTrue(parent.getElementsByAttributeStarting("nonexistent-").isEmpty());
    }

    @Test
    public void getElementsByAttributeValueEndingReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.attr("data-test", "value");
        parent.attr("data-test2", "value2");

        assertEquals(2, parent.getElementsByAttributeValueEnding("test", "2").size());
    }

    @Test
    public void getElementsByAttributeValueEndingReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.attr("data-test", "value");

        assertTrue(parent.getElementsByAttributeValueEnding("test", "nonexistent").isEmpty());
    }

    @Test
    public void getElementsByAttributeValueContainingReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.attr("test", "value");
        parent.attr("test2", "value2");

        assertEquals(2, parent.getElementsByAttributeValueContaining("test", "value").size());
    }

    @Test
    public void getElementsByAttributeValueContainingReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.attr("test", "value");

        assertTrue(parent.getElementsByAttributeValueContaining("test", "nonexistent").isEmpty());
    }

    @Test
    public void getElementsByAttributeValueMatchingPatternReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.attr("test", "value");
        parent.attr("test2", "value2");

        assertEquals(2, parent.getElementsByAttributeValueMatching("test", Pattern.compile("value.*")).size());
    }

    @Test
    public void getElementsByAttributeValueMatchingPatternReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.attr("test", "value");

        assertTrue(parent.getElementsByAttributeValueMatching("test", Pattern.compile("nonexistent.*")).isEmpty());
    }

    @Test
    public void getElementsByAttributeValueMatchingStringReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.attr("test", "value");
        parent.attr("test2", "value2");

        assertEquals(2, parent.getElementsByAttributeValueMatching("test", "value.*").size());
    }

    @Test
    public void getElementsByAttributeValueMatchingStringReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.attr("test", "value");

        assertTrue(parent.getElementsByAttributeValueMatching("test", "nonexistent.*").isEmpty());
    }

    @Test
    public void getElementsByIndexLessThanReturnsElementsWithLowerIndex() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsByIndexLessThan(2);
        assertEquals(2, result.size());
        assertEquals("One", result.get(0).text());
        assertEquals("Two", result.get(1).text());
    }

    @Test
    public void getElementsByIndexLessThanReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.append("<p>One</p>");

        Elements result = parent.getElementsByIndexLessThan(1);
        assertTrue(result.isEmpty());
    }

    @Test
    public void getElementsByIndexGreaterThanReturnsElementsWithHigherIndex() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsByIndexGreaterThan(0);
        assertEquals(2, result.size());
        assertEquals("Two", result.get(0).text());
        assertEquals("Three", result.get(1).text());
    }

    @Test
    public void getElementsByIndexGreaterThanReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.append("<p>One</p>");

        Elements result = parent.getElementsByIndexGreaterThan(0);
        assertTrue(result.isEmpty());
    }

    @Test
    public void getElementsByIndexEqualsReturnsElementWithExactIndex() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsByIndexEquals(1);
        assertEquals(1, result.size());
        assertEquals("Two", result.get(0).text());
    }

    @Test
    public void getElementsByIndexEqualsReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.append("<p>One</p>");

        Elements result = parent.getElementsByIndexEquals(1);
        assertTrue(result.isEmpty());
    }

    @Test
    public void getElementsContainingTextReturnsElementsWithMatchingText() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsContainingText("Two");
        assertEquals(1, result.size());
        assertEquals("Two", result.get(0).text());
    }

    @Test
    public void getElementsContainingTextReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsContainingText("Four");
        assertTrue(result.isEmpty());
    }

    @Test
    public void getElementsContainingOwnTextReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsContainingOwnText("Two");
        assertEquals(1, result.size());
        assertEquals("Two", result.get(0).text());
    }

    @Test
    public void getElementsContainingOwnTextReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsContainingOwnText("Four");
        assertTrue(result.isEmpty());
    }

    @Test
    public void getElementsMatchingTextReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsMatchingText(Pattern.compile("Tw.*"));
        assertEquals(1, result.size());
        assertEquals("Two", result.get(0).text());
    }

    @Test
    public void getElementsMatchingTextReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsMatchingText(Pattern.compile("Fo.*"));
        assertTrue(result.isEmpty());
    }

    @Test
    public void getElementsMatchingOwnTextReturnsMatchingElements() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsMatchingOwnText(Pattern.compile("Th.*"));
        assertEquals(1, result.size());
        assertEquals("Three", result.get(0).text());
    }

    @Test
    public void getElementsMatchingOwnTextReturnsEmptyWhenNoMatch() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getElementsMatchingOwnText(Pattern.compile("Fo.*"));
        assertTrue(result.isEmpty());
    }

    @Test
    public void getAllElementsReturnsAllElements() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        Elements result = parent.getAllElements();
        assertEquals(4, result.size()); // div and 3 p elements
    }

    @Test
    public void textReturnsCombinedText() {
        Element parent = new Element("div");
        parent.append("<p>One</p><p>Two</p><p>Three</p>");

        String result = parent.text();
        assertEquals("One Two Three", result);
    }

    @Test
    public void textReturnsEmptyWhenNoText() {
        Element parent = new Element("div");

        String result = parent.text();
        assertEquals("", result);
    }

    @Test
    public void wholeTextReturnsCorrectText() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.appendText("Hello");
        element.appendElement("br");
        element.appendText("World");
        assertEquals("Hello\nWorld", element.wholeText());
    }

    @Test
    public void wholeTextReturnsEmptyForEmptyElement() {
        Element element = new Element(Tag.valueOf("div"), "");
        assertEquals("", element.wholeText());
    }

    @Test
    public void wholeTextReturnsTextWithMultipleChildren() {
        Element element = new Element(Tag.valueOf("div"), "");
        element.appendText("Hello");
        Element childElement = element.appendElement("p");
        childElement.appendText("World");
        assertEquals("Hello\nWorld", element.wholeText());
    }

    @Test
    public void wholeOwnTextReturnsCorrectText() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.appendText("Hello");
        element.appendElement("br");
        element.appendText("World");
        assertEquals("Hello\nWorld", element.wholeOwnText());
    }

    @Test
    public void wholeOwnTextReturnsEmptyForEmptyElement() {
        Element element = new Element(Tag.valueOf("div"), "");
        assertEquals("", element.wholeOwnText());
    }

    @Test
    public void wholeOwnTextReturnsTextWithMultipleChildren() {
        Element element = new Element(Tag.valueOf("div"), "");
        element.appendText("Hello");
        Element childElement = element.appendElement("p");
        childElement.appendText("World");
        assertEquals("Hello\nWorld", element.wholeOwnText());
    }

    @Test
    public void ownTextReturnsCorrectText() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.appendText("Hello");
        element.appendElement("br");
        element.appendText("World");
        assertEquals("Hello World", element.ownText());
    }

    @Test
    public void ownTextReturnsEmptyForEmptyElement() {
        Element element = new Element(Tag.valueOf("div"), "");
        assertEquals("", element.ownText());
    }

    @Test
    public void ownTextIgnoresChildElements() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.appendText("Hello");
        Element childElement = element.appendElement("span");
        childElement.appendText("World");
        assertEquals("Hello", element.ownText());
    }

    @Test
    public void preserveWhitespaceReturnsTrueForElementWithPreserveWhitespaceTag() {
        Element element = new Element(Tag.valueOf("pre"), "");
        assertTrue(Element.preserveWhitespace(element));
    }

    @Test
    public void preserveWhitespaceReturnsFalseForElementWithoutPreserveWhitespaceTag() {
        Element element = new Element(Tag.valueOf("div"), "");
        assertFalse(Element.preserveWhitespace(element));
    }

    @Test
    public void textSetsTextNodeAsChildForNonScriptOrStyleTag() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.text("Hello");
        assertEquals("Hello", element.text());
    }

    @Test
    public void textSetsDataNodeAsChildForScriptTag() {
        Element element = new Element(Tag.valueOf("script"), "");
        element.text("Hello");
        assertTrue(element.childNode(0) instanceof DataNode);
    }

    @Test
    public void textSetsDataNodeAsChildForStyleTag() {
        Element element = new Element(Tag.valueOf("style"), "");
        element.text("Hello");
        assertTrue(element.childNode(0) instanceof DataNode);
    }

    @Test
    public void hasTextReturnsTrueWhenElementHasNonBlankText() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.text("Hello");
        assertTrue(element.hasText());
    }

    @Test
    public void hasTextReturnsFalseWhenElementHasOnlyWhitespace() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.text("   ");
        assertFalse(element.hasText());
    }

    @Test
    public void hasTextReturnsFalseWhenElementHasNoText() {
        Element element = new Element(Tag.valueOf("p"), "");
        assertFalse(element.hasText());
    }

    @Test
    public void dataReturnsCorrectData() {
        Element element = new Element(Tag.valueOf("script"), "");
        element.appendChild(new DataNode("Example data"));
        assertEquals("Example data", element.data());
    }

    @Test
    public void dataReturnsEmptyForElementWithoutData() {
        Element element = new Element(Tag.valueOf("p"), "");
        assertEquals("", element.data());
    }

    @Test
    public void classNameReturnsCorrectClassName() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "testClass");
        assertEquals("testClass", element.className());
    }

    @Test
    public void classNameReturnsEmptyForElementWithoutClass() {
        Element element = new Element(Tag.valueOf("p"), "");
        assertEquals("", element.className());
    }

    @Test
    public void classNamesReturnsCorrectClassNames() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "testClass1 testClass2");
        Set<String> classNames = element.classNames();
        assertTrue(classNames.contains("testClass1"));
        assertTrue(classNames.contains("testClass2"));
    }

    @Test
    public void classNamesReturnsEmptyForElementWithoutClass() {
        Element element = new Element(Tag.valueOf("p"), "");
        assertTrue(element.classNames().isEmpty());
    }

    @Test
    public void classNamesSetsClassAttribute() {
        Element element = new Element(Tag.valueOf("p"), "");
        Set<String> classNames = new HashSet<>(Arrays.asList("class1", "class2"));
        element.classNames(classNames);
        assertEquals("class1 class2", element.attr("class"));
    }

    @Test
    public void classNamesRemovesClassAttributeWhenEmpty() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "class1");
        element.classNames(new HashSet<>());
        assertFalse(element.hasAttr("class"));
    }

    @Test
    public void hasClassReturnsTrueWhenClassExists() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "class1 class2");
        assertTrue(element.hasClass("class1"));
        assertTrue(element.hasClass("class2"));
    }

    @Test
    public void hasClassReturnsFalseWhenClassDoesNotExist() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "class1 class2");
        assertFalse(element.hasClass("class3"));
    }

    @Test
    public void hasClassReturnsFalseWhenNoClassAttribute() {
        Element element = new Element(Tag.valueOf("p"), "");
        assertFalse(element.hasClass("class1"));
    }

    @Test
    public void hasClassReturnsFalseWhenClassAttributeIsEmpty() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "");
        assertFalse(element.hasClass("class1"));
    }

    @Test
    public void addClassAddsNewClassToElement() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.addClass("newClass");
        assertTrue(element.classNames().contains("newClass"));
    }

    @Test
    public void addClassDoesNotAddExistingClassToElement() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.addClass("newClass");
        element.addClass("newClass");
        assertEquals(1, element.classNames().size());
    }

    @Test
    public void removeClassRemovesExistingClassFromElement() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.addClass("newClass");
        element.removeClass("newClass");
        assertFalse(element.classNames().contains("newClass"));
    }

    @Test
    public void removeClassDoesNotRemoveNonExistingClassFromElement() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.removeClass("nonExistingClass");
        assertFalse(element.classNames().contains("nonExistingClass"));
    }

    @Test
    public void toggleClassAddsClassWhenNotPresent() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.toggleClass("newClass");
        assertTrue(element.classNames().contains("newClass"));
    }

    @Test
    public void toggleClassRemovesClassWhenPresent() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.addClass("newClass");
        element.toggleClass("newClass");
        assertFalse(element.classNames().contains("newClass"));
    }

    @Test
    public void valReturnsTextForTextarea() {
        Element element = new Element(Tag.valueOf("textarea"), "");
        element.text("Sample Text");
        assertEquals("Sample Text", element.val());
    }

    @Test
    public void valReturnsAttributeValueForNonTextarea() {
        Element element = new Element(Tag.valueOf("input"), "");
        element.attr("value", "Sample Value");
        assertEquals("Sample Value", element.val());
    }

    @Test
    public void valSetsTextForTextarea() {
        Element element = new Element(Tag.valueOf("textarea"), "");
        element.val("Sample Text");
        assertEquals("Sample Text", element.text());
    }

    @Test
    public void valSetsAttributeValueForNonTextarea() {
        Element element = new Element(Tag.valueOf("input"), "");
        element.val("Sample Value");
        assertEquals("Sample Value", element.attr("value"));
    }

    @Test
    public void shouldIndentReturnsTrueForBlockElementWithPrettyPrint() {
        Element element = new Element(Tag.valueOf("div"), "");
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.prettyPrint(true);
        assertTrue(element.shouldIndent(outputSettings));
    }

    @Test
    public void shouldIndentReturnsFalseForInlineElementWithPrettyPrint() {
        Element element = new Element(Tag.valueOf("span"), "");
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.prettyPrint(true);
        assertFalse(element.shouldIndent(outputSettings));
    }

    @Test
    public void shouldIndentReturnsFalseForBlockElementWithoutPrettyPrint() {
        Element element = new Element(Tag.valueOf("div"), "");
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.prettyPrint(false);
        assertFalse(element.shouldIndent(outputSettings));
    }

    @Test
    public void outerHtmlHeadAppendsCorrectlyForNonEmptyElement() throws IOException {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "test");
        StringBuilder accum = new StringBuilder();
        element.outerHtmlHead(accum, 0, new Document.OutputSettings());
        assertEquals("<p class=\"test\">", accum.toString());
    }

    @Test
    public void outerHtmlHeadAppendsCorrectlyForEmptyElement() throws IOException {
        Element element = new Element(Tag.valueOf("img"), "");
        element.attr("src", "test.jpg");
        StringBuilder accum = new StringBuilder();
        element.outerHtmlHead(accum, 0, new Document.OutputSettings());
        assertEquals("<img src=\"test.jpg\" />", accum.toString());
    }

    @Test
    public void outerHtmlTailAppendsCorrectlyForNonEmptyElement() throws IOException {
        Element element = new Element(Tag.valueOf("p"), "");
        StringBuilder accum = new StringBuilder();
        element.outerHtmlTail(accum, 0, new Document.OutputSettings());
        assertEquals("</p>", accum.toString());
    }

    @Test
    public void outerHtmlTailDoesNotAppendForEmptyElement() throws IOException {
        Element element = new Element(Tag.valueOf("img"), "");
        StringBuilder accum = new StringBuilder();
        element.outerHtmlTail(accum, 0, new Document.OutputSettings());
        assertEquals("", accum.toString());
    }

    @Test
    public void htmlReturnsCorrectHtml() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.html("<span>test</span>");
        assertEquals("<span>test</span>", element.html());
    }

    @Test
    public void htmlAppendsToProvidedAppendable() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.html("<span>test</span>");
        StringBuilder sb = new StringBuilder();
        element.html(sb);
        assertEquals("<span>test</span>", sb.toString());
    }

    @Test
    public void htmlSetsInnerHtmlCorrectly() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.html("<span>test</span>");
        assertEquals("<span>test</span>", element.html());
    }

    @Test
    public void htmlClearsExistingHtml() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.html("<span>old</span>");
        element.html("<span>new</span>");
        assertEquals("<span>new</span>", element.html());
    }

    @Test
    public void htmlHandlesEmptyString() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.html("");
        assertEquals("", element.html());
    }

    @Test
    public void cloneReturnsIdenticalElement() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "test");
        Element clone = element.clone();

        assertEquals(element.tagName(), clone.tagName());
        assertEquals(element.attributes(), clone.attributes());
    }

    @Test
    public void shallowCloneReturnsElementWithSameAttributes() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "test");
        Element shallowClone = element.shallowClone();

        assertEquals(element.tagName(), shallowClone.tagName());
        assertEquals(element.attributes(), shallowClone.attributes());
        assertNull(shallowClone.parent());
    }

    @Test
    public void doCloneReturnsElementWithSameAttributesAndParent() {
        Element parent = new Element(Tag.valueOf("div"), "");
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "test");
        parent.appendChild(element);

        Element clone = element.doClone(parent);

        assertEquals(element.tagName(), clone.tagName());
        assertEquals(element.attributes(), clone.attributes());
        assertEquals(parent, clone.parent());
    }

    @Test
    public void clearAttributesRemovesAllAttributes() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "test");
        element.attr("id", "testId");
        element.clearAttributes();
        assertTrue(element.attributes().size() == 0);
    }

    @Test
    public void clearAttributesReturnsSelf() {
        Element element = new Element(Tag.valueOf("p"), "");
        Element returnedElement = element.clearAttributes();
        assertSame(element, returnedElement);
    }

    @Test
    public void removeAttrRemovesSpecificAttribute() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.attr("class", "test");
        element.removeAttr("class");
        assertFalse(element.hasAttr("class"));
    }

    @Test
    public void removeAttrReturnsSelf() {
        Element element = new Element(Tag.valueOf("p"), "");
        Element returnedElement = element.removeAttr("class");
        assertSame(element, returnedElement);
    }

    @Test
    public void rootReturnsRootElement() {
        Element element = new Element(Tag.valueOf("p"), "");
        Element root = element.root();
        assertSame(root, element);
    }

    @Test
    public void traverseReturnsSelf() {
        Element element = new Element(Tag.valueOf("p"), "");
        Element returnedElement = element.traverse(new NodeVisitor() {
            @Override
            public void head(Node node, int depth) {
            }

            @Override
            public void tail(Node node, int depth) {
            }
        });
        assertSame(element, returnedElement);
    }

    @Test
    public void forEachNodeExecutesActionOnEachNode() {
        Element element = new Element(Tag.valueOf("p"), "");
        element.appendChild(new TextNode("Test"));
        AtomicBoolean actionExecuted = new AtomicBoolean(false);
        element.forEachNode(node -> actionExecuted.set(true));
        assertTrue(actionExecuted.get());
    }

    @Test
    public void forEachExecutesActionOnEachElement() {
        Element element = new Element(Tag.valueOf("div"), "");
        element.appendChild(new Element(Tag.valueOf("p"), ""));
        AtomicBoolean actionExecuted = new AtomicBoolean(false);
        element.forEach(el -> actionExecuted.set(true));
        assertTrue(actionExecuted.get());
    }
}