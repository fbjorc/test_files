package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EntitiesCopilotTest {

    @Test
    public void xhtmlEscapeModeReturnsCorrectCodepointForName() {
        int codepoint = Entities.EscapeMode.xhtml.codepointForName("lt");
        assertEquals(60, codepoint);
    }

    @Test
    public void xhtmlEscapeModeReturnsEmptyForInvalidName() {
        int codepoint = Entities.EscapeMode.xhtml.codepointForName("invalid");
        assertEquals(-1, codepoint);
    }

    @Test
    public void xhtmlEscapeModeReturnsCorrectNameForCodepoint() {
        String name = Entities.EscapeMode.xhtml.nameForCodepoint(60);
        assertEquals("lt", name);
    }

    @Test
    public void xhtmlEscapeModeReturnsEmptyForInvalidCodepoint() {
        String name = Entities.EscapeMode.xhtml.nameForCodepoint(999999);
        assertEquals("", name);
    }

    @Test
    public void baseEscapeModeReturnsCorrectCodepointForName() {
        int codepoint = Entities.EscapeMode.base.codepointForName("amp");
        assertEquals(38, codepoint);
    }

    @Test
    public void baseEscapeModeReturnsEmptyForInvalidName() {
        int codepoint = Entities.EscapeMode.base.codepointForName("invalid");
        assertEquals(-1, codepoint);
    }

    @Test
    public void baseEscapeModeReturnsCorrectNameForCodepoint() {
        String name = Entities.EscapeMode.base.nameForCodepoint(38);
        assertEquals("amp", name);
    }

    @Test
    public void baseEscapeModeReturnsEmptyForInvalidCodepoint() {
        String name = Entities.EscapeMode.base.nameForCodepoint(999999);
        assertEquals("", name);
    }

    @Test
    public void extendedEscapeModeReturnsCorrectCodepointForName() {
        int codepoint = Entities.EscapeMode.extended.codepointForName("copy");
        assertEquals(169, codepoint);
    }

    @Test
    public void extendedEscapeModeReturnsEmptyForInvalidName() {
        int codepoint = Entities.EscapeMode.extended.codepointForName("invalid");
        assertEquals(-1, codepoint);
    }

    @Test
    public void extendedEscapeModeReturnsCorrectNameForCodepoint() {
        String name = Entities.EscapeMode.extended.nameForCodepoint(169);
        assertEquals("copy", name);
    }

    @Test
    public void extendedEscapeModeReturnsEmptyForInvalidCodepoint() {
        String name = Entities.EscapeMode.extended.nameForCodepoint(999999);
        assertEquals("", name);
    }

    @Test
    public void isNamedEntityReturnsTrueForKnownEntity() {
        assertTrue(Entities.isNamedEntity("lt"));
    }

    @Test
    public void isNamedEntityReturnsFalseForUnknownEntity() {
        assertFalse(Entities.isNamedEntity("unknownEntity"));
    }

    @Test
    public void isBaseNamedEntityReturnsTrueForKnownBaseEntity() {
        assertTrue(Entities.isBaseNamedEntity("amp"));
    }

    @Test
    public void isBaseNamedEntityReturnsFalseForNonBaseEntity() {
        assertFalse(Entities.isBaseNamedEntity("copy"));
    }

    @Test
    public void getByNameReturnsCorrectCharacterForKnownEntity() {
        assertEquals("<", Entities.getByName("lt"));
    }

    @Test
    public void getByNameReturnsEmptyStringForUnknownEntity() {
        assertEquals("", Entities.getByName("unknownEntity"));
    }

    @Test
    public void getByNameReturnsCorrectCharactersForMultiPointEntity() {
        assertEquals("©", Entities.getByName("copy"));
    }

    @Test
    public void codepointsForNameReturnsCorrectValuesForMultiPointEntity() {
        int[] codepoints = new int[2];
        int count = Entities.codepointsForName("copy", codepoints);
        assertEquals(2, count);
        assertEquals(169, codepoints[0]);
        assertEquals(0, codepoints[1]);
    }

    @Test
    public void codepointsForNameReturnsCorrectValuesForSinglePointEntity() {
        int[] codepoints = new int[2];
        int count = Entities.codepointsForName("lt", codepoints);
        assertEquals(1, count);
        assertEquals(60, codepoints[0]);
    }

    @Test
    public void codepointsForNameReturnsZeroForUnknownEntity() {
        int[] codepoints = new int[2];
        int count = Entities.codepointsForName("unknownEntity", codepoints);
        assertEquals(0, count);
    }

    @Test
    public void escapeReturnsEscapedString() {
        String escaped = Entities.escape("<html>", new Document.OutputSettings());
        assertEquals("&lt;html&gt;", escaped);
    }

    @Test
    public void escapeReturnsEmptyStringForNullInput() {
        String escaped = Entities.escape(null, new Document.OutputSettings());
        assertEquals("", escaped);
    }

    @Test
    public void escapeWithDefaultSettingsReturnsEscapedString() {
        String escaped = Entities.escape("<html>");
        assertEquals("&lt;html&gt;", escaped);
    }

    @Test
    public void escapeHandlesAmpersand() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "&", new Document.OutputSettings(), false, false, false, false);
        assertEquals("&amp;", accum.toString());
    }

    @Test
    public void escapeHandlesLessThan() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "<", new Document.OutputSettings(), false, false, false, false);
        assertEquals("&lt;", accum.toString());
    }

    @Test
    public void escapeHandlesGreaterThan() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, ">", new Document.OutputSettings(), false, false, false, false);
        assertEquals("&gt;", accum.toString());
    }

    @Test
    public void escapeHandlesQuote() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "\"", new Document.OutputSettings(), true, false, false, false);
        assertEquals("&quot;", accum.toString());
    }

    @Test
    public void escapeHandlesNonBreakingSpace() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "\u00A0", new Document.OutputSettings(), false, false, false, false);
        assertEquals("&nbsp;", accum.toString());
    }

    @Test
    public void escapeHandlesAsciiControl() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "\u0009", new Document.OutputSettings(), false, false, false, false);
        assertEquals("\u0009", accum.toString());
    }

    @Test
    public void escapeHandlesNonAsciiControl() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "\u001F", new Document.OutputSettings(), false, false, false, false);
        assertEquals("&#x1f;", accum.toString());
    }

    @Test
    public void escapeNormalisesWhitespace() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "  \n  ", new Document.OutputSettings(), false, true, false, false);
        assertEquals(" ", accum.toString());
    }

    @Test
    public void escapeStripsLeadingWhitespace() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "  hello", new Document.OutputSettings(), false, true, true, false);
        assertEquals("hello", accum.toString());
    }

    @Test
    public void escapeTrimsTrailingWhitespace() throws IOException {
        StringBuilder accum = new StringBuilder();
        Entities.escape(accum, "hello  ", new Document.OutputSettings(), false, true, false, true);
        assertEquals("hello", accum.toString());
    }

    @Test
    public void unescapeReturnsOriginalStringWhenNoEntitiesPresent() {
        String input = "Hello, World!";
        String output = Entities.unescape(input);
        assertEquals(input, output);
    }

    @Test
    public void unescapeReturnsUnescapedStringForKnownEntity() {
        String input = "Hello, &lt;World&gt;!";
        String expected = "Hello, <World>!";
        String output = Entities.unescape(input);
        assertEquals(expected, output);
    }

    @Test
    public void unescapeReturnsUnescapedStringForMultipleKnownEntities() {
        String input = "&lt;p&gt;Hello, &amp;lt;World&amp;gt;!&lt;/p&gt;";
        String expected = "<p>Hello, &lt;World&gt;!</p>";
        String output = Entities.unescape(input);
        assertEquals(expected, output);
    }

    @Test
    public void unescapeReturnsInputWhenEntityIsUnknown() {
        String input = "Hello, &unknown;!";
        String output = Entities.unescape(input);
        assertEquals(input, output);
    }

    @Test
    public void unescapeStrictReturnsOriginalStringWhenNoTrailingSemicolon() {
        String input = "Hello, &ltWorld&gt!";
        String output = Entities.unescape(input, true);
        assertEquals(input, output);
    }

    @Test
    public void unescapeStrictReturnsUnescapedStringWhenTrailingSemicolonPresent() {
        String input = "Hello, &lt;World&gt;!";
        String expected = "Hello, <World>!";
        String output = Entities.unescape(input, true);
        assertEquals(expected, output);
    }
}
