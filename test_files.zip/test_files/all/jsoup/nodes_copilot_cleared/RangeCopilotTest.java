package org.jsoup.nodes;

import org.jsoup.nodes.Range;
import org.jsoup.nodes.Range.Position;
import org.jsoup.parser.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RangeCopilotTest {

    @Test
    public void constructorCreatesRangeWithGivenStartAndEndPositions() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        assertEquals(start, range.start());
        assertEquals(end, range.end());
    }

    @Test
    public void startReturnsStartPosition() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        assertEquals(start, range.start());
    }

    @Test
    public void startReturnsNonNullPosition() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        assertNotNull(range.start());
    }

    @Test
    public void startPosReturnsStartPosition() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        assertEquals(0, range.startPos());
    }

    @Test
    public void endReturnsEndPosition() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        assertEquals(end, range.end());
    }

    @Test
    public void endPosReturnsEndPosition() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        assertEquals(10, range.endPos());
    }

    @Test
    public void isTrackedReturnsTrueForTrackedRange() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        assertTrue(range.isTracked());
    }

    @Test
    public void isTrackedReturnsFalseForUntrackedRange() {
        Range range = Range.Untracked;
        assertFalse(range.isTracked());
    }

    @Test
    public void isImplicitReturnsFalseForTrackedRangeWithDifferentStartAndEnd() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        assertFalse(range.isImplicit());
    }

    @Test
    public void isImplicitReturnsTrueForTrackedRangeWithSameStartAndEnd() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(0, 1, 1);
        Range range = new Range(start, end);
        assertTrue(range.isImplicit());
    }

    @Test
    public void isImplicitReturnsFalseForUntrackedRange() {
        Range range = Range.Untracked;
        assertFalse(range.isImplicit());
    }

    @Test
    public void ofReturnsUntrackedForNodeWithoutAttributes() {
        Node node = new Element(Tag.valueOf("div"), "");
        Range range = Range.of(node, true);
        assertEquals(Range.Untracked, range);
    }

    @Test
    public void equalsReturnsTrueForSameRange() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range1 = new Range(start, end);
        Range range2 = new Range(start, end);
        assertTrue(range1.equals(range2));
    }

    @Test
    public void equalsReturnsFalseForDifferentRanges() {
        Position start1 = new Position(0, 1, 1);
        Position end1 = new Position(10, 1, 11);
        Range range1 = new Range(start1, end1);

        Position start2 = new Position(5, 2, 2);
        Position end2 = new Position(15, 2, 12);
        Range range2 = new Range(start2, end2);

        assertFalse(range1.equals(range2));
    }

    @Test
    public void hashCodeReturnsConsistentValueForSameRange() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range1 = new Range(start, end);
        Range range2 = new Range(start, end);
        assertEquals(range1.hashCode(), range2.hashCode());
    }

    @Test
    public void hashCodeReturnsDifferentValuesForDifferentRanges() {
        Position start1 = new Position(0, 1, 1);
        Position end1 = new Position(10, 1, 11);
        Range range1 = new Range(start1, end1);

        Position start2 = new Position(5, 2, 2);
        Position end2 = new Position(15, 2, 12);
        Range range2 = new Range(start2, end2);

        assertNotEquals(range1.hashCode(), range2.hashCode());
    }

    @Test
    public void toStringReturnsExpectedFormatForRange() {
        Position start = new Position(0, 1, 1);
        Position end = new Position(10, 1, 11);
        Range range = new Range(start, end);
        String expected = start.toString() + "-" + end.toString();
        assertEquals(expected, range.toString());
    }

    @Test
    public void positionConstructorSetsFieldsCorrectly() {
        Position position = new Position(5, 10, 15);
        assertEquals(5, position.pos());
        assertEquals(10, position.lineNumber());
        assertEquals(15, position.columnNumber());
    }

    @Test
    public void isTrackedReturnsTrueForTrackedPosition() {
        Position position = new Position(5, 10, 15);
        assertTrue(position.isTracked());
    }

    @Test
    public void toStringReturnsExpectedFormat() {
        Position position = new Position(5, 10, 15);
        assertEquals("10,15:5", position.toString());
    }

    @Test
    public void equalsReturnsTrueForSamePosition() {
        Position position1 = new Position(5, 10, 15);
        Position position2 = new Position(5, 10, 15);
        assertTrue(position1.equals(position2));
    }

    @Test
    public void equalsReturnsFalseForDifferentPositions() {
        Position position1 = new Position(5, 10, 15);
        Position position2 = new Position(10, 15, 20);
        assertFalse(position1.equals(position2));
    }

    @Test
    public void hashCodeReturnsConsistentValueForSamePosition() {
        Position position1 = new Position(5, 10, 15);
        Position position2 = new Position(5, 10, 15);
        assertEquals(position1.hashCode(), position2.hashCode());
    }

    @Test
    public void hashCodeReturnsDifferentValuesForDifferentPositions() {
        Position position1 = new Position(5, 10, 15);
        Position position2 = new Position(10, 15, 20);
        assertNotEquals(position1.hashCode(), position2.hashCode());
    }

    @Test
    public void attributeRangeConstructorSetsFieldsCorrectly() {
        Range nameRange = new Range(new Position(0, 1, 1), new Position(10, 1, 11));
        Range valueRange = new Range(new Position(20, 2, 2), new Position(30, 2, 12));
        Range.AttributeRange attributeRange = new Range.AttributeRange(nameRange, valueRange);
        assertEquals(nameRange, attributeRange.nameRange());
        assertEquals(valueRange, attributeRange.valueRange());
    }

    @Test
    public void nameRangeReturnsNameRange() {
        Range nameRange = new Range(new Position(0, 1, 1), new Position(10, 1, 11));
        Range valueRange = new Range(new Position(20, 2, 2), new Position(30, 2, 12));
        Range.AttributeRange attributeRange = new Range.AttributeRange(nameRange, valueRange);
        assertEquals(nameRange, attributeRange.nameRange());
    }

    @Test
    public void valueRangeReturnsValueRange() {
        Range nameRange = new Range(new Position(0, 1, 1), new Position(10, 1, 11));
        Range valueRange = new Range(new Position(20, 2, 2), new Position(30, 2, 12));
        Range.AttributeRange attributeRange = new Range.AttributeRange(nameRange, valueRange);
        assertEquals(valueRange, attributeRange.valueRange());
    }

    @Test
    public void equalsReturnsTrueForSameAttributeRange() {
        Range nameRange = new Range(new Position(0, 1, 1), new Position(10, 1, 11));
        Range valueRange = new Range(new Position(20, 2, 2), new Position(30, 2, 12));
        Range.AttributeRange attributeRange1 = new Range.AttributeRange(nameRange, valueRange);
        Range.AttributeRange attributeRange2 = new Range.AttributeRange(nameRange, valueRange);
        assertTrue(attributeRange1.equals(attributeRange2));
    }

    @Test
    public void equalsReturnsFalseForDifferentAttributeRanges() {
        Range nameRange1 = new Range(new Position(0, 1, 1), new Position(10, 1, 11));
        Range valueRange1 = new Range(new Position(20, 2, 2), new Position(30, 2, 12));
        Range.AttributeRange attributeRange1 = new Range.AttributeRange(nameRange1, valueRange1);

        Range nameRange2 = new Range(new Position(5, 2, 2), new Position(15, 2, 12));
        Range valueRange2 = new Range(new Position(25, 3, 3), new Position(35, 3, 13));
        Range.AttributeRange attributeRange2 = new Range.AttributeRange(nameRange2, valueRange2);

        assertFalse(attributeRange1.equals(attributeRange2));
    }

    @Test
    public void hashCodeReturnsConsistentValueForSameAttributeRange() {
        Range nameRange = new Range(new Position(0, 1, 1), new Position(10, 1, 11));
        Range valueRange = new Range(new Position(20, 2, 2), new Position(30, 2, 12));
        Range.AttributeRange attributeRange1 = new Range.AttributeRange(nameRange, valueRange);
        Range.AttributeRange attributeRange2 = new Range.AttributeRange(nameRange, valueRange);
        assertEquals(attributeRange1.hashCode(), attributeRange2.hashCode());
    }

    @Test
    public void hashCodeReturnsDifferentValuesForDifferentAttributeRanges() {
        Range nameRange1 = new Range(new Position(0, 1, 1), new Position(10, 1, 11));
        Range valueRange1 = new Range(new Position(20, 2, 2), new Position(30, 2, 12));
        Range.AttributeRange attributeRange1 = new Range.AttributeRange(nameRange1, valueRange1);

        Range nameRange2 = new Range(new Position(5, 2, 2), new Position(15, 2, 12));
        Range valueRange2 = new Range(new Position(25, 3, 3), new Position(35, 3, 13));
        Range.AttributeRange attributeRange2 = new Range.AttributeRange(nameRange2, valueRange2);

        assertNotEquals(attributeRange1.hashCode(), attributeRange2.hashCode());
    }
}
