package org.jsoup.nodes;

import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.PseudoTextElement;
import org.jsoup.parser.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class PseudoTextElementCopilotTest {

    @Test
    public void constructorCreatesPseudoTextElementWithGivenTag() {
        Tag tag = Tag.valueOf("div");
        PseudoTextElement element = new PseudoTextElement(tag, "", new Attributes());
        assertEquals(tag, element.tag());
    }

    @Test
    public void constructorCreatesPseudoTextElementWithGivenBaseUri() {
        String baseUri = "http://example.com";
        PseudoTextElement element = new PseudoTextElement(Tag.valueOf("div"), baseUri, new Attributes());
        assertEquals(baseUri, element.baseUri());
    }

    @Test
    public void constructorCreatesPseudoTextElementWithGivenAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        PseudoTextElement element = new PseudoTextElement(Tag.valueOf("div"), "", attributes);
        assertEquals(attributes, element.attributes());
    }

    @Test
    public void constructorCreatesPseudoTextElementWithNonNullNode() {
        PseudoTextElement element = new PseudoTextElement(Tag.valueOf("div"), "", new Attributes());
        assertNotNull(element);
    }

    @Test
    public void outerHtmlHeadDoesNotModifyAccum() {
        PseudoTextElement element = new PseudoTextElement(Tag.valueOf("div"), "", new Attributes());
        StringBuilder accum = new StringBuilder("Test");
        element.outerHtmlHead(accum, 0, new Document.OutputSettings());
        assertEquals("Test", accum.toString());
    }

    @Test
    public void outerHtmlTailDoesNotModifyAccum() {
        PseudoTextElement element = new PseudoTextElement(Tag.valueOf("div"), "", new Attributes());
        StringBuilder accum = new StringBuilder("Test");
        element.outerHtmlTail(accum, 0, new Document.OutputSettings());
        assertEquals("Test", accum.toString());
    }
}
