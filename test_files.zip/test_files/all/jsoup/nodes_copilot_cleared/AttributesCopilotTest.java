package org.jsoup.nodes;

import org.jsoup.parser.ParseSettings;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.jsoup.internal.SharedConstants.AttrRangeKey;
import static org.junit.jupiter.api.Assertions.*;

class AttributesCopilotTest {

    @Test
    public void returnsEmptyStringWhenValueIsNull() {
        Object val = null;
        assertEquals(Attributes.checkNotNull(val), "");
    }

    @Test
    public void returnsStringValueWhenValueIsNotNull() {
        Object val = "test";
        assertEquals(Attributes.checkNotNull(val), "test");
    }

    @Test
    public void returnsEmptyStringWhenKeyNotFound() {
        Attributes attributes = new Attributes();
        assertEquals(attributes.get("nonexistentKey"), "");
    }

    @Test
    public void returnsAttributeValueWhenKeyFound() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        assertEquals(attributes.get("key"), "value");
    }

    @Test
    public void returnsAttributeWhenKeyExists() {
        Attributes attributes = new Attributes();
        attributes.add("key", "value");
        Attribute attribute = attributes.attribute("key");
        assertNotNull(attribute);
        assertEquals("key", attribute.getKey());
        assertEquals("value", attribute.getValue());
    }

    @Test
    public void returnsNullWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        Attribute attribute = attributes.attribute("nonexistentKey");
        assertNull(attribute);
    }

    @Test
    public void returnsValueWhenKeyExistsIgnoreCase() {
        Attributes attributes = new Attributes();
        attributes.add("Key", "value");
        String value = attributes.getIgnoreCase("key");
        assertEquals("value", value);
    }

    @Test
    public void returnsEmptyStringWhenKeyDoesNotExistIgnoreCase() {
        Attributes attributes = new Attributes();
        String value = attributes.getIgnoreCase("nonexistentKey");
        assertEquals("", value);
    }

    @Test
    public void addsNewAttribute() {
        Attributes attributes = new Attributes();
        attributes.add("key", "value");
        assertEquals("value", attributes.get("key"));
    }

    @Test
    public void addsDuplicateAttribute() {
        Attributes attributes = new Attributes();
        attributes.add("key", "value1");
        attributes.add("key", "value2");
        assertEquals("value1", attributes.get("key"));
        assertEquals("value2", attributes.getIgnoreCase("key"));
    }

    @Test
    public void putAddsNewAttributeWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        assertEquals("value", attributes.get("key"));
    }

    @Test
    public void putUpdatesValueWhenKeyExists() {
        Attributes attributes = new Attributes();
        attributes.put("key", "initialValue");
        attributes.put("key", "updatedValue");
        assertEquals("updatedValue", attributes.get("key"));
    }

    @Test
    public void putReturnsSameAttributesInstance() {
        Attributes attributes = new Attributes();
        Attributes returnedAttributes = attributes.put("key", "value");
        assertSame(attributes, returnedAttributes);
    }

    @Test
    public void userDataReturnsEmptyMapWhenNoUserData() {
        Attributes attributes = new Attributes();
        Map<String, Object> userData = attributes.userData();
        assertTrue(userData.isEmpty());
    }

    @Test
    public void userDataReturnsUserDataWhenExists() {
        Attributes attributes = new Attributes();
        attributes.userData("testKey", "testValue");
        Map<String, Object> userData = attributes.userData();
        assertEquals("testValue", userData.get("testKey"));
    }

    @Test
    public void userDataReturnsNullWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        assertNull(attributes.userData("nonexistentKey"));
    }

    @Test
    public void userDataReturnsValueWhenKeyExists() {
        Attributes attributes = new Attributes();
        attributes.userData("testKey", "testValue");
        assertEquals("testValue", attributes.userData("testKey"));
    }

    @Test
    public void userDataAddsNewData() {
        Attributes attributes = new Attributes();
        attributes.userData("newKey", "newValue");
        assertEquals("newValue", attributes.userData("newKey"));
    }

    @Test
    public void putIgnoreCaseAddsNewAttributeWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        attributes.putIgnoreCase("key", "value");
        assertEquals("value", attributes.getIgnoreCase("key"));
    }

    @Test
    public void putIgnoreCaseUpdatesValueWhenKeyExists() {
        Attributes attributes = new Attributes();
        attributes.putIgnoreCase("key", "initialValue");
        attributes.putIgnoreCase("key", "updatedValue");
        assertEquals("updatedValue", attributes.getIgnoreCase("key"));
    }

    @Test
    public void putIgnoreCaseUpdatesKeyCaseWhenKeyExists() {
        Attributes attributes = new Attributes();
        attributes.putIgnoreCase("key", "value");
        attributes.putIgnoreCase("KEY", "value");
        assertFalse(attributes.hasKey("key"));
        assertTrue(attributes.hasKey("KEY"));
    }

    @Test
    public void putAddsBooleanAttributeWhenValueIsTrue() {
        Attributes attributes = new Attributes();
        attributes.put("key", true);
        assertTrue(attributes.hasKey("key"));
        assertEquals("", attributes.get("key"));
    }

    @Test
    public void putRemovesAttributeWhenValueIsFalse() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        attributes.put("key", false);
        assertFalse(attributes.hasKey("key"));
    }

    @Test
    public void putAddsNewAttribute() {
        Attributes attributes = new Attributes();
        Attribute attribute = new Attribute("key", "value");
        attributes.put(attribute);
        assertTrue(attributes.hasKey("key"));
        assertEquals("value", attributes.get("key"));
    }

    @Test
    public void putReplacesExistingAttribute() {
        Attributes attributes = new Attributes();
        attributes.put("key", "initialValue");
        Attribute attribute = new Attribute("key", "updatedValue");
        attributes.put(attribute);
        assertTrue(attributes.hasKey("key"));
        assertEquals("updatedValue", attributes.get("key"));
    }

    @Test
    public void removesAttributeWhenKeyExists() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        attributes.remove("key");
        assertFalse(attributes.hasKey("key"));
    }

    @Test
    public void doesNotRemoveAttributeWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        attributes.remove("nonexistentKey");
        assertEquals(0, attributes.size());
    }

    @Test
    public void removesAttributeWhenKeyExistsIgnoreCase() {
        Attributes attributes = new Attributes();
        attributes.put("Key", "value");
        attributes.removeIgnoreCase("key");
        assertFalse(attributes.hasKey("Key"));
    }

    @Test
    public void doesNotRemoveAttributeWhenKeyDoesNotExistIgnoreCase() {
        Attributes attributes = new Attributes();
        attributes.removeIgnoreCase("nonexistentKey");
        assertEquals(0, attributes.size());
    }

    @Test
    public void hasKeyReturnsTrueWhenKeyExists() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        assertTrue(attributes.hasKey("key"));
    }

    @Test
    public void hasKeyReturnsFalseWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        assertFalse(attributes.hasKey("nonexistentKey"));
    }

    @Test
    public void hasKeyIgnoreCaseReturnsTrueWhenKeyExists() {
        Attributes attributes = new Attributes();
        attributes.put("Key", "value");
        assertTrue(attributes.hasKeyIgnoreCase("key"));
    }

    @Test
    public void hasKeyIgnoreCaseReturnsFalseWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        assertFalse(attributes.hasKeyIgnoreCase("nonexistentKey"));
    }

    @Test
    public void hasDeclaredValueForKeyReturnsTrueWhenKeyExistsWithValue() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        assertTrue(attributes.hasDeclaredValueForKey("key"));
    }

    @Test
    public void hasDeclaredValueForKeyReturnsFalseWhenKeyExistsWithoutValue() {
        Attributes attributes = new Attributes();
        attributes.put("key", null);
        assertFalse(attributes.hasDeclaredValueForKey("key"));
    }

    @Test
    public void hasDeclaredValueForKeyReturnsFalseWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        assertFalse(attributes.hasDeclaredValueForKey("nonexistentKey"));
    }

    @Test
    public void hasDeclaredValueForKeyIgnoreCaseReturnsTrueWhenKeyExistsWithValue() {
        Attributes attributes = new Attributes();
        attributes.put("Key", "value");
        assertTrue(attributes.hasDeclaredValueForKeyIgnoreCase("key"));
    }

    @Test
    public void hasDeclaredValueForKeyIgnoreCaseReturnsFalseWhenKeyExistsWithoutValue() {
        Attributes attributes = new Attributes();
        attributes.put("Key", null);
        assertFalse(attributes.hasDeclaredValueForKeyIgnoreCase("key"));
    }

    @Test
    public void hasDeclaredValueForKeyIgnoreCaseReturnsFalseWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        assertFalse(attributes.hasDeclaredValueForKeyIgnoreCase("nonexistentKey"));
    }

    @Test
    public void sizeReturnsCorrectCount() {
        Attributes attributes = new Attributes();
        attributes.put("key1", "value1");
        attributes.put("key2", "value2");
        assertEquals(2, attributes.size());
    }

    @Test
    public void sizeReturnsZeroForEmptyAttributes() {
        Attributes attributes = new Attributes();
        assertEquals(0, attributes.size());
    }

    @Test
    public void isEmptyReturnsTrueForEmptyAttributes() {
        Attributes attributes = new Attributes();
        assertTrue(attributes.isEmpty());
    }

    @Test
    public void isEmptyReturnsFalseForNonEmptyAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        assertFalse(attributes.isEmpty());
    }

    @Test
    public void addAllAddsAllAttributesFromIncoming() {
        Attributes attributes = new Attributes();
        Attributes incoming = new Attributes();
        incoming.put("key1", "value1");
        incoming.put("key2", "value2");
        attributes.addAll(incoming);
        assertEquals(2, attributes.size());
        assertEquals("value1", attributes.get("key1"));
        assertEquals("value2", attributes.get("key2"));
    }

    @Test
    public void addAllDoesNothingForEmptyIncoming() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        Attributes incoming = new Attributes();
        attributes.addAll(incoming);
        assertEquals(1, attributes.size());
        assertEquals("value", attributes.get("key"));
    }

    @Test
    public void sourceRangeReturnsUntrackedWhenKeyDoesNotExist() {
        Attributes attributes = new Attributes();
        assertEquals(Range.AttributeRange.UntrackedAttr, attributes.sourceRange("nonexistentKey"));
    }

    @Test
    public void sourceRangeReturnsUntrackedWhenRangesIsNull() {
        Attributes attributes = new Attributes();
        attributes.put("testKey", "testValue");
        assertEquals(Range.AttributeRange.UntrackedAttr, attributes.sourceRange("testKey"));
    }

    @Test
    public void sourceRangeReturnsUntrackedWhenRangeIsNull() {
        Attributes attributes = new Attributes();
        attributes.put("testKey", "testValue");
        Map<String, Range.AttributeRange> ranges = new HashMap<>();
        ranges.put("testKey", null);
        attributes.userData(AttrRangeKey, ranges);
        assertEquals(Range.AttributeRange.UntrackedAttr, attributes.sourceRange("testKey"));
    }

    @Test
    public void getRangesReturnsNullWhenNoUserData() {
        Attributes attributes = new Attributes();
        assertNull(attributes.getRanges());
    }

    @Test
    public void iteratorReturnsAttributesInOrder() {
        Attributes attributes = new Attributes();
        attributes.put("key1", "value1");
        attributes.put("key2", "value2");
        Iterator<Attribute> iterator = attributes.iterator();
        assertTrue(iterator.hasNext());
        assertEquals("key1", iterator.next().getKey());
        assertEquals("key2", iterator.next().getKey());
        assertFalse(iterator.hasNext());
    }

    @Test
    public void iteratorSkipsInternalKeys() {
        Attributes attributes = new Attributes();
        attributes.put("key1", "value1");
        attributes.put(Attributes.internalKey("internal"), "value2");
        Iterator<Attribute> iterator = attributes.iterator();
        assertTrue(iterator.hasNext());
        assertEquals("key1", iterator.next().getKey());
        assertFalse(iterator.hasNext());
    }

    @Test
    public void iteratorThrowsExceptionOnConcurrentModification() {
        Attributes attributes = new Attributes();
        attributes.put("key1", "value1");
        Iterator<Attribute> iterator = attributes.iterator();
        attributes.put("key2", "value2");
        assertThrows(ConcurrentModificationException.class, iterator::next);
    }

    @Test
    public void asListReturnsAttributesInOrder() {
        Attributes attributes = new Attributes();
        attributes.put("key1", "value1");
        attributes.put("key2", "value2");
        List<Attribute> list = attributes.asList();
        assertEquals(2, list.size());
        assertEquals("key1", list.get(0).getKey());
        assertEquals("key2", list.get(1).getKey());
    }

    @Test
    public void asListSkipsInternalKeys() {
        Attributes attributes = new Attributes();
        attributes.put("key1", "value1");
        attributes.put(Attributes.internalKey("internal"), "value2");
        List<Attribute> list = attributes.asList();
        assertEquals(1, list.size());
        assertEquals("key1", list.get(0).getKey());
    }

    @Test
    public void datasetReturnsCorrectMap() {
        Attributes attributes = new Attributes();
        attributes.put("data-test", "value");
        Map<String, String> dataset = attributes.dataset();
        assertEquals(1, dataset.size());
        assertTrue(dataset.containsKey("test"));
        assertEquals("value", dataset.get("test"));
    }

    @Test
    public void datasetReturnsEmptyMapForNoDataAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("test", "value");
        Map<String, String> dataset = attributes.dataset();
        assertTrue(dataset.isEmpty());
    }

    @Test
    public void htmlReturnsCorrectRepresentation() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        String html = attributes.html();
        assertEquals("key=\"value\"", html);
    }

    @Test
    public void htmlReturnsEmptyStringForNoAttributes() {
        Attributes attributes = new Attributes();
        String html = attributes.html();
        assertEquals("", html);
    }

    @Test
    public void htmlDoesNotIncludeInternalAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        attributes.put(Attributes.internalKey("internal"), "value");
        String html = attributes.html();
        assertEquals("key=\"value\"", html);
    }

    @Test
    public void toStringReturnsHtmlRepresentation() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        assertEquals("key=\"value\"", attributes.toString());
    }

    @Test
    public void equalsReturnsTrueForSameAttributes() {
        Attributes attributes1 = new Attributes();
        attributes1.put("key", "value");
        Attributes attributes2 = new Attributes();
        attributes2.put("key", "value");
        assertTrue(attributes1.equals(attributes2));
    }

    @Test
    public void equalsReturnsFalseForDifferentAttributes() {
        Attributes attributes1 = new Attributes();
        attributes1.put("key", "value");
        Attributes attributes2 = new Attributes();
        attributes2.put("key", "differentValue");
        assertFalse(attributes1.equals(attributes2));
    }

    @Test
    public void equalsReturnsFalseForDifferentSize() {
        Attributes attributes1 = new Attributes();
        attributes1.put("key1", "value");
        attributes1.put("key2", "value");
        Attributes attributes2 = new Attributes();
        attributes2.put("key", "value");
        assertFalse(attributes1.equals(attributes2));
    }

    @Test
    public void equalsReturnsFalseWhenComparingWithNull() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        assertFalse(attributes.equals(null));
    }

    @Test
    public void equalsReturnsFalseWhenComparingWithDifferentClass() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        assertFalse(attributes.equals(new Object()));
    }

    @Test
    public void hashCodeReturnsConsistentValue() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        int initialHashCode = attributes.hashCode();
        assertEquals(initialHashCode, attributes.hashCode());
    }

    @Test
    public void hashCodeChangesWhenAttributesChange() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        int initialHashCode = attributes.hashCode();
        attributes.put("anotherKey", "anotherValue");
        assertNotEquals(initialHashCode, attributes.hashCode());
    }

    @Test
    public void cloneCreatesIdenticalAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        Attributes clone = attributes.clone();
        assertEquals(attributes, clone);
        assertNotSame(attributes, clone);
    }

    @Test
    public void cloneCreatesIndependentAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("key", "value");
        Attributes clone = attributes.clone();
        clone.put("anotherKey", "anotherValue");
        assertNotEquals(attributes, clone);
    }

    @Test
    public void normalizeConvertsKeysToLowerCase() {
        Attributes attributes = new Attributes();
        attributes.put("KEY", "value");
        attributes.normalize();
        assertTrue(attributes.hasKey("key"));
        assertFalse(attributes.hasKey("KEY"));
    }

    @Test
    public void normalizeDoesNotConvertInternalKeys() {
        Attributes attributes = new Attributes();
        attributes.put(Attributes.internalKey("KEY"), "value");
        attributes.normalize();
        assertTrue(attributes.hasKey(Attributes.internalKey("KEY")));
        assertFalse(attributes.hasKey(Attributes.internalKey("key")));
    }

    @Test
    public void deduplicateRemovesDuplicateAttributesWithCaseSensitivity() {
        Attributes attributes = new Attributes();
        attributes.put("Key", "value");
        attributes.put("key", "value");
        ParseSettings settings = new ParseSettings(true, true);
        int duplicates = attributes.deduplicate(settings);
        assertEquals(1, duplicates);
        assertEquals(1, attributes.size());
    }

    @Test
    public void deduplicateRemovesDuplicateAttributesWithoutCaseSensitivity() {
        Attributes attributes = new Attributes();
        attributes.put("Key", "value");
        attributes.put("key", "value");
        ParseSettings settings = new ParseSettings(false, true);
        int duplicates = attributes.deduplicate(settings);
        assertEquals(1, duplicates);
        assertEquals(1, attributes.size());
    }

    @Test
    public void deduplicateDoesNotRemoveNonDuplicateAttributes() {
        Attributes attributes = new Attributes();
        attributes.put("Key1", "value");
        attributes.put("Key2", "value");
        ParseSettings settings = new ParseSettings(true, true);
        int duplicates = attributes.deduplicate(settings);
        assertEquals(0, duplicates);
        assertEquals(2, attributes.size());
    }

    @Test
    public void deduplicateReturnsZeroWhenAttributesAreEmpty() {
        Attributes attributes = new Attributes();
        ParseSettings settings = new ParseSettings(true, true);
        int duplicates = attributes.deduplicate(settings);
        assertEquals(0, duplicates);
        assertEquals(0, attributes.size());
    }

    @Test
    public void internalKeyAppendsPrefix() {
        String key = "testKey";
        String expected = "/" + key;
        assertEquals(expected, Attributes.internalKey(key));
    }

    @Test
    public void internalKeyHandlesNullInput() {
        assertNull(Attributes.internalKey(null));
    }

    @Test
    public void isInternalKeyReturnsTrueForInternalKeys() {
        String key = "/testKey";
        assertTrue(Attributes.isInternalKey(key));
    }

    @Test
    public void isInternalKeyReturnsFalseForNonInternalKeys() {
        String key = "testKey";
        assertFalse(Attributes.isInternalKey(key));
    }

    @Test
    public void isInternalKeyReturnsFalseForNullInput() {
        assertFalse(Attributes.isInternalKey(null));
    }

    @Test
    public void isInternalKeyReturnsFalseForEmptyString() {
        assertFalse(Attributes.isInternalKey(""));
    }

    @Test
    public void isInternalKeyReturnsFalseForSingleCharacterKeys() {
        assertFalse(Attributes.isInternalKey("/"));
    }
}