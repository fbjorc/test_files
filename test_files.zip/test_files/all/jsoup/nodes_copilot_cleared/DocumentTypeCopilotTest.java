package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class DocumentTypeCopilotTest {

    @Test
    public void documentTypeConstructorSetsValues() {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        assertEquals("html", documentType.attr("name"));
        assertEquals("publicId", documentType.attr("publicId"));
        assertEquals("systemId", documentType.attr("systemId"));
    }

    @Test
    public void documentTypeConstructorThrowsExceptionForNullName() {
        assertThrows(IllegalArgumentException.class, () -> new DocumentType(null, "publicId", "systemId"));
    }

    @Test
    public void documentTypeConstructorThrowsExceptionForNullPublicId() {
        assertThrows(IllegalArgumentException.class, () -> new DocumentType("html", null, "systemId"));
    }

    @Test
    public void documentTypeConstructorThrowsExceptionForNullSystemId() {
        assertThrows(IllegalArgumentException.class, () -> new DocumentType("html", "publicId", null));
    }

    @Test
    public void setPubSysKeySetsValue() {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        documentType.setPubSysKey("newKey");
        assertEquals("newKey", documentType.attr("pubSysKey"));
    }

    @Test
    public void setPubSysKeyDoesNotSetNullValue() {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        documentType.setPubSysKey(null);
        assertNotEquals(null, documentType.attr("pubSysKey"));
    }

    @Test
    public void nameReturnsCorrectName() {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        assertEquals("html", documentType.name());
    }

    @Test
    public void nameReturnsEmptyStringForNoName() {
        DocumentType documentType = new DocumentType("", "publicId", "systemId");
        assertEquals("", documentType.name());
    }

    @Test
    public void publicIdReturnsCorrectPublicId() {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        assertEquals("publicId", documentType.publicId());
    }

    @Test
    public void publicIdReturnsEmptyStringForNoPublicId() {
        DocumentType documentType = new DocumentType("html", "", "systemId");
        assertEquals("", documentType.publicId());
    }

    @Test
    public void systemIdReturnsCorrectSystemId() {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        assertEquals("systemId", documentType.systemId());
    }

    @Test
    public void systemIdReturnsEmptyStringForNoSystemId() {
        DocumentType documentType = new DocumentType("html", "publicId", "");
        assertEquals("", documentType.systemId());
    }

    @Test
    public void nodeNameReturnsCorrectValue() {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        assertEquals("#doctype", documentType.nodeName());
    }

    @Test
    public void outerHtmlHeadReturnsCorrectValueForHtmlSyntax() throws IOException {
        DocumentType documentType = new DocumentType("html", "", "");
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.syntax(Document.OutputSettings.Syntax.html);
        StringBuilder accum = new StringBuilder();
        documentType.outerHtmlHead(accum, 0, outputSettings);
        assertEquals("<!doctype html>", accum.toString());
    }

    @Test
    public void outerHtmlHeadReturnsCorrectValueForXmlSyntax() throws IOException {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.syntax(Document.OutputSettings.Syntax.xml);
        StringBuilder accum = new StringBuilder();
        documentType.outerHtmlHead(accum, 0, outputSettings);
        assertEquals("<!DOCTYPE html PUBLIC \"publicId\" \"systemId\">", accum.toString());
    }

    @Test
    public void outerHtmlHeadReturnsCorrectValueWithPrecedingNode() throws IOException {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        documentType.siblingIndex = 1; // Simulate a preceding node
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.syntax(Document.OutputSettings.Syntax.xml);
        outputSettings.prettyPrint(true);
        StringBuilder accum = new StringBuilder();
        documentType.outerHtmlHead(accum, 0, outputSettings);
        assertEquals("\n<!DOCTYPE html PUBLIC \"publicId\" \"systemId\">", accum.toString());
    }

    @Test
    public void outerHtmlTailDoesNotModifyAccum() throws IOException {
        DocumentType documentType = new DocumentType("html", "publicId", "systemId");
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        StringBuilder accum = new StringBuilder("initialValue");
        documentType.outerHtmlTail(accum, 0, outputSettings);
        assertEquals("initialValue", accum.toString());
    }
}
