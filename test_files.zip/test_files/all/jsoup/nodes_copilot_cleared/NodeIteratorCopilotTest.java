package org.jsoup.nodes;

import org.jsoup.parser.Tag;
import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

public class NodeIteratorCopilotTest {

    @Test
    public void restartSetsNextToStartWhenTypeMatches() {
        Node start = new TextNode("Test");
        NodeIterator<TextNode> it = new NodeIterator<>(start, TextNode.class);
        it.restart(start);
        assertEquals(start, it.next());
    }

    @Test
    public void restartSetsNextToNullWhenTypeDoesNotMatch() {
        Node start = new Element(Tag.valueOf("div"), "");
        NodeIterator<TextNode> it = new NodeIterator<>(start, TextNode.class);
        it.restart(start);
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    public void hasNextReturnsTrueWhenNextNodeExists() {
        Node start = new TextNode("Test");
        NodeIterator<TextNode> it = new NodeIterator<>(start, TextNode.class);
        assertTrue(it.hasNext());
    }

    @Test
    public void hasNextReturnsFalseWhenNoNextNode() {
        Node start = new Element(Tag.valueOf("div"), "");
        NodeIterator<TextNode> it = new NodeIterator<>(start, TextNode.class);
        assertFalse(it.hasNext());
    }

    @Test
    public void nextReturnsNextNodeWhenExists() {
        Node start = new TextNode("Test");
        NodeIterator<TextNode> it = new NodeIterator<>(start, TextNode.class);
        assertEquals(start, it.next());
    }

    @Test
    public void nextThrowsExceptionWhenNoNextNode() {
        Node start = new Element(Tag.valueOf("div"), "");
        NodeIterator<TextNode> it = new NodeIterator<>(start, TextNode.class);
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    public void removeRemovesCurrentNode() {
        Node start = new TextNode("Test");
        NodeIterator<TextNode> it = new NodeIterator<>(start, TextNode.class);
        it.next();
        it.remove();
        assertFalse(it.hasNext());
    }

    @Test
    public void removeThrowsExceptionWhenNoCurrentNode() {
        Node start = new Element(Tag.valueOf("div"), "");
        NodeIterator<TextNode> it = new NodeIterator<>(start, TextNode.class);
        assertThrows(IllegalStateException.class, it::remove);
    }
}
