package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class TextNodeCopilotTest {

    @Test
    public void constructorSetsValueCorrectly() {
        TextNode node = new TextNode("Test");
        assertEquals("Test", node.getWholeText());
    }

    @Test
    public void nodeNameReturnsCorrectValue() {
        TextNode node = new TextNode("Test");
        assertEquals("#text", node.nodeName());
    }

    @Test
    public void textReturnsNormalizedText() {
        TextNode node = new TextNode("  Test  ");
        assertEquals("Test", node.text());
    }

    @Test
    public void textReturnsEmptyForWhitespaceOnly() {
        TextNode node = new TextNode("  ");
        assertEquals("", node.text());
    }

    @Test
    public void textReturnsOriginalTextForNonWhitespace() {
        TextNode node = new TextNode("Test");
        assertEquals("Test", node.text());
    }

    @Test
    public void textSetsValueCorrectly() {
        TextNode node = new TextNode("Initial");
        node.text("Updated");
        assertEquals("Updated", node.getWholeText());
    }

    @Test
    public void getWholeTextReturnsCorrectValue() {
        TextNode node = new TextNode("Test");
        assertEquals("Test", node.getWholeText());
    }

    @Test
    public void isBlankReturnsTrueForEmptyString() {
        TextNode node = new TextNode("");
        assertTrue(node.isBlank());
    }

    @Test
    public void isBlankReturnsTrueForWhitespaceOnly() {
        TextNode node = new TextNode("  ");
        assertTrue(node.isBlank());
    }

    @Test
    public void isBlankReturnsFalseForNonWhitespace() {
        TextNode node = new TextNode("Test");
        assertFalse(node.isBlank());
    }

    @Test
    public void splitTextReturnsCorrectTailNode() {
        TextNode node = new TextNode("Hello World");
        TextNode tailNode = node.splitText(6);
        assertEquals("World", tailNode.getWholeText());
    }

    @Test
    public void splitTextUpdatesOriginalNodeCorrectly() {
        TextNode node = new TextNode("Hello World");
        node.splitText(6);
        assertEquals("Hello ", node.getWholeText());
    }

    @Test
    public void splitTextThrowsExceptionForNegativeOffset() {
        TextNode node = new TextNode("Hello World");
        assertThrows(IllegalArgumentException.class, () -> node.splitText(-1));
    }

    @Test
    public void splitTextThrowsExceptionForOffsetGreaterThanLength() {
        TextNode node = new TextNode("Hello World");
        assertThrows(IllegalArgumentException.class, () -> node.splitText(20));
    }

    @Test
    public void outerHtmlHeadHandlesWhitespaceCorrectly() throws IOException {
        TextNode node = new TextNode("  Hello  ");
        StringBuilder accum = new StringBuilder();
        node.outerHtmlHead(accum, 0, new Document.OutputSettings().prettyPrint(true));
        assertEquals("Hello", accum.toString());
    }

    @Test
    public void outerHtmlHeadHandlesNonWhitespaceCorrectly() throws IOException {
        TextNode node = new TextNode("Hello");
        StringBuilder accum = new StringBuilder();
        node.outerHtmlHead(accum, 0, new Document.OutputSettings().prettyPrint(true));
        assertEquals("Hello", accum.toString());
    }

    @Test
    public void outerHtmlHeadSkipsWhitespaceOnlyNode() throws IOException {
        TextNode node = new TextNode("  ");
        StringBuilder accum = new StringBuilder();
        node.outerHtmlHead(accum, 0, new Document.OutputSettings().prettyPrint(true));
        assertEquals("", accum.toString());
    }

    @Test
    public void outerHtmlTailDoesNotModifyAccum() throws IOException {
        TextNode node = new TextNode("Test");
        StringBuilder accum = new StringBuilder("Initial");
        node.outerHtmlTail(accum, 0, new Document.OutputSettings().prettyPrint(true));
        assertEquals("Initial", accum.toString());
    }

    @Test
    public void toStringReturnsOuterHtml() {
        TextNode node = new TextNode("Test");
        assertEquals(node.outerHtml(), node.toString());
    }

    @Test
    public void cloneCreatesNewInstance() {
        TextNode node = new TextNode("Test");
        TextNode clone = node.clone();
        assertNotSame(node, clone);
    }

    @Test
    public void cloneCopiesValue() {
        TextNode node = new TextNode("Test");
        TextNode clone = node.clone();
        assertEquals(node.getWholeText(), clone.getWholeText());
    }
}