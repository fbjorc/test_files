package org.jsoup.nodes;

import org.jsoup.Jsoup;
import org.jsoup.parser.Parser;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class NodeUtilsCopilotTest {

    @Test
    public void selectXpathReturnsCorrectNodes() {
        Document doc = Jsoup.parse("<div><p>Test</p><p>Test</p></div>");
        List<Element> elements = NodeUtils.selectXpath("//p", doc.body(), Element.class);
        assertEquals(2, elements.size());
        assertEquals("p", elements.get(0).tagName());
        assertEquals("p", elements.get(1).tagName());
    }

    @Test
    public void selectXpathThrowsExceptionForEmptyXpath() {
        Document doc = Jsoup.parse("<div><p>Test</p><p>Test</p></div>");
        assertThrows(IllegalArgumentException.class, () -> NodeUtils.selectXpath("", doc.body(), Element.class));
    }

    @Test
    public void selectXpathThrowsExceptionForNullElement() {
        assertThrows(IllegalArgumentException.class, () -> NodeUtils.selectXpath("//p", null, Element.class));
    }

    @Test
    public void selectXpathThrowsExceptionForNullNodeType() {
        Document doc = Jsoup.parse("<div><p>Test</p><p>Test</p></div>");
        assertThrows(IllegalArgumentException.class, () -> NodeUtils.selectXpath("//p", doc.body(), null));
    }
}
