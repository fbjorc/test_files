package org.jsoup.nodes;

import org.jsoup.parser.Tag;
import org.junit.jupiter.api.Test;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class LeafNodeCopilotTest {

    @Test
    public void hasAttributesReturnsFalseWhenNoAttributes() {
        LeafNode leafNode = new TextNode("Test");
        assertFalse(leafNode.hasAttributes());
    }

    @Test
    public void hasAttributesReturnsTrueWhenAttributesExist() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("key", "value");
        assertTrue(leafNode.hasAttributes());
    }

    @Test
    public void attributesReturnsEmptyAttributesWhenNoAttributes() {
        LeafNode leafNode = new TextNode("Test");
        Attributes attributes = leafNode.attributes();
        assertTrue(attributes.isEmpty());
    }

    @Test
    public void attributesReturnsAttributesWhenAttributesExist() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("key", "value");
        Attributes attributes = leafNode.attributes();
        assertEquals("value", attributes.get("key"));
    }

    @Test
    public void coreValueReturnsNodeNameWhenNoAttributes() {
        LeafNode leafNode = new TextNode("Test");
        assertEquals("Test", leafNode.coreValue());
    }

    @Test
    public void coreValueReturnsAttributeValueWhenAttributeExists() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("Test", "Value");
        assertEquals("Value", leafNode.coreValue());
    }

    @Test
    public void coreValueSetsAttributeValue() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.coreValue("Value");
        assertEquals("Value", leafNode.attr("Test"));
    }

    @Test
    public void attrReturnsEmptyStringWhenNoAttributesAndKeyNotNodeName() {
        LeafNode leafNode = new TextNode("Test");
        assertEquals("", leafNode.attr("NotTest"));
    }

    @Test
    public void attrReturnsNodeNameWhenNoAttributesAndKeyIsNodeName() {
        LeafNode leafNode = new TextNode("Test");
        assertEquals("Test", leafNode.attr("Test"));
    }

    @Test
    public void attrReturnsAttributeValueWhenAttributesExist() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("Key", "Value");
        assertEquals("Value", leafNode.attr("Key"));
    }

    @Test
    public void attrSetsAttributeValueWhenNoAttributesAndKeyIsNodeName() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("Test", "Value");
        assertEquals("Value", leafNode.attr("Test"));
    }

    @Test
    public void attrSetsAttributeValueWhenAttributesExist() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("Key", "Value");
        leafNode.attr("Key", "NewValue");
        assertEquals("NewValue", leafNode.attr("Key"));
    }

    @Test
    public void hasAttrReturnsFalseWhenNoAttributes() {
        LeafNode leafNode = new TextNode("Test");
        assertFalse(leafNode.hasAttr("key"));
    }

    @Test
    public void hasAttrReturnsTrueWhenAttributeExists() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("key", "value");
        assertTrue(leafNode.hasAttr("key"));
    }

    @Test
    public void removeAttrRemovesAttribute() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("key", "value");
        leafNode.removeAttr("key");
        assertFalse(leafNode.hasAttr("key"));
    }

    @Test
    public void absUrlReturnsEmptyWhenNoAttributes() {
        LeafNode leafNode = new TextNode("Test");
        assertEquals("", leafNode.absUrl("key"));
    }

    @Test
    public void absUrlReturnsUrlWhenAttributeExists() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("key", "http://example.com");
        assertEquals("http://example.com", leafNode.absUrl("key"));
    }

    @Test
    public void baseUriReturnsEmptyWhenNoParent() {
        LeafNode leafNode = new TextNode("Test");
        assertEquals("", leafNode.baseUri());
    }

    @Test
    public void baseUriReturnsParentBaseUriWhenParentExists() {
        LeafNode leafNode = new TextNode("Test");
        Node parent = new Element(Tag.valueOf("div"), "");
        parent.setBaseUri("http://example.com");
        leafNode.setParentNode(parent);
        assertEquals("http://example.com", leafNode.baseUri());
    }

    @Test
    public void doSetBaseUriDoesNotChangeBaseUri() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.doSetBaseUri("http://example.com");
        assertEquals("", leafNode.baseUri());
    }

    @Test
    public void childNodeSizeReturnsZero() {
        LeafNode leafNode = new TextNode("Test");
        assertEquals(0, leafNode.childNodeSize());
    }

    @Test
    public void emptyReturnsSelf() {
        LeafNode leafNode = new TextNode("Test");
        assertSame(leafNode, leafNode.empty());
    }

    @Test
    public void ensureChildNodesReturnsEmptyNodes() {
        LeafNode leafNode = new TextNode("Test");
        assertEquals(Collections.emptyList(), leafNode.ensureChildNodes());
    }

    @Test
    public void doCloneReturnsIdenticalNode() {
        LeafNode leafNode = new TextNode("Test");
        LeafNode clone = leafNode.doClone(leafNode);
        assertEquals(leafNode.outerHtml(), clone.outerHtml());
    }

    @Test
    public void doCloneReturnsNodeWithClonedAttributes() {
        LeafNode leafNode = new TextNode("Test");
        leafNode.attr("key", "value");
        LeafNode clone = leafNode.doClone(leafNode);
        assertEquals(leafNode.attributes(), clone.attributes());
    }
}