package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class NodeCopilotTest {

    @Test
    public void nodeNameReturnsCorrectNameForTextNode() {
        TextNode textNode = new TextNode("Test");
        assertEquals("text", textNode.nodeName());
    }

    @Test
    public void normalNameReturnsCorrectNameForTextNode() {
        TextNode textNode = new TextNode("Test");
        assertEquals("text", textNode.normalName());
    }

    @Test
    public void nodeNameReturnsCorrectNameForElement() {
        Element element = new Element("div");
        assertEquals("div", element.nodeName());
    }

    @Test
    public void normalNameReturnsCorrectNameForElement() {
        Element element = new Element("div");
        assertEquals("div", element.normalName());
    }

    @Test
    public void nodeNameReturnsCorrectNameForComment() {
        Comment comment = new Comment("Test");
        assertEquals("#comment", comment.nodeName());
    }

    @Test
    public void normalNameReturnsCorrectNameForComment() {
        Comment comment = new Comment("Test");
        assertEquals("#comment", comment.normalName());
    }

    @Test
    public void nameIsReturnsTrueForMatchingName() {
        TextNode textNode = new TextNode("Test");
        assertTrue(textNode.nameIs("text"));
    }

    @Test
    public void nameIsReturnsFalseForNonMatchingName() {
        TextNode textNode = new TextNode("Test");
        assertFalse(textNode.nameIs("nonMatchingName"));
    }

    @Test
    public void parentNameIsReturnsTrueForMatchingParentName() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertTrue(child.parentNameIs("div"));
    }

    @Test
    public void parentNameIsReturnsFalseForNonMatchingParentName() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertFalse(child.parentNameIs("nonMatchingName"));
    }

    @Test
    public void parentNameIsReturnsFalseForNullParent() {
        TextNode node = new TextNode("Test");
        assertFalse(node.parentNameIs("div"));
    }

    @Test
    public void parentElementIsReturnsTrueForMatchingParentNameAndNamespace() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertTrue(child.parentElementIs("div", "http://www.w3.org/1999/xhtml"));
    }

    @Test
    public void parentElementIsReturnsFalseForNonMatchingParentName() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertFalse(child.parentElementIs("span", "http://www.w3.org/1999/xhtml"));
    }

    @Test
    public void parentElementIsReturnsFalseForNonMatchingNamespace() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertFalse(child.parentElementIs("div", "http://www.w3.org/2000/svg"));
    }

    @Test
    public void parentElementIsReturnsFalseForNullParent() {
        TextNode node = new TextNode("Test");
        assertFalse(node.parentElementIs("div", "http://www.w3.org/1999/xhtml"));
    }

    @Test
    public void attrReturnsAttributeValueForExistingAttribute() {
        Element element = new Element("div");
        element.attr("id", "test");
        assertEquals("test", element.attr("id"));
    }

    @Test
    public void attrReturnsEmptyStringForNonExistingAttribute() {
        Element element = new Element("div");
        assertEquals("", element.attr("nonExistingAttribute"));
    }

    @Test
    public void attributesReturnsAttributesOfNode() {
        Element element = new Element("div");
        element.attr("id", "test");
        Attributes attributes = element.attributes();
        assertEquals(1, attributes.size());
        assertEquals("test", attributes.get("id"));
    }

    @Test
    public void attributesSizeReturnsCorrectSize() {
        Element element = new Element("div");
        assertEquals(0, element.attributesSize());
        element.attr("id", "test");
        assertEquals(1, element.attributesSize());
    }

    @Test
    public void attrSetsAttributeCorrectly() {
        Element element = new Element("div");
        element.attr("id", "test");
        assertEquals("test", element.attr("id"));
    }

    @Test
    public void hasAttrReturnsTrueForExistingAttribute() {
        Element element = new Element("div");
        element.attr("id", "test");
        assertTrue(element.hasAttr("id"));
    }

    @Test
    public void hasAttrReturnsFalseForNonExistingAttribute() {
        Element element = new Element("div");
        assertFalse(element.hasAttr("id"));
    }

    @Test
    public void removeAttrRemovesAttributeCorrectly() {
        Element element = new Element("div");
        element.attr("id", "test");
        element.removeAttr("id");
        assertFalse(element.hasAttr("id"));
    }

    @Test
    public void clearAttributesRemovesAllAttributes() {
        Element element = new Element("div");
        element.attr("id", "test");
        element.attr("class", "testClass");
        element.clearAttributes();
        assertEquals(0, element.attributesSize());
    }

    @Test
    public void clearAttributesDoesNotThrowOnEmptyAttributes() {
        Element element = new Element("div");
        assertDoesNotThrow(element::clearAttributes);
    }

    @Test
    public void baseUriReturnsEmptyWhenNotDefined() {
        Element element = new Element("div");
        assertEquals("", element.baseUri());
    }

    @Test
    public void setBaseUriUpdatesBaseUri() {
        Element element = new Element("div");
        element.setBaseUri("http://example.com");
        assertEquals("http://example.com", element.baseUri());
    }

    @Test
    public void absUrlReturnsEmptyWhenAttributeMissing() {
        Element element = new Element("div");
        assertEquals("", element.absUrl("href"));
    }

    @Test
    public void absUrlReturnsAbsoluteUrlForRelativeUrl() {
        Element element = new Element("a");
        element.attr("href", "/test");
        element.setBaseUri("http://example.com");
        assertEquals("http://example.com/test", element.absUrl("href"));
    }

    @Test
    public void absUrlReturnsUrlDirectlyForAbsoluteUrl() {
        Element element = new Element("a");
        element.attr("href", "http://example.com/test");
        assertEquals("http://example.com/test", element.absUrl("href"));
    }

    @Test
    public void childNodeReturnsCorrectNode() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        parent.appendChild(child1);
        parent.appendChild(child2);
        assertEquals(child1, parent.childNode(0));
        assertEquals(child2, parent.childNode(1));
    }

    @Test
    public void childNodeThrowsExceptionForInvalidIndex() {
        Element parent = new Element("div");
        assertThrows(IndexOutOfBoundsException.class, () -> parent.childNode(0));
    }

    @Test
    public void childNodesReturnsCorrectList() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        parent.appendChild(child1);
        parent.appendChild(child2);
        List<Node> children = parent.childNodes();
        assertEquals(2, children.size());
        assertTrue(children.contains(child1));
        assertTrue(children.contains(child2));
    }

    @Test
    public void childNodesReturnsEmptyListForNoChildren() {
        Element parent = new Element("div");
        List<Node> children = parent.childNodes();
        assertTrue(children.isEmpty());
    }

    @Test
    public void childNodesCopyReturnsCorrectList() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        parent.appendChild(child1);
        parent.appendChild(child2);
        List<Node> children = parent.childNodesCopy();
        assertEquals(2, children.size());
        assertNotSame(child1, children.get(0));
        assertNotSame(child2, children.get(1));
        assertEquals(child1.outerHtml(), children.get(0).outerHtml());
        assertEquals(child2.outerHtml(), children.get(1).outerHtml());
    }

    @Test
    public void childNodeSizeReturnsCorrectSize() {
        Element parent = new Element("div");
        assertEquals(0, parent.childNodeSize());
        parent.appendChild(new TextNode("Test1"));
        assertEquals(1, parent.childNodeSize());
        parent.appendChild(new TextNode("Test2"));
        assertEquals(2, parent.childNodeSize());
    }

    @Test
    public void emptyRemovesAllChildren() {
        Element parent = new Element("div");
        parent.appendChild(new TextNode("Test1"));
        parent.appendChild(new TextNode("Test2"));
        parent.empty();
        assertEquals(0, parent.childNodeSize());
    }

    @Test
    public void parentNodeReturnsCorrectParent() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertEquals(parent, child.parent());
    }

    @Test
    public void parentNodeReturnsNullForNoParent() {
        TextNode node = new TextNode("Test");
        assertNull(node.parent());
    }

    @Test
    public void rootReturnsSelfForNoParent() {
        TextNode node = new TextNode("Test");
        assertEquals(node, node.root());
    }

    @Test
    public void rootReturnsCorrectRootForNestedNodes() {
        Element root = new Element("div");
        Element child = new Element("span");
        TextNode grandChild = new TextNode("Test");
        child.appendChild(grandChild);
        root.appendChild(child);
        assertEquals(root, grandChild.root());
    }

    @Test
    public void ownerDocumentReturnsCorrectDocument() {
        Document doc = new Document("http://example.com");
        Element el = new Element("div");
        doc.appendChild(el);
        assertEquals(doc, el.ownerDocument());
    }

    @Test
    public void ownerDocumentReturnsNullForNoDocument() {
        Element el = new Element("div");
        assertNull(el.ownerDocument());
    }

    @Test
    public void removeRemovesNodeFromParent() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        child.remove();
        assertTrue(parent.childNodes().isEmpty());
    }

    @Test
    public void removeDoesNotThrowForNoParent() {
        TextNode node = new TextNode("Test");
        assertDoesNotThrow(node::remove);
    }

    @Test
    public void beforeInsertsHtmlBeforeNode() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        child.before("<span>Test</span>");
        assertEquals("span", parent.childNode(0).nodeName());
    }

    @Test
    public void beforeInsertsNodeBeforeNode() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        parent.appendChild(child1);
        child1.before(child2);
        assertEquals(child2, parent.childNode(0));
        assertEquals(child1, parent.childNode(1));
    }

    @Test
    public void afterStringInsertsHtmlAfterNode() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        child.after("<span>Test</span>");
        assertEquals("span", parent.childNode(2).nodeName());
    }

    @Test
    public void afterNodeInsertsNodeAfterNode() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        parent.appendChild(child1);
        child1.after(child2);
        assertEquals(child1, parent.childNode(0));
        assertEquals(child2, parent.childNode(1));
    }

    @Test
    public void wrapWrapsHtmlAroundNode() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        child.wrap("<span></span>");
        assertEquals("span", parent.childNode(0).nodeName());
        assertEquals(child, ((Element) parent.childNode(0)).childNode(0));
    }

    @Test
    public void wrapNoOpWhenHtmlDoesNotStartWithElement() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        child.wrap("<!-- comment -->");
        assertEquals(child, parent.childNode(0));
    }

    @Test
    public void wrapHandlesUnbalancedWrappingHtml() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        child.wrap("<div></div><p></p>");
        assertEquals("div", parent.childNode(0).nodeName());
        assertEquals("p", parent.childNode(1).nodeName());
        assertEquals(child, ((Element) parent.childNode(0)).childNode(0));
    }

    @Test
    public void addChildrenAppendsChildrenToNode() {
        Node parent = new Element("div");
        Node child1 = new TextNode("Test1");
        Node child2 = new TextNode("Test2");
        parent.addChildren(child1, child2);
        assertEquals(2, parent.childNodeSize());
        assertEquals(child1, parent.childNode(0));
        assertEquals(child2, parent.childNode(1));
    }

    @Test
    public void addChildrenAtIndexInsertsChildrenAtCorrectPosition() {
        Node parent = new Element("div");
        Node child1 = new TextNode("Test1");
        Node child2 = new TextNode("Test2");
        Node child3 = new TextNode("Test3");
        parent.addChildren(child1, child3);
        parent.addChildren(1, child2);
        assertEquals(3, parent.childNodeSize());
        assertEquals(child1, parent.childNode(0));
        assertEquals(child2, parent.childNode(1));
        assertEquals(child3, parent.childNode(2));
    }

    @Test
    public void addChildrenAtIndexHandlesEmptyChildren() {
        Node parent = new Element("div");
        parent.addChildren(0);
        assertEquals(0, parent.childNodeSize());
    }

    @Test
    public void reparentChildUpdatesParentOfChild() {
        Node parent = new Element("div");
        Node child = new TextNode("Test");
        parent.reparentChild(child);
        assertEquals(parent, child.parent());
    }

    @Test
    public void siblingNodesReturnsEmptyListForRootNode() {
        Node node = new TextNode("Test");
        assertTrue(node.siblingNodes().isEmpty());
    }

    @Test
    public void siblingNodesReturnsCorrectSiblings() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        TextNode child3 = new TextNode("Test3");
        parent.addChildren(child1, child2, child3);
        List<Node> siblings = child2.siblingNodes();
        assertEquals(2, siblings.size());
        assertTrue(siblings.contains(child1));
        assertTrue(siblings.contains(child3));
    }

    @Test
    public void nextSiblingReturnsNullForLastSibling() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertNull(child.nextSibling());
    }

    @Test
    public void nextSiblingReturnsCorrectSibling() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        parent.addChildren(child1, child2);
        assertEquals(child2, child1.nextSibling());
    }

    @Test
    public void previousSiblingReturnsNullForFirstSibling() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertNull(child.previousSibling());
    }

    @Test
    public void previousSiblingReturnsCorrectSibling() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        parent.addChildren(child1, child2);
        assertEquals(child1, child2.previousSibling());
    }

    @Test
    public void siblingIndexReturnsCorrectIndex() {
        Element parent = new Element("div");
        TextNode child1 = new TextNode("Test1");
        TextNode child2 = new TextNode("Test2");
        parent.addChildren(child1, child2);
        assertEquals(0, child1.siblingIndex());
        assertEquals(1, child2.siblingIndex());
    }

    @Test
    public void setSiblingIndexUpdatesSiblingIndex() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        child.setSiblingIndex(5);
        assertEquals(5, child.siblingIndex());
    }

    @Test
    public void firstChildReturnsNullWhenNoChildren() {
        Node node = new Element("div");
        assertNull(node.firstChild());
    }

    @Test
    public void firstChildReturnsFirstChildNode() {
        Node parent = new Element("div");
        Node child1 = new TextNode("Test1");
        Node child2 = new TextNode("Test2");
        parent.addChildren(child1, child2);
        assertEquals(child1, parent.firstChild());
    }

    @Test
    public void lastChildReturnsNullWhenNoChildren() {
        Node node = new Element("div");
        assertNull(node.lastChild());
    }

    @Test
    public void lastChildReturnsLastChildNode() {
        Node parent = new Element("div");
        Node child1 = new TextNode("Test1");
        Node child2 = new TextNode("Test2");
        parent.addChildren(child1, child2);
        assertEquals(child2, parent.lastChild());
    }

    @Test
    public void outerHtmlReturnsCorrectHtml() {
        Element element = new Element("div");
        element.attr("id", "test");
        assertEquals("<div id=\"test\"></div>", element.outerHtml());
    }

    @Test
    public void outerHtmlHandlesNestedElements() {
        Element parent = new Element("div");
        Element child = new Element("span");
        parent.appendChild(child);
        assertEquals("<div><span></span></div>", parent.outerHtml());
    }

    @Test
    public void outerHtmlHandlesTextNode() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        assertEquals("<div>Test</div>", parent.outerHtml());
    }

    @Test
    public void htmlReturnsCorrectHtml() {
        Element element = new Element("div");
        element.attr("id", "test");
        StringBuilder accum = new StringBuilder();
        element.html(accum);
        assertEquals("<div id=\"test\"></div>", accum.toString());
    }

    @Test
    public void isEffectivelyFirstReturnsTrueForFirstNode() {
        Node node = new TextNode("Test");
        assertTrue(node.isEffectivelyFirst());
    }

    @Test
    public void isEffectivelyFirstReturnsTrueForSecondNodeWhenFirstNodeIsBlank() {
        Node parent = new Element("div");
        Node child1 = new TextNode(" ");
        Node child2 = new TextNode("Test");
        parent.addChildren(child1, child2);
        assertTrue(child2.isEffectivelyFirst());
    }

    @Test
    public void isEffectivelyFirstReturnsFalseForNonFirstNode() {
        Node parent = new Element("div");
        Node child1 = new TextNode("Test1");
        Node child2 = new TextNode("Test2");
        parent.addChildren(child1, child2);
        assertFalse(child2.isEffectivelyFirst());
    }

    @Test
    public void toStringReturnsOuterHtml() {
        Element element = new Element("div");
        element.attr("id", "test");
        assertEquals(element.outerHtml(), element.toString());
    }

    @Test
    public void indentAppendsNewLineAndPadding() throws IOException {
        Element element = new Element("div");
        StringBuilder accum = new StringBuilder();
        element.indent(accum, 2, new Document.OutputSettings().indentAmount(4));
        assertEquals("\n        ", accum.toString());
    }

    @Test
    public void equalsReturnsTrueForSameInstance() {
        Node node = new TextNode("Test");
        assertTrue(node.equals(node));
    }

    @Test
    public void equalsReturnsFalseForDifferentInstance() {
        Node node1 = new TextNode("Test");
        Node node2 = new TextNode("Test");
        assertFalse(node1.equals(node2));
    }

    @Test
    public void hashCodeReturnsSameValueForSameInstance() {
        Node node = new TextNode("Test");
        assertEquals(node.hashCode(), node.hashCode());
    }

    @Test
    public void hasSameValueReturnsTrueForSameContent() {
        Node node1 = new TextNode("Test");
        Node node2 = new TextNode("Test");
        assertTrue(node1.hasSameValue(node2));
    }

    @Test
    public void hasSameValueReturnsFalseForDifferentContent() {
        Node node1 = new TextNode("Test1");
        Node node2 = new TextNode("Test2");
        assertFalse(node1.hasSameValue(node2));
    }

    @Test
    public void cloneCreatesDeepCopyOfNode() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        Node clone = parent.clone();
        assertNotSame(parent, clone);
        assertEquals(parent.outerHtml(), clone.outerHtml());
    }

    @Test
    public void cloneCreatesOrphanWhenParentIsNull() {
        Node node = new TextNode("Test");
        Node clone = node.clone();
        assertNull(clone.parent());
    }

    @Test
    public void clonePreservesSiblingIndexWhenParentIsNull() {
        Node node = new TextNode("Test");
        node.setSiblingIndex(5);
        Node clone = node.clone();
        assertEquals(5, clone.siblingIndex());
    }

    @Test
    public void shallowCloneCreatesCopyWithoutChildren() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        parent.appendChild(child);
        Node clone = parent.shallowClone();
        assertNotSame(parent, clone);
        assertTrue(clone.childNodes().isEmpty());
    }

    @Test
    public void doCloneCreatesCopyWithGivenParent() {
        Element parent = new Element("div");
        TextNode child = new TextNode("Test");
        Node clone = child.doClone(parent);
        assertSame(parent, clone.parent());
    }

    @Test
    public void doCloneCreatesOrphanWhenParentIsNull() {
        Node node = new TextNode("Test");
        Node clone = node.doClone(null);
        assertNull(clone.parent());
    }

    @Test
    public void doClonePreservesSiblingIndexWhenParentIsNull() {
        Node node = new TextNode("Test");
        node.setSiblingIndex(5);
        Node clone = node.doClone(null);
        assertEquals(5, clone.siblingIndex());
    }
}
