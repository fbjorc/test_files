package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class CDataNodeCopilotTest {

    @Test
    public void cDataNodeConstructorSetsText() {
        String text = "sample text";
        CDataNode cDataNode = new CDataNode(text);
        assertEquals(text, cDataNode.text());
    }

    @Test
    public void cDataNodeConstructorHandlesNullText() {
        CDataNode cDataNode = new CDataNode(null);
        assertEquals("", cDataNode.text());
    }

    @Test
    public void cDataNodeConstructorHandlesEmptyText() {
        CDataNode cDataNode = new CDataNode("");
        assertEquals("", cDataNode.text());
    }

    @Test
    public void nodeNameReturnsCorrectValue() {
        CDataNode cDataNode = new CDataNode("data");
        assertEquals("#cdata", cDataNode.nodeName());
    }

    @Test
    public void textReturnsUnencodedNonNormalizedText() {
        String text = "sample text";
        CDataNode cDataNode = new CDataNode(text);
        assertEquals(text, cDataNode.text());
    }

    @Test
    public void outerHtmlHeadAppendsCDataStartAndText() throws IOException {
        String text = "sample text";
        CDataNode cDataNode = new CDataNode(text);
        StringBuilder accum = new StringBuilder();
        cDataNode.outerHtmlHead(accum, 0, new Document.OutputSettings());
        assertEquals("<![CDATA[" + text, accum.toString());
    }

    @Test
    public void outerHtmlTailAppendsCDataEnd() throws IOException {
        CDataNode cDataNode = new CDataNode("data");
        StringBuilder accum = new StringBuilder();
        cDataNode.outerHtmlTail(accum, 0, new Document.OutputSettings());
        assertEquals("]]>", accum.toString());
    }

    @Test
    public void cloneCreatesIdenticalCDataNode() {
        String text = "sample text";
        CDataNode cDataNode = new CDataNode(text);
        CDataNode clone = cDataNode.clone();
        assertEquals(cDataNode.text(), clone.text());
        assertNotSame(cDataNode, clone);
    }

    @Test
    public void cloneCreatesIndependentCDataNode() {
        String text = "sample text";
        CDataNode cDataNode = new CDataNode(text);
        CDataNode clone = cDataNode.clone();
        clone.text("modified text");
        assertNotEquals(cDataNode.text(), clone.text());
    }
}
