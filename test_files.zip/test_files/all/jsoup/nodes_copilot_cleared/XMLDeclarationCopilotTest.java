package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class XMLDeclarationCopilotTest {
	
    @Test
    public void nodeNameReturnsDeclaration() {
        XmlDeclaration declaration = new XmlDeclaration("xml", true);
        assertEquals("#declaration", declaration.nodeName());
    }

    @Test
    public void getWholeDeclarationReturnsCorrectDeclaration() {
        XmlDeclaration declaration = new XmlDeclaration("xml", true);
        declaration.attr("version", "1.0");
        assertEquals("<!?xml version=\"1.0\"!>", declaration.getWholeDeclaration());
    }

    @Test
    public void getWholeDeclarationHandlesEmptyAttributes() {
        XmlDeclaration declaration = new XmlDeclaration("xml", true);
        declaration.attr("version", "");
        assertEquals("<!?xml version!>", declaration.getWholeDeclaration());
    }
}
