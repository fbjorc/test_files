package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class DataNodeCopilotTest {

    @Test
    public void dataNodeConstructorSetsData() {
        String data = "sample data";
        DataNode dataNode = new DataNode(data);
        assertEquals(data, dataNode.getWholeData());
    }

    @Test
    public void dataNodeConstructorHandlesNullData() {
        DataNode dataNode = new DataNode(null);
        assertEquals("", dataNode.getWholeData());
    }

    @Test
    public void nodeNameReturnsCorrectValue() {
        DataNode dataNode = new DataNode("data");
        assertEquals("#data", dataNode.nodeName());
    }

    @Test
    public void getWholeDataReturnsDataContent() {
        String data = "sample data";
        DataNode dataNode = new DataNode(data);
        assertEquals(data, dataNode.getWholeData());
    }

    @Test
    public void setWholeDataChangesDataContent() {
        String initialData = "initial data";
        String newData = "new data";
        DataNode dataNode = new DataNode(initialData);
        dataNode.setWholeData(newData);
        assertEquals(newData, dataNode.getWholeData());
    }

    @Test
    public void setWholeDataHandlesNullInput() {
        String initialData = "initial data";
        DataNode dataNode = new DataNode(initialData);
        dataNode.setWholeData(null);
        assertEquals("", dataNode.getWholeData());
    }

    @Test
    public void outerHtmlHeadAppendsDataInXmlSyntax() throws IOException {
        String data = "sample data";
        DataNode dataNode = new DataNode(data);
        StringBuilder accum = new StringBuilder();
        dataNode.outerHtmlHead(accum, 0, new Document.OutputSettings().syntax(Document.OutputSettings.Syntax.xml));
        assertTrue(accum.toString().contains("<![CDATA[" + data + "]]>"));
    }

    @Test
    public void outerHtmlHeadAppendsDataInHtmlSyntax() throws IOException {
        String data = "sample data";
        DataNode dataNode = new DataNode(data);
        StringBuilder accum = new StringBuilder();
        dataNode.outerHtmlHead(accum, 0, new Document.OutputSettings().syntax(Document.OutputSettings.Syntax.html));
        assertEquals(data, accum.toString());
    }

    @Test
    public void outerHtmlTailDoesNotModifyAccumulator() throws IOException {
        StringBuilder accum = new StringBuilder("initial content");
        DataNode dataNode = new DataNode("data");
        dataNode.outerHtmlTail(accum, 0, new Document.OutputSettings());
        assertEquals("initial content", accum.toString());
    }

    @Test
    public void toStringReturnsOuterHtml() {
        String data = "sample data";
        DataNode dataNode = new DataNode(data);
        assertEquals(dataNode.outerHtml(), dataNode.toString());
    }

    @Test
    public void cloneCreatesIdenticalDataNode() {
        String data = "sample data";
        DataNode dataNode = new DataNode(data);
        DataNode clone = dataNode.clone();
        assertEquals(dataNode.getWholeData(), clone.getWholeData());
        assertNotSame(dataNode, clone);
    }

    @Test
    public void cloneCreatesIndependentDataNode() {
        String data = "sample data";
        DataNode dataNode = new DataNode(data);
        DataNode clone = dataNode.clone();
        clone.setWholeData("modified data");
        assertNotEquals(dataNode.getWholeData(), clone.getWholeData());
    }
}
