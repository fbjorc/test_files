package org.jsoup.nodes;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.parser.ParseSettings;
import org.jsoup.parser.Parser;
import org.jsoup.parser.Tag;
import org.junit.jupiter.api.Test;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DocumentCopilotTest {

    @Test
    public void documentConstructorSetsBaseUri() {
        String baseUri = "http://example.com";
        Document document = new Document(baseUri);
        assertEquals(baseUri, document.baseUri());
    }

    @Test
    public void documentConstructorSetsHtmlNamespace() {
        String baseUri = "http://example.com";
        Document document = new Document(baseUri);
        assertEquals("html", document.tagName());
    }

    @Test
    public void createShellCreatesDocumentWithHtmlHeadBody() {
        String baseUri = "http://example.com";
        Document document = Document.createShell(baseUri);
        assertNotNull(document.selectFirst("html"));
        assertNotNull(document.selectFirst("head"));
        assertNotNull(document.selectFirst("body"));
    }

    @Test
    public void createShellSetsBaseUri() {
        String baseUri = "http://example.com";
        Document document = Document.createShell(baseUri);
        assertEquals(baseUri, document.baseUri());
    }

    @Test
    public void documentConstructorWithNamespaceSetsBaseUri() {
        String baseUri = "http://example.com";
        Document document = new Document("html", baseUri);
        assertEquals(baseUri, document.baseUri());
    }

    @Test
    public void documentConstructorWithNamespaceSetsNamespace() {
        String baseUri = "http://example.com";
        Document document = new Document("html", baseUri);
        assertEquals("html", document.tagName());
    }

    @Test
    public void locationReturnsCorrectLocation() {
        String baseUri = "http://example.com";
        Document document = new Document(baseUri);
        assertEquals(baseUri, document.location());
    }

    @Test
    public void connectionReturnsNewSessionIfNotSet() {
        Document document = new Document("http://example.com");
        Connection connection = document.connection();
        assertNotNull(connection);
        // Further assertions can be made if you know the expected state of a new Connection
    }

    @Test
    public void connectionReturnsExistingSessionIfSet() {
        Document document = new Document("http://example.com");
        Connection existingConnection = Jsoup.newSession();
        document.connection(existingConnection);
        Connection returnedConnection = document.connection();
        assertSame(existingConnection, returnedConnection);
    }

    @Test
    public void documentTypeReturnsNullIfNotSet() {
        Document document = new Document("http://example.com");
        assertNull(document.documentType());
    }

    @Test
    public void headReturnsExistingHeadElement() {
        Document document = new Document("http://example.com");
        document.appendElement("html").appendElement("head");
        assertNotNull(document.head());
        assertEquals("head", document.head().tagName());
    }

    @Test
    public void headCreatesNewHeadElementIfNotExists() {
        Document document = new Document("http://example.com");
        document.appendElement("html");
        assertNotNull(document.head());
        assertEquals("head", document.head().tagName());
    }

    @Test
    public void bodyReturnsExistingBodyElement() {
        Document document = new Document("http://example.com");
        document.appendElement("html").appendElement("body");
        assertNotNull(document.body());
        assertEquals("body", document.body().tagName());
    }

    @Test
    public void bodyReturnsExistingFramesetElement() {
        Document document = new Document("http://example.com");
        document.appendElement("html").appendElement("frameset");
        assertNotNull(document.body());
        assertEquals("frameset", document.body().tagName());
    }

    @Test
    public void bodyCreatesNewBodyElementIfNotExists() {
        Document document = new Document("http://example.com");
        document.appendElement("html");
        assertNotNull(document.body());
        assertEquals("body", document.body().tagName());
    }

    @Test
    public void formsReturnsAllFormElements() {
        Document document = Jsoup.parse("<form id='form1'></form><div><form id='form2'></form></div>");
        List<FormElement> forms = document.forms();
        assertEquals(2, forms.size());
        assertEquals("form1", forms.get(0).id());
        assertEquals("form2", forms.get(1).id());
    }

    @Test
    public void formsReturnsEmptyListIfNoForm() {
        Document document = Jsoup.parse("<div>No form here</div>");
        List<FormElement> forms = document.forms();
        assertTrue(forms.isEmpty());
    }

    @Test
    public void expectFormReturnsFirstMatchingForm() {
        Document document = Jsoup.parse("<form id='form1'></form><div><form id='form2'></form></div>");
        FormElement form = document.expectForm("#form2");
        assertNotNull(form);
        assertEquals("form2", form.id());
    }

    @Test
    public void expectFormThrowsExceptionIfNoMatch() {
        Document document = Jsoup.parse("<form id='form1'></form><div><form id='form2'></form></div>");
        assertThrows(IllegalArgumentException.class, () -> document.expectForm("#form3"));
    }

    @Test
    public void titleReturnsEmptyWhenNoTitleElement() {
        Document document = new Document("http://example.com");
        assertEquals("", document.title());
    }

    @Test
    public void titleReturnsTitleTextNormalized() {
        Document document = new Document("http://example.com");
        document.head().appendElement("title").text("   My Title   ");
        assertEquals("My Title", document.title());
    }

    @Test
    public void titleReturnsTitleTextWithMultipleSpacesNormalized() {
        Document document = new Document("http://example.com");
        document.head().appendElement("title").text("My   Title");
        assertEquals("My Title", document.title());
    }

    @Test
    public void titleSetsNewTitleWhenTitleElementDoesNotExist() {
        Document document = new Document("http://example.com");
        String title = "New Title";
        document.title(title);
        assertEquals(title, document.title());
    }

    @Test
    public void titleUpdatesExistingTitleWhenTitleElementExists() {
        Document document = new Document("http://example.com");
        String initialTitle = "Initial Title";
        document.title(initialTitle);
        String newTitle = "New Title";
        document.title(newTitle);
        assertEquals(newTitle, document.title());
    }

    @Test
    public void createElementCreatesNewElementWithDocumentBaseUri() {
        Document document = new Document("http://example.com");
        String tagName = "div";
        Element element = document.createElement(tagName);
        assertEquals(tagName, element.tagName());
        assertEquals(document.baseUri(), element.baseUri());
    }

    @Test
    public void outerHtmlReturnsHtmlWithoutOuterWrapperTag() {
        Document document = new Document("http://example.com");
        String html = "<html><head><title>Test</title></head><body>Body content</body></html>";
        document.html(html);
        assertEquals(html, document.outerHtml());
    }

    @Test
    public void textSetsBodyText() {
        Document document = new Document("http://example.com");
        String text = "New Body Text";
        document.text(text);
        assertEquals(text, document.body().text());
    }

    @Test
    public void textClearsExistingBodyText() {
        Document document = new Document("http://example.com");
        document.body().text("Existing Body Text");
        document.text("New Body Text");
        assertEquals("New Body Text", document.body().text());
    }

    @Test
    public void textHandlesNullInput() {
        Document document = new Document("http://example.com");
        document.text(null);
        assertEquals("", document.body().text());
    }

    @Test
    public void nodeNameReturnsDocument() {
        Document document = new Document("http://example.com");
        assertEquals("#document", document.nodeName());
    }

    @Test
    public void charsetSetsCharsetAndUpdatesMetaCharsetElement() {
        Document document = new Document("http://example.com");
        Charset charset = Charset.forName("ISO-8859-1");
        document.charset(charset);
        assertEquals(charset, document.charset());
    }

    @Test
    public void charsetReturnsCurrentCharset() {
        Document document = new Document("http://example.com");
        Charset charset = Charset.forName("UTF-8");
        assertEquals(charset, document.charset());
    }

    @Test
    public void updateMetaCharsetElementSetsUpdateFlag() {
        Document document = new Document("http://example.com");
        document.updateMetaCharsetElement(true);
        Charset charset = Charset.forName("ISO-8859-1");
        document.charset(charset);
        assertEquals(charset, document.charset());
    }

    @Test
    public void updateMetaCharsetElementDoesNotUpdateCharsetWhenFlagIsFalse() {
        Document document = new Document("http://example.com");
        document.updateMetaCharsetElement(false);
        Charset initialCharset = document.charset();
        Charset newCharset = Charset.forName("ISO-8859-1");
        document.charset(newCharset);
        assertEquals(initialCharset, document.charset());
    }

    @Test
    public void cloneReturnsNewDocumentWithSameValues() {
        Document document = new Document("http://example.com");
        Document clonedDocument = document.clone();

        assertNotSame(document, clonedDocument);
        assertEquals(document.baseUri(), clonedDocument.baseUri());
        assertEquals(document.outputSettings(), clonedDocument.outputSettings());
    }

    @Test
    public void cloneReturnsNewDocumentWithDifferentOutputSettingsInstance() {
        Document document = new Document("http://example.com");
        Document clonedDocument = document.clone();

        assertNotSame(document.outputSettings(), clonedDocument.outputSettings());
    }

    @Test
    public void shallowCloneReturnsNewDocumentWithSameValues() {
        Document document = new Document("http://example.com");
        Document shallowClonedDocument = document.shallowClone();

        assertNotSame(document, shallowClonedDocument);
        assertEquals(document.baseUri(), shallowClonedDocument.baseUri());
        assertEquals(document.outputSettings(), shallowClonedDocument.outputSettings());
    }

    @Test
    public void shallowCloneReturnsNewDocumentWithDifferentOutputSettingsInstance() {
        Document document = new Document("http://example.com");
        Document shallowClonedDocument = document.shallowClone();

        assertNotSame(document.outputSettings(), shallowClonedDocument.outputSettings());
    }

    @Test
    public void escapeModeReturnsBaseAsDefault() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertEquals(Entities.EscapeMode.base, outputSettings.escapeMode());
    }

    @Test
    public void escapeModeCanBeChanged() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.escapeMode(Entities.EscapeMode.extended);
        assertEquals(Entities.EscapeMode.extended, outputSettings.escapeMode());
    }

    @Test
    public void defaultCharsetIsUtf8() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertEquals(Charset.forName("UTF-8"), outputSettings.charset());
    }

    @Test
    public void charsetCanBeChanged() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        Charset isoCharset = Charset.forName("ISO-8859-1");
        outputSettings.charset(isoCharset);
        assertEquals(isoCharset, outputSettings.charset());
    }

    @Test
    public void defaultSyntaxIsHtml() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertEquals(Document.OutputSettings.Syntax.html, outputSettings.syntax());
    }

    @Test
    public void syntaxCanBeChangedToXml() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.syntax(Document.OutputSettings.Syntax.xml);
        assertEquals(Document.OutputSettings.Syntax.xml, outputSettings.syntax());
    }

    @Test
    public void escapeModeChangesEscapeMode() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.escapeMode(Entities.EscapeMode.extended);
        assertEquals(Entities.EscapeMode.extended, outputSettings.escapeMode());
    }

    @Test
    public void charsetHandlesUnsupportedCharset() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        String charsetName = "unsupported-charset";
        assertThrows(IllegalArgumentException.class, () -> outputSettings.charset(charsetName));
    }

    @Test
    public void prepareEncoderReturnsNonNullEncoder() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertNotNull(outputSettings.prepareEncoder());
    }

    @Test
    public void prepareEncoderSetsEncoderInThreadLocal() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.prepareEncoder();
        assertNotNull(outputSettings.encoder());
    }

    @Test
    public void encoderReturnsExistingEncoder() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.prepareEncoder();
        CharsetEncoder firstEncoder = outputSettings.encoder();
        CharsetEncoder secondEncoder = outputSettings.encoder();
        assertSame(firstEncoder, secondEncoder);
    }

    @Test
    public void encoderPreparesNewEncoderIfNotSet() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertNotNull(outputSettings.encoder());
    }

    @Test
    public void syntaxReturnsCurrentSyntax() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertEquals(Document.OutputSettings.Syntax.html, outputSettings.syntax());
    }

    @Test
    public void syntaxCanBeChanged() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.syntax(Document.OutputSettings.Syntax.xml);
        assertEquals(Document.OutputSettings.Syntax.xml, outputSettings.syntax());
    }

    @Test
    public void syntaxSetsHtmlSyntax() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.syntax(Document.OutputSettings.Syntax.html);
        assertEquals(Document.OutputSettings.Syntax.html, outputSettings.syntax());
    }

    @Test
    public void syntaxSetsXmlSyntaxAndEscapeModeToXhtml() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.syntax(Document.OutputSettings.Syntax.xml);
        assertEquals(Document.OutputSettings.Syntax.xml, outputSettings.syntax());
        assertEquals(Entities.EscapeMode.xhtml, outputSettings.escapeMode());
    }

    @Test
    public void prettyPrintReturnsTrueByDefault() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertTrue(outputSettings.prettyPrint());
    }

    @Test
    public void prettyPrintCanBeDisabled() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.prettyPrint(false);
        assertFalse(outputSettings.prettyPrint());
    }

    @Test
    public void prettyPrintCanBeEnabled() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.prettyPrint(false);
        outputSettings.prettyPrint(true);
        assertTrue(outputSettings.prettyPrint());
    }

    @Test
    public void outlineReturnsFalseByDefault() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertFalse(outputSettings.outline());
    }

    @Test
    public void outlineCanBeEnabled() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.outline(true);
        assertTrue(outputSettings.outline());
    }

    @Test
    public void outlineCanBeDisabled() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.outline(true);
        outputSettings.outline(false);
        assertFalse(outputSettings.outline());
    }

    @Test
    public void indentAmountReturnsOneByDefault() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertEquals(1, outputSettings.indentAmount());
    }

    @Test
    public void indentAmountCanBeChanged() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.indentAmount(3);
        assertEquals(3, outputSettings.indentAmount());
    }

    @Test
    public void indentAmountCannotBeNegative() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertThrows(IllegalArgumentException.class, () -> outputSettings.indentAmount(-1));
    }

    @Test
    public void indentAmountSetsPositiveValue() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.indentAmount(5);
        assertEquals(5, outputSettings.indentAmount());
    }

    @Test
    public void indentAmountThrowsExceptionForNegativeValue() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertThrows(IllegalArgumentException.class, () -> outputSettings.indentAmount(-1));
    }

    @Test
    public void maxPaddingWidthSetsPositiveValue() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.maxPaddingWidth(10);
        assertEquals(10, outputSettings.maxPaddingWidth());
    }

    @Test
    public void maxPaddingWidthSetsNegativeOne() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.maxPaddingWidth(-1);
        assertEquals(-1, outputSettings.maxPaddingWidth());
    }

    @Test
    public void maxPaddingWidthThrowsExceptionForValuesLessThanNegativeOne() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        assertThrows(IllegalArgumentException.class, () -> outputSettings.maxPaddingWidth(-2));
    }

    @Test
    public void cloneReturnsNewOutputSettingsWithSameValues() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.charset("ISO-8859-1");
        outputSettings.escapeMode(Entities.EscapeMode.extended);
        outputSettings.indentAmount(3);
        outputSettings.prettyPrint(false);
        outputSettings.outline(true);
        outputSettings.maxPaddingWidth(5);

        Document.OutputSettings clonedSettings = outputSettings.clone();

        assertNotSame(outputSettings, clonedSettings);
        assertEquals(outputSettings.charset(), clonedSettings.charset());
        assertEquals(outputSettings.escapeMode(), clonedSettings.escapeMode());
        assertEquals(outputSettings.indentAmount(), clonedSettings.indentAmount());
        assertEquals(outputSettings.prettyPrint(), clonedSettings.prettyPrint());
        assertEquals(outputSettings.outline(), clonedSettings.outline());
        assertEquals(outputSettings.maxPaddingWidth(), clonedSettings.maxPaddingWidth());
    }

    @Test
    public void cloneReturnsNewOutputSettingsWithDifferentCharsetEncoder() {
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        outputSettings.charset("ISO-8859-1");

        Document.OutputSettings clonedSettings = outputSettings.clone();

        assertNotSame(outputSettings.encoder(), clonedSettings.encoder());
    }

    @Test
    public void outputSettingsReturnsNotNull() {
        Document document = new Document("http://example.com");
        assertNotNull(document.outputSettings());
    }

    @Test
    public void outputSettingsReturnsCorrectInstance() {
        Document document = new Document("http://example.com");
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        document.outputSettings(outputSettings);
        assertSame(outputSettings, document.outputSettings());
    }

    @Test
    public void outputSettingsSetsNewOutputSettings() {
        Document document = new Document("http://example.com");
        Document.OutputSettings outputSettings = new Document.OutputSettings();
        document.outputSettings(outputSettings);
        assertSame(outputSettings, document.outputSettings());
    }

    @Test
    public void outputSettingsThrowsExceptionForNull() {
        Document document = new Document("http://example.com");
        assertThrows(IllegalArgumentException.class, () -> document.outputSettings(null));
    }

    @Test
    public void quirksModeReturnsNoQuirksByDefault() {
        Document document = new Document("http://example.com");
        assertEquals(Document.QuirksMode.noQuirks, document.quirksMode());
    }

    @Test
    public void quirksModeCanBeChangedToQuirks() {
        Document document = new Document("http://example.com");
        document.quirksMode(Document.QuirksMode.quirks);
        assertEquals(Document.QuirksMode.quirks, document.quirksMode());
    }

    @Test
    public void quirksModeCanBeChangedToLimitedQuirks() {
        Document document = new Document("http://example.com");
        document.quirksMode(Document.QuirksMode.limitedQuirks);
        assertEquals(Document.QuirksMode.limitedQuirks, document.quirksMode());
    }

    @Test
    public void parserReturnsHtmlParserByDefault() {
        Document document = new Document("http://example.com");
        assertTrue(document.parser() instanceof Parser);
    }

    @Test
    public void parserThrowsExceptionForNull() {
        Document document = new Document("http://example.com");
        assertThrows(IllegalArgumentException.class, () -> document.parser(null));
    }

    @Test
    public void connectionSetsNewConnection() {
        Document document = new Document("http://example.com");
        Connection connection = Jsoup.newSession();
        document.connection(connection);
        assertSame(connection, document.connection());
    }

    @Test
    public void connectionThrowsExceptionForNull() {
        Document document = new Document("http://example.com");
        assertThrows(IllegalArgumentException.class, () -> document.connection(null));
    }
}
