package org.jsoup.nodes;

import org.jsoup.nodes.Document.OutputSettings.Syntax;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AttributeCopilotTest {

    @Test
    public void shouldCreateAttributeWithNonNullKey() {
        Attribute attribute = new Attribute("key", "value");
        assertEquals("key", attribute.getKey());
        assertEquals("value", attribute.getValue());
    }

    @Test
    public void shouldCreateAttributeWithNullValue() {
        Attribute attribute = new Attribute("key", null);
        assertEquals("key", attribute.getKey());
        assertNull(attribute.getValue());
    }

    @Test
    public void shouldCreateAttributeWithParent() {
        Attributes parent = new Attributes();
        Attribute attribute = new Attribute("key", "value", parent);
        assertEquals("key", attribute.getKey());
        assertEquals("value", attribute.getValue());
    }

    @Test
    public void shouldTrimKey() {
        Attribute attribute = new Attribute(" key ", "value");
        assertEquals("key", attribute.getKey());
    }

    @Test
    public void shouldReturnKey() {
        Attribute attribute = new Attribute("key", "value");
        assertEquals("key", attribute.getKey());
    }

    @Test
    public void shouldSetKey() {
        Attribute attribute = new Attribute("key", "value");
        attribute.setKey("newKey");
        assertEquals("newKey", attribute.getKey());
    }

    @Test
    public void shouldThrowExceptionForNullKey() {
        Attribute attribute = new Attribute("key", "value");
        assertThrows(IllegalArgumentException.class, () -> attribute.setKey(null));
    }

    @Test
    public void shouldThrowExceptionForEmptyKey() {
        Attribute attribute = new Attribute("key", "value");
        assertThrows(IllegalArgumentException.class, () -> attribute.setKey(" "));
    }

    @Test
    public void shouldUpdateParentKeysWhenKeySet() {
        Attributes parent = new Attributes();
        Attribute attribute = new Attribute("key", "value", parent);
        attribute.setKey("newKey");
        assertTrue(parent.hasKey("newKey"));
    }

    @Test
    public void returnsValueWhenNotNull() {
        Attribute attribute = new Attribute("key", "value");
        assertEquals("value", attribute.getValue());
    }

    @Test
    public void returnsEmptyStringWhenValueIsNull() {
        Attribute attribute = new Attribute("key", null);
        assertEquals("", attribute.getValue());
    }

    @Test
    public void returnsTrueWhenValueIsDeclared() {
        Attribute attribute = new Attribute("key", "value");
        assertTrue(attribute.hasDeclaredValue());
    }

    @Test
    public void returnsFalseWhenValueIsNotDeclared() {
        Attribute attribute = new Attribute("key", null);
        assertFalse(attribute.hasDeclaredValue());
    }

    @Test
    public void setsValueWhenParentIsNull() {
        Attribute attribute = new Attribute("key", "oldValue");
        String oldValue = attribute.setValue("newValue");
        assertEquals("oldValue", oldValue);
        assertEquals("newValue", attribute.getValue());
    }

    @Test
    public void setsValueWhenParentIsNotNull() {
        Attributes parent = new Attributes();
        Attribute attribute = new Attribute("key", "oldValue", parent);
        parent.put(attribute);
        String oldValue = attribute.setValue("newValue");
        assertEquals("oldValue", oldValue);
        assertEquals("newValue", attribute.getValue());
    }

    @Test
    public void returnsHtmlRepresentation() {
        Attribute attribute = new Attribute("key", "value");
        String html = attribute.html();
        assertEquals("key=\"value\"", html);
    }

    @Test
    public void returnsHtmlRepresentationWhenValueIsNull() {
        Attribute attribute = new Attribute("key", null);
        String html = attribute.html();
        assertEquals("key=\"\"", html);
    }

    @Test
    public void returnsUntrackedWhenParentIsNull() {
        Attribute attribute = new Attribute("key", "value");
        assertEquals(Range.AttributeRange.UntrackedAttr, attribute.sourceRange());
    }

    @Test
    public void returnsSourceRangeWhenParentIsNotNull() {
        Attributes parent = new Attributes();
        Attribute attribute = new Attribute("key", "value", parent);
        parent.put(attribute);
        assertNotNull(attribute.sourceRange());
    }

    @Test
    public void htmlRepresentationWhenKeyIsValid() {
        Attribute attribute = new Attribute("key", "value");
        assertNotNull(attribute.html());
    }

    @Test
    public void htmlRepresentationWhenKeyIsInvalid() {
        Attribute attribute = new Attribute(" ", "value");
        assertEquals("", attribute.html());
    }

    @Test
    public void returnsValidKeyWhenSyntaxIsXmlAndKeyIsValid() {
        String key = Attribute.getValidKey("validKey", Syntax.xml);
        assertEquals("validKey", key);
    }

    @Test
    public void returnsNullWhenSyntaxIsXmlAndKeyIsInvalid() {
        String key = Attribute.getValidKey("invalid key", Syntax.xml);
        assertNull(key);
    }

    @Test
    public void returnsValidKeyWhenSyntaxIsHtmlAndKeyIsValid() {
        String key = Attribute.getValidKey("validKey", Syntax.html);
        assertEquals("validKey", key);
    }

    @Test
    public void returnsNullWhenSyntaxIsHtmlAndKeyIsInvalid() {
        String key = Attribute.getValidKey("invalid key", Syntax.html);
        assertNull(key);
    }

    @Test
    public void returnsHtmlRepresentationWhenToStringIsCalled() {
        Attribute attribute = new Attribute("key", "value");
        assertEquals(attribute.html(), attribute.toString());
    }

    @Test
    public void createsAttributeFromEncodedKeyAndValue() {
        Attribute attribute = Attribute.createFromEncoded("key", "value&amp;");
        assertEquals("key", attribute.getKey());
        assertEquals("value&", attribute.getValue());
    }

    @Test
    public void returnsTrueWhenKeyIsDataAttribute() {
        Attribute attribute = new Attribute("data-test", "value");
        assertTrue(attribute.isDataAttribute());
    }

    @Test
    public void returnsFalseWhenKeyIsNotDataAttribute() {
        Attribute attribute = new Attribute("key", "value");
        assertFalse(attribute.isDataAttribute());
    }

    @Test
    public void staticMethodReturnsTrueWhenKeyIsDataAttribute() {
        assertTrue(Attribute.isDataAttribute("data-test"));
    }

    @Test
    public void staticMethodReturnsFalseWhenKeyIsNotDataAttribute() {
        assertFalse(Attribute.isDataAttribute("key"));
    }

    @Test
    public void collapsesAttributeWhenSyntaxIsHtmlAndValueIsNull() {
        Document.OutputSettings out = new Document.OutputSettings();
        out.syntax(Syntax.html);
        assertTrue(Attribute.shouldCollapseAttribute("checked", null, out));
    }

    @Test
    public void collapsesAttributeWhenSyntaxIsHtmlAndValueIsEmpty() {
        Document.OutputSettings out = new Document.OutputSettings();
        out.syntax(Syntax.html);
        assertTrue(Attribute.shouldCollapseAttribute("checked", "", out));
    }

    @Test
    public void collapsesAttributeWhenSyntaxIsHtmlAndValueIsSameAsKey() {
        Document.OutputSettings out = new Document.OutputSettings();
        out.syntax(Syntax.html);
        assertTrue(Attribute.shouldCollapseAttribute("checked", "checked", out));
    }

    @Test
    public void doesNotCollapseAttributeWhenSyntaxIsHtmlAndValueIsDifferentFromKey() {
        Document.OutputSettings out = new Document.OutputSettings();
        out.syntax(Syntax.html);
        assertFalse(Attribute.shouldCollapseAttribute("checked", "unchecked", out));
    }

    @Test
    public void doesNotCollapseAttributeWhenSyntaxIsXml() {
        Document.OutputSettings out = new Document.OutputSettings();
        out.syntax(Syntax.xml);
        assertFalse(Attribute.shouldCollapseAttribute("checked", "checked", out));
    }

    @Test
    public void identifiesBooleanAttribute() {
        assertTrue(Attribute.isBooleanAttribute("checked"));
    }

    @Test
    public void doesNotIdentifyNonBooleanAttribute() {
        assertFalse(Attribute.isBooleanAttribute("href"));
    }

    @Test
    public void equalsReturnsTrueWhenBothAttributesAreIdentical() {
        Attribute attribute1 = new Attribute("key", "value");
        Attribute attribute2 = new Attribute("key", "value");
        assertTrue(attribute1.equals(attribute2));
    }

    @Test
    public void equalsReturnsFalseWhenKeysAreDifferent() {
        Attribute attribute1 = new Attribute("key1", "value");
        Attribute attribute2 = new Attribute("key2", "value");
        assertFalse(attribute1.equals(attribute2));
    }

    @Test
    public void equalsReturnsFalseWhenValuesAreDifferent() {
        Attribute attribute1 = new Attribute("key", "value1");
        Attribute attribute2 = new Attribute("key", "value2");
        assertFalse(attribute1.equals(attribute2));
    }

    @Test
    public void hashCodeIsConsistent() {
        Attribute attribute = new Attribute("key", "value");
        int initialHashCode = attribute.hashCode();
        attribute.setKey("newKey");
        attribute.setValue("newValue");
        assertEquals(initialHashCode, attribute.hashCode());
    }

    @Test
    public void cloneCreatesIdenticalAttribute() {
        Attribute attribute = new Attribute("key", "value");
        Attribute clonedAttribute = attribute.clone();
        assertTrue(attribute.equals(clonedAttribute));
        assertNotSame(attribute, clonedAttribute);
    }
}
