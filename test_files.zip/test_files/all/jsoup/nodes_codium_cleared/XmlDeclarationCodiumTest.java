package org.jsoup.nodes;

import org.jsoup.SerializationException;
import org.jsoup.helper.ValidationException;
import org.jsoup.nodes.XmlDeclaration;

import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;

public class XmlDeclarationCodiumTest {

    // Check behavior when name is null and expect a ValidationException
    @Test
    public void test_null_name_throws_exception() {
        assertThrows(ValidationException.class, () -> {
            new XmlDeclaration(null, false);
        });
    }

    // Verify that the method returns the string '#declaration'
    @Test
    public void test_returns_declaration() {
        XmlDeclaration xmlDeclaration = new XmlDeclaration("doc", true);
        assertEquals("#declaration", xmlDeclaration.nodeName());
    }

    // Test the method with an instance of XmlDeclaration initialized with various names and boolean flags
    @Test
    public void test_various_initializations() {
        XmlDeclaration xmlDeclaration1 = new XmlDeclaration("root", false);
        assertEquals("#declaration", xmlDeclaration1.nodeName());
        XmlDeclaration xmlDeclaration2 = new XmlDeclaration("xml", true);
        assertEquals("#declaration", xmlDeclaration2.nodeName());
        XmlDeclaration xmlDeclaration3 = new XmlDeclaration("data", false);
        assertEquals("#declaration", xmlDeclaration3.nodeName());
    }

    // Invoke the method on a newly created but uninitialized XmlDeclaration object if possible
    @Test
    public void test_uninitialized_instance() {
        XmlDeclaration xmlDeclaration = new XmlDeclaration(null, true);
        assertEquals("#declaration", xmlDeclaration.nodeName());
    }

    // method returns the correct name of the XML declaration
    @Test
    public void test_returns_correct_name() {
        XmlDeclaration xmlDecl = new XmlDeclaration("xml", false);
        assertEquals("xml", xmlDecl.name());
    }

    // method returns an empty string if the declaration name is set to an empty string
    @Test
    public void test_returns_empty_string_for_empty_name() {
        XmlDeclaration xmlDecl = new XmlDeclaration("", false);
        assertEquals("", xmlDecl.name());
    }

    // method handles null gracefully if the core value somehow becomes null
    @Test
    public void test_handles_null_gracefully() {
        XmlDeclaration xmlDecl = new XmlDeclaration(null, false);
        assertNull(xmlDecl.name());
    }

    // method returns a trimmed string representation of the XML declaration
    @Test
    public void test_returns_trimmed_xml_declaration() {
        XmlDeclaration declaration = new XmlDeclaration("xml", false);
        String result = declaration.getWholeDeclaration();
        assertNotNull(result);
        assertEquals(result, result.trim());
    }

    // toString returns the XML declaration as a string
    @Test
    public void test_returns_xml_declaration() {
        XmlDeclaration xmlDecl = new XmlDeclaration("xml", false);
        String expected = "<?xml>";
        assertEquals(expected, xmlDecl.toString());
    }

    // toString handles empty attributes correctly
    @Test
    public void test_handles_empty_attributes() {
        XmlDeclaration xmlDecl = new XmlDeclaration("xml", false);
        xmlDecl.attr("version", "");
        String expected = "<?xml version=\"\">";
        assertEquals(expected, xmlDecl.toString());
    }

    // toString handles declarations with no attributes
    @Test
    public void test_handles_no_attributes() {
        XmlDeclaration xmlDecl = new XmlDeclaration("xml", false);
        String expected = "<?xml>";
        assertEquals(expected, xmlDecl.toString());
    }

    // clone should create a new XmlDeclaration object
    @Test
    public void test_clone_creates_new_object() {
        XmlDeclaration original = new XmlDeclaration("xml", false);
        XmlDeclaration cloned = original.clone();
        assertNotNull(cloned);
        assertNotSame(original, cloned);
    }

    // cloning an XmlDeclaration with no attributes should succeed
    @Test
    public void test_clone_with_no_attributes() {
        XmlDeclaration original = new XmlDeclaration("xml", false);
        XmlDeclaration cloned = original.clone();
        assertEquals(0, cloned.attributes().size());
    }

    // cloning an XmlDeclaration with extensive attributes should succeed without errors
    @Test
    public void test_clone_with_extensive_attributes() {
        XmlDeclaration original = new XmlDeclaration("xml", false);
        original.attr("version", "1.0");
        original.attr("encoding", "UTF-8");
        XmlDeclaration cloned = original.clone();
        assertEquals("1.0", cloned.attr("version"));
        assertEquals("UTF-8", cloned.attr("encoding"));
        assertEquals(2, cloned.attributes().size());
    }
}


