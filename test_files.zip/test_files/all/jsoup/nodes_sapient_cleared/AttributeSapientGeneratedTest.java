package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import org.mockito.stubbing.Answer;
import org.jsoup.internal.Normalizer;
import org.jsoup.helper.Validate;
import org.jsoup.SerializationException;

import java.util.Map;
import java.util.HashMap;

import org.mockito.MockedStatic;
import org.jsoup.internal.StringUtil;

import static org.mockito.Mockito.doNothing;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.verify;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class AttributeSapientGeneratedTest {

    private final Attributes parentMock = mock(Attributes.class, "parent");

    private final Appendable appendableMock = mock(Appendable.class);

    private final Document.OutputSettings documentOutputSettingsMock = mock(Document.OutputSettings.class);

    private final Document.OutputSettings outMock = mock(Document.OutputSettings.class);


    //Sapient generated method id: ${b0d20fa9-e250-397e-b581-b3faccc5922b}, hash: 022A4493586D8C5137CEE149131D7B23
    @Test()
    void getValueTest() {
        //Arrange Statement(s)
        try (MockedStatic<Attributes> attributes = mockStatic(Attributes.class)) {
            attributes.when(() -> Attributes.checkNotNull("val1")).thenReturn("return_of_checkNotNull1");
            Attribute target = new Attribute("key1", "val1", parentMock);
            //Act Statement(s)
            String result = target.getValue();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_checkNotNull1"));
                attributes.verify(() -> Attributes.checkNotNull("val1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${6cf2a51b-a06b-33d7-98e3-c2fd5164e6ed}, hash: 44A07F66F9992607E189740B3DBA9423
    @Test()
    void hasDeclaredValueWhenValIsNotNull() {
        /* Branches:* (val != null) : true*/
        //Arrange Statement(s)
        Attribute target = new Attribute("key1", "val1", parentMock);
        //Act Statement(s)
        boolean result = target.hasDeclaredValue();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.TRUE)));
    }

    //Sapient generated method id: ${644caafa-af67-3fdc-a8c9-deecdd8a07ab}, hash: 00BFF7D5ADC54B27C853C14E0661592F
    @Test()
    void hasDeclaredValueWhenValIsNull() {
        /* Branches:* (val != null) : false*/
        //Arrange Statement(s)
        Attribute target = new Attribute("key1", (String) null, parentMock);
        //Act Statement(s)
        boolean result = target.hasDeclaredValue();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.FALSE)));
    }



    //Sapient generated method id: ${cfa3b072-5479-311e-9060-4d7b7a80a7ed}, hash: F06F28CE75365BF621C3BB98BA1795B3
    @Test()
    void htmlTest() throws IOException {
        //Arrange Statement(s)
        Attribute target = spy(new Attribute("key1", "val1", parentMock));
        doNothing().when(target).html((StringBuilder) any(), (Document.OutputSettings) any());
        //Act Statement(s)
        String result = target.html();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(""));
            verify(target).html((StringBuilder) any(), (Document.OutputSettings) any());
        });
    }


    //Sapient generated method id: ${46708de7-497d-3913-be98-2f21b0097558}, hash: 83986DD40B165B66FE832174A527C6BD
    @Test()
    void sourceRangeWhenParentIsNull() {
        /* Branches:* (parent == null) : true*/
        //Arrange Statement(s)
        Attribute target = new Attribute("key1", "val1", (Attributes) null);
        //Act Statement(s)
        Range.AttributeRange result = target.sourceRange();
        Range.AttributeRange attributeRange = Range.AttributeRange.UntrackedAttr;
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(attributeRange)));
    }

    //Sapient generated method id: ${820e9f53-8318-35db-b470-fdb523f1d5ab}, hash: B3DF9BD61592236D1208A59F1366D16F
    @Test()
    void sourceRangeWhenParentIsNotNull() {
        /* Branches:* (parent == null) : false*/
        //Arrange Statement(s)
        Attribute target = new Attribute("key1", "val1", parentMock);
        Range.AttributeRange rangeAttributeRangeMock = mock(Range.AttributeRange.class);
        doReturn(rangeAttributeRangeMock).when(parentMock).sourceRange("key1");
        //Act Statement(s)
        Range.AttributeRange result = target.sourceRange();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(rangeAttributeRangeMock));
            verify(parentMock).sourceRange("key1");
        });
    }

    //Sapient generated method id: ${e0048c3a-915b-31d3-ad20-f0350cbc93cf}, hash: 42F346AE4E39A5EA480DA4F2481BF6F3
    @Test()
    void html1Test() throws IOException {
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class)) {
            attribute.when(() -> Attribute.html("key1", "val1", appendableMock, documentOutputSettingsMock)).thenAnswer((Answer<Void>) invocation -> null);
            Attribute target = new Attribute("key1", "val1", parentMock);
            //Act Statement(s)
            target.html(appendableMock, documentOutputSettingsMock);
            //Assert statement(s)
            assertAll("result", () -> attribute.verify(() -> Attribute.html("key1", "val1", appendableMock, documentOutputSettingsMock), atLeast(1)));
        }
    }

    //Sapient generated method id: ${73f599a0-5679-3576-81ce-7ae2b84a7095}, hash: EADB64C880F3D7B7E5F971690E1EA573
    @Test()
    void html2WhenKeyIsNull() throws IOException {
        /* Branches:* (key == null) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class, CALLS_REAL_METHODS)) {
            doReturn(Document.OutputSettings.Syntax.html).when(outMock).syntax();
            attribute.when(() -> Attribute.getValidKey("key1", Document.OutputSettings.Syntax.html)).thenReturn(null);
            //Act Statement(s)
            Attribute.html("key1", "val1", appendableMock, outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock, atLeast(1)).syntax();
                attribute.verify(() -> Attribute.getValidKey("key1", Document.OutputSettings.Syntax.html), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${aa12be27-50bf-3754-b2d3-88bddf94fd42}, hash: 404DFBC8DAD2EA4B3B5C77299D236A08
    @Test()
    void html2WhenKeyIsNotNull() throws IOException {
        /* Branches:* (key == null) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class, CALLS_REAL_METHODS)) {
            doReturn(Document.OutputSettings.Syntax.html).when(outMock).syntax();
            attribute.when(() -> Attribute.getValidKey("key1", Document.OutputSettings.Syntax.html)).thenReturn("return_of_getValidKey1");
            attribute.when(() -> Attribute.htmlNoValidate("return_of_getValidKey1", "val1", appendableMock, outMock)).thenAnswer((Answer<Void>) invocation -> null);
            //Act Statement(s)
            Attribute.html("key1", "val1", appendableMock, outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock, atLeast(1)).syntax();
                attribute.verify(() -> Attribute.getValidKey("key1", Document.OutputSettings.Syntax.html), atLeast(1));
                attribute.verify(() -> Attribute.htmlNoValidate("return_of_getValidKey1", "val1", appendableMock, outMock), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${d8bb895e-3974-3031-8a25-44624c0b93a2}, hash: 3F9499F26B26C3047EBBD2596FCC1FB6
    @Test()
    void htmlNoValidateWhenShouldCollapseAttributeNotKeyValOut() throws IOException {
        /* Branches:* (!shouldCollapseAttribute(key, val, out)) : true*/
        //Arrange Statement(s)
        Appendable accumMock = mock(Appendable.class, "someValue");
        try (MockedStatic<Entities> entities = mockStatic(Entities.class);
             MockedStatic<Attributes> attributes = mockStatic(Attributes.class);
             MockedStatic<Attribute> attribute = mockStatic(Attribute.class, CALLS_REAL_METHODS)) {
            doReturn(null).when(accumMock).append("allowfullscreen");
            doReturn(null).when(accumMock).append("=\"");
            doReturn(null).when(accumMock).append('\"');
            Document.OutputSettings documentOutputSettings = new Document.OutputSettings();
            attribute.when(() -> Attribute.shouldCollapseAttribute("allowfullscreen", "true", documentOutputSettings)).thenReturn(false);
            attributes.when(() -> Attributes.checkNotNull("true")).thenReturn("return_of_checkNotNull1");
            entities.when(() -> Entities.escape(accumMock, "return_of_checkNotNull1", documentOutputSettings, true, false, false, false)).thenAnswer((Answer<Void>) invocation -> null);
            //Act Statement(s)
            Attribute.htmlNoValidate("allowfullscreen", "true", accumMock, documentOutputSettings);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(accumMock, atLeast(1)).append("allowfullscreen");
                verify(accumMock, atLeast(1)).append("=\"");
                verify(accumMock, atLeast(1)).append('\"');
                attribute.verify(() -> Attribute.shouldCollapseAttribute("allowfullscreen", "true", documentOutputSettings), atLeast(1));
                attributes.verify(() -> Attributes.checkNotNull("true"), atLeast(1));
                entities.verify(() -> Entities.escape(accumMock, "return_of_checkNotNull1", documentOutputSettings, true, false, false, false), atLeast(1));
            });
        }
    }


    //Sapient generated method id: ${e7398add-bfc6-364e-beaf-318591a6611f}, hash: C0AB16AFE1FB7AAC0A64DE9C40907A45
    @Test()
    void getValidKeyWhenHtmlKeyValidMatcherKeyMatches() {
        /* Branches:* (syntax == Syntax.xml) : false* (syntax == Syntax.html) : true* (!htmlKeyValid.matcher(key).matches()) : false*/
        //Act Statement(s)
        String result = Attribute.getValidKey("A", Document.OutputSettings.Syntax.html);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("A")));
    }

    //Sapient generated method id: ${363d3698-f34c-39ad-914f-376a19498023}, hash: EA4DC8E704D3520054B2DE8E6CBF382F
    @Test()
    void toStringTest() throws IOException {
        //Arrange Statement(s)
        Attribute target = spy(new Attribute("key1", "val1", parentMock));
        doReturn("return_of_html1").when(target).html();
        //Act Statement(s)
        String result = target.toString();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_html1"));
            verify(target).html();
        });
    }

    //Sapient generated method id: ${85162c67-e55f-3547-a153-27aa33e98805}, hash: C61B1D64AFCB8D5A7FD6B031C547C514
    @Test()
    void createFromEncodedTest() {
        //Arrange Statement(s)
        try (MockedStatic<Entities> entities = mockStatic(Entities.class)) {
            entities.when(() -> Entities.unescape("encodedValue1", true)).thenReturn("return_of_unescape1");
            //Act Statement(s)
            Attribute result = Attribute.createFromEncoded("unencodedKey1", "encodedValue1");
            Attribute attribute = new Attribute("unencodedKey1", "return_of_unescape1", (Attributes) null);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(attribute));
                entities.verify(() -> Entities.unescape("encodedValue1", true), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${edcd0c1d-9d9e-3690-833d-69d8e6d73c4e}, hash: 7FD8C733BF6C05D2944D78CCC6AC6185
    @Test()
    void isDataAttributeWhenIsDataAttributeKey() {
        /* Branches:* (isDataAttribute(key)) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class)) {
            attribute.when(() -> Attribute.isDataAttribute("key1")).thenReturn(true);
            Attribute target = new Attribute("key1", "val1", parentMock);
            //Act Statement(s)
            boolean result = target.isDataAttribute();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                attribute.verify(() -> Attribute.isDataAttribute("key1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${561c717c-b60d-3296-be48-6d2fcaee704d}, hash: 780EECD0BD6D94F5DFFE853907E69394
    @Test()
    void isDataAttributeWhenIsDataAttributeNotKey() {
        /* Branches:* (isDataAttribute(key)) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class)) {
            attribute.when(() -> Attribute.isDataAttribute("key1")).thenReturn(false);
            Attribute target = new Attribute("key1", "val1", parentMock);
            //Act Statement(s)
            boolean result = target.isDataAttribute();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                attribute.verify(() -> Attribute.isDataAttribute("key1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${f1e81e26-2aee-3caf-8fcc-ed38418b4bcf}, hash: 05F2B51A92972BD16B977B278B7B06CA
    @Test()
    void isDataAttribute1WhenKeyLengthGreaterThanAttributesDataPrefixLength() {
        /* Branches:* (key.startsWith(Attributes.dataPrefix)) : true* (key.length() > Attributes.dataPrefix.length()) : true*/
        //Act Statement(s)
        boolean result = Attribute.isDataAttribute("data-A");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.TRUE)));
    }

    //Sapient generated method id: ${ad384638-e866-390d-9bb8-dc6598db5f91}, hash: 352E31B11161738FC2C9AF9E7BE3F746
    @Test()
    void isDataAttribute1WhenKeyLengthNotGreaterThanAttributesDataPrefixLength() {
        /* Branches:* (key.startsWith(Attributes.dataPrefix)) : true* (key.length() > Attributes.dataPrefix.length()) : false*/
        //Act Statement(s)
        boolean result = Attribute.isDataAttribute("data-");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.FALSE)));
    }

    //Sapient generated method id: ${ca12afcb-7670-3aff-ac10-84f6bf09af35}, hash: 3601D5CD4421BC37468F0BF7E90EEDF5
    @Test()
    void shouldCollapseAttributeWhenShouldCollapseAttributeKeyValOut() {
        /* Branches:* (shouldCollapseAttribute(key, val, out)) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class)) {
            attribute.when(() -> Attribute.shouldCollapseAttribute("key1", "val1", documentOutputSettingsMock)).thenReturn(true);
            Attribute target = new Attribute("key1", "val1", parentMock);
            //Act Statement(s)
            boolean result = target.shouldCollapseAttribute(documentOutputSettingsMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                attribute.verify(() -> Attribute.shouldCollapseAttribute("key1", "val1", documentOutputSettingsMock), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${d1c69b82-5859-3466-b06c-8b03c0bf1939}, hash: 129D06DDBE48C9CC4F76D3F69AE1DBE1
    @Test()
    void shouldCollapseAttributeWhenShouldCollapseAttributeNotKeyValOut() {
        /* Branches:* (shouldCollapseAttribute(key, val, out)) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class)) {
            attribute.when(() -> Attribute.shouldCollapseAttribute("key1", "val1", documentOutputSettingsMock)).thenReturn(false);
            Attribute target = new Attribute("key1", "val1", parentMock);
            //Act Statement(s)
            boolean result = target.shouldCollapseAttribute(documentOutputSettingsMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                attribute.verify(() -> Attribute.shouldCollapseAttribute("key1", "val1", documentOutputSettingsMock), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${ffc560be-f1ce-3e9e-8461-0d5fe6b5b479}, hash: EF57518CB777DB5C2E716BAE5A550342
    @Test()
    void shouldCollapseAttribute1WhenValEqualsIgnoreCaseKeyAndAttributeIsBooleanAttributeKey() {
        /* Branches:* (out.syntax() == Syntax.html) : true* (val == null) : false* (val.isEmpty()) : false* (val.equalsIgnoreCase(key)) : true* (Attribute.isBooleanAttribute(key)) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class, CALLS_REAL_METHODS)) {
            doReturn(Document.OutputSettings.Syntax.html).when(outMock).syntax();
            attribute.when(() -> Attribute.isBooleanAttribute("B")).thenReturn(true);
            //Act Statement(s)
            boolean result = Attribute.shouldCollapseAttribute("B", "B", outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                verify(outMock, atLeast(1)).syntax();
                attribute.verify(() -> Attribute.isBooleanAttribute("B"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${0c69c517-9f67-35cd-89de-e07c1a63703d}, hash: 67DFD518E1124C11DD0E8DFBE4F22CDC
    @Test()
    void shouldCollapseAttribute1WhenValEqualsIgnoreCaseKeyAndAttributeNotIsBooleanAttributeKey() {
        /* Branches:* (out.syntax() == Syntax.html) : true* (val == null) : false* (val.isEmpty()) : false* (val.equalsIgnoreCase(key)) : true* (Attribute.isBooleanAttribute(key)) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Attribute> attribute = mockStatic(Attribute.class, CALLS_REAL_METHODS)) {
            doReturn(Document.OutputSettings.Syntax.html).when(outMock).syntax();
            attribute.when(() -> Attribute.isBooleanAttribute("B")).thenReturn(false);
            //Act Statement(s)
            boolean result = Attribute.shouldCollapseAttribute("B", "B", outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                verify(outMock, atLeast(1)).syntax();
                attribute.verify(() -> Attribute.isBooleanAttribute("B"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${16a51429-cf39-335b-8f04-45d88d08af7d}, hash: 63C08F6CBDCAF1878CA915808FD47826
    @Test()
    void isBooleanAttributeWhenArraysBinarySearchBooleanAttributesNormalizerLowerCaseKeyLessThan0() {
        /* Branches:* (Arrays.binarySearch(booleanAttributes, Normalizer.lowerCase(key)) >= 0) : false*/
        //Act Statement(s)
        boolean result = Attribute.isBooleanAttribute("A");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.FALSE)));
    }

}
