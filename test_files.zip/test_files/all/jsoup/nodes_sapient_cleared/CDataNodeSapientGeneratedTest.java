package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class CDataNodeSapientGeneratedTest {

    private final Document.OutputSettings documentOutputSettingsMock = mock(Document.OutputSettings.class, "2");

    //Sapient generated method id: ${8dd87bf2-664a-3f64-ad35-7dd70d78f42d}, hash: 6E0095055969B428258046DAFFB4AC74
    @Test()
    void nodeNameTest() {
        //Arrange Statement(s)
        CDataNode target = new CDataNode("text1");
        //Act Statement(s)
        String result = target.nodeName();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("#cdata")));
    }

    //Sapient generated method id: ${b33ddd5c-4cde-36be-92ea-cbe76b042145}, hash: B7C5CD99A452F5869D2FB539DB9FA6A5
    @Test()
    void textTest() {
        //Arrange Statement(s)
        CDataNode target = spy(new CDataNode("text1"));
        doReturn("return_of_getWholeText1").when(target).getWholeText();
        //Act Statement(s)
        String result = target.text();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_getWholeText1"));
            verify(target).getWholeText();
        });
    }

    //Sapient generated method id: ${050ee114-0f72-3bff-b278-6545023ca3e0}, hash: 87C98EA69DD4D88960F9B32C2BD56720
    @Test()
    void outerHtmlHeadTest() throws IOException {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Appendable accumMock = mock(Appendable.class);
        Appendable appendableMock = mock(Appendable.class);
        doReturn(appendableMock).when(accumMock).append("<![CDATA[");
        CDataNode target = spy(new CDataNode("Hello World"));
        doReturn("return_of_getWholeText1").when(target).getWholeText();
        //Act Statement(s)
        target.outerHtmlHead(accumMock, 1, documentOutputSettingsMock);
        //Assert statement(s)
        assertAll("result", () -> {
            verify(accumMock).append("<![CDATA[");
            verify(target).getWholeText();
        });
    }

    //Sapient generated method id: ${8863bee1-d17b-3962-b643-7bc77922cd18}, hash: 4C60F91354B3AA44FC8A07CC15073B4D
    @Test()
    void outerHtmlTailTest() throws IOException {
        //Arrange Statement(s)
        Appendable accumMock = mock(Appendable.class, "someValue");
        doReturn(null).when(accumMock).append("]]>");
        CDataNode target = new CDataNode("someText");
        //Act Statement(s)
        target.outerHtmlTail(accumMock, 1, documentOutputSettingsMock);
        //Assert statement(s)
        assertAll("result", () -> verify(accumMock).append("]]>"));
    }

    //Sapient generated method id: ${cefb663d-1a78-3851-9cc0-65d3bfdeb313}, hash: D0E2C258B4091C2088CF231AABA472E5
    @Test()
    void clone3Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        CDataNode target = new CDataNode("text1");
        //Act Statement(s)
        CDataNode result = target.clone();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
}
