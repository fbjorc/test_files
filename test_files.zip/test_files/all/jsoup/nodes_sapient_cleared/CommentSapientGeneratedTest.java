package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import org.jsoup.parser.ParseSettings;
import org.jsoup.parser.Parser;
import org.mockito.MockedStatic;
import org.jsoup.internal.StringUtil;

import static org.mockito.Mockito.doNothing;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.verify;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class CommentSapientGeneratedTest {

    //Sapient generated method id: ${8dd87bf2-664a-3f64-ad35-7dd70d78f42d}, hash: 9F8B8E06A839DBEFF88913BAF9D981AE
    @Test()
    void nodeNameTest() {
        //Arrange Statement(s)
        Comment target = new Comment("data1");
        //Act Statement(s)
        String result = target.nodeName();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("#comment")));
    }

    //Sapient generated method id: ${0d4a0928-1565-335c-afe7-48a03027cfa1}, hash: 8BF1F016611C9094ABDF7D52CD661C91
    @Test()
    void getDataTest() {
        //Arrange Statement(s)
        Comment target = spy(new Comment("data1"));
        doReturn("return_of_coreValue1").when(target).coreValue();
        //Act Statement(s)
        String result = target.getData();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_coreValue1"));
            verify(target).coreValue();
        });
    }

    //Sapient generated method id: ${bf0705d4-e012-3155-9cb3-f4142e3661bf}, hash: 938FA61CA2795EE78052167032B759FD
    @Test()
    void setDataTest() {
        //Arrange Statement(s)
        Comment target = spy(new Comment("data1"));
        doNothing().when(target).coreValue("data1");
        //Act Statement(s)
        Comment result = target.setData("data1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(target));
            verify(target).coreValue("data1");
        });
    }

    //Sapient generated method id: ${a92fadaf-2705-34ca-8b6e-27ce690dfa9b}, hash: A69A13D61D040CEDA6CECACD2D4A8B72
    @Test()
    void outerHtmlHeadWhenParentNodeNotInstanceOfElementAndOutOutline() throws IOException {
        /* Branches:* (out.prettyPrint()) : true* (isEffectivelyFirst()) : true* (parentNode instanceof Element) : false* (out.outline()) : true*/
        //Arrange Statement(s)
        Appendable accumMock = mock(Appendable.class, "someValue");
        Document.OutputSettings outMock = mock(Document.OutputSettings.class, "1");
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class)) {
            doReturn(null).when(accumMock).append('\n');
            doReturn(true).when(outMock).prettyPrint();
            doReturn(true).when(outMock).outline();
            doReturn(1).when(outMock).indentAmount();
            doReturn(1).when(outMock).maxPaddingWidth();
            stringUtil.when(() -> StringUtil.padding(1, 1)).thenReturn("");
            Comment target = spy(new Comment("someData"));
            doReturn(true).when(target).isEffectivelyFirst();
            //Act Statement(s)
            final NullPointerException result = assertThrows(NullPointerException.class, () -> {
                target.outerHtmlHead(accumMock, 1, outMock);
            });
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                verify(accumMock).append('\n');
                verify(outMock).prettyPrint();
                verify(outMock).outline();
                verify(outMock).indentAmount();
                verify(outMock).maxPaddingWidth();
                stringUtil.verify(() -> StringUtil.padding(1, 1), atLeast(1));
                verify(target).isEffectivelyFirst();
            });
        }
    }

    //Sapient generated method id: ${363d3698-f34c-39ad-914f-376a19498023}, hash: C36DBBD33087C3A5F8CC275EE5927E8F
    @Test()
    void toStringTest() {
        //Arrange Statement(s)
        Comment target = spy(new Comment("data1"));
        doReturn("return_of_outerHtml1").when(target).outerHtml();
        //Act Statement(s)
        String result = target.toString();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_outerHtml1"));
            verify(target).outerHtml();
        });
    }

    //Sapient generated method id: ${889f17a1-e6fb-3c01-9799-b69eed02fb7d}, hash: 3DA4F6089E8484B464BFD2058C113009
    @Test()
    void clone2Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Comment target = new Comment("data1");
        //Act Statement(s)
        Comment result = target.clone();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${701e0d3b-e980-334d-91dd-8e67f4e32c76}, hash: E0D887EBF7D1CC531ADF5C4177910DBD
    @Test()
    void isXmlDeclarationWhenDataNotStartsWith_AndDataStartsWith_() {
        /* Branches:* (data.length() > 1) : true  #  inside isXmlDeclarationData method* (data.startsWith("!")) : false  #  inside isXmlDeclarationData method* (data.startsWith("?")) : true  #  inside isXmlDeclarationData method*/
        //Arrange Statement(s)
        Comment target = spy(new Comment("data1"));
        doReturn("?A").when(target).getData();
        //Act Statement(s)
        boolean result = target.isXmlDeclaration();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.TRUE));
            verify(target).getData();
        });
    }

    //Sapient generated method id: ${733c7b91-24c9-3cc6-9b31-b73eed98ed97}, hash: D97D4ACE54ED0BDFA4A8248DDA6AB93C
    @Test()
    void isXmlDeclarationWhenDataNotStartsWith_() {
        /* Branches:* (data.length() > 1) : true  #  inside isXmlDeclarationData method* (data.startsWith("!")) : false  #  inside isXmlDeclarationData method* (data.startsWith("?")) : false  #  inside isXmlDeclarationData method*/
        //Arrange Statement(s)
        Comment target = spy(new Comment("data1"));
        doReturn("AB").when(target).getData();
        //Act Statement(s)
        boolean result = target.isXmlDeclaration();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.FALSE));
            verify(target).getData();
        });
    }

    //Sapient generated method id: ${d6e77e2d-d36e-3bc3-ae41-e0f495de9f2c}, hash: 2D825AC74058F9E8AC30E41E5E53D9A1
    @Test()
    void asXmlDeclarationWhenDataStartsWith_AndIsXmlDeclarationDataDeclContent() {
        /* Branches:* (data.length() > 1) : true  #  inside isXmlDeclarationData method* (data.startsWith("!")) : false  #  inside isXmlDeclarationData method* (data.startsWith("?")) : true  #  inside isXmlDeclarationData method* (isXmlDeclarationData(declContent)) : true*/
        //Arrange Statement(s)
        Comment target = spy(new Comment("data1"));
        doReturn("A?BC").when(target).getData();
        //Act Statement(s)
        XmlDeclaration result = target.asXmlDeclaration();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(nullValue()));
            verify(target).getData();
        });
    }

}
