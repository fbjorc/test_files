package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doNothing;

import org.mockito.MockedStatic;
import org.jsoup.internal.StringUtil;

import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;
import org.mockito.stubbing.Answer;
import org.jsoup.helper.Validate;

import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import static org.mockito.Mockito.times;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class TextNodeSapientGeneratedTest {

    private final TextNode textNodeMock = mock(TextNode.class);

    private final Appendable appendableMock = mock(Appendable.class);

    private final Element elementMock = mock(Element.class);

    private final Element elementMock2 = mock(Element.class);

    private final Node nodeMock = mock(Node.class);

    private final Document.OutputSettings outMock = mock(Document.OutputSettings.class);

    //Sapient generated method id: ${8dd87bf2-664a-3f64-ad35-7dd70d78f42d}, hash: C963D6A74DDD011ED3F57F16959809F6
    @Test()
    void nodeNameTest() {
        //Arrange Statement(s)
        TextNode target = new TextNode("text1");

        //Act Statement(s)
        String result = target.nodeName();

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("#text")));
    }

    //Sapient generated method id: ${b33ddd5c-4cde-36be-92ea-cbe76b042145}, hash: 9AC429D5D44594E4BBF781244A0A553A
    @Test()
    void textTest() {
        //Arrange Statement(s)
        TextNode target = spy(new TextNode("text1"));
        doReturn("A").when(target).getWholeText();

        //Act Statement(s)
        String result = target.text();

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("A"));
            verify(target).getWholeText();
        });
    }

    //Sapient generated method id: ${0585d9c0-c963-3588-800b-2bcd599de146}, hash: 87CF02243A70BA8CFE570B867C4BC6C6
    @Test()
    void text1Test() {
        //Arrange Statement(s)
        TextNode target = spy(new TextNode("text1"));
        doNothing().when(target).coreValue("text1");

        //Act Statement(s)
        TextNode result = target.text("text1");

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(target));
            verify(target).coreValue("text1");
        });
    }

    //Sapient generated method id: ${b33c3661-958f-3734-8208-7631bb214a90}, hash: 16B6B81B915046E85B0A072A21B29415
    @Test()
    void getWholeTextTest() {
        //Arrange Statement(s)
        TextNode target = spy(new TextNode("text1"));
        doReturn("return_of_coreValue1").when(target).coreValue();

        //Act Statement(s)
        String result = target.getWholeText();

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_coreValue1"));
            verify(target).coreValue();
        });
    }

    //Sapient generated method id: ${2252375e-d04e-330c-87c9-e8a0750e435b}, hash: C743EE7A451DF8A58FD2F855CB45CF46
    @Test()
    void isBlankWhenStringUtilIsBlankCoreValue() {
        /* Branches:* (StringUtil.isBlank(coreValue())) : true*/
        //Arrange Statement(s)
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class)) {
            stringUtil.when(() -> StringUtil.isBlank("A")).thenReturn(true);
            TextNode target = spy(new TextNode("text1"));
            doReturn("A").when(target).coreValue();
            //Act Statement(s)
            boolean result = target.isBlank();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                stringUtil.verify(() -> StringUtil.isBlank("A"), atLeast(1));
                verify(target).coreValue();
            });
        }
    }

    //Sapient generated method id: ${5a4d2806-07e3-3d1a-832e-6ff2a6a2c603}, hash: D08AD8CAE81F036FA9186B0EB2649A01
    @Test()
    void isBlankWhenStringUtilNotIsBlankCoreValue() {
        /* Branches:* (StringUtil.isBlank(coreValue())) : false*/
        //Arrange Statement(s)
        TextNode target = spy(new TextNode("text1"));
        doReturn("A").when(target).coreValue();

        //Act Statement(s)
        boolean result = target.isBlank();

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.FALSE));
            verify(target).coreValue();
        });
    }

    //Sapient generated method id: ${51cf374f-4744-3d15-8dc8-302d96130c13}, hash: F185502203796A1CCD5A5CEB04022837
    @Test()
    void splitTextWhenParentNodeIsNull() {
        /* Branches:* (offset >= 0) : true* (offset < text.length()) : true* (parentNode != null) : false*/
        //Arrange Statement(s)
        TextNode target = spy(new TextNode("text1"));
        doReturn("A").when(target).coreValue();
        doReturn(textNodeMock).when(target).text("");

        //Act Statement(s)
        TextNode result = target.splitText(0);
        TextNode textNode = new TextNode("A");

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(textNode));
            verify(target).coreValue();
            verify(target).text("");
        });
    }


    //Sapient generated method id: ${c21c25ef-d1a4-393b-88da-45910ac31ad1}, hash: 27F04E13EAA9F65D9B73CEDA7769C991
    @Test()
    void outerHtmlHeadWhenPrevNotInstanceOfElementAndPrevIsBlockAndCouldSkipAndIsBlank() throws IOException {
        /* Branches:* (parentNode instanceof Element) : false* (prettyPrint) : true* (!Element.preserveWhitespace(parentNode)) : true* (parent != null) : false* (normaliseWhite) : true* (trimLikeBlock) : false* (parentNode instanceof Document) : false* (trimLikeBlock) : false* (next instanceof Element) : true* (((Element) next).shouldIndent(out)) : false* (next instanceof TextNode) : false* (next instanceof TextNode) : true* (prev instanceof Element) : false* (((Element) prev).isBlock()) : true* (couldSkip) : true* (isBlank) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Element> element = mockStatic(Element.class)) {
            doReturn(true).when(outMock).prettyPrint();
            element.when(() -> Element.preserveWhitespace((Node) null)).thenReturn(false);
            TextNode target = spy(new TextNode("text1"));
            doReturn(elementMock).when(target).nextSibling();
            doReturn(false).when(elementMock).shouldIndent(outMock);
            doReturn(elementMock2).when(target).previousSibling();
            doReturn(false).when(elementMock2).isBlock();
            doReturn(true).when(elementMock2).nameIs("br");
            doReturn(true).when(target).isBlank();
            //Act Statement(s)
            target.outerHtmlHead(appendableMock, 0, outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).prettyPrint();
                element.verify(() -> Element.preserveWhitespace((Node) null), atLeast(1));
                verify(target).nextSibling();
                verify(elementMock).shouldIndent(outMock);
                verify(target).previousSibling();
                verify(elementMock2).isBlock();
                verify(elementMock2).nameIs("br");
                verify(target).isBlank();
            });
        }
    }

    //Sapient generated method id: ${d10c4979-f527-3906-8153-211be0d035c1}, hash: 1109BFF4F1E1AD91C3A5C4D5FD6C14B4
    @Test()
    void outerHtmlHeadWhenPrevIsNullAndParentIsNullAndOutOutlineAndNotIsBlank() throws IOException {
        /* Branches:* (parentNode instanceof Element) : false* (prettyPrint) : true* (!Element.preserveWhitespace(parentNode)) : true* (parent != null) : false* (normaliseWhite) : true* (trimLikeBlock) : false* (parentNode instanceof Document) : false* (trimLikeBlock) : false* (next instanceof Element) : true* (((Element) next).shouldIndent(out)) : false* (next instanceof TextNode) : false* (next instanceof TextNode) : false* (couldSkip) : false* (prev == null) : true* (parent != null) : false* (out.outline()) : true* (!isBlank) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Entities> entities = mockStatic(Entities.class);
             MockedStatic<Element> element = mockStatic(Element.class)) {
            doReturn(true).when(outMock).prettyPrint();
            doReturn(true).when(outMock).outline();
            element.when(() -> Element.preserveWhitespace((Node) null)).thenReturn(false);
            entities.when(() -> Entities.escape(appendableMock, "return_of_coreValue1", outMock, false, true, false, false)).thenAnswer((Answer<Void>) invocation -> null);
            TextNode target = spy(new TextNode("text1"));
            doReturn(elementMock).when(target).nextSibling();
            doReturn(false).when(elementMock).shouldIndent(outMock);
            doReturn(null).when(target).previousSibling();
            doReturn(true).when(target).isBlank();
            List<Node> nodeList = new ArrayList<>();
            nodeList.add(nodeMock);
            doReturn(nodeList).when(target).siblingNodes();
            doReturn("return_of_coreValue1").when(target).coreValue();
            //Act Statement(s)
            target.outerHtmlHead(appendableMock, 0, outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).prettyPrint();
                verify(outMock).outline();
                element.verify(() -> Element.preserveWhitespace((Node) null), atLeast(1));
                entities.verify(() -> Entities.escape(appendableMock, "return_of_coreValue1", outMock, false, true, false, false), atLeast(1));
                verify(target).nextSibling();
                verify(elementMock).shouldIndent(outMock);
                verify(target).previousSibling();
                verify(target).isBlank();
                verify(target).siblingNodes();
                verify(target).coreValue();
            });
        }
    }

    //Sapient generated method id: ${363d3698-f34c-39ad-914f-376a19498023}, hash: C9FF79A5E9E17FBAC371D8283D208714
    @Test()
    void toStringTest() {
        //Arrange Statement(s)
        TextNode target = spy(new TextNode("text1"));
        doReturn("return_of_outerHtml1").when(target).outerHtml();

        //Act Statement(s)
        String result = target.toString();

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_outerHtml1"));
            verify(target).outerHtml();
        });
    }


    //Sapient generated method id: ${151cb2e7-e25e-34d4-a6d2-66ad7b26b7a0}, hash: 8DB9A34B1A54F2AD4F50097F3B2B137A
    @Test()
    void normaliseWhitespaceTest() {

        //Act Statement(s)
        String result = TextNode.normaliseWhitespace("A");

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("A")));
    }

    //Sapient generated method id: ${ac1e5a24-a7a8-3063-b908-5b87a0d6cf2a}, hash: E9BA5FD5C61E2ABE6FA8ACFFC8E0DD9A
    @Test()
    void stripLeadingWhitespaceTest() {

        //Act Statement(s)
        String result = TextNode.stripLeadingWhitespace("A");

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("A")));
    }

    //Sapient generated method id: ${b1b40594-be80-3d1b-8b49-4c79dd16d3e1}, hash: D46BF0D05350BF5669865B4596C2CC13
    @Test()
    void lastCharIsWhitespaceWhenSbCharAtSbLengthMinus1Equals___() {
        /* Branches:* (sb.length() != 0) : true* (sb.charAt(sb.length() - 1) == ' ') : true*/
        //Arrange Statement(s)
        StringBuilder stringBuilder = new StringBuilder();

        //Act Statement(s)
        boolean result = TextNode.lastCharIsWhitespace(stringBuilder);

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.TRUE)));
    }

    //Sapient generated method id: ${b28990a2-7631-311b-9e93-03cafee7a7fa}, hash: BC68883A37486CFD9E770C02BE2D0B2A
    @Test()
    void lastCharIsWhitespaceWhenSbCharAtSbLengthMinus1NotEquals___() {
        /* Branches:* (sb.length() != 0) : true* (sb.charAt(sb.length() - 1) == ' ') : false*/
        //Arrange Statement(s)
        StringBuilder stringBuilder = new StringBuilder();

        //Act Statement(s)
        boolean result = TextNode.lastCharIsWhitespace(stringBuilder);

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.FALSE)));
    }
}
