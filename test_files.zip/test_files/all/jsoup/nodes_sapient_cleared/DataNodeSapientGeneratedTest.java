package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.mockito.Mockito.doNothing;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class DataNodeSapientGeneratedTest {

    private final Appendable appendableMock = mock(Appendable.class);

    private final Document.OutputSettings outMock = mock(Document.OutputSettings.class);

    //Sapient generated method id: ${8dd87bf2-664a-3f64-ad35-7dd70d78f42d}, hash: FA9D727F9752315DB64F86FA3329BF31
    @Test()
    void nodeNameTest() {
        //Arrange Statement(s)
        DataNode target = new DataNode("data1");
        //Act Statement(s)
        String result = target.nodeName();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("#data")));
    }

    //Sapient generated method id: ${2c40d231-73ac-3f6a-ae3b-737603c00a39}, hash: 707A370CF22C9B0E31DE3EA86217FAD1
    @Test()
    void getWholeDataTest() {
        //Arrange Statement(s)
        DataNode target = spy(new DataNode("data1"));
        doReturn("return_of_coreValue1").when(target).coreValue();
        //Act Statement(s)
        String result = target.getWholeData();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_coreValue1"));
            verify(target).coreValue();
        });
    }

    //Sapient generated method id: ${c20bc8b4-d369-30a8-9063-86f5ead1eebc}, hash: 6DED1BC61D8D20A45D5E0743889B8ADD
    @Test()
    void setWholeDataTest() {
        //Arrange Statement(s)
        DataNode target = spy(new DataNode("data1"));
        doNothing().when(target).coreValue("data1");
        //Act Statement(s)
        DataNode result = target.setWholeData("data1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(target));
            verify(target).coreValue("data1");
        });
    }

    //Sapient generated method id: ${2bda0df7-7677-3ab6-bc4f-5f4534e73db9}, hash: 4DE46B536D1FF281D8FF8ACA89F1F687
    @Test()
    void outerHtmlHeadWhenDataContains___CDATA_() throws IOException {
        /* Branches:* (out.syntax() == Document.OutputSettings.Syntax.xml) : true* (!data.contains("<![CDATA[")) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        doReturn(Document.OutputSettings.Syntax.xml).when(outMock).syntax();
        DataNode target = spy(new DataNode("data1"));
        doReturn("<![CDATA[", "return_of_getWholeData1").when(target).getWholeData();
        //Act Statement(s)
        target.outerHtmlHead(appendableMock, 0, outMock);
        //Assert statement(s)
        assertAll("result", () -> {
            verify(outMock).syntax();
            verify(target, times(2)).getWholeData();
        });
    }


    //Sapient generated method id: ${363d3698-f34c-39ad-914f-376a19498023}, hash: D88E3982133ECF46C1BE40EC6E62CD39
    @Test()
    void toStringTest() {
        //Arrange Statement(s)
        DataNode target = spy(new DataNode("data1"));
        doReturn("return_of_outerHtml1").when(target).outerHtml();
        //Act Statement(s)
        String result = target.toString();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_outerHtml1"));
            verify(target).outerHtml();
        });
    }

    //Sapient generated method id: ${889f17a1-e6fb-3c01-9799-b69eed02fb7d}, hash: B643ED60AEAF70FFE542F27200C3890A
    @Test()
    void clone2Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        DataNode target = new DataNode("data1");
        //Act Statement(s)
        DataNode result = target.clone();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
}
