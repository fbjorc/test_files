package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.mockito.InjectMocks;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.stubbing.Answer;
import org.mockito.MockitoAnnotations;
import org.jsoup.helper.Validate;
import java.util.NoSuchElementException;
import org.mockito.MockedStatic;
import static org.mockito.Mockito.doNothing;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;
import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class NodeIteratorSapientGeneratedTest {

    private final Node currentMock = mock(Node.class, "current");

    private AutoCloseable autoCloseableMocks;

    @InjectMocks()
    private NodeIterator target;

    @AfterEach()
    public void afterTest() throws Exception {
        if (autoCloseableMocks != null)
            autoCloseableMocks.close();
    }

    //Sapient generated method id: ${fromWhenTypeIsInstanceStart}, hash: BFCB23D44ADFB3FCAEF59B4E90858CED
    @Test()
    void fromWhenTypeIsInstanceStart() {
        /* Branches:
         * (type.isInstance(start)) : true  #  inside restart method
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class, CALLS_REAL_METHODS)) {
            validate.when(() -> Validate.notNull(currentMock)).thenAnswer((Answer<Void>) invocation -> null);
            doReturn(nodeMock).when(currentMock).parent();
            //Act Statement(s)
            NodeIterator result = NodeIterator.from(currentMock);
            //Assert statement(s)
            //TODO: Please implement equals method in NodeIterator for verification of the entire object or you need to adjust respective assertion statements
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.notNull(currentMock), atLeast(1));
                verify(currentMock, atLeast(1)).parent();
            });
        }
    }

    //Sapient generated method id: ${restartWhenTypeIsInstanceStart}, hash: 4A952246757798D423CA65A033D61FE3
    @Test()
    void restartWhenTypeIsInstanceStart() {
        /* Branches:
         * (type.isInstance(start)) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        Node nodeMock2 = mock(Node.class);
        Node nodeMock3 = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(nodeMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(Node.class)).thenAnswer((Answer<Void>) invocation -> null);
            target = new NodeIterator(nodeMock, Node.class);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(nodeMock2, nodeMock3).when(nodeMock).parent();
            //Act Statement(s)
            target.restart(nodeMock);
            //Assert statement(s)
            assertAll("result", () -> {
                validate.verify(() -> Validate.notNull(nodeMock), atLeast(1));
                validate.verify(() -> Validate.notNull(Node.class), atLeast(1));
                verify(nodeMock, times(2)).parent();
            });
        }
    }

    //Sapient generated method id: ${hasNextWhenNextIsNotNull}, hash: 33FEF37D9DD2DC5DE5E3E6F7FD24E1CC
    @Test()
    void hasNextWhenNextIsNotNull() {
        /* Branches:
         * (next != null) : true  #  inside maybeFindNext method
         * (next != null) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(currentMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(Node.class)).thenAnswer((Answer<Void>) invocation -> null);
            target = new NodeIterator(currentMock, Node.class);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(nodeMock).when(currentMock).parent();
            //Act Statement(s)
            boolean result = target.hasNext();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                validate.verify(() -> Validate.notNull(currentMock), atLeast(1));
                validate.verify(() -> Validate.notNull(Node.class), atLeast(1));
                verify(currentMock).parent();
            });
        }
    }

    //Sapient generated method id: ${nextWhenNextIsNotNull}, hash: 1BF1DAEC7F5CF8263CD946370D5884BA
    @Test()
    void nextWhenNextIsNotNull() {
        /* Branches:
         * (next != null) : true  #  inside maybeFindNext method
         * (next == null) : false
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        Node nodeMock2 = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(currentMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(Node.class)).thenAnswer((Answer<Void>) invocation -> null);
            target = new NodeIterator(currentMock, Node.class);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(nodeMock, nodeMock2).when(currentMock).parent();
            //Act Statement(s)
            Node result = target.next();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(currentMock));
                validate.verify(() -> Validate.notNull(currentMock), atLeast(1));
                validate.verify(() -> Validate.notNull(Node.class), atLeast(1));
                verify(currentMock, atLeast(2)).parent();
            });
        }
    }

    //Sapient generated method id: ${removeTest}, hash: 6AF04D2C16F8493F32EABD324A9179EE
    @Test()
    void removeTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(currentMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(Node.class)).thenAnswer((Answer<Void>) invocation -> null);
            target = new NodeIterator(currentMock, Node.class);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(nodeMock).when(currentMock).parent();
            doNothing().when(currentMock).remove();
            //Act Statement(s)
            target.remove();
            //Assert statement(s)
            assertAll("result", () -> {
                validate.verify(() -> Validate.notNull(currentMock), atLeast(1));
                validate.verify(() -> Validate.notNull(Node.class), atLeast(1));
                verify(currentMock).parent();
                verify(currentMock).remove();
            });
        }
    }
}
