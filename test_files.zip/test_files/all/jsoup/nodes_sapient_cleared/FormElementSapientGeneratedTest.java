package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import java.util.List;
import org.jsoup.Jsoup;
import org.mockito.stubbing.Answer;
import org.jsoup.Connection;
import org.jsoup.select.Elements;
import org.jsoup.helper.Validate;
import org.jsoup.parser.Tag;
import org.mockito.MockedStatic;
import java.util.ArrayList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.doReturn;
import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class FormElementSapientGeneratedTest {

    private final Attributes attributesMock = mock(Attributes.class);

    private final Connection connectionMock = mock(Connection.class);

    private final Connection connectionMock2 = mock(Connection.class);

    private final Connection connectionMock3 = mock(Connection.class);

    private final Connection connectionMock4 = mock(Connection.class);

    private final Tag tagMock = mock(Tag.class);

    //Sapient generated method id: ${elementsTest}, hash: 2CA62EE7048216B9CAC668690B57D32D
    @Test()
    void elementsTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            FormElement target = new FormElement(tagMock, "A", attributesMock);
            //Act Statement(s)
            Elements result = target.elements();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${addElementTest}, hash: FC3D9B539FFA7929B6D1A3C4D1080193
    @Test()
    void addElementTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            FormElement target = new FormElement(tagMock, "A", attributesMock);
            //Act Statement(s)
            FormElement result = target.addElement(elementMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${submitWhenOwnerIsNotNull}, hash: E310BE59169A0E0ADBAF57B7843E2216
    @Test()
    void submitWhenOwnerIsNotNull() {
        /* Branches:
         * (hasAttr("action")) : true
         * (attr("method").equalsIgnoreCase("POST")) : true
         * (owner != null) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Document documentMock = mock(Document.class);
        Connection connectionMock5 = mock(Connection.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("B", "Could not determine a form action URL for submit. Ensure you set a base URI when parsing.")).thenAnswer((Answer<Void>) invocation -> null);
            FormElement target = spy(new FormElement(tagMock, "A", attributesMock));
            doReturn(true).when(target).hasAttr("action");
            doReturn("B").when(target).absUrl("action");
            doReturn("POST").when(target).attr("method");
            doReturn(documentMock).when(target).ownerDocument();
            doReturn(connectionMock).when(documentMock).connection();
            doReturn(connectionMock2).when(connectionMock).newRequest();
            doReturn(connectionMock3).when(connectionMock2).url("B");
            List<Connection.KeyVal> connectionKeyValList = new ArrayList<>();
            doReturn(connectionMock4).when(connectionMock3).data(connectionKeyValList);
            doReturn(connectionMock5).when(connectionMock4).method(Connection.Method.POST);
            doReturn(connectionKeyValList).when(target).formData();
            //Act Statement(s)
            Connection result = target.submit();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(connectionMock5));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("B", "Could not determine a form action URL for submit. Ensure you set a base URI when parsing."), atLeast(1));
                verify(target).hasAttr("action");
                verify(target).absUrl("action");
                verify(target).attr("method");
                verify(target).ownerDocument();
                verify(documentMock).connection();
                verify(connectionMock).newRequest();
                verify(connectionMock2).url("B");
                verify(connectionMock3).data(connectionKeyValList);
                verify(connectionMock4).method(Connection.Method.POST);
                verify(target).formData();
            });
        }
    }

    //Sapient generated method id: ${submitWhenHasAttrNotActionAndAttrMethodNotEqualsIgnoreCasePOSTAndOwnerIsNull}, hash: 03E4571561829E63D39AB7DCEBD4E6DD
    @Test()
    void submitWhenHasAttrNotActionAndAttrMethodNotEqualsIgnoreCasePOSTAndOwnerIsNull() {
        /* Branches:
         * (hasAttr("action")) : false
         * (attr("method").equalsIgnoreCase("POST")) : false
         * (owner != null) : false
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        try (MockedStatic<Jsoup> jsoup = mockStatic(Jsoup.class);
            MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("B", "Could not determine a form action URL for submit. Ensure you set a base URI when parsing.")).thenAnswer((Answer<Void>) invocation -> null);
            jsoup.when(() -> Jsoup.newSession()).thenReturn(connectionMock);
            doReturn(connectionMock2).when(connectionMock).url("B");
            List<Connection.KeyVal> connectionKeyValList = new ArrayList<>();
            doReturn(connectionMock3).when(connectionMock2).data(connectionKeyValList);
            doReturn(connectionMock4).when(connectionMock3).method(Connection.Method.GET);
            FormElement target = spy(new FormElement(tagMock, "A", attributesMock));
            doReturn(false).when(target).hasAttr("action");
            doReturn("B").when(target).baseUri();
            doReturn("C").when(target).attr("method");
            doReturn(null).when(target).ownerDocument();
            doReturn(connectionKeyValList).when(target).formData();
            //Act Statement(s)
            Connection result = target.submit();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(connectionMock4));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("B", "Could not determine a form action URL for submit. Ensure you set a base URI when parsing."), atLeast(1));
                jsoup.verify(() -> Jsoup.newSession(), atLeast(1));
                verify(connectionMock).url("B");
                verify(connectionMock2).data(connectionKeyValList);
                verify(connectionMock3).method(Connection.Method.GET);
                verify(target).hasAttr("action");
                verify(target).baseUri();
                verify(target).attr("method");
                verify(target).ownerDocument();
                verify(target).formData();
            });
        }
    }

    //Sapient generated method id: ${formDataWhenElementsIsEmpty}, hash: D4827B7640FF16CD544468D8AD2E64AD
    @Test()
    void formDataWhenElementsIsEmpty() {
        /* Branches:
         * (for-each(elements)) : false
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            FormElement target = new FormElement(tagMock, "A", attributesMock);
            //Act Statement(s)
            List<Connection.KeyVal> result = target.formData();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }
}
