package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.mockito.InjectMocks;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import org.jsoup.Jsoup;
import org.mockito.MockitoAnnotations;

import java.nio.charset.Charset;
import java.util.ArrayList;

import org.jsoup.internal.StringUtil;
import org.mockito.stubbing.Answer;
import org.jsoup.Connection;
import org.jsoup.select.Elements;
import org.jsoup.helper.Validate;
import org.jsoup.select.Evaluator;
import org.jsoup.parser.ParseSettings;
import org.jsoup.parser.Tag;
import org.jsoup.parser.Parser;
import org.mockito.MockedStatic;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.verify;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class DocumentSapientGeneratedTest {

    private final Document.OutputSettings outputSettingsMock = mock(Document.OutputSettings.class, "outputSettings");

    private AutoCloseable autoCloseableMocks;

    @InjectMocks()
    private Document target;

    @AfterEach()
    public void afterTest() throws Exception {
        if (autoCloseableMocks != null)
            autoCloseableMocks.close();
    }

    //Sapient generated method id: ${3b77ee2e-e3cc-3634-a812-57da572aea8b}, hash: 337BC23C4F251AD2D61DFE68A69FFAEE
    @Test()
    void locationTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.location();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("A"));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${00184b9a-f508-35bd-a613-30b1edabdd77}, hash: BDCA45548D261137B4BBE04424C617AF
    @Test()
    void connectionWhenConnectionIsNull() {
        /* Branches:* (connection == null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Connection result = target.connection();
            //Assert statement(s)
            //TODO: Please implement equals method in Connection for verification of the entire object or you need to adjust respective assertion statements
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${8a0146b8-754d-3514-92b1-376895092fe7}, hash: 837EAEA0E90DFA4BD3D52EFB63B687DC
    @Test()
    void documentTypeWhenNodeNotInstanceOfLeafNode() {
        /* Branches:* (for-each(childNodes)) : true* (node instanceof DocumentType) : false* (!(node instanceof LeafNode)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            DocumentType result = target.documentType();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${61f3c4f8-fb92-3a54-9920-28c5fb15d941}, hash: 7F0A75C11242580BCBA92DFF389BBC99
    @Test()
    void headWhenElNotNameIsHtmlAndElIsNull() {
        /* Branches:* (el != null) : true  #  inside htmlEl method* (el.nameIs("html")) : false  #  inside htmlEl method* (el != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        Element elementMock3 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).firstElementChild();
            doReturn(false).when(elementMock).nameIs("html");
            doReturn(null).when(elementMock).nextElementSibling();
            doReturn(elementMock2).when(target).appendElement("html");
            doReturn(null).when(elementMock2).firstElementChild();
            doReturn(elementMock3).when(elementMock2).prependElement("head");
            //Act Statement(s)
            Element result = target.head();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock3));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).firstElementChild();
                verify(elementMock).nameIs("html");
                verify(elementMock).nextElementSibling();
                verify(target).appendElement("html");
                verify(elementMock2).firstElementChild();
                verify(elementMock2).prependElement("head");
            });
        }
    }

    //Sapient generated method id: ${df82d8a3-20df-37f1-9c5f-a5f291658c03}, hash: DC0C9D829C98228E96ADC0CAF41F4C02
    @Test()
    void headWhenElNameIsHead() {
        /* Branches:* (el != null) : true  #  inside htmlEl method* (el.nameIs("html")) : true  #  inside htmlEl method* (el != null) : true* (el.nameIs("head")) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).firstElementChild();
            doReturn(true).when(elementMock).nameIs("html");
            doReturn(elementMock2).when(elementMock).firstElementChild();
            doReturn(true).when(elementMock2).nameIs("head");
            //Act Statement(s)
            Element result = target.head();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock2));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).firstElementChild();
                verify(elementMock).nameIs("html");
                verify(elementMock).firstElementChild();
                verify(elementMock2, atLeast(1)).nameIs("head");
            });
        }
    }

    //Sapient generated method id: ${9d9f1a82-c4be-3c2d-8809-37c0f18c335c}, hash: 9FECB58345535736858D41C9DC3AEBC8
    @Test()
    void headWhenElNotNameIsHead() {
        /* Branches:* (el != null) : true  #  inside htmlEl method* (el.nameIs("html")) : true  #  inside htmlEl method* (el != null) : true* (el.nameIs("head")) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        Element elementMock3 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).firstElementChild();
            doReturn(true).when(elementMock).nameIs("html");
            doReturn(elementMock2).when(elementMock).firstElementChild();
            doReturn(false).when(elementMock2).nameIs("head");
            doReturn(null).when(elementMock2).nextElementSibling();
            doReturn(elementMock3).when(elementMock).prependElement("head");
            //Act Statement(s)
            Element result = target.head();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock3));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).firstElementChild();
                verify(elementMock).nameIs("html");
                verify(elementMock).firstElementChild();
                verify(elementMock2).nameIs("head");
                verify(elementMock2).nextElementSibling();
                verify(elementMock).prependElement("head");
            });
        }
    }

    //Sapient generated method id: ${aa585f4d-0aff-3401-910c-d7613dc00f12}, hash: CB651DA5B19842F46192925AA135459B
    @Test()
    void bodyWhenElNotNameIsHtmlAndElIsNull() {
        /* Branches:* (el != null) : true  #  inside htmlEl method* (el.nameIs("html")) : false  #  inside htmlEl method* (el != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        Element elementMock3 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).firstElementChild();
            doReturn(false).when(elementMock).nameIs("html");
            doReturn(null).when(elementMock).nextElementSibling();
            doReturn(elementMock2).when(target).appendElement("html");
            doReturn(null).when(elementMock2).firstElementChild();
            doReturn(elementMock3).when(elementMock2).appendElement("body");
            //Act Statement(s)
            Element result = target.body();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock3));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).firstElementChild();
                verify(elementMock).nameIs("html");
                verify(elementMock).nextElementSibling();
                verify(target).appendElement("html");
                verify(elementMock2).firstElementChild();
                verify(elementMock2).appendElement("body");
            });
        }
    }

    //Sapient generated method id: ${46814fe0-8861-3441-81a3-427cef837eac}, hash: 7AEAB93515B750AC9997D4FBA4DA87F9
    @Test()
    void bodyWhenElNameIsFrameset() {
        /* Branches:* (el != null) : true  #  inside htmlEl method* (el.nameIs("html")) : true  #  inside htmlEl method* (el != null) : true* (el.nameIs("body")) : false* (el.nameIs("frameset")) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).firstElementChild();
            doReturn(true).when(elementMock).nameIs("html");
            doReturn(elementMock2).when(elementMock).firstElementChild();
            doReturn(false).when(elementMock2).nameIs("body");
            doReturn(true).when(elementMock2).nameIs("frameset");
            //Act Statement(s)
            Element result = target.body();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock2));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).firstElementChild();
                verify(elementMock).nameIs("html");
                verify(elementMock).firstElementChild();
                verify(elementMock2, atLeast(1)).nameIs("body");
                verify(elementMock2, atLeast(1)).nameIs("frameset");
            });
        }
    }

    //Sapient generated method id: ${f5aa7395-888f-3f68-817c-0b017d332114}, hash: A656BCF1562AD5625158DBA7AAD318A0
    @Test()
    void bodyWhenElNotNameIsFrameset() {
        /* Branches:* (el != null) : true  #  inside htmlEl method* (el.nameIs("html")) : true  #  inside htmlEl method* (el != null) : true* (el.nameIs("body")) : false* (el.nameIs("frameset")) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        Element elementMock3 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).firstElementChild();
            doReturn(true).when(elementMock).nameIs("html");
            doReturn(elementMock2).when(elementMock).firstElementChild();
            doReturn(false).when(elementMock2).nameIs("body");
            doReturn(false).when(elementMock2).nameIs("frameset");
            doReturn(null).when(elementMock2).nextElementSibling();
            doReturn(elementMock3).when(elementMock).appendElement("body");
            //Act Statement(s)
            Element result = target.body();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock3));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).firstElementChild();
                verify(elementMock).nameIs("html");
                verify(elementMock).firstElementChild();
                verify(elementMock2).nameIs("body");
                verify(elementMock2).nameIs("frameset");
                verify(elementMock2).nextElementSibling();
                verify(elementMock).appendElement("body");
            });
        }
    }

    //Sapient generated method id: ${43ba8abf-2bc2-361c-8ec4-0264ee82c47d}, hash: 310EC277D6426A898E7727B22D8E6B7A
    @Test()
    void formsTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            doReturn(elements).when(target).select("form");
            //Act Statement(s)
            List<FormElement> result = target.forms();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).select("form");
            });
        }
    }

    //Sapient generated method id: ${2245b6d8-7c85-383d-bb74-5ee9f2c0ac78}, hash: 29D2B531A9582A8FB77A393FAAC8C3FD
    @Test()
    void expectFormWhenElInstanceOfFormElement() {
        /* Branches:* (for-each(els)) : true* (el instanceof FormElement) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        FormElement formElementMock = mock(FormElement.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            elements.add(formElementMock);
            doReturn(elements).when(target).select("cssQuery1");
            //Act Statement(s)
            FormElement result = target.expectForm("cssQuery1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(formElementMock));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).select("cssQuery1");
            });
        }
    }

    //Sapient generated method id: ${5b73e131-acbe-3414-ae10-2f5641508272}, hash: 6F29BA68F003ED3D41842B8A621DE68E
    @Test()
    void expectFormWhenElNotInstanceOfFormElement() {
        /* Branches:* (for-each(els)) : true* (el instanceof FormElement) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Object[] objectArray = new Object[]{"cssQuery1"};
            validate.when(() -> Validate.fail("No form elements matched the query '%s' in the document.", objectArray)).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            elements.add(elementMock);
            doReturn(elements).when(target).select("cssQuery1");
            //Act Statement(s)
            FormElement result = target.expectForm("cssQuery1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.fail("No form elements matched the query '%s' in the document.", objectArray), atLeast(1));
                verify(target).select("cssQuery1");
            });
        }
    }

    //Sapient generated method id: ${8a0c1219-2d3c-3669-a584-c76923bc0f56}, hash: 7EC368C3AC5E05D57A46DE5354AA93B8
    @Test()
    void titleWhenTitleElIsNull() {
        /* Branches:* (titleEl != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).head();
            doReturn(null).when(elementMock).selectFirst((Evaluator.Tag) any());
            //Act Statement(s)
            String result = target.title();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).head();
                verify(elementMock).selectFirst((Evaluator.Tag) any());
            });
        }
    }

    //Sapient generated method id: ${0882f984-58dd-3f20-b5dd-69517e07f642}, hash: 6A9512C17BCB4DB7CD57D28CA03665F3
    @Test()
    void title1WhenTitleElIsNull() {
        /* Branches:* (titleEl == null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        Element elementMock3 = mock(Element.class);
        Element elementMock4 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(null).when(elementMock).selectFirst((Evaluator.Tag) any());
            doReturn(elementMock, elementMock2).when(target).head();
            doReturn(elementMock3).when(elementMock2).appendElement("title");
            doReturn(elementMock4).when(elementMock3).text("B");
            //Act Statement(s)
            target.title("B");
            //Assert statement(s)
            assertAll("result", () -> {
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target, times(2)).head();
                verify(elementMock).selectFirst((Evaluator.Tag) any());
                verify(elementMock2).appendElement("title");
                verify(elementMock3).text("B");
            });
        }
    }


    //Sapient generated method id: ${91df0505-df63-3e4f-a242-c464596116dc}, hash: 747CC1D38A7459EE57F6E33FEE03FC83
    @Test()
    void outerHtmlTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("return_of_html1").when(target).html();
            //Act Statement(s)
            String result = target.outerHtml();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_html1"));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).html();
            });
        }
    }

    //Sapient generated method id: ${0585d9c0-c963-3588-800b-2bcd599de146}, hash: F4097945284978EA478EC8991D7B4211
    @Test()
    void text1Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Document("namespace1", "A"));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).body();
            doReturn(elementMock2).when(elementMock).text("text1");
            //Act Statement(s)
            Element result = target.text("text1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).body();
                verify(elementMock).text("text1");
            });
        }
    }

    //Sapient generated method id: ${8dd87bf2-664a-3f64-ad35-7dd70d78f42d}, hash: DC767C83FD643179E200B5BE97B12B73
    @Test()
    void nodeNameTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.nodeName();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("#document"));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }


    //Sapient generated method id: ${0ee37da3-2bbc-3560-a10c-239712b27300}, hash: DCF2193E4B2A957B838DDA644EA30093
    @Test()
    void charset1Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Charset result = target.charset();
            Charset charset = outputSettingsMock.charset();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(charset));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${dbb949ad-2f80-3e7f-aa6a-9c10c3123b14}, hash: DC425F08702E20E7313D2DA0BDEFEEE0
    @Test()
    void updateMetaCharsetElementTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            target.updateMetaCharsetElement(false);
            //Assert statement(s)
            assertAll("result", () -> {
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${b7130c64-fe9f-3e4c-b164-c1dc3e2edbec}, hash: F5FE84E023D8D9D7F23D3FFA45543207
    @Test()
    void updateMetaCharsetElement1Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            boolean result = target.updateMetaCharsetElement();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${8c85596a-d253-3187-8725-0beeca7d7b09}, hash: B0C45BC6E369361AD4E3AFA1E29A73C2
    @Test()
    void outputSettingsTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Document.OutputSettings result = target.outputSettings();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(outputSettingsMock));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${e293e550-c3fb-3e32-a4a2-3617c514c8f7}, hash: 5C55CE84985DD80EA01E2FF8E009B4B7
    @Test()
    void outputSettings1Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Document.OutputSettings documentOutputSettingsMock = mock(Document.OutputSettings.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(documentOutputSettingsMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Document result = target.outputSettings(documentOutputSettingsMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(documentOutputSettingsMock), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${92e4ca10-d1aa-3eab-92e7-71442d15eae1}, hash: 2241FAAE75ABA7C095B79F5CFE6915C1
    @Test()
    void quirksModeTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Document.QuirksMode result = target.quirksMode();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Document.QuirksMode.noQuirks));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${705ecbca-8fd5-3f3c-8aa3-3f322b9b88b3}, hash: FE415DC34A207486BCD4B457DC8BBF0F
    @Test()
    void quirksMode1Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Document result = target.quirksMode(Document.QuirksMode.noQuirks);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${5643e378-ea21-3fca-b3b0-fd23a5e9c059}, hash: F1746ED8BDF326F221F6B80E7695EA34
    @Test()
    void parserTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Parser result = target.parser();
            //Assert statement(s)
            //TODO: Please implement equals method in Parser for verification of the entire object or you need to adjust respective assertion statements
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${964fe3df-54d6-3f91-ac6f-e99b4170fb7e}, hash: 8DD1CFC4C550BC58CE8105B8D2137E28
    @Test()
    void parser1Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Document result = target.parser(parserMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${66a34627-853e-3872-b267-7924f0fcaaa9}, hash: D5AF0692547C611E28B40A0EF4E7E569
    @Test()
    void connection1Test() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Tag tagMock = mock(Tag.class);
        Connection connectionMock = mock(Connection.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class)) {
            ParseSettings parseSettings = ParseSettings.htmlDefault;
            tag.when(() -> Tag.valueOf("#root", "namespace1", parseSettings)).thenReturn(tagMock);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(connectionMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Document("namespace1", "A");
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Document result = target.connection(connectionMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                tag.verify(() -> Tag.valueOf("#root", "namespace1", parseSettings), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(connectionMock), atLeast(1));
            });
        }
    }
}
