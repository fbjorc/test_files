package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

import org.mockito.stubbing.Answer;

import java.util.Iterator;

import org.jsoup.helper.Validate;
import org.jsoup.parser.ParseSettings;
import org.jsoup.SerializationException;

import java.util.Map;
import java.util.HashMap;

import org.mockito.MockedStatic;

import static org.mockito.Mockito.doNothing;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.verify;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.doThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class AttributesSapientGeneratedTest {

    private final Attributes attributesMock = mock(Attributes.class);

    private final Attributes incomingMock = mock(Attributes.class);

    //Sapient generated method id: ${d760518d-abea-3b85-8a71-51b7b18eb6db}, hash: BC490FCC6F2E064FA52710A1D4DEBF6A
    @Test()
    void indexOfKeyWhenINotLessThanSize() {
        /* Branches:* (i < size) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = new Attributes();
            //Act Statement(s)
            int result = target.indexOfKey("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(-1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${657a1136-5fdf-39a3-acc4-2be3341ba4a0}, hash: 67CEE5C81ADE578C877D794709BDF66F
    @Test()
    void checkNotNullWhenValIsNull() {
        /* Branches:* (val == null) : true*/
        //Arrange Statement(s)
        Object object = null;
        //Act Statement(s)
        String result = Attributes.checkNotNull(object);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("")));
    }

    //Sapient generated method id: ${d22a0e21-307b-369e-98c1-28ae744b20c2}, hash: 993D3AADC0579254599A3CB965BDE5E0
    @Test()
    void checkNotNullWhenValIsNotNull() {
        /* Branches:* (val == null) : false*/
        //Act Statement(s)
        String result = Attributes.checkNotNull("val1");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("val1")));
    }

    //Sapient generated method id: ${934c53eb-5886-3fb0-8857-1aab5f179cf9}, hash: 47C50F31DC4D0AE3C70E979D6AFA3D19
    @Test()
    void getWhenIEqualsNotFound() {
        /* Branches:* (i == NotFound) : true*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(-1).when(target).indexOfKey("key1");
        //Act Statement(s)
        String result = target.get("key1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(""));
            verify(target).indexOfKey("key1");
        });
    }


    //Sapient generated method id: ${7c8bd3d7-2981-3a2a-87de-ffec5ebca420}, hash: FE7043F2E9C0E45BD2477DF79E478303
    @Test()
    void attributeWhenIEqualsNotFound() {
        /* Branches:* (i == NotFound) : true*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(-1).when(target).indexOfKey("key1");
        //Act Statement(s)
        Attribute result = target.attribute("key1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(nullValue()));
            verify(target).indexOfKey("key1");
        });
    }


    //Sapient generated method id: ${1a48770c-a006-3be8-a782-3c24ff49f53c}, hash: 1ACF30FC55BD90388F629696A1484F9F
    @Test()
    void getIgnoreCaseWhenIEqualsNotFound() {
        /* Branches:* (i < size) : false  #  inside indexOfKeyIgnoreCase method* (i == NotFound) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = new Attributes();
            //Act Statement(s)
            String result = target.getIgnoreCase("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${c9745fe5-3e5a-3aa5-a959-2fef54445619}, hash: 408A5DFE444C06C960C3B8431F3A6EC1
    @Test()
    void addWhenCurCapGreaterThanOrEqualsToMinNewSize() {
        /* Branches:* (minNewSize >= size) : true  #  inside checkCapacity method* (curCap >= minNewSize) : true  #  inside checkCapacity method*/
        //Arrange Statement(s)
        Attributes target = new Attributes();
        //Act Statement(s)
        Attributes result = target.add("key1", "value1");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(target)));
    }

    //Sapient generated method id: ${21047f1e-8d98-309f-a615-a8938336cf30}, hash: E4DC4E6E26D0DDA673D43E46802D85EB
    @Test()
    void putWhenINotEqualsNotFound() {
        /* Branches:* (i != NotFound) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = spy(new Attributes());
            doReturn(0).when(target).indexOfKey("A");
            //Act Statement(s)
            Attributes result = target.put("A", "value1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).indexOfKey("A");
            });
        }
    }

    //Sapient generated method id: ${74a839d7-5e39-3371-b1d4-d1dbfe55a777}, hash: EA0D51F4E3A4260C2E26DFD43D34CD5B
    @Test()
    void putWhenIEqualsNotFound() {
        /* Branches:* (i != NotFound) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = spy(new Attributes());
            doReturn(-1).when(target).indexOfKey("A");
            doReturn(attributesMock).when(target).add("A", "value1");
            //Act Statement(s)
            Attributes result = target.put("A", "value1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).indexOfKey("A");
                verify(target).add("A", "value1");
            });
        }
    }

    //Sapient generated method id: ${737355b0-e0bb-3cee-8c99-dc08a573c538}, hash: EA492147CA1955D44C62069EF7E3F83C
    @Test()
    void userDataWhenCurCapGreaterThanOrEqualsToMinNewSize() {
        /* Branches:* (i == NotFound) : true* (minNewSize >= size) : true  #  inside checkCapacity method* (curCap >= minNewSize) : true  #  inside checkCapacity method*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(-1).when(target).indexOfKey("/jsoup.userdata");
        //Act Statement(s)
        Map<String, Object> result = target.userData();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result.size(), equalTo(0));
            verify(target).indexOfKey("/jsoup.userdata");
        });
    }

    //Sapient generated method id: ${3f98a00a-6285-3051-9e24-4457cbc84647}, hash: 36A9B454917EEE7FFCD6B3A3D56F3059
    @Test()
    void userData1WhenHasKeyNotSharedConstantsUserDataKey() {
        /* Branches:* (!hasKey(SharedConstants.UserDataKey)) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = spy(new Attributes());
            doReturn(false).when(target).hasKey("/jsoup.userdata");
            //Act Statement(s)
            Object result = target.userData("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).hasKey("/jsoup.userdata");
            });
        }
    }

    //Sapient generated method id: ${effaac07-bdaf-3919-8b67-41eeed42d929}, hash: 97983C110F69924AB74122065479F5E1
    @Test()
    void userData1WhenHasKeySharedConstantsUserDataKey() {
        /* Branches:* (!hasKey(SharedConstants.UserDataKey)) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = spy(new Attributes());
            doReturn(true).when(target).hasKey("/jsoup.userdata");
            Object object = new Object();
            Map<String, Object> stringObjectMap = new HashMap<>();
            stringObjectMap.put("A", object);
            doReturn(stringObjectMap).when(target).userData();
            //Act Statement(s)
            Object result = target.userData("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(object));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).hasKey("/jsoup.userdata");
                verify(target).userData();
            });
        }
    }

    //Sapient generated method id: ${34089c4a-fcad-3879-8c17-ff2562cec256}, hash: E6C9AB6A2150BFB5C8DA8CCDD7AD21CF
    @Test()
    void userData2Test() {
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = spy(new Attributes());
            Object object = new Object();
            Map<String, Object> stringObjectMap = new HashMap<>();
            stringObjectMap.put("A", object);
            doReturn(stringObjectMap).when(target).userData();
            //Act Statement(s)
            Attributes result = target.userData("A", object);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).userData();
            });
        }
    }

    //Sapient generated method id: ${dc8f1e1a-10df-3ed0-8352-37fe5a2a8b3d}, hash: BD33290FD8227CE8D21248121204D221
    @Test()
    void putIgnoreCaseWhenIEqualsNotFound() {
        /* Branches:* (i < size) : false  #  inside indexOfKeyIgnoreCase method* (i != NotFound) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = spy(new Attributes());
            doReturn(attributesMock).when(target).add("A", "value1");
            //Act Statement(s)
            target.putIgnoreCase("A", "value1");
            //Assert statement(s)
            assertAll("result", () -> {
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).add("A", "value1");
            });
        }
    }

    //Sapient generated method id: ${0df86825-3532-38e7-b474-55e06c16ce08}, hash: 5471254F6AF0BAE574280B862924B083
    @Test()
    void put1WhenValue() {
        /* Branches:* (value) : true*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doNothing().when(target).putIgnoreCase("key1", (String) null);
        //Act Statement(s)
        Attributes result = target.put("key1", true);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(target));
            verify(target).putIgnoreCase("key1", (String) null);
        });
    }

    //Sapient generated method id: ${021f8ba0-e2bd-305f-9d37-33b96a17b5de}, hash: 00C0639314C6D0A78492E03400196794
    @Test()
    void put1WhenNotValue() {
        /* Branches:* (value) : false*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doNothing().when(target).remove("key1");
        //Act Statement(s)
        Attributes result = target.put("key1", false);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(target));
            verify(target).remove("key1");
        });
    }

    //Sapient generated method id: ${2055ceaa-5479-3e53-8751-b5f52650f52f}, hash: 377B7EE979E2ED89ABA359BAE89BD4FE
    @Test()
    void put2Test() {
        //Arrange Statement(s)
        Attribute attributeMock = mock(Attribute.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn("return_of_getKey1").when(attributeMock).getKey();
            doReturn("return_of_getValue1").when(attributeMock).getValue();
            validate.when(() -> Validate.notNull(attributeMock)).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = spy(new Attributes());
            doReturn(attributesMock).when(target).put("return_of_getKey1", "return_of_getValue1");
            //Act Statement(s)
            Attributes result = target.put(attributeMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                verify(attributeMock).getKey();
                verify(attributeMock).getValue();
                validate.verify(() -> Validate.notNull(attributeMock), atLeast(1));
                verify(target).put("return_of_getKey1", "return_of_getValue1");
            });
        }
    }

    //Sapient generated method id: ${674db5c0-2c58-3e65-a2a2-7f9e13f37523}, hash: 29D11FCEFC97CA5FC8E8DFA4A469D5AB
    @Test()
    void remove1WhenIEqualsNotFound() {
        /* Branches:* (i != NotFound) : false*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(-1).when(target).indexOfKey("key1");
        //Act Statement(s)
        target.remove("key1");
        //Assert statement(s)
        assertAll("result", () -> verify(target).indexOfKey("key1"));
    }

    //Sapient generated method id: ${65f829c4-ba33-3fa1-8003-f87595df1bd8}, hash: FCE24ADB225E4D7154D6EC1CB9E0C044
    @Test()
    void remove1WhenShiftedGreaterThan0ThrowsArrayIndexOutOfBoundsException() {
        /* Branches:* (i != NotFound) : true* (index >= size) : true  #  inside remove method* (shifted > 0) : true  #  inside remove method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.isFalse(true)).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = spy(new Attributes());
            doReturn(0).when(target).indexOfKey("key1");
            //Act Statement(s)
            final ArrayIndexOutOfBoundsException result = assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
                target.remove("key1");
            });
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.isFalse(true), atLeast(1));
                verify(target).indexOfKey("key1");
            });
        }
    }

    //Sapient generated method id: ${77c6df50-631d-30ed-9250-10149196c45c}, hash: F342FAED8C57E74D4D1DD5A617E12F3A
    @Test()
    void remove1WhenIndexLessThanSizeAndShiftedGreaterThan0ThrowsArrayIndexOutOfBoundsException() {
        /* Branches:* (i != NotFound) : true* (index >= size) : false  #  inside remove method* (shifted > 0) : true  #  inside remove method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(-2).when(target).indexOfKey("key1");
        //Act Statement(s)
        final ArrayIndexOutOfBoundsException result = assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            target.remove("key1");
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            verify(target).indexOfKey("key1");
        });
    }

    //Sapient generated method id: ${f3c973e8-8ce1-3b99-8f35-5b48d95c99a1}, hash: A3BF8B1C0CC24F9E770D771995F175B0
    @Test()
    void removeIgnoreCaseWhenIEqualsNotFound() {
        /* Branches:* (i < size) : false  #  inside indexOfKeyIgnoreCase method* (i != NotFound) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = new Attributes();
            //Act Statement(s)
            target.removeIgnoreCase("A");
            //Assert statement(s)
            assertAll("result", () -> validate.verify(() -> Validate.notNull("A"), atLeast(1)));
        }
    }

    //Sapient generated method id: ${86e35c55-c198-3237-86bc-2f2e34dc6dbd}, hash: 34B815899697C57E868075DAC9001BE9
    @Test()
    void hasKeyWhenIndexOfKeyKeyNotEqualsNotFound() {
        /* Branches:* (indexOfKey(key) != NotFound) : true*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(1).when(target).indexOfKey("key1");
        //Act Statement(s)
        boolean result = target.hasKey("key1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.TRUE));
            verify(target).indexOfKey("key1");
        });
    }

    //Sapient generated method id: ${27e6ff24-bd1e-39eb-ab22-2109f8ddb4cf}, hash: A1A306F1D8782A81693CF2C962D844EC
    @Test()
    void hasKeyWhenIndexOfKeyKeyEqualsNotFound() {
        /* Branches:* (indexOfKey(key) != NotFound) : false*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(-1).when(target).indexOfKey("key1");
        //Act Statement(s)
        boolean result = target.hasKey("key1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.FALSE));
            verify(target).indexOfKey("key1");
        });
    }

    //Sapient generated method id: ${2f161652-028d-38d4-aa4f-13f5e2725522}, hash: 69B0E994C142EB154031998A27DF394A
    @Test()
    void hasKeyIgnoreCaseWhenIndexOfKeyIgnoreCaseKeyEqualsNotFound() {
        /* Branches:* (i < size) : false  #  inside indexOfKeyIgnoreCase method* (indexOfKeyIgnoreCase(key) != NotFound) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = new Attributes();
            //Act Statement(s)
            boolean result = target.hasKeyIgnoreCase("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }


    //Sapient generated method id: ${5170174e-b935-3384-b5b2-b4c6ac030e7d}, hash: 926DC1E2F076AD46AF2D222C9C75E221
    @Test()
    void hasDeclaredValueForKeyWhenIIndexOfValsIsNull() {
        /* Branches:* (i != NotFound) : true* (vals[i] != null) : false*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(1).when(target).indexOfKey("key1");
        //Act Statement(s)
        boolean result = target.hasDeclaredValueForKey("key1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.FALSE));
            verify(target).indexOfKey("key1");
        });
    }

    //Sapient generated method id: ${1c8dab98-739d-3a27-bf8d-3b5a970246a3}, hash: 3F9B2FBBAFF7C153077898A169216AE1
    @Test()
    void hasDeclaredValueForKeyIgnoreCaseWhenIEqualsNotFound() {
        /* Branches:* (i < size) : false  #  inside indexOfKeyIgnoreCase method* (i != NotFound) : false*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Attributes target = new Attributes();
            //Act Statement(s)
            boolean result = target.hasDeclaredValueForKeyIgnoreCase("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${0a253188-e32a-3fb1-a265-54df02efeff0}, hash: F616D7226E3D25E7B6FA4438EA60AC46
    @Test()
    void sizeTest() {
        //Arrange Statement(s)
        Attributes target = new Attributes();
        //Act Statement(s)
        int result = target.size();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(0)));
    }

    //Sapient generated method id: ${76867866-9dcb-37e5-8f01-8958731641a7}, hash: F96C866CBFB8AEF11DB69756739C808D
    @Test()
    void isEmptyWhenSizeEquals0() {
        /* Branches:* (size == 0) : true*/
        //Arrange Statement(s)
        Attributes target = new Attributes();
        //Act Statement(s)
        boolean result = target.isEmpty();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.TRUE)));
    }

    //Sapient generated method id: ${5e48e5fa-68ba-3eec-becf-9000980860dd}, hash: C0A8058C9354749941DCAA64DA74206D
    @Test()
    void addAllWhenIncomingSizeEquals0() {
        /* Branches:* (incoming.size() == 0) : true*/
        //Arrange Statement(s)
        doReturn(0).when(incomingMock).size();
        Attributes target = new Attributes();
        //Act Statement(s)
        target.addAll(incomingMock);
        //Assert statement(s)
        assertAll("result", () -> verify(incomingMock).size());
    }


    //Sapient generated method id: ${341efd92-6ed0-3ef5-8cf2-c3cfb0c4f7e4}, hash: A722C7B7381CD52554ACBF357C143426
    @Test()
    void sourceRangeWhenHasKeyNotKey() {
        /* Branches:* (!hasKey(key)) : true*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(false).when(target).hasKey("key1");
        //Act Statement(s)
        Range.AttributeRange result = target.sourceRange("key1");
        Range.AttributeRange attributeRange = Range.AttributeRange.UntrackedAttr;
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(attributeRange));
            verify(target).hasKey("key1");
        });
    }

    //Sapient generated method id: ${9b2b6e20-ef8e-3cd8-b0da-84f5288cdd34}, hash: F942050452F0B17955E96CC9B9FD51CE
    @Test()
    void sourceRangeWhenRangesIsNull() {
        /* Branches:* (!hasKey(key)) : false* (ranges == null) : true*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(true).when(target).hasKey("key1");
        doReturn(null).when(target).getRanges();
        //Act Statement(s)
        Range.AttributeRange result = target.sourceRange("key1");
        Range.AttributeRange attributeRange = Range.AttributeRange.UntrackedAttr;
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(attributeRange));
            verify(target).hasKey("key1");
            verify(target).getRanges();
        });
    }

    //Sapient generated method id: ${1b7a412f-890c-3aae-a4e6-abb2e41cee65}, hash: 5D6B240B3356DC1AEC36DD55EF2F53C1
    @Test()
    void sourceRangeWhenRangeIsNotNull() {
        /* Branches:* (!hasKey(key)) : false* (ranges == null) : false* (range != null) : true*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(true).when(target).hasKey("key1");
        Range.AttributeRange attributeRangeMock = mock(Range.AttributeRange.class);
        Map<String, Range.AttributeRange> stringRangeAttributeRangeMap = new HashMap<>();
        stringRangeAttributeRangeMap.put("key1", attributeRangeMock);
        doReturn(stringRangeAttributeRangeMap).when(target).getRanges();
        //Act Statement(s)
        Range.AttributeRange result = target.sourceRange("key1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(attributeRangeMock));
            verify(target).hasKey("key1");
            verify(target).getRanges();
        });
    }

    //Sapient generated method id: ${9d82b89c-7638-316c-a494-4924ee315c4b}, hash: 40F2D1446471E67C3F137D4554DE853C
    @Test()
    void sourceRangeWhenRangeIsNull() {
        /* Branches:* (!hasKey(key)) : false* (ranges == null) : false* (range != null) : false*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(true).when(target).hasKey("key1");
        Map<String, Range.AttributeRange> stringRangeAttributeRangeMap = new HashMap<>();
        stringRangeAttributeRangeMap.put("key1", (Range.AttributeRange) null);
        doReturn(stringRangeAttributeRangeMap).when(target).getRanges();
        //Act Statement(s)
        Range.AttributeRange result = target.sourceRange("key1");
        Range.AttributeRange attributeRange = Range.AttributeRange.UntrackedAttr;
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(attributeRange));
            verify(target).hasKey("key1");
            verify(target).getRanges();
        });
    }

    //Sapient generated method id: ${f9cb6f07-0462-3d3c-af90-9de6e813a02e}, hash: F7EB6551F26B9011815455AAD1C346E5
    @Test()
    void getRangesTest() {
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        Map map = new HashMap<>();
        doReturn(map).when(target).userData("jsoup.attrs");
        //Act Statement(s)
        Map<String, Range.AttributeRange> result = target.getRanges();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(map));
            verify(target).userData("jsoup.attrs");
        });
    }

    //Sapient generated method id: ${78c09fb6-edcf-3ce7-9932-6ef4ffc152b3}, hash: 662E596436BE763D677CD8D8A2F61528
    @Test()
    void iteratorTest() {
        //Arrange Statement(s)
        Attributes target = new Attributes();
        //Act Statement(s)
        Iterator<Attribute> result = target.iterator();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${b1fd6784-ce2b-3da9-83d1-fa40b4f92542}, hash: 6BECDBAD14C142F52985C6D5A7F510A7
    @Test()
    void asListWhenINotLessThanSize() {
        /* Branches:* (i < size) : false*/
        //Arrange Statement(s)
        Attributes target = new Attributes();
        //Act Statement(s)
        List<Attribute> result = target.asList();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result.size(), equalTo(0)));
    }

    //Sapient generated method id: ${4a80fd18-810e-37d0-ad09-72527f9540a6}, hash: 05A2B2F55AC9FE119BE1D7FFA18AEA71
    @Test()
    void datasetTest() {
        //Arrange Statement(s)
        Attributes target = new Attributes();
        //Act Statement(s)
        Map<String, String> result = target.dataset();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }


    //Sapient generated method id: ${5155c958-b402-36fc-bd0b-760da8db1448}, hash: AE5E2E5397E056FCCBFE951CE0F6820F
    @Test()
    void html1WhenINotLessThanSz() throws IOException {
        /* Branches:* (i < sz) : false*/
        //Arrange Statement(s)
        Attributes target = new Attributes();
        Appendable appendableMock = mock(Appendable.class);
        Document.OutputSettings documentOutputSettingsMock = mock(Document.OutputSettings.class);
        //Act Statement(s)
        target.html(appendableMock, documentOutputSettingsMock);
    }

    //Sapient generated method id: ${363d3698-f34c-39ad-914f-376a19498023}, hash: 0668A94592EB792C2FB6A0806A064F3E
    @Test()
    void toStringTest() throws IOException {
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn("return_of_html1").when(target).html();
        //Act Statement(s)
        String result = target.toString();
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo("return_of_html1"));
            verify(target).html();
        });
    }

    //Sapient generated method id: ${4940d98d-11fd-3bb1-87e7-4e48368ce6b3}, hash: 71A9ED1C320ED541D13FA6C7050A69C1
    @Test()
    void cloneTest() throws CloneNotSupportedException {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        Attributes target = new Attributes();
        //Act Statement(s)
        Attributes result = target.clone();
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }


    //Sapient generated method id: ${968e73dd-620e-3162-8ada-a3be7e46af1d}, hash: 33E9B56B54CD5A3145F8C5F2621CB69C
    @Test()
    void normalizeWhenINotLessThanSize() {
        /* Branches:* (i < size) : false*/
        //Arrange Statement(s)
        Attributes target = new Attributes();
        //Act Statement(s)
        target.normalize();
    }

    //Sapient generated method id: ${224f18e5-d4aa-3032-90e0-ec457193f377}, hash: 2EFD360060951CD7C8EE0F5A0043E4EB
    @Test()
    void deduplicateWhenIsEmpty() {
        /* Branches:* (isEmpty()) : true*/
        //Arrange Statement(s)
        Attributes target = spy(new Attributes());
        doReturn(true).when(target).isEmpty();
        ParseSettings parseSettingsMock = mock(ParseSettings.class);
        //Act Statement(s)
        int result = target.deduplicate(parseSettingsMock);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(0));
            verify(target).isEmpty();
        });
    }

    //Sapient generated method id: ${94000ce2-81aa-3d3c-bbd5-b512ee692445}, hash: 094E81CD77615A72CF4DCB64B6141594
    @Test()
    void deduplicateWhenJIndexOfKeysIsNull() {
        /* Branches:* (isEmpty()) : false* (i < keys.length) : true* (j < keys.length) : true* (keys[j] == null) : true*/
        //Arrange Statement(s)
        ParseSettings settingsMock = mock(ParseSettings.class);
        doReturn(false).when(settingsMock).preserveAttributeCase();
        Attributes target = spy(new Attributes());
        doReturn(false).when(target).isEmpty();
        //Act Statement(s)
        int result = target.deduplicate(settingsMock);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(0));
            verify(settingsMock).preserveAttributeCase();
            verify(target).isEmpty();
        });
    }

    //Sapient generated method id: ${a720a4fb-fead-342f-81a3-343657ac5843}, hash: 0A136D57D94768BF2FA05A5DA923C40D
    @Test()
    void internalKeyTest() {
        //Act Statement(s)
        String result = Attributes.internalKey("A");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("/A")));
    }

    //Sapient generated method id: ${88963be0-faaf-33d6-8e8f-6495ecbb8fc7}, hash: 62994D96FE9B1167340E35049409AC98
    @Test()
    void isInternalKeyWhenKeyCharAt0EqualsInternalPrefix() {
        /* Branches:* (key != null) : true* (key.length() > 1) : true* (key.charAt(0) == InternalPrefix) : true*/
        //Act Statement(s)
        boolean result = Attributes.isInternalKey("/A");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.TRUE)));
    }

    //Sapient generated method id: ${74f6f497-35fe-3a06-a842-0ac41820ebcf}, hash: BA0BB317B78B90920B95D2A91E04882D
    @Test()
    void isInternalKeyWhenKeyCharAt0NotEqualsInternalPrefix() {
        /* Branches:* (key != null) : true* (key.length() > 1) : true* (key.charAt(0) == InternalPrefix) : false*/
        //Act Statement(s)
        boolean result = Attributes.isInternalKey("AB");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.FALSE)));
    }
}
