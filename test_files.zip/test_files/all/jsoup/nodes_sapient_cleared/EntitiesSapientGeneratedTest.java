package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import org.mockito.stubbing.Answer;
import org.jsoup.SerializationException;
import org.mockito.MockedStatic;
import org.jsoup.internal.StringUtil;

import java.nio.charset.CharsetEncoder;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class EntitiesSapientGeneratedTest {

    private final Appendable appendableMock = mock(Appendable.class);

    private final CharsetEncoder charsetEncoderMock = mock(CharsetEncoder.class);

    private final Document.OutputSettings documentOutputSettingsMock = mock(Document.OutputSettings.class);

    private final Document.OutputSettings outMock = mock(Document.OutputSettings.class);

    //Sapient generated method id: ${cbb3b459-7923-3cb8-a74d-232e4c92dbb4}, hash: 378B157B7FB89869E45AA2D1F16A40C1
    @Test()
    void isNamedEntityWhenExtendedCodepointForNameNameEqualsEmpty() {
        /* Branches:* (extended.codepointForName(name) != empty) : false*/
        //Act Statement(s)
        boolean result = Entities.isNamedEntity("");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.FALSE)));
    }


    //Sapient generated method id: ${5c1c2910-8c37-387c-8bea-56d2a5c13749}, hash: 2547518F24D1836832786A4D0880C379
    @Test()
    void isBaseNamedEntityWhenBaseCodepointForNameNameEqualsEmpty() {
        /* Branches:* (base.codepointForName(name) != empty) : false*/
        //Act Statement(s)
        boolean result = Entities.isBaseNamedEntity("");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.FALSE)));
    }

    //Sapient generated method id: ${60cdb437-8204-329e-86a1-1fab4145aadf}, hash: 02E7E00FBE24A6E7F39646C22CA16C8B
    @Test()
    void getByNameWhenCodepointEqualsEmpty() {
        /* Branches:* (val != null) : false* (codepoint != empty) : false*/
        //Act Statement(s)
        String result = Entities.getByName("");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("")));
    }


    //Sapient generated method id: ${c2b567fc-2307-3f10-b94e-252b9c4bc743}, hash: 6130061266B294EDA619E163FECEDB10
    @Test()
    void codepointsForNameWhenCodepointEqualsEmpty() {
        /* Branches:* (val != null) : false* (codepoint != empty) : false*/
        //Arrange Statement(s)
        int[] intArray = new int[]{};
        //Act Statement(s)
        int result = Entities.codepointsForName("", intArray);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(0)));
    }

    //Sapient generated method id: ${b81183d4-96b8-357d-a42d-979cb80ef48e}, hash: 4F03B844095D145D50297CABA321BA5F
    @Test()
    void escapeWhenStringIsNull() throws IOException {
        /* Branches:* (string == null) : true*/
        //Act Statement(s)
        String result = Entities.escape((String) null, documentOutputSettingsMock);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("")));
    }


    //Sapient generated method id: ${1e2c184e-4c7a-396f-9d04-8882ccbee852}, hash: 4CD71E82FA8BFDC83EE28E4E584E6E23
    @Test()
    void escape1WhenDefaultOutputIsNull() throws IOException {
        /* Branches:* (DefaultOutput == null) : true*/
        //Arrange Statement(s)
        try (MockedStatic<Entities> entities = mockStatic(Entities.class, CALLS_REAL_METHODS)) {
            entities.when(() -> Entities.escape(eq("string1"), (Document.OutputSettings) any())).thenReturn("return_of_escape1");
            //Act Statement(s)
            String result = Entities.escape("string1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_escape1"));
                entities.verify(() -> Entities.escape(eq("string1"), (Document.OutputSettings) any()), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${7ec3f411-3809-3934-af13-3eaf1b61b292}, hash: 2013AC1788E6EC8898F6F8F633BDDAE4
    @Test()
    void escape2WhenNotReachedNonWhite() throws IOException {
        /* Branches:* (offset < length) : true* (normaliseWhite) : true* (StringUtil.isWhitespace(codePoint)) : true* (stripLeadingWhite) : true* (!reachedNonWhite) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class)) {
            doReturn(Entities.EscapeMode.xhtml).when(outMock).escapeMode();
            doReturn(charsetEncoderMock).when(outMock).encoder();
            stringUtil.when(() -> StringUtil.isWhitespace(65)).thenReturn(true);
            //Act Statement(s)
            Entities.escape(appendableMock, "A", outMock, false, true, true, false);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).escapeMode();
                verify(outMock).encoder();
                stringUtil.verify(() -> StringUtil.isWhitespace(65), atLeast(1));
            });
        }
    }


    //Sapient generated method id: ${a281549a-03c9-3a18-b413-c6eb01308669}, hash: 598C1C1ECE886CE9786D6837C9A07E74
    @Test()
    void escape2WhenTrimTrailing() throws IOException {
        /* Branches:* (offset < length) : true* (normaliseWhite) : true* (StringUtil.isWhitespace(codePoint)) : true* (stripLeadingWhite) : false* (lastWasWhite) : false* (trimTrailing) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class)) {
            doReturn(Entities.EscapeMode.xhtml).when(outMock).escapeMode();
            doReturn(charsetEncoderMock).when(outMock).encoder();
            stringUtil.when(() -> StringUtil.isWhitespace(65)).thenReturn(true);
            //Act Statement(s)
            Entities.escape(appendableMock, "A", outMock, false, true, false, true);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).escapeMode();
                verify(outMock).encoder();
                stringUtil.verify(() -> StringUtil.isWhitespace(65), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${2dbaaa35-9de1-3325-95d2-89b408cb9efb}, hash: 8F76B7DDB6CBE37081422C1B155F301B
    @Test()
    void escape2WhenNotTrimTrailing() throws IOException {
        /* Branches:* (offset < length) : true* (normaliseWhite) : true* (StringUtil.isWhitespace(codePoint)) : true* (stripLeadingWhite) : false* (lastWasWhite) : false* (trimTrailing) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class)) {
            doReturn(Entities.EscapeMode.xhtml).when(outMock).escapeMode();
            doReturn(charsetEncoderMock).when(outMock).encoder();
            stringUtil.when(() -> StringUtil.isWhitespace(65)).thenReturn(true);
            //Act Statement(s)
            Entities.escape(appendableMock, "A", outMock, false, true, false, false);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).escapeMode();
                verify(outMock).encoder();
                stringUtil.verify(() -> StringUtil.isWhitespace(65), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${6b8e098d-400f-3658-873c-126e4afeb2d2}, hash: ECBC25838A34BEEBF8AC66B35D0AE95C
    @Test()
    void escape2WhenSwitchCCaseDefaultAndCNotLessThan32ThrowsNullPointerException() throws IOException {
        /* Branches:* (offset < length) : true* (normaliseWhite) : true* (StringUtil.isWhitespace(codePoint)) : false* (skipped) : false* (codePoint < Character.MIN_SUPPLEMENTARY_CODE_POINT) : true* (switch(c) = default) : true* (c < 0x20) : false*/
        //Arrange Statement(s)
        doReturn(Entities.EscapeMode.xhtml).when(outMock).escapeMode();
        doReturn(charsetEncoderMock).when(outMock).encoder();
        //Act Statement(s)
        final NullPointerException result = assertThrows(NullPointerException.class, () -> {
            Entities.escape(appendableMock, "A", outMock, false, true, false, false);
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            verify(outMock).escapeMode();
            verify(outMock).encoder();
        });
    }


    //Sapient generated method id: ${208f31ce-9725-3a93-a830-df75e660c117}, hash: 1E4ED47AEA124DF0E17ACC1C6A24A6F2
    @Test()
    void unescapeTest() {
        //Act Statement(s)
        String result = Entities.unescape("A");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("A")));
    }

    //Sapient generated method id: ${ec9f3f99-4ce6-3244-8772-53f3e02b0ca8}, hash: 4DE52538A3F374F0E8D25EE3E8AC6BE9
    @Test()
    void unescape1Test() {
        //Act Statement(s)
        String result = Entities.unescape("A", false);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("A")));
    }
}
