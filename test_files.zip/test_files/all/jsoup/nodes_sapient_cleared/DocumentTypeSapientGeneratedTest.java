package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import org.mockito.stubbing.Answer;
import org.mockito.MockedStatic;
import org.jsoup.internal.StringUtil;
import org.jsoup.helper.Validate;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class DocumentTypeSapientGeneratedTest {

    private final Appendable appendableMock = mock(Appendable.class);

    private final Document.OutputSettings outMock = mock(Document.OutputSettings.class);

    //Sapient generated method id: ${1823ed73-42f7-36cc-b65a-39720ee52ad9}, hash: 9085B7479E37463C8CB867AE71731D91
    @Test()
    void setPubSysKeyWhenValueIsNotNull() {
        /* Branches:* (value != null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            DocumentType target = spy(new DocumentType("A", "B", "C"));
            doReturn(nodeMock).when(target).attr("pubSysKey", "value1");
            //Act Statement(s)
            target.setPubSysKey("value1");
            //Assert statement(s)
            assertAll("result", () -> {
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
                verify(target).attr("pubSysKey", "value1");
            });
        }
    }

    //Sapient generated method id: ${135d2cf9-fee1-3588-b3da-a55f6d066d25}, hash: 60AD7E95F4FC8961E788D3431CAA1754
    @Test()
    void nameTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            DocumentType target = spy(new DocumentType("A", "B", "C"));
            doReturn("return_of_attr1").when(target).attr("name");
            //Act Statement(s)
            String result = target.name();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_attr1"));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
                verify(target).attr("name");
            });
        }
    }

    //Sapient generated method id: ${d3bc5182-de3e-3c16-b17b-9c2a3a7b3712}, hash: 58D8F65253F65F4F554EC17C2B29B1DA
    @Test()
    void publicIdTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            DocumentType target = spy(new DocumentType("A", "B", "C"));
            doReturn("return_of_attr1").when(target).attr("publicId");
            //Act Statement(s)
            String result = target.publicId();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_attr1"));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
                verify(target).attr("publicId");
            });
        }
    }

    //Sapient generated method id: ${1e37926c-f186-3201-8579-93553ceb8d26}, hash: 84A658A6C13C23CAF53264D3665EB1D9
    @Test()
    void systemIdTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            DocumentType target = spy(new DocumentType("A", "B", "C"));
            doReturn("return_of_attr1").when(target).attr("systemId");
            //Act Statement(s)
            String result = target.systemId();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_attr1"));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
                verify(target).attr("systemId");
            });
        }
    }

    //Sapient generated method id: ${8dd87bf2-664a-3f64-ad35-7dd70d78f42d}, hash: 8D87E6C4553B06C696A1370F193DB5E2
    @Test()
    void nodeNameTest() {
        /**
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            DocumentType target = new DocumentType("A", "B", "C");
            //Act Statement(s)
            String result = target.nodeName();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("#doctype"));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
            });
        }
    }

}
