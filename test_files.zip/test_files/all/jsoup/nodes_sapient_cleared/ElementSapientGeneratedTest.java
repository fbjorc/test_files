package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.mockito.InjectMocks;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import org.jsoup.select.NodeVisitor;
import org.jsoup.internal.Normalizer;
import org.mockito.MockitoAnnotations;

import java.util.HashSet;

import org.jsoup.parser.TokenQueue;

import java.util.HashMap;

import org.jsoup.internal.StringUtil;

import java.util.ArrayList;

import org.mockito.stubbing.Answer;
import org.jsoup.select.Elements;
import org.jsoup.select.QueryParser;

import java.util.stream.Stream;

import org.jsoup.parser.Tag;
import org.jsoup.parser.Parser;
import org.jsoup.select.Evaluator;

import java.util.regex.PatternSyntaxException;
import java.util.List;
import java.util.regex.Pattern;

import org.jsoup.select.NodeFilter;

import java.util.Map;
import java.util.function.Consumer;

import org.jsoup.select.Selector;

import java.util.Set;

import org.jsoup.helper.Validate;
import org.jsoup.parser.ParseSettings;

import java.util.Collection;

import org.mockito.MockedStatic;
import org.jsoup.select.NodeTraversor;
import org.jsoup.select.Collector;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.verify;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeast;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.mockito.Mockito.mockStatic;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class ElementSapientGeneratedTest {

    private final Tag tagMock = mock(Tag.class, "tag");

    private final Attributes attributesMock = mock(Attributes.class, "attributes");

    private final Node parentNodeMock = mock(Node.class, "parentNode");

    private AutoCloseable autoCloseableMocks;

    @InjectMocks()
    private Element target;

    @AfterEach()
    public void afterTest() throws Exception {
        if (autoCloseableMocks != null)
            autoCloseableMocks.close();
    }

    //Sapient generated method id: ${45b883a5-e2c0-3db0-ae8a-efd85a652aac}, hash: 4CD609F2C9F51A1E6E7B855C9CB1F725
    @Test()
    void hasChildNodesWhenChildNodesNotEqualsEmptyNodes() {
        /* Branches:* (childNodes != EmptyNodes) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            boolean result = target.hasChildNodes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${f6f656d5-4117-30c4-a673-43aaa801d806}, hash: 55B74DA508ABD1AEFD79C89C7A2D356D
    @Test()
    void hasChildNodesWhenChildNodesEqualsEmptyNodes() {
        /* Branches:* (childNodes != EmptyNodes) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            boolean result = target.hasChildNodes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${f318809a-a07d-3fd6-919e-7f841b063574}, hash: DE85AD40166B96F902595CC78FFC971A
    @Test()
    void ensureChildNodesWhenChildNodesEqualsEmptyNodes() {
        /* Branches:* (childNodes == EmptyNodes) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            List<Node> result = target.ensureChildNodes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${04769c7c-d3ed-35b2-9595-18fce5701bc1}, hash: 7E373AFA75C95B556D93D45234CF7C57
    @Test()
    void hasAttributesWhenAttributesIsNotNull() {
        /* Branches:* (attributes != null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            boolean result = target.hasAttributes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${6189da20-11f7-32e2-a5c1-935493498b4e}, hash: DB0A480AF2D6C0E0865A4ADCA522FA6B
    @Test()
    void hasAttributesWhenAttributesIsNull() {
        /* Branches:* (attributes != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", (Attributes) null);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            boolean result = target.hasAttributes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${8fa51068-1870-3d9f-8703-d416621bdf57}, hash: 6955B0FEE9E61CD8EDE9F36FF6205959
    @Test()
    void attributesWhenAttributesIsNull() {
        /* Branches:* (attributes == null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", (Attributes) null);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Attributes result = target.attributes();
            Attributes attributes = new Attributes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(attributes));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${068ec3dd-451c-3e47-90b3-a6f3bd999893}, hash: BB9578DF2E894416AC2B3A3DCACB6A5A
    @Test()
    void baseUriWhenElAttributesHasKeyKey() {
        /* Branches:* (el != null) : true  #  inside searchUpForAttribute method* (el.attributes != null) : true  #  inside searchUpForAttribute method* (el.attributes.hasKey(key)) : true  #  inside searchUpForAttribute method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.baseUri();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_get1"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${262c9a7f-5690-37f6-987b-cb3de2a3e183}, hash: 54846C1C33B9B10D8211E0576C3BAF4F
    @Test()
    void baseUriWhenElAttributesNotHasKeyKey() {
        /* Branches:* (el != null) : true  #  inside searchUpForAttribute method* (el.attributes != null) : true  #  inside searchUpForAttribute method* (el.attributes.hasKey(key)) : false  #  inside searchUpForAttribute method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.baseUri();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${0a151b0d-81ef-3bff-a474-aa51a2363945}, hash: A802E0E22F43B7109C7D0A8AD1996249
    @Test()
    void doSetBaseUriTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Attributes attributesMock2 = mock(Attributes.class);
        Attributes attributesMock3 = mock(Attributes.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(attributesMock2).when(target).attributes();
            doReturn(attributesMock3).when(attributesMock2).put("key1", "baseUri1");
            //Act Statement(s)
            target.doSetBaseUri("baseUri1");
            //Assert statement(s)
            assertAll("result", () -> {
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).attributes();
                verify(attributesMock2).put("key1", "baseUri1");
            });
        }
    }

    //Sapient generated method id: ${3f78a9a4-635d-3e6a-9823-acb8c48fe1c6}, hash: 31C5AFE30949172C0D2061F7892C9199
    @Test()
    void childNodeSizeTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            int result = target.childNodeSize();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${8dd87bf2-664a-3f64-ad35-7dd70d78f42d}, hash: BE3BFD0ED6B0F0D54AAA83DEAA223DA4
    @Test()
    void nodeNameTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("return_of_getName1").when(tagMock).getName();
            //Act Statement(s)
            String result = target.nodeName();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_getName1"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).getName();
            });
        }
    }

    //Sapient generated method id: ${8e24fc40-8f52-3636-a7ae-3028c84c044c}, hash: 01C9B09D9B695B97E780D2F955C3EFB7
    @Test()
    void tagNameTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("return_of_getName1").when(tagMock).getName();
            //Act Statement(s)
            String result = target.tagName();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_getName1"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).getName();
            });
        }
    }

    //Sapient generated method id: ${16f4f10a-abf2-3bcb-a13f-71bd1c9d398b}, hash: 437CD9EF535D2FC6EF51872A10CE63BF
    @Test()
    void normalNameTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("return_of_normalName1").when(tagMock).normalName();
            //Act Statement(s)
            String result = target.normalName();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_normalName1"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).normalName();
            });
        }
    }

    //Sapient generated method id: ${0f57ddeb-08ad-3c78-a0e5-943ca5b6453a}, hash: 144561353CCCBD47D0F20F01DA8649CC
    @Test()
    void elementIsWhenTagNamespaceEqualsNamespace() {
        /* Branches:* (tag.normalName().equals(normalName)) : true* (tag.namespace().equals(namespace)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("B").when(tagMock).normalName();
            doReturn("C").when(tagMock).namespace();
            //Act Statement(s)
            boolean result = target.elementIs("B", "C");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).normalName();
                verify(tagMock).namespace();
            });
        }
    }

    //Sapient generated method id: ${66fb33e7-2c22-3959-a3c1-8c9ee372955f}, hash: 653A21227E411F480FE9F89ADDB2E443
    @Test()
    void elementIsWhenTagNamespaceNotEqualsNamespace() {
        /* Branches:* (tag.normalName().equals(normalName)) : true* (tag.namespace().equals(namespace)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("B").when(tagMock).normalName();
            doReturn("C").when(tagMock).namespace();
            //Act Statement(s)
            boolean result = target.elementIs("B", "D");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).normalName();
                verify(tagMock).namespace();
            });
        }
    }

    //Sapient generated method id: ${aa5b9673-d06b-3c89-9f19-626f2d41ec08}, hash: 162A2DCDCBF1D8D49CFC18A5BC38BC09
    @Test()
    void tagName1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock2 = mock(Tag.class);
        ParseSettings parseSettingsMock = mock(ParseSettings.class);
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<Tag> tag = mockStatic(Tag.class);
             MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmptyParam("B", "tagName")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmptyParam("C", "namespace")).thenAnswer((Answer<Void>) invocation -> null);
            tag.when(() -> Tag.valueOf("B", "C", parseSettingsMock)).thenReturn(tagMock2);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("C").when(tagMock).namespace();
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            doReturn(parseSettingsMock).when(parserMock).settings();
            //Act Statement(s)
            Element result = target.tagName("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmptyParam("B", "tagName"), atLeast(1));
                validate.verify(() -> Validate.notEmptyParam("C", "namespace"), atLeast(1));
                tag.verify(() -> Tag.valueOf("B", "C", parseSettingsMock), atLeast(1));
                verify(tagMock).namespace();
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).settings();
            });
        }
    }

    //Sapient generated method id: ${5fc5d915-a9ad-336a-addd-73a51dbf1354}, hash: 73E28D5F0A24D72782F9310390199D66
    @Test()
    void tagName2Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock2 = mock(Tag.class);
        ParseSettings parseSettingsMock = mock(ParseSettings.class);
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<Tag> tag = mockStatic(Tag.class);
             MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmptyParam("B", "tagName")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmptyParam("C", "namespace")).thenAnswer((Answer<Void>) invocation -> null);
            tag.when(() -> Tag.valueOf("B", "C", parseSettingsMock)).thenReturn(tagMock2);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            doReturn(parseSettingsMock).when(parserMock).settings();
            //Act Statement(s)
            Element result = target.tagName("B", "C");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmptyParam("B", "tagName"), atLeast(1));
                validate.verify(() -> Validate.notEmptyParam("C", "namespace"), atLeast(1));
                tag.verify(() -> Tag.valueOf("B", "C", parseSettingsMock), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).settings();
            });
        }
    }

    //Sapient generated method id: ${1492b9c2-b980-3a4a-9204-051aa921c1c9}, hash: 2BA369D04B43518F6CA39F7B0D87A3AF
    @Test()
    void tagTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Tag result = target.tag();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(tagMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${ad1d694e-b53c-30b0-8291-25ce5ea68628}, hash: 3374BA5E25EFE17A90A1473BD16519A7
    @Test()
    void isBlockWhenTagIsBlock() {
        /* Branches:* (tag.isBlock()) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(true).when(tagMock).isBlock();
            //Act Statement(s)
            boolean result = target.isBlock();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).isBlock();
            });
        }
    }

    //Sapient generated method id: ${579b4d8e-7c9f-3107-a3e0-adb7b09f7446}, hash: 815C58A4B4E34502C6A107DB87CF3CC9
    @Test()
    void isBlockWhenTagNotIsBlock() {
        /* Branches:* (tag.isBlock()) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(tagMock).isBlock();
            //Act Statement(s)
            boolean result = target.isBlock();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).isBlock();
            });
        }
    }

    //Sapient generated method id: ${e6608d60-6fec-39df-b5d8-c85fe6b64205}, hash: 110B2879864DE8C7F3E5D7DFBFA1143F
    @Test()
    void idWhenAttributesIsNotNull() {
        /* Branches:* (attributes != null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("return_of_getIgnoreCase1").when(attributesMock).getIgnoreCase("id");
            //Act Statement(s)
            String result = target.id();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_getIgnoreCase1"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(attributesMock).getIgnoreCase("id");
            });
        }
    }

    //Sapient generated method id: ${b3b04b7d-4b35-3fff-b3f4-34ba7b557c08}, hash: E097F7B607803A94A5183DE962C338DE
    @Test()
    void idWhenAttributesIsNull() {
        /* Branches:* (attributes != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", (Attributes) null);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.id();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${4c693c4a-24f4-3af2-9832-b9d852b466ea}, hash: E6A20D4DCE1C6E7B91B61CFE1D8A8D57
    @Test()
    void id1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).attr("id", "B");
            //Act Statement(s)
            Element result = target.id("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).attr("id", "B");
            });
        }
    }

    //Sapient generated method id: ${d93c4d3b-968d-3621-b928-248d14fa4fef}, hash: 74AB438F6EC9137CA2BACEBDD223D132
    @Test()
    void attr2Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Parser parserMock = mock(Parser.class);
        ParseSettings parseSettingsMock = mock(ParseSettings.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            doReturn(parseSettingsMock).when(parserMock).settings();
            doReturn("return_of_normalizeAttribute1").when(parseSettingsMock).normalizeAttribute("attributeKey1");
            //Act Statement(s)
            Element result = target.attr("attributeKey1", "attributeValue1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).settings();
                verify(parseSettingsMock).normalizeAttribute("attributeKey1");
            });
        }
    }

    //Sapient generated method id: ${b9d39181-67d1-3e2d-be99-888fea023c83}, hash: C243B44945976705546110E63756D013
    @Test()
    void attr3Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Attributes attributesMock2 = mock(Attributes.class);
        Attributes attributesMock3 = mock(Attributes.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(attributesMock2).when(target).attributes();
            doReturn(attributesMock3).when(attributesMock2).put("attributeKey1", false);
            //Act Statement(s)
            Element result = target.attr("attributeKey1", false);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).attributes();
                verify(attributesMock2).put("attributeKey1", false);
            });
        }
    }

    //Sapient generated method id: ${2187b7c3-847f-3e8c-9ce3-13cefa5ee6f8}, hash: 93684809702AB1C967A2A343D7A5C864
    @Test()
    void attributeWhenHasAttributes() {
        /* Branches:* (hasAttributes()) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Attributes attributesMock2 = mock(Attributes.class);
        Attribute attributeMock = mock(Attribute.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(true).when(target).hasAttributes();
            doReturn(attributesMock2).when(target).attributes();
            doReturn(attributeMock).when(attributesMock2).attribute("key1");
            //Act Statement(s)
            Attribute result = target.attribute("key1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(attributeMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).hasAttributes();
                verify(target).attributes();
                verify(attributesMock2).attribute("key1");
            });
        }
    }

    //Sapient generated method id: ${fb80177d-5b6e-393e-857f-e00bc1363a48}, hash: A72EE3DB95DC5B45F863E61D0153B87F
    @Test()
    void attributeWhenHasAttributesNot() {
        /* Branches:* (hasAttributes()) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(target).hasAttributes();
            //Act Statement(s)
            Attribute result = target.attribute("key1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).hasAttributes();
            });
        }
    }

    //Sapient generated method id: ${4a80fd18-810e-37d0-ad09-72527f9540a6}, hash: 2ECA8CA685E75257BD409223D19764B0
    @Test()
    void datasetTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Attributes attributesMock2 = mock(Attributes.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(attributesMock2).when(target).attributes();
            Map<String, String> stringStringMap = new HashMap<>();
            doReturn(stringStringMap).when(attributesMock2).dataset();
            //Act Statement(s)
            Map<String, String> result = target.dataset();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(stringStringMap));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).attributes();
                verify(attributesMock2).dataset();
            });
        }
    }

    //Sapient generated method id: ${192853e0-b4d6-3408-b828-7863ac42eb5d}, hash: B2D353C276F0E3B80FD73AF9BE10AB24
    @Test()
    void parent1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.parent();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(parentNodeMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${db9ec2b7-54f9-33e8-b84c-9075b2def202}, hash: 275F2AB0D2A395DA1FE98E99B8BB219F
    @Test()
    void parentsWhenParentIsNull() {
        /* Branches:* (parent != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Elements result = target.parents();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${9edf64c4-8f43-3202-945d-12a6bc8ff24d}, hash: 087C9C6C1DA1F3445F281DF736EB02A4
    @Test()
    void childTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            List<Element> elementList = new ArrayList<>();
            elementList.add(elementMock);
            doReturn(elementList).when(target).childElementsList();
            //Act Statement(s)
            Element result = target.child(0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).childElementsList();
            });
        }
    }

    //Sapient generated method id: ${29268c1e-e221-37ac-9a40-733c0ed0064b}, hash: 80270C0851061A8B2445487467229D64
    @Test()
    void childrenSizeTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            List<Element> elementList = new ArrayList<>();
            doReturn(elementList).when(target).childElementsList();
            //Act Statement(s)
            int result = target.childrenSize();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).childElementsList();
            });
        }
    }

    //Sapient generated method id: ${84e3f8e5-46e1-35d1-9a27-00428180148c}, hash: B1BE5446A3EA731B792DDBC8FF9BA4EB
    @Test()
    void childrenTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            List<Element> elementList = new ArrayList<>();
            elementList.add(elementMock);
            doReturn(elementList).when(target).childElementsList();
            //Act Statement(s)
            Elements result = target.children();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).childElementsList();
            });
        }
    }

    //Sapient generated method id: ${d6f0eb25-8191-32d3-9e17-f26f755670d5}, hash: 2D2CCCF09AA3876A5E9AE8A66D962FC3
    @Test()
    void childElementsListWhenChildNodeSizeEquals0() {
        /* Branches:* (childNodeSize() == 0) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            List<Element> result = target.childElementsList();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${c0aad254-3f38-39f7-9c4c-e77ca7b22a7e}, hash: 9151CD27751B6D73B6EBC08CB6F18818
    @Test()
    void childElementsListWhenNodeInstanceOfElement() {
        /* Branches:* (childNodeSize() == 0) : false* (shadowChildrenRef == null) : true* (i < size) : true* (node instanceof Element) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            List<Element> result = target.childElementsList();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(1));
                assertThat(result.get(0), is(instanceOf(Element.class)));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${d7045c8a-175e-3936-b8f0-c4b405ef2afb}, hash: C5F83124B8D1FA290031110D2265D2F2
    @Test()
    void nodelistChangedTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            target.nodelistChanged();
            //Assert statement(s)
            assertAll("result", () -> {
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${b4af2388-e781-3800-820a-b8ede09bd914}, hash: FC72F1B2DA03E9B3709CBD6F0D013086
    @Test()
    void streamTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Stream stream = Stream.empty();
            nodeUtils.when(() -> NodeUtils.stream(target, Element.class)).thenReturn(stream);
            //Act Statement(s)
            Stream<Element> result = target.stream();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(stream));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.stream(target, Element.class), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${51bfa4c8-bf3b-3c98-af04-ed958019d57c}, hash: A887C00F2C0BAD68EFD6C6AE39D606BF
    @Test()
    void textNodesTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            List<TextNode> result = target.textNodes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${2d222d8a-6d72-3ae9-9bab-1483da527592}, hash: 4761F2AD29733BA574B8172F96EF10D7
    @Test()
    void dataNodesTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            List<DataNode> result = target.dataNodes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${aed9f177-f3ce-3975-b7af-2913e041c3b4}, hash: 52513E55691B41167696ABC150793F54
    @Test()
    void selectTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Selector> selector = mockStatic(Selector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            selector.when(() -> Selector.select("cssQuery1", target)).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.select("cssQuery1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                selector.verify(() -> Selector.select("cssQuery1", target), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${c8a9e4c5-5e6c-3907-a638-0f3279b6b668}, hash: E9D9F8D248A311B7F8B0FF9E6FFB68AB
    @Test()
    void select1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Evaluator evaluatorMock = mock(Evaluator.class);
        try (MockedStatic<Selector> selector = mockStatic(Selector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            selector.when(() -> Selector.select(evaluatorMock, target)).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.select(evaluatorMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                selector.verify(() -> Selector.select(evaluatorMock, target), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${c8e45d4c-26f2-3e71-851d-320be2d2595f}, hash: 3A9FF020FE4A836D87099E7AAB0F31A6
    @Test()
    void selectFirstTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Selector> selector = mockStatic(Selector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            selector.when(() -> Selector.selectFirst("cssQuery1", target)).thenReturn(elementMock);
            //Act Statement(s)
            Element result = target.selectFirst("cssQuery1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                selector.verify(() -> Selector.selectFirst("cssQuery1", target), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${970a2b31-0f7d-3fa9-9e86-b2941732fc23}, hash: 035690945C218149A3F27F72EC03DF33
    @Test()
    void selectFirst1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Evaluator evaluatorMock = mock(Evaluator.class);
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            collector.when(() -> Collector.findFirst(evaluatorMock, target)).thenReturn(elementMock);
            //Act Statement(s)
            Element result = target.selectFirst(evaluatorMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.findFirst(evaluatorMock, target), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${a23590eb-4631-33b6-a26e-86c259adf1a9}, hash: 3F55618C5EA4A1441EBA5086A3076EEE
    @Test()
    void expectFirstWhenParentIsNull() {
        /* Branches:* (parent() != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Selector> selector = mockStatic(Selector.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Object[] objectArray = new Object[]{"cssQuery1", "return_of_getName1"};
            validate.when(() -> Validate.ensureNotNull(elementMock2, "No elements matched the query '%s' in the document.", objectArray)).thenReturn(elementMock);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            selector.when(() -> Selector.selectFirst("cssQuery1", target)).thenReturn(elementMock2);
            doReturn("return_of_getName1").when(tagMock).getName();
            //Act Statement(s)
            Element result = target.expectFirst("cssQuery1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.ensureNotNull(elementMock2, "No elements matched the query '%s' in the document.", objectArray), atLeast(1));
                selector.verify(() -> Selector.selectFirst("cssQuery1", target), atLeast(1));
                verify(tagMock).getName();
            });
        }
    }

    //Sapient generated method id: ${ad32b47b-ce05-3016-9b5a-c14ede5b274a}, hash: 1E13A4A419FF0C0BC7126F4858F30727
    @Test()
    void isWhenIsQueryParserParseCssQuery() {
        /* Branches:* (is(QueryParser.parse(cssQuery))) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Evaluator evaluatorMock = mock(Evaluator.class);
        try (MockedStatic<QueryParser> queryParser = mockStatic(QueryParser.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            queryParser.when(() -> QueryParser.parse("cssQuery1")).thenReturn(evaluatorMock);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(true).when(target).is(evaluatorMock);
            //Act Statement(s)
            boolean result = target.is("cssQuery1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                queryParser.verify(() -> QueryParser.parse("cssQuery1"), atLeast(1));
                verify(target).is(evaluatorMock);
            });
        }
    }

    //Sapient generated method id: ${348353aa-81e0-37e0-b96c-a9cc85788bf7}, hash: EE287206985C9376BF88C8F9F2A1D095
    @Test()
    void isWhenIsNotQueryParserParseCssQuery() {
        /* Branches:* (is(QueryParser.parse(cssQuery))) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Evaluator evaluatorMock = mock(Evaluator.class);
        try (MockedStatic<QueryParser> queryParser = mockStatic(QueryParser.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            queryParser.when(() -> QueryParser.parse("cssQuery1")).thenReturn(evaluatorMock);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(target).is(evaluatorMock);
            //Act Statement(s)
            boolean result = target.is("cssQuery1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                queryParser.verify(() -> QueryParser.parse("cssQuery1"), atLeast(1));
                verify(target).is(evaluatorMock);
            });
        }
    }

    //Sapient generated method id: ${0e3b841d-04c0-301c-aa39-2f79995ce906}, hash: 1C3D1C41BDEACDBCF628DF634FDC388B
    @Test()
    void is1WhenEvaluatorMatchesThisRootThis() {
        /* Branches:* (evaluator.matches(this.root(), this)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Evaluator evaluatorMock = mock(Evaluator.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).root();
            doReturn(true).when(evaluatorMock).matches(elementMock, target);
            //Act Statement(s)
            boolean result = target.is(evaluatorMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).root();
                verify(evaluatorMock).matches(elementMock, target);
            });
        }
    }

    //Sapient generated method id: ${03e284cf-3bde-3189-bdab-ed64ac112a74}, hash: CE25FC427E4774D82598F5D2BED9D398
    @Test()
    void is1WhenEvaluatorNotMatchesThisRootThis() {
        /* Branches:* (evaluator.matches(this.root(), this)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Evaluator evaluatorMock = mock(Evaluator.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).root();
            doReturn(false).when(evaluatorMock).matches(elementMock, target);
            //Act Statement(s)
            boolean result = target.is(evaluatorMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).root();
                verify(evaluatorMock).matches(elementMock, target);
            });
        }
    }

    //Sapient generated method id: ${5a96484f-db69-3f61-8449-b2e44798145b}, hash: 3739792C524725563A9940BFD5AF902B
    @Test()
    void closestTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Evaluator evaluatorMock = mock(Evaluator.class);
        Element elementMock = mock(Element.class);
        try (MockedStatic<QueryParser> queryParser = mockStatic(QueryParser.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            queryParser.when(() -> QueryParser.parse("cssQuery1")).thenReturn(evaluatorMock);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).closest(evaluatorMock);
            //Act Statement(s)
            Element result = target.closest("cssQuery1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                queryParser.verify(() -> QueryParser.parse("cssQuery1"), atLeast(1));
                verify(target).closest(evaluatorMock);
            });
        }
    }

    //Sapient generated method id: ${bcf79d06-6023-3c6d-8d0b-8a34bab152e6}, hash: B9E72331604C11DD90D1F9D81BC0B6CF
    @Test()
    void closest1WhenEvaluatorMatchesRootEl() {
        /* Branches:* (evaluator.matches(root, el)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Evaluator evaluatorMock = mock(Evaluator.class);
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(evaluatorMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).root();
            doReturn(true).when(evaluatorMock).matches(elementMock, target);
            //Act Statement(s)
            Element result = target.closest(evaluatorMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(evaluatorMock), atLeast(1));
                verify(target).root();
                verify(evaluatorMock).matches(elementMock, target);
            });
        }
    }

    //Sapient generated method id: ${01338e05-367b-3edf-bbb0-d3bd0446ccdb}, hash: 685CF380B09D0252B754DFDF0A4CA3BB
    @Test()
    void closest1WhenElIsNull() {
        /* Branches:* (evaluator.matches(root, el)) : false* (el != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Evaluator evaluatorMock = mock(Evaluator.class);
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(evaluatorMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).root();
            doReturn(false).when(evaluatorMock).matches(elementMock, target);
            //Act Statement(s)
            Element result = target.closest(evaluatorMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(evaluatorMock), atLeast(1));
                verify(target).root();
                verify(evaluatorMock).matches(elementMock, target);
            });
        }
    }

    //Sapient generated method id: ${5ed1593e-1a35-3d02-92c2-74a04c1db07b}, hash: FFC2A2EE6FC39C1CDD95B16B0C059140
    @Test()
    void selectXpathTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            List<Element> elementList = new ArrayList<>();
            elementList.add(elementMock);
            nodeUtils.when(() -> NodeUtils.selectXpath("xpath1", target, Element.class)).thenReturn(elementList);
            //Act Statement(s)
            Elements result = target.selectXpath("xpath1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(1));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.selectXpath("xpath1", target, Element.class), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${4036bb5d-0433-3da8-a712-250558a97be6}, hash: CC8100BC435892A64401F506638B3DB1
    @Test()
    void selectXpath1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            List<Node> nodeList = new ArrayList<>();
            nodeUtils.when(() -> NodeUtils.selectXpath("xpath1", target, Node.class)).thenReturn(nodeList);
            //Act Statement(s)
            List<Node> result = target.selectXpath("xpath1", Node.class);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(nodeList));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.selectXpath("xpath1", target, Node.class), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${667469f9-b7f9-38af-affb-30b93ff88011}, hash: 2EE1C64F0F4B81F0EA91B5AB91990314
    @Test()
    void appendChildTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node childMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doNothing().when(childMock).setSiblingIndex(0);
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(childMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(target).ensureChildNodes();
            doNothing().when(childMock).setParentNode(target);
            //Act Statement(s)
            Element result = target.appendChild(childMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                verify(childMock).setSiblingIndex(0);
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(childMock), atLeast(1));
                verify(target).ensureChildNodes();
                verify(childMock).setParentNode(target);
            });
        }
    }

    //Sapient generated method id: ${68cf1bfc-bc40-3156-990b-1db7e3e43295}, hash: 3C373D667CEEAE30BCC1BCF0CAD469E7
    @Test()
    void appendChildrenTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Collection<Node> collection = new ArrayList<>();
            doReturn(elementMock).when(target).insertChildren(-1, collection);
            //Act Statement(s)
            Element result = target.appendChildren(collection);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).insertChildren(-1, collection);
            });
        }
    }

    //Sapient generated method id: ${86e5d82a-37da-3d4c-96f2-81ab2829512b}, hash: 778A8D7FE4B51F83DA92A25A16146BDD
    @Test()
    void appendToTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(elementMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock2).when(elementMock).appendChild(target);
            //Act Statement(s)
            Element result = target.appendTo(elementMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(elementMock), atLeast(1));
                verify(elementMock).appendChild(target);
            });
        }
    }

    //Sapient generated method id: ${994e670c-65a9-3701-bbfb-ced84fdfcf3a}, hash: 1E4FDD5EE5096904F6A32B8FB08D52AB
    @Test()
    void prependChildTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(nodeMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Node[] nodeArray = new Node[]{nodeMock};
            doNothing().when(target).addChildren(0, nodeArray);
            //Act Statement(s)
            Element result = target.prependChild(nodeMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(nodeMock), atLeast(1));
                verify(target).addChildren(0, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${4f339689-3292-3611-9539-a69b62bcc721}, hash: 004734AF1A8FF338A174DCA86858D090
    @Test()
    void prependChildrenTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Collection<Node> collection = new ArrayList<>();
            doReturn(elementMock).when(target).insertChildren(0, collection);
            //Act Statement(s)
            Element result = target.prependChildren(collection);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).insertChildren(0, collection);
            });
        }
    }

    //Sapient generated method id: ${5ac403cb-b7d0-31e1-a3b8-e89069ffc006}, hash: CF69CEE2222E920308C841D678FBC614
    @Test()
    void insertChildrenWhenIndexLessThan0() {
        /* Branches:* (index < 0) : true* (index >= 0) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(anyCollection(), eq("Children collection to be inserted must not be null."))).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.isTrue(false, "Insert position out of bounds.")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Node[] nodeArray = new Node[]{};
            doNothing().when(target).addChildren(-1, nodeArray);
            Collection<Node> collection = new ArrayList<>();
            //Act Statement(s)
            Element result = target.insertChildren(-2, collection);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(anyCollection(), eq("Children collection to be inserted must not be null.")));
                validate.verify(() -> Validate.isTrue(false, "Insert position out of bounds."), atLeast(1));
                verify(target).addChildren(-1, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${08f52160-1b0c-3428-83d0-25b105a7f37a}, hash: B7EB31582D5214B57A22CACC67505A73
    @Test()
    void insertChildrenWhenIndexLessThanOrEqualsToCurrentSize() {
        /* Branches:* (index < 0) : true* (index >= 0) : true* (index <= currentSize) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class, CALLS_REAL_METHODS)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(anyCollection(), eq("Children collection to be inserted must not be null."))).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Node[] nodeArray = new Node[]{};
            doNothing().when(target).addChildren(0, nodeArray);
            Collection<Node> collection = new ArrayList<>();
            //Act Statement(s)
            Element result = target.insertChildren(-1, collection);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull(""), atLeast(1));
                validate.verify(() -> Validate.notNull(anyCollection(), eq("Children collection to be inserted must not be null.")), atLeast(1));
                verify(target, atLeast(1)).addChildren(0, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${3a9522e9-aaad-326d-924c-feb89bbea7da}, hash: 86F957D8F5363CF22501A99F3AE631D1
    @Test()
    void insertChildren1WhenIndexLessThan0() {
        /* Branches:* (index < 0) : true* (index >= 0) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            Node[] nodeArray = new Node[]{};
            validate.when(() -> Validate.notNull(nodeArray, "Children collection to be inserted must not be null.")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.isTrue(false, "Insert position out of bounds.")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doNothing().when(target).addChildren(-1, nodeArray);
            //Act Statement(s)
            Element result = target.insertChildren(-2, nodeArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(nodeArray, "Children collection to be inserted must not be null."), atLeast(1));
                validate.verify(() -> Validate.isTrue(false, "Insert position out of bounds."), atLeast(1));
                verify(target).addChildren(-1, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${ef3b6175-7009-30ba-a48d-d3f2314fbf67}, hash: 74F19964CBBC49DAE0256FB69D785580
    @Test()
    void insertChildren1WhenIndexLessThanOrEqualsToCurrentSize() {
        /* Branches:* (index < 0) : true* (index >= 0) : true* (index <= currentSize) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class, CALLS_REAL_METHODS)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("")).thenAnswer((Answer<Void>) invocation -> null);
            Node[] nodeArray = new Node[]{};
            validate.when(() -> Validate.notNull(nodeArray, "Children collection to be inserted must not be null.")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doNothing().when(target).addChildren(0, nodeArray);
            //Act Statement(s)
            Element result = target.insertChildren(-1, nodeArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull(""), atLeast(1));
                validate.verify(() -> Validate.notNull(nodeArray, "Children collection to be inserted must not be null."), atLeast(1));
                verify(target, atLeast(1)).addChildren(0, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${34039f4c-1671-321e-92be-0b8f7a402bfd}, hash: 6EEB2EB020282CF27E6ED0223C099E6D
    @Test()
    void appendElementTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("return_of_namespace1").when(tagMock).namespace();
            doReturn(elementMock).when(target).appendElement("tagName1", "return_of_namespace1");
            //Act Statement(s)
            Element result = target.appendElement("tagName1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).namespace();
                verify(target).appendElement("tagName1", "return_of_namespace1");
            });
        }
    }

    //Sapient generated method id: ${da433d7e-2888-36f7-a3a7-c44c3709e814}, hash: 9B792B991965541AE740CADD002C95E3
    @Test()
    void appendElement1WhenDefaultBranch() {
        /* Branches:* (branch expression (line 88)) : false  #  inside <init> method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock2 = mock(Tag.class);
        ParseSettings parseSettingsMock = mock(ParseSettings.class);
        Parser parserMock = mock(Parser.class);
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class);
             MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            tag.when(() -> Tag.valueOf("tagName1", "namespace1", parseSettingsMock)).thenReturn(tagMock2);
            validate.when(() -> Validate.notNull(tagMock2)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            doReturn(parseSettingsMock).when(parserMock).settings();
            doReturn("B").when(target).baseUri();
            doReturn(elementMock).when(target).appendChild((Element) any());
            //Act Statement(s)
            Element result = target.appendElement("tagName1", "namespace1");
            Element element = new Element(tagMock2, "B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(element));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                tag.verify(() -> Tag.valueOf("tagName1", "namespace1", parseSettingsMock), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock2), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).settings();
                verify(target).baseUri();
                verify(target).appendChild((Element) any());
            });
        }
    }

    //Sapient generated method id: ${de5b5cbe-e76a-3995-8cc9-c16dc054fb8d}, hash: 74D8E1C29391150F77DD667DFCF53218
    @Test()
    void prependElementTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("return_of_namespace1").when(tagMock).namespace();
            doReturn(elementMock).when(target).prependElement("tagName1", "return_of_namespace1");
            //Act Statement(s)
            Element result = target.prependElement("tagName1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).namespace();
                verify(target).prependElement("tagName1", "return_of_namespace1");
            });
        }
    }

    //Sapient generated method id: ${17d89e0c-69d1-3f50-97bd-2995ff0dde61}, hash: 267F7C5EA1101190F250CF334D262C1D
    @Test()
    void prependElement1WhenDefaultBranch() {
        /* Branches:* (branch expression (line 88)) : false  #  inside <init> method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Tag tagMock2 = mock(Tag.class);
        ParseSettings parseSettingsMock = mock(ParseSettings.class);
        Parser parserMock = mock(Parser.class);
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class);
             MockedStatic<Tag> tag = mockStatic(Tag.class);
             MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            tag.when(() -> Tag.valueOf("tagName1", "namespace1", parseSettingsMock)).thenReturn(tagMock2);
            validate.when(() -> Validate.notNull(tagMock2)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            doReturn(parseSettingsMock).when(parserMock).settings();
            doReturn("B").when(target).baseUri();
            doReturn(elementMock).when(target).prependChild((Element) any());
            //Act Statement(s)
            Element result = target.prependElement("tagName1", "namespace1");
            Element element = new Element(tagMock2, "B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(element));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                tag.verify(() -> Tag.valueOf("tagName1", "namespace1", parseSettingsMock), atLeast(1));
                validate.verify(() -> Validate.notNull(tagMock2), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).settings();
                verify(target).baseUri();
                verify(target).prependChild((Element) any());
            });
        }
    }

    //Sapient generated method id: ${91f6c70c-a458-3a7b-89ec-6d0cfc9d1996}, hash: 3D703C80636FE08B30AA5DE36224F62D
    @Test()
    void appendTextTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).appendChild((TextNode) any());
            //Act Statement(s)
            Element result = target.appendText("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).appendChild((TextNode) any());
            });
        }
    }

    //Sapient generated method id: ${8fa29ecf-c9c1-3021-bdf9-3b0c17169ca9}, hash: A6CB2C28C7031C264023099A5AC09681
    @Test()
    void prependTextTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).prependChild((TextNode) any());
            //Act Statement(s)
            Element result = target.prependText("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).prependChild((TextNode) any());
            });
        }
    }

    //Sapient generated method id: ${676fd4ee-a054-37bb-b933-26f808f69714}, hash: D22D1FCD99F82808B4E4E31121C87D3D
    @Test()
    void appendTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(parserMock).parseFragmentInput("B", target, "return_of_baseUri1");
            doReturn("return_of_baseUri1").when(target).baseUri();
            Node[] nodeArray = new Node[]{};
            doNothing().when(target).addChildren(nodeArray);
            //Act Statement(s)
            Element result = target.append("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).parseFragmentInput("B", target, "return_of_baseUri1");
                verify(target).baseUri();
                verify(target).addChildren(nodeArray);
            });
        }
    }

    //Sapient generated method id: ${a4b8cd13-a8e5-316d-88a7-720278d41680}, hash: 57E63802411EA57F6691858EBA78E752
    @Test()
    void prependTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(parserMock).parseFragmentInput("B", target, "return_of_baseUri1");
            doReturn("return_of_baseUri1").when(target).baseUri();
            Node[] nodeArray = new Node[]{};
            doNothing().when(target).addChildren(0, nodeArray);
            //Act Statement(s)
            Element result = target.prepend("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).parseFragmentInput("B", target, "return_of_baseUri1");
                verify(target).baseUri();
                verify(target).addChildren(0, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${a196c145-0fc6-308c-a2bb-defd6dac20a1}, hash: E120D862B6FE762885527708CAC47FC8
    @Test()
    void before2WhenParentNotInstanceOfElement() {
        /* Branches:* (parent() instanceof Element) : false  #  inside addSiblingHtml method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(parentNodeMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(parserMock).parseFragmentInput("B", (Element) null, "baseUri1");
            Node[] nodeArray = new Node[]{};
            doNothing().when(parentNodeMock).addChildren(0, nodeArray);
            //Act Statement(s)
            Element result = target.before("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                validate.verify(() -> Validate.notNull(parentNodeMock), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).parseFragmentInput("B", (Element) null, "baseUri1");
                verify(parentNodeMock, atLeast(1)).addChildren(0, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${e5fcc1cf-95be-357d-85c3-1d959746cc1c}, hash: FAB5822501DA3383BA39761EABD5B1CA
    @Test()
    void before3WhenNodeParentNodeEqualsParentNode() {
        /* Branches:* (node.parentNode == parentNode) : true  #  inside before method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doNothing().when(nodeMock).remove();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(nodeMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(parentNodeMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Node[] nodeArray = new Node[]{nodeMock};
            doNothing().when(parentNodeMock).addChildren(0, nodeArray);
            //Act Statement(s)
            Element result = target.before(nodeMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                verify(nodeMock).remove();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(nodeMock), atLeast(1));
                validate.verify(() -> Validate.notNull(parentNodeMock), atLeast(1));
                verify(parentNodeMock, atLeast(1)).addChildren(0, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${1e10bac7-1838-3eee-a306-2a1b527adef0}, hash: F037E3A09D9E8418A47B115DD9037BE4
    @Test()
    void after2WhenParentNotInstanceOfElement() {
        /* Branches:* (parent() instanceof Element) : false  #  inside addSiblingHtml method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(parentNodeMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(parserMock).parseFragmentInput("B", (Element) null, "baseUri1");
            Node[] nodeArray = new Node[]{};
            doNothing().when(parentNodeMock).addChildren(1, nodeArray);
            //Act Statement(s)
            Element result = target.after("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                validate.verify(() -> Validate.notNull(parentNodeMock), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).parseFragmentInput("B", (Element) null, "baseUri1");
                verify(parentNodeMock, atLeast(1)).addChildren(1, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${de4fab57-c08a-36d9-aba2-a6618af38db8}, hash: 2E7C87730000C22A524A2F3B9B0A6AAC
    @Test()
    void after3WhenNodeParentNodeEqualsParentNode() {
        /* Branches:* (node.parentNode == parentNode) : true  #  inside after method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doNothing().when(nodeMock).remove();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(nodeMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(parentNodeMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Node[] nodeArray = new Node[]{nodeMock};
            doNothing().when(parentNodeMock).addChildren(1, nodeArray);
            //Act Statement(s)
            Element result = target.after(nodeMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                verify(nodeMock).remove();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(nodeMock), atLeast(1));
                validate.verify(() -> Validate.notNull(parentNodeMock), atLeast(1));
                verify(parentNodeMock, atLeast(1)).addChildren(1, nodeArray);
            });
        }
    }

    //Sapient generated method id: ${be7bc51a-70ee-32e7-8297-13dce2abb3d2}, hash: FD37429F50D299E28AD64139DCEFAC15
    @Test()
    void empty1WhenChildNodesIsNotEmpty() {
        /* Branches:* (for-each(childNodes)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.empty();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${42065097-189e-3149-a74c-7e73b54d70fa}, hash: 284CE192B8E59F115047A2B004D4FB3F
    @Test()
    void wrap1WhenWrapNodeNotInstanceOfElement() {
        /* Branches:* (parentNode != null) : false  #  inside wrap method* (this instanceof Element) : false  #  inside wrap method* (!(wrapNode instanceof Element)) : true  #  inside wrap method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Parser parserMock = mock(Parser.class);
        Node nodeMock = mock(Node.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            List<Node> nodeList = new ArrayList<>();
            nodeList.add(nodeMock);
            doReturn(nodeList).when(parserMock).parseFragmentInput("B", (Element) null, "baseUri1");
            //Act Statement(s)
            Element result = target.wrap("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("B"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).parseFragmentInput("B", (Element) null, "baseUri1");
            });
        }
    }

    //Sapient generated method id: ${ce290ac6-2fc5-33be-b12c-deba3edf6414}, hash: C39C7014089C88C711A1D926D800A9F8
    @Test()
    void wrap1WhenWrapEqualsRemainder() {
        /* Branches:* (parentNode != null) : false  #  inside wrap method* (this instanceof Element) : false  #  inside wrap method* (!(wrapNode instanceof Element)) : false  #  inside wrap method* (child != null) : true  #  inside getDeepChild method* (parentNode != null) : false  #  inside wrap method* (wrapChildren.size() > 0) : true  #  inside wrap method* (i < wrapChildren.size()) : true  #  inside wrap method* (wrap == remainder) : true  #  inside wrap method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("baseUri1")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("html1")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "baseUri1", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(parserMock).parseFragmentInput("html1", (Element) null, "baseUri1");
            //Act Statement(s)
            Element result = target.wrap("html1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("baseUri1"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("html1"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).parseFragmentInput("html1", (Element) null, "baseUri1");
            });
        }
    }

    //Sapient generated method id: ${e9c9b7f6-856d-3fa8-b573-50bfb2aa781b}, hash: 7993C093EBD67253ABDD74CFDEDF43D6
    @Test()
    void wrap1WhenRemainderParentNodeIsNull() {
        /* Branches:* (parentNode != null) : false  #  inside wrap method* (this instanceof Element) : false  #  inside wrap method* (!(wrapNode instanceof Element)) : false  #  inside wrap method* (child != null) : true  #  inside getDeepChild method* (parentNode != null) : false  #  inside wrap method* (wrapChildren.size() > 0) : true  #  inside wrap method* (i < wrapChildren.size()) : true  #  inside wrap method* (wrap == remainder) : false  #  inside wrap method* (remainder.parentNode != null) : false  #  inside wrap method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Parser parserMock = mock(Parser.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("baseUri1")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("html1")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "baseUri1", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeUtils.when(() -> NodeUtils.parser(target)).thenReturn(parserMock);
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(parserMock).parseFragmentInput("html1", (Element) null, "baseUri1");
            //Act Statement(s)
            Element result = target.wrap("html1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("baseUri1"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("html1"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.parser(target), atLeast(1));
                verify(parserMock).parseFragmentInput("html1", (Element) null, "baseUri1");
            });
        }
    }

    //Sapient generated method id: ${617ea231-6da5-3a9b-9217-c85e4c6d7c35}, hash: D4852ADE29EC5DAA5119EDE6EB71EA7E
    @Test()
    void cssSelectorWhenDocIsNull() {
        /* Branches:* (id().length() > 0) : true* (doc != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("D")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "D", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("A", "B").when(target).id();
            doReturn(null).when(target).ownerDocument();
            //Act Statement(s)
            String result = target.cssSelector();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("#B"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("D"), atLeast(1));
                verify(target, times(2)).id();
                verify(target).ownerDocument();
            });
        }
    }

    //Sapient generated method id: ${def15b77-c52a-3128-9fe2-6b8b6ad674cf}, hash: 8080CE90A36EB2911653B3A4C86BCC34
    @Test()
    void cssSelectorWhenElsGet0EqualsThis() {
        /* Branches:* (id().length() > 0) : true* (doc != null) : true* (els.size() == 1) : true* (els.get(0) == this) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document documentMock = mock(Document.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("D")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "D", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("A", "B").when(target).id();
            doReturn(documentMock).when(target).ownerDocument();
            Elements elements = new Elements();
            elements.add(target);
            doReturn(elements).when(documentMock).select("#B");
            //Act Statement(s)
            String result = target.cssSelector();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("#B"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("D"), atLeast(1));
                verify(target, times(2)).id();
                verify(target).ownerDocument();
                verify(documentMock).select("#B");
            });
        }
    }

    //Sapient generated method id: ${06f32389-8e8c-39e0-8390-d4df7435e0be}, hash: F40DBFE79CDC6683A203B9CB9BFE1798
    @Test()
    void cssSelectorWhenElsGet0NotEqualsThisAndElIsNotNullAndElNotInstanceOfDocument() {
        /* Branches:* (id().length() > 0) : true* (doc != null) : true* (els.size() == 1) : true* (els.get(0) == this) : false* (el != null) : true* (!(el instanceof Document)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document documentMock = mock(Document.class);
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class, CALLS_REAL_METHODS);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("E")).thenAnswer((Answer<Void>) invocation -> null);
            stringUtil.when(() -> StringUtil.releaseBuilder((StringBuilder) any())).thenReturn("return_of_releaseBuilder1");
            target = spy(new Element(tagMock, "E", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("A", "B").when(target).id();
            doReturn(documentMock).when(target).ownerDocument();
            Object object = new Object();
            Elements elements = new Elements();
            elements.add((Element) object);
            doReturn(elements).when(documentMock).select("#B");
            //Act Statement(s)
            String result = target.cssSelector();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_releaseBuilder1"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("E"), atLeast(1));
                stringUtil.verify(() -> StringUtil.releaseBuilder((StringBuilder) any()), atLeast(1));
                verify(target, times(2)).id();
                verify(target, atLeast(1)).ownerDocument();
                verify(documentMock, atLeast(1)).select("#B");
            });
        }
    }

    //Sapient generated method id: ${87b662c5-47e3-359a-9503-c5ad9215ae88}, hash: 9EE1ACECE28905D487C4B2BE6DC7A695
    @Test()
    void siblingElementsWhenParentNodeIsNull() {
        /* Branches:* (parentNode == null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Elements result = target.siblingElements();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${405299e9-981d-31c5-af1b-0ab72f84f16c}, hash: 45B41CC8DA000D00C7D1B743D228067C
    @Test()
    void nextElementSiblingWhenNextAssignedNextNextSiblingIsNull() {
        /* Branches:* ((next = next.nextSibling()) != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.nextElementSibling();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${cc2b5798-9f5e-3aca-ab8c-7f4d3d7a5f29}, hash: 374519FF87431683DCD9303CC0ED64E2
    @Test()
    void nextElementSiblingWhenNextInstanceOfElement() {
        /* Branches:* ((next = next.nextSibling()) != null) : true* (next instanceof Element) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.nextElementSibling();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${8254530c-de5d-3f6f-ba05-de4f36b7bdf3}, hash: 64A93782DB4AC8DE3811BC355C7BA739
    @Test()
    void nextElementSiblingsWhenParentNodeIsNull() {
        /* Branches:* (parentNode == null) : true  #  inside nextElementSiblings method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Elements result = target.nextElementSiblings();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${a49c4c90-8142-32a6-8330-b11b158458dc}, hash: 9950D6AD539E9DDC18C3F820042CFE76
    @Test()
    void previousElementSiblingWhenPrevAssignedPrevPreviousSiblingIsNull() {
        /* Branches:* ((prev = prev.previousSibling()) != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.previousElementSibling();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${f9e013af-cb2e-3071-a4d8-e90da81f19fc}, hash: B409272926DD2EF5CBDDAC5294B6391D
    @Test()
    void previousElementSiblingWhenPrevInstanceOfElement() {
        /* Branches:* ((prev = prev.previousSibling()) != null) : true* (prev instanceof Element) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.previousElementSibling();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${516be008-6341-367a-bbe8-2744e715fb4b}, hash: 69F70013A13F71528F9CD1F8010E98DB
    @Test()
    void previousElementSiblingsWhenParentNodeIsNull() {
        /* Branches:* (parentNode == null) : true  #  inside nextElementSiblings method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Elements result = target.previousElementSiblings();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${1bac043c-4684-32af-ade3-b6c96bdaa7cf}, hash: AE9FAFDF5191D69802B42B51F48E2378
    @Test()
    void firstElementSiblingWhenParentIsNull() {
        /* Branches:* (parent() != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.firstElementSibling();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${5401c6b1-c638-335b-87bb-12b25556c02a}, hash: C7800553D3E2CBC53CB021695CA4870C
    @Test()
    void elementSiblingIndexWhenParentIsNull() {
        /* Branches:* (parent() == null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            int result = target.elementSiblingIndex();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${021797dd-6a59-32fe-96f6-bfe70877ca43}, hash: 9DB24656CE9AB7D7159EFB193AC89971
    @Test()
    void lastElementSiblingWhenParentIsNull() {
        /* Branches:* (parent() != null) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.lastElementSibling();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${f4e6b4fb-0207-31b2-9e9b-bfb51a22af59}, hash: 370A4321678424D870FF782F090F310D
    @Test()
    void firstElementChildWhenChildInstanceOfElement() {
        /* Branches:* (child != null) : true* (child instanceof Element) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).firstChild();
            //Act Statement(s)
            Element result = target.firstElementChild();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).firstChild();
            });
        }
    }

    //Sapient generated method id: ${1ce44379-5a55-3781-9b76-5a8b196c5ffb}, hash: DFC5CA1C3B585B947CE40DD37FB211EC
    @Test()
    void firstElementChildWhenChildNotInstanceOfElement() {
        /* Branches:* (child != null) : true* (child instanceof Element) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(nodeMock).when(target).firstChild();
            doReturn(null).when(nodeMock).nextSibling();
            //Act Statement(s)
            Element result = target.firstElementChild();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).firstChild();
                verify(nodeMock).nextSibling();
            });
        }
    }

    //Sapient generated method id: ${e8757f5c-17d0-32b3-b4d5-ea628a27c64d}, hash: E476528CB26B47BA01E4804781F9D801
    @Test()
    void lastElementChildWhenChildInstanceOfElement() {
        /* Branches:* (child != null) : true* (child instanceof Element) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).lastChild();
            //Act Statement(s)
            Element result = target.lastElementChild();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).lastChild();
            });
        }
    }

    //Sapient generated method id: ${824e72d7-d181-3768-b5a3-f6065106221a}, hash: DD8919AB0D5DB530B8623BB5DC9B5953
    @Test()
    void lastElementChildWhenChildNotInstanceOfElement() {
        /* Branches:* (child != null) : true* (child instanceof Element) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(nodeMock).when(target).lastChild();
            doReturn(null).when(nodeMock).previousSibling();
            //Act Statement(s)
            Element result = target.lastElementChild();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).lastChild();
                verify(nodeMock).previousSibling();
            });
        }
    }

    //Sapient generated method id: ${29001b28-2215-3d3b-a1b3-7a2863b438cc}, hash: ADAC08F83FC75BAE01D9596AC82ED452
    @Test()
    void getElementsByTagTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByTag("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("B"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${d8aae356-8f47-3a91-91db-2c6337b4af3c}, hash: 094783B595C7D9FDE0D4F0C546C111A2
    @Test()
    void getElementByIdWhenElementsSizeGreaterThan0() {
        /* Branches:* (elements.size() > 0) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            elements.add(elementMock);
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Element result = target.getElementById("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elementMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("B"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${edfa4cc6-0717-3c69-8064-61d5a91c0256}, hash: E91FF81121B38EA240FC2AF9F0C38AAB
    @Test()
    void getElementByIdWhenElementsSizeNotGreaterThan0() {
        /* Branches:* (elements.size() > 0) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Element result = target.getElementById("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(nullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("B"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${52d0a355-3c8d-3813-a29e-671258308ce5}, hash: CA88C43CA01F9597F5B5A8115A928E95
    @Test()
    void getElementsByClassTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByClass("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("B"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${3cc63e5e-a39f-3fcf-8949-6ec2481ecea0}, hash: A38F41B361C7FD4432F6AEB823E94535
    @Test()
    void getElementsByAttributeTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("baseUri1")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("key1")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "baseUri1", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByAttribute("key1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("baseUri1"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("key1"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${579f33ce-84bd-3724-9d1a-8e8e5c907004}, hash: F662EB514BB86D0275BE73F23D8902FC
    @Test()
    void getElementsByAttributeStartingTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("baseUri1")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notEmpty("keyPrefix1")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "baseUri1", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByAttributeStarting("keyPrefix1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("baseUri1"), atLeast(1));
                validate.verify(() -> Validate.notEmpty("keyPrefix1"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${478f83f3-69e9-33be-a388-9692cc61c27a}, hash: 2FF30641A07616CEB384AF9ED3877F1F
    @Test()
    void getElementsByAttributeValueTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByAttributeValue("key1", "value1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${5ba9c95b-f961-37d5-b315-a526adcf4518}, hash: 8A36B965B874B1FC1C0DE288325355F9
    @Test()
    void getElementsByAttributeValueNotTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByAttributeValueNot("key1", "value1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${d8ffd22d-5031-3228-9866-9e98e8332a40}, hash: 0C46EFE25D24C77DFDBD3CCE5B7A1CF4
    @Test()
    void getElementsByAttributeValueStartingTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByAttributeValueStarting("key1", "valuePrefix1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${f1be4392-6473-3c6b-a813-fcf5d37d5c29}, hash: 93D132D44D3A4622F3DEE42303846EEB
    @Test()
    void getElementsByAttributeValueEndingTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByAttributeValueEnding("key1", "valueSuffix1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${1f1283ef-2145-3a75-ae25-b97b785c9411}, hash: AEA7CDF302A89B4FB114DCE99F569684
    @Test()
    void getElementsByAttributeValueContainingTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByAttributeValueContaining("key1", "match1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${06267ddc-f86c-3dfa-b532-c2922adff1b3}, hash: EF9276970677D1F82FE70A2011C03EC0
    @Test()
    void getElementsByAttributeValueMatchingTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            Pattern pattern = Pattern.compile("regex1");
            //Act Statement(s)
            Elements result = target.getElementsByAttributeValueMatching("key1", pattern);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${ba6d40f6-24e0-3487-97c4-136a09e5ac33}, hash: D83EF059A305B4318BB0D4E327415C94
    @Test()
    void getElementsByAttributeValueMatching1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            doReturn(elements).when(target).getElementsByAttributeValueMatching(eq("key1"), (Pattern) any());
            //Act Statement(s)
            Elements result = target.getElementsByAttributeValueMatching("key1", "B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).getElementsByAttributeValueMatching(eq("key1"), (Pattern) any());
            });
        }
    }

    //Sapient generated method id: ${2586caff-c6c2-3de7-81c9-ddfdd2290efc}, hash: 221BDAE0476FE7AE2B321EF4CB371623
    @Test()
    void getElementsByAttributeValueMatching1WhenCaughtPatternSyntaxExceptionThrowsIllegalArgumentException() {
        /* Branches:* (catch-exception (PatternSyntaxException)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
                target.getElementsByAttributeValueMatching("key1", "B");
            });
            PatternSyntaxException patternSyntaxException = new PatternSyntaxException("desc1", "regex1", 0);
            IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Pattern syntax error: B", patternSyntaxException);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
                assertThat(result.getCause(), is(instanceOf(patternSyntaxException.getClass())));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${7695f663-264a-3bda-b34c-944253db66a4}, hash: 7D5E618F3D1ED214CE84D81C9C909D4F
    @Test()
    void getElementsByIndexLessThanTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByIndexLessThan(0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${0d76f185-c0c5-3a21-bd9f-7a6325dbcd68}, hash: F7F3E536FBF26FD2625D85CF3BB49F4F
    @Test()
    void getElementsByIndexGreaterThanTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByIndexGreaterThan(0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${4985070f-8a81-3407-8ad4-b2a6387e999f}, hash: 503E07C85ECC8EC615557FB078E3188E
    @Test()
    void getElementsByIndexEqualsTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsByIndexEquals(0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${232c4de9-484b-329d-8e89-39a61a37c6b6}, hash: 8F7F41C2A09F23FE1790310521FE597F
    @Test()
    void getElementsContainingTextTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsContainingText("searchText1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${888a5305-3427-3066-86da-3f025df17f53}, hash: 59B9C3C786B8E2121DBD9711E1C14753
    @Test()
    void getElementsContainingOwnTextTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getElementsContainingOwnText("searchText1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${353fe28a-ed7e-3d89-a007-2944bbe1d717}, hash: BBFF1FCB8911C3BA3D95EA502AF62F9D
    @Test()
    void getElementsMatchingTextTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            Pattern pattern = Pattern.compile("regex1");
            //Act Statement(s)
            Elements result = target.getElementsMatchingText(pattern);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${8b2580d4-5870-3fc4-8e97-0d2356921d9f}, hash: 949D8351A7E6E7948F37F8A75493C7BF
    @Test()
    void getElementsMatchingText1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            doReturn(elements).when(target).getElementsMatchingText((Pattern) any());
            //Act Statement(s)
            Elements result = target.getElementsMatchingText("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).getElementsMatchingText((Pattern) any());
            });
        }
    }

    //Sapient generated method id: ${53fe8a62-3de4-357b-89fb-7f9b6e8f2890}, hash: 402E529282F5882BF5195A666FAD9661
    @Test()
    void getElementsMatchingText1WhenCaughtPatternSyntaxExceptionThrowsIllegalArgumentException() {
        /* Branches:* (catch-exception (PatternSyntaxException)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
                target.getElementsMatchingText("B");
            });
            PatternSyntaxException patternSyntaxException = new PatternSyntaxException("desc1", "regex1", 0);
            IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Pattern syntax error: B", patternSyntaxException);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
                assertThat(result.getCause(), is(instanceOf(patternSyntaxException.getClass())));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${92a44f67-4e4d-3e63-b0ed-8119defcb0be}, hash: 245917F1A6B52D3A55BB67E51253D0C2
    @Test()
    void getElementsMatchingOwnTextTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            Pattern pattern = Pattern.compile("regex1");
            //Act Statement(s)
            Elements result = target.getElementsMatchingOwnText(pattern);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${43be9533-f7b2-3c2b-838e-385238a47397}, hash: 7BB90AC95FB53AC6C3AAA4E70DE2628D
    @Test()
    void getElementsMatchingOwnText1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            doReturn(elements).when(target).getElementsMatchingOwnText((Pattern) any());
            //Act Statement(s)
            Elements result = target.getElementsMatchingOwnText("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).getElementsMatchingOwnText((Pattern) any());
            });
        }
    }

    //Sapient generated method id: ${0768e853-dd92-33b3-9d38-5cddbd5c8d6c}, hash: E484CD37C02C8576D1C8E388E84D8118
    @Test()
    void getElementsMatchingOwnText1WhenCaughtPatternSyntaxExceptionThrowsIllegalArgumentException() {
        /* Branches:* (catch-exception (PatternSyntaxException)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
                target.getElementsMatchingOwnText("B");
            });
            PatternSyntaxException patternSyntaxException = new PatternSyntaxException("desc1", "regex1", 0);
            IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Pattern syntax error: B", patternSyntaxException);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                assertThat(result.getMessage(), equalTo(illegalArgumentException.getMessage()));
                assertThat(result.getCause(), is(instanceOf(patternSyntaxException.getClass())));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${e8bfc39f-6065-3e03-ada8-5bfdf7687551}, hash: 41C1D2F07FBB9C06CFE3C1854A0CF5AF
    @Test()
    void getAllElementsTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Collector> collector = mockStatic(Collector.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Elements elements = new Elements();
            collector.when(() -> Collector.collect((Evaluator) any(), eq(target))).thenReturn(elements);
            //Act Statement(s)
            Elements result = target.getAllElements();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(elements));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                collector.verify(() -> Collector.collect((Evaluator) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${b33ddd5c-4cde-36be-92ea-cbe76b042145}, hash: 79912B5182009DE7DE7DEEA3C270A30F
    @Test()
    void textTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<NodeTraversor> nodeTraversor = mockStatic(NodeTraversor.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeTraversor.when(() -> NodeTraversor.traverse((NodeVisitor) any(), eq(target))).thenAnswer((Answer<Void>) invocation -> null);
            //Act Statement(s)
            String result = target.text();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                nodeTraversor.verify(() -> NodeTraversor.traverse((NodeVisitor) any(), eq(target)));
            });
        }
    }

    //Sapient generated method id: ${f99781d6-774f-3e36-823e-4f206e9eeb76}, hash: 784F5BF46AA0A13D3B254C84A7AD2E30
    @Test()
    void wholeTextTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Stream stream = Stream.empty();
            nodeUtils.when(() -> NodeUtils.stream(target, Node.class)).thenReturn(stream);
            //Act Statement(s)
            String result = target.wholeText();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.stream(target, Node.class), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${6097be78-d485-365a-bc77-c15c4726a433}, hash: D7B340519A9D4D60DAA1D4D2E7F6B48D
    @Test()
    void wholeOwnTextWhenNodeInstanceOfTextNode() {
        /* Branches:* (i < size) : true* (node instanceof TextNode) : true  #  inside appendWholeText method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.wholeOwnText();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${8df33c5c-fb76-304a-963b-dab49b56c08d}, hash: C6540A49DC90F9AE559A946B61A24A00
    @Test()
    void wholeOwnTextWhenNodeNameIsBr() {
        /* Branches:* (i < size) : true* (node instanceof TextNode) : false  #  inside appendWholeText method* (node.nameIs("br")) : true  #  inside appendWholeText method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.wholeOwnText();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("\n"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${9b265bd3-0925-3449-ac2a-1ef7753b542f}, hash: C001C26820FE5064EA232900B9F7CA65
    @Test()
    void ownTextWhenPreserveWhitespaceTextNodeParentNode() {
        /* Branches:* (i < childNodeSize()) : true  #  inside ownText method* (child instanceof TextNode) : true  #  inside ownText method* (preserveWhitespace(textNode.parentNode)) : true  #  inside appendNormalisedText method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Element> element = mockStatic(Element.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            element.when(() -> Element.preserveWhitespace((Node) null)).thenReturn(true);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.ownText();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                element.verify(() -> Element.preserveWhitespace((Node) null), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${01e7e11a-8568-3d4f-b52e-d4548204163a}, hash: 11202A9A3361D65387DEB0D9C89C6E11
    @Test()
    void ownTextWhenTextNodeNotInstanceOfCDataNode() {
        /* Branches:* (i < childNodeSize()) : true  #  inside ownText method* (child instanceof TextNode) : true  #  inside ownText method* (preserveWhitespace(textNode.parentNode)) : false  #  inside appendNormalisedText method* (textNode instanceof CDataNode) : false  #  inside appendNormalisedText method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class, CALLS_REAL_METHODS);
             MockedStatic<TextNode> textNode = mockStatic(TextNode.class);
             MockedStatic<Element> element = mockStatic(Element.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            element.when(() -> Element.preserveWhitespace((Node) null)).thenReturn(false);
            textNode.when(() -> TextNode.lastCharIsWhitespace((StringBuilder) any())).thenReturn(false);
            stringUtil.when(() -> StringUtil.appendNormalisedWhitespace((StringBuilder) any(), eq("return_of_getWholeText1"), eq(false))).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.ownText();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                element.verify(() -> Element.preserveWhitespace((Node) null), atLeast(1));
                textNode.verify(() -> TextNode.lastCharIsWhitespace((StringBuilder) any()), atLeast(1));
                stringUtil.verify(() -> StringUtil.appendNormalisedWhitespace((StringBuilder) any(), eq("return_of_getWholeText1"), eq(false)), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${9dbe8e4c-33c5-34d1-9b84-d7d5f86e28a0}, hash: 0C048EA262C38B722D81A5C49EE4DBC3
    @Test()
    void ownTextWhenLastCharIsWhitespaceNotAccum() {
        /* Branches:* (i < childNodeSize()) : true  #  inside ownText method* (child instanceof TextNode) : false  #  inside ownText method* (child.nameIs("br")) : true  #  inside ownText method* (!lastCharIsWhitespace(accum)) : true  #  inside ownText method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<TextNode> textNode = mockStatic(TextNode.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            textNode.when(() -> TextNode.lastCharIsWhitespace((StringBuilder) any())).thenReturn(false);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            String result = target.ownText();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                textNode.verify(() -> TextNode.lastCharIsWhitespace((StringBuilder) any()));
            });
        }
    }

    //Sapient generated method id: ${604f5b3d-afcf-31df-825a-d2a72142b2ef}, hash: 02EFA9CFFF5BFDE3B8589870D0A7343B
    @Test()
    void preserveWhitespaceWhenElTagPreserveWhitespace() {
        /* Branches:* (node instanceof Element) : true* (el.tag.preserveWhitespace()) : true*/
        //Arrange Statement(s)
        Tag tagMock2 = mock(Tag.class);
        doReturn(true).when(tagMock2).preserveWhitespace();
        Attributes attributesMock2 = mock(Attributes.class);
        Element element = new Element(tagMock2, "baseUri1", attributesMock2);

        //Act Statement(s)
        boolean result = Element.preserveWhitespace(element);

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.TRUE));
            verify(tagMock2).preserveWhitespace();
        });
    }

    //Sapient generated method id: ${070a8706-8f00-3b88-a5f7-11573ff15552}, hash: 1771FA587A53F1AA643CF2FD3E778D71
    @Test()
    void preserveWhitespaceWhenElIsNull() {
        /* Branches:* (node instanceof Element) : true* (el.tag.preserveWhitespace()) : false* (i < 6) : true* (el != null) : false*/
        //Arrange Statement(s)
        Element elMock = mock(Element.class);
        Element elementMock = mock(Element.class);
        doReturn(elementMock).when(elMock).parent();

        //Act Statement(s)
        boolean result = Element.preserveWhitespace(elMock);

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.FALSE));
            verify(elMock).parent();
        });
    }

    //Sapient generated method id: ${7999c1e1-a1f2-39a0-adb7-de7176bd3b28}, hash: A751EC073CF1ADA562EFF6CEBBC0760D
    @Test()
    void text1WhenOwnerParserIsContentForTagDataNormalName() {
        /* Branches:* (owner != null) : true* (owner.parser().isContentForTagData(normalName())) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Document documentMock = mock(Document.class);
        Parser parserMock = mock(Parser.class);
        Element elementMock2 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).empty();
            doReturn(documentMock).when(target).ownerDocument();
            doReturn(parserMock).when(documentMock).parser();
            doReturn(true).when(parserMock).isContentForTagData("return_of_normalName1");
            doReturn("return_of_normalName1").when(tagMock).normalName();
            doReturn(elementMock2).when(target).appendChild((DataNode) any());
            //Act Statement(s)
            Element result = target.text("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).empty();
                verify(target).ownerDocument();
                verify(documentMock).parser();
                verify(parserMock).isContentForTagData("return_of_normalName1");
                verify(tagMock).normalName();
                verify(target).appendChild((DataNode) any());
            });
        }
    }

    //Sapient generated method id: ${6f490b70-c30d-3d91-b962-7e6b062d1083}, hash: E0B2DB8BB63F767D5CEEC3A67F51C447
    @Test()
    void text1WhenOwnerParserNotIsContentForTagDataNormalName() {
        /* Branches:* (owner != null) : true* (owner.parser().isContentForTagData(normalName())) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Document documentMock = mock(Document.class);
        Parser parserMock = mock(Parser.class);
        Element elementMock2 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).empty();
            doReturn(documentMock).when(target).ownerDocument();
            doReturn(parserMock).when(documentMock).parser();
            doReturn(false).when(parserMock).isContentForTagData("return_of_normalName1");
            doReturn("return_of_normalName1").when(tagMock).normalName();
            doReturn(elementMock2).when(target).appendChild((TextNode) any());
            //Act Statement(s)
            Element result = target.text("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).empty();
                verify(target).ownerDocument();
                verify(documentMock).parser();
                verify(parserMock).isContentForTagData("return_of_normalName1");
                verify(tagMock).normalName();
                verify(target).appendChild((TextNode) any());
            });
        }
    }

    //Sapient generated method id: ${594da9f7-656a-3011-b863-0a835f859040}, hash: BBE203DE28DD0CE2EBBB0D466DA75903
    @Test()
    void hasTextTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).filter((NodeFilter) any());
            //Act Statement(s)
            boolean result = target.hasText();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).filter((NodeFilter) any());
            });
        }
    }

    //Sapient generated method id: ${7cdbecb0-b646-350a-8383-09980c047fc5}, hash: 83D1DCC6BE63C5C066A34B3E67C468E6
    @Test()
    void dataTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).traverse((NodeVisitor) any());
            //Act Statement(s)
            String result = target.data();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).traverse((NodeVisitor) any());
            });
        }
    }

    //Sapient generated method id: ${93f2ee4f-72be-3435-a3f8-c9d6596888ae}, hash: F7D89EEFA6DA19B1CBF2AECCB46BF5C1
    @Test()
    void classNameTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("B ").when(target).attr("class");
            //Act Statement(s)
            String result = target.className();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("B"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).attr("class");
            });
        }
    }

    //Sapient generated method id: ${1b9e09e3-a43c-3d2c-8f28-f1a84150f491}, hash: AD83828E49C8853620E7E7B16019F491
    @Test()
    void classNamesTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("B").when(target).className();
            //Act Statement(s)
            Set<String> result = target.classNames();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result.size(), equalTo(0));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).className();
            });
        }
    }

    //Sapient generated method id: ${dc7105cb-e962-3bab-837e-b63e985921ad}, hash: 144B84C1EE8E603CB20A49C00ECCF85E
    @Test()
    void classNames1WhenClassNamesIsEmpty() {
        /* Branches:* (classNames.isEmpty()) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Attributes attributesMock2 = mock(Attributes.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(anySet())).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(attributesMock2).when(target).attributes();
            doNothing().when(attributesMock2).remove("class");
            Set<String> stringSet = new HashSet<>();
            //Act Statement(s)
            Element result = target.classNames(stringSet);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(anySet()));
                verify(target).attributes();
                verify(attributesMock2).remove("class");
            });
        }
    }

    //Sapient generated method id: ${da1af137-fa27-3617-972b-c006781191f9}, hash: 6BE90B78F5F252B5BCB768BD1BCE7F41
    @Test()
    void classNames1WhenClassNamesNotIsEmpty() {
        /* Branches:* (classNames.isEmpty()) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Attributes attributesMock2 = mock(Attributes.class);
        Attributes attributesMock3 = mock(Attributes.class);
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(anySet())).thenAnswer((Answer<Void>) invocation -> null);
            stringUtil.when(() -> StringUtil.join(anySet(), eq(" "))).thenReturn("return_of_join1");
            target = spy(new Element(tagMock, "", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(attributesMock2).when(target).attributes();
            doReturn(attributesMock3).when(attributesMock2).put("class", "return_of_join1");
            Set<String> stringSet = new HashSet<>();
            stringSet.add("classNamesItem1");
            //Act Statement(s)
            Element result = target.classNames(stringSet);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull(""), atLeast(1));
                validate.verify(() -> Validate.notNull(anySet()));
                stringUtil.verify(() -> StringUtil.join(anySet(), eq(" ")));
                verify(target).attributes();
                verify(attributesMock2).put("class", "return_of_join1");
            });
        }
    }

    //Sapient generated method id: ${9b623ef1-2c38-376d-8823-8099c1fb7ec0}, hash: 921835ACC7119D476BC20F2AC7F9D6D4
    @Test()
    void hasClassWhenAttributesIsNull() {
        /* Branches:* (attributes == null) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", (Attributes) null);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            boolean result = target.hasClass("java.lang.String");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${ea4e3f96-a659-3c47-bec3-978c312c92f5}, hash: ABD6C621BD03D000C182D0DAC2FD812B
    @Test()
    void hasClassWhenLenLessThanWantLen() {
        /* Branches:* (attributes == null) : false* (len == 0) : false* (len < wantLen) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "C", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("A").when(attributesMock).getIgnoreCase("class");
            //Act Statement(s)
            boolean result = target.hasClass("DE");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
                verify(attributesMock).getIgnoreCase("class");
            });
        }
    }

    //Sapient generated method id: ${f3e1d275-f2d9-3346-83be-054c7efcce99}, hash: 864433215D6685E76A3EB2B303749E7B
    @Test()
    void hasClassWhenClassNameEqualsIgnoreCaseClassAttr() {
        /* Branches:* (attributes == null) : false* (len == 0) : false* (len < wantLen) : false* (len == wantLen) : true* (className.equalsIgnoreCase(classAttr)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "C", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("B").when(attributesMock).getIgnoreCase("class");
            //Act Statement(s)
            boolean result = target.hasClass("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
                verify(attributesMock).getIgnoreCase("class");
            });
        }
    }

    //Sapient generated method id: ${fec6174e-8cd7-341f-8574-2fe189657dee}, hash: AB7AFB6B03AA37C3502008E68C018702
    @Test()
    void hasClassWhenClassNameNotEqualsIgnoreCaseClassAttr() {
        /* Branches:* (attributes == null) : false* (len == 0) : false* (len < wantLen) : false* (len == wantLen) : true* (className.equalsIgnoreCase(classAttr)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "C", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("A").when(attributesMock).getIgnoreCase("class");
            //Act Statement(s)
            boolean result = target.hasClass("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
                verify(attributesMock).getIgnoreCase("class");
            });
        }
    }

    //Sapient generated method id: ${07894174-11fc-397d-930f-c4e9197b14f0}, hash: 3991C3522DCAD9C5B7229CE3EF8BEFF4
    @Test()
    void hasClassWhenNotInClass() {
        /* Branches:* (attributes == null) : false* (len == 0) : false* (len < wantLen) : false* (len == wantLen) : false* (i < len) : true* (Character.isWhitespace(classAttr.charAt(i))) : true* (inClass) : false* (inClass) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("baseUri1")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "baseUri1", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("return_of_getIgnoreCase1").when(attributesMock).getIgnoreCase("class");
            //Act Statement(s)
            boolean result = target.hasClass("java.lang.String");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("baseUri1"), atLeast(1));
                verify(attributesMock).getIgnoreCase("class");
            });
        }
    }

    //Sapient generated method id: ${9b024dea-b48a-336e-a1d9-463350fcac69}, hash: 96729A8438038498D68B8075B1B217DC
    @Test()
    void hasClassWhenLenMinusStartNotEqualsWantLen() {
        /* Branches:* (attributes == null) : false* (len == 0) : false* (len < wantLen) : false* (len == wantLen) : false* (i < len) : true* (Character.isWhitespace(classAttr.charAt(i))) : false* (!inClass) : true* (inClass) : true* (len - start == wantLen) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("A").when(attributesMock).getIgnoreCase("class");
            //Act Statement(s)
            boolean result = target.hasClass("");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull(""), atLeast(1));
                verify(attributesMock).getIgnoreCase("class");
            });
        }
    }

    //Sapient generated method id: ${a58c18cf-8c05-37d2-b7e7-d66e52576678}, hash: F35B52658D5B221BE4F2077BB3C482BB
    @Test()
    void addClassTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Set<String> stringSet = new HashSet<>();
            stringSet.add("B");
            doReturn(stringSet).when(target).classNames();
            doReturn(elementMock).when(target).classNames(stringSet);
            //Act Statement(s)
            Element result = target.addClass("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).classNames();
                verify(target).classNames(stringSet);
            });
        }
    }

    //Sapient generated method id: ${9750823a-3388-3de9-9510-00ca26300686}, hash: 2CFABFCC1A14E8F5296A47E918C8C3B3
    @Test()
    void removeClassTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Set<String> stringSet = new HashSet<>();
            doReturn(stringSet).when(target).classNames();
            doReturn(elementMock).when(target).classNames(stringSet);
            //Act Statement(s)
            Element result = target.removeClass("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).classNames();
                verify(target).classNames(stringSet);
            });
        }
    }

    //Sapient generated method id: ${a906d526-84a3-3ba3-986e-8ee25b98ed39}, hash: 7584233DB59D2029EB008DCD0086226A
    @Test()
    void toggleClassWhenClassesContainsClassName() {
        /* Branches:* (classes.contains(className)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Set<String> stringSet = new HashSet<>();
            doReturn(stringSet).when(target).classNames();
            doReturn(elementMock).when(target).classNames(stringSet);
            //Act Statement(s)
            Element result = target.toggleClass("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).classNames();
                verify(target).classNames(stringSet);
            });
        }
    }

    //Sapient generated method id: ${dacc3b1c-7df2-3318-a7b7-c249c674adab}, hash: 177D5062513AB0FCBDE00247BD95FD7D
    @Test()
    void toggleClassWhenClassesNotContainsClassName() {
        /* Branches:* (classes.contains(className)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Set<String> stringSet = new HashSet<>();
            stringSet.add("B");
            doReturn(stringSet).when(target).classNames();
            doReturn(elementMock).when(target).classNames(stringSet);
            //Act Statement(s)
            Element result = target.toggleClass("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
                verify(target).classNames();
                verify(target).classNames(stringSet);
            });
        }
    }

    //Sapient generated method id: ${739a4ac6-15fa-36a6-b20e-472aa80a5a83}, hash: 252DC568C8D5E7C85F13AAFCB5EFBF16
    @Test()
    void valWhenElementIsTextareaNamespaceHtml() {
        /* Branches:* (elementIs("textarea", NamespaceHtml)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(true).when(target).elementIs("textarea", "http://www.w3.org/1999/xhtml");
            doReturn("return_of_text1").when(target).text();
            //Act Statement(s)
            String result = target.val();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_text1"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).elementIs("textarea", "http://www.w3.org/1999/xhtml");
                verify(target).text();
            });
        }
    }

    //Sapient generated method id: ${dbf1f27b-ae9c-3644-ab8c-04e430c779a7}, hash: BA85193B53A8C84343C13C1C53712103
    @Test()
    void valWhenElementIsNotTextareaNamespaceHtml() {
        /* Branches:* (elementIs("textarea", NamespaceHtml)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(target).elementIs("textarea", "http://www.w3.org/1999/xhtml");
            doReturn("return_of_attr1").when(target).attr("value");
            //Act Statement(s)
            String result = target.val();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_attr1"));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).elementIs("textarea", "http://www.w3.org/1999/xhtml");
                verify(target).attr("value");
            });
        }
    }

    //Sapient generated method id: ${91da3e6d-c6fc-34f0-9543-e3fd9eaac0dd}, hash: 6499B0379A48698BB7B2182A9693E231
    @Test()
    void val1WhenElementIsTextareaNamespaceHtml() {
        /* Branches:* (elementIs("textarea", NamespaceHtml)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(true).when(target).elementIs("textarea", "http://www.w3.org/1999/xhtml");
            doReturn(elementMock).when(target).text("value1");
            //Act Statement(s)
            Element result = target.val("value1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).elementIs("textarea", "http://www.w3.org/1999/xhtml");
                verify(target).text("value1");
            });
        }
    }

    //Sapient generated method id: ${459b8e6d-8308-3041-8559-6fff0f7fbfe4}, hash: D3AF2ADB92DA9FF8DA63DE0C7A21BCF6
    @Test()
    void val1WhenElementIsNotTextareaNamespaceHtml() {
        /* Branches:* (elementIs("textarea", NamespaceHtml)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(target).elementIs("textarea", "http://www.w3.org/1999/xhtml");
            doReturn(elementMock).when(target).attr("value", "value1");
            //Act Statement(s)
            Element result = target.val("value1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).elementIs("textarea", "http://www.w3.org/1999/xhtml");
                verify(target).attr("value", "value1");
            });
        }
    }

    //Sapient generated method id: ${ccda0873-bc8e-3873-8aad-af022e93cb07}, hash: D602FCBAA2EB11960FBB70DCBF6E2320
    @Test()
    void endSourceRangeTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Range rangeMock = mock(Range.class);
        try (MockedStatic<Range> range = mockStatic(Range.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            range.when(() -> Range.of(target, false)).thenReturn(rangeMock);
            //Act Statement(s)
            Range result = target.endSourceRange();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(rangeMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                range.verify(() -> Range.of(target, false), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${b216182d-9f79-3a32-9229-4eaec3f43b7f}, hash: 2BC5606A36A934C7F105D0DAEADA88E2
    @Test()
    void shouldIndentWhenIsFormatAsBlockNotOut() {
        /* Branches:* (out.prettyPrint()) : true* (tag.isBlock()) : false  #  inside isFormatAsBlock method* (parent() != null) : false  #  inside isFormatAsBlock method* (out.outline()) : false  #  inside isFormatAsBlock method* (isFormatAsBlock(out)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document.OutputSettings outMock = mock(Document.OutputSettings.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn(true).when(outMock).prettyPrint();
            doReturn(false).when(outMock).outline();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(tagMock).isBlock();
            //Act Statement(s)
            boolean result = target.shouldIndent(outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                verify(outMock).prettyPrint();
                verify(outMock).outline();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).isBlock();
            });
        }
    }

    //Sapient generated method id: ${4518fc91-cb21-3780-be7b-e9ad1e65f183}, hash: E9A1B2A462DB0FF72175BAD450061BBB
    @Test()
    void shouldIndentWhenPreserveWhitespaceNotParentNode() {
        /* Branches:* (out.prettyPrint()) : true* (tag.isBlock()) : false  #  inside isFormatAsBlock method* (parent() != null) : false  #  inside isFormatAsBlock method* (out.outline()) : true  #  inside isFormatAsBlock method* (isFormatAsBlock(out)) : true* (!tag.isInline()) : true  #  inside isInlineable method* (!isInlineable(out)) : true* (!preserveWhitespace(parentNode)) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document.OutputSettings outMock = mock(Document.OutputSettings.class);
        try (MockedStatic<Element> element = mockStatic(Element.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn(true).when(outMock).prettyPrint();
            doReturn(true).when(outMock).outline();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            element.when(() -> Element.preserveWhitespace((Element) null)).thenReturn(false);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(tagMock).isBlock();
            doReturn(false).when(tagMock).isInline();
            //Act Statement(s)
            boolean result = target.shouldIndent(outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                verify(outMock).prettyPrint();
                verify(outMock).outline();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                element.verify(() -> Element.preserveWhitespace((Element) null), atLeast(1));
                verify(tagMock).isBlock();
                verify(tagMock).isInline();
            });
        }
    }

    //Sapient generated method id: ${27808092-2740-32d9-9671-287fe900ad2a}, hash: 93806D112DBBC8530E4119596F081013
    @Test()
    void shouldIndentWhenIsInlineableOut() {
        /* Branches:* (out.prettyPrint()) : true* (tag.isBlock()) : false  #  inside isFormatAsBlock method* (parent() != null) : false  #  inside isFormatAsBlock method* (out.outline()) : true  #  inside isFormatAsBlock method* (isFormatAsBlock(out)) : true* (!tag.isInline()) : false  #  inside isInlineable method* (parent() == null) : true  #  inside isInlineable method* (!isEffectivelyFirst()) : true  #  inside isInlineable method* (!out.outline()) : true  #  inside isInlineable method* (!nameIs("br")) : true  #  inside isInlineable method* (!isInlineable(out)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document.OutputSettings outMock = mock(Document.OutputSettings.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn(true).when(outMock).prettyPrint();
            doReturn(true, false).when(outMock).outline();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(tagMock).isBlock();
            doReturn(true).when(tagMock).isInline();
            doReturn(false).when(target).isEffectivelyFirst();
            doReturn(false).when(target).nameIs("br");
            //Act Statement(s)
            boolean result = target.shouldIndent(outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                verify(outMock).prettyPrint();
                verify(outMock, times(2)).outline();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(tagMock).isBlock();
                verify(tagMock).isInline();
                verify(target).isEffectivelyFirst();
                verify(target).nameIs("br");
            });
        }
    }

    //Sapient generated method id: ${853cab0c-2619-381a-9179-58bde10c49fb}, hash: 38013D03D4966FE483E0920B093D3D38
    @Test()
    void shouldIndentWhenNameIsBrAndIsInlineableNotOutAndPreserveWhitespaceParentNode() {
        /* Branches:* (out.prettyPrint()) : true* (tag.isBlock()) : false  #  inside isFormatAsBlock method* (parent() != null) : false  #  inside isFormatAsBlock method* (out.outline()) : true  #  inside isFormatAsBlock method* (isFormatAsBlock(out)) : true* (!tag.isInline()) : false  #  inside isInlineable method* (parent() == null) : true  #  inside isInlineable method* (!isEffectivelyFirst()) : true  #  inside isInlineable method* (!out.outline()) : true  #  inside isInlineable method* (!nameIs("br")) : false  #  inside isInlineable method* (!isInlineable(out)) : true* (!preserveWhitespace(parentNode)) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document.OutputSettings outMock = mock(Document.OutputSettings.class);
        try (MockedStatic<Element> element = mockStatic(Element.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn(true).when(outMock).prettyPrint();
            doReturn(true, false).when(outMock).outline();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            element.when(() -> Element.preserveWhitespace((Element) null)).thenReturn(true);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(tagMock).isBlock();
            doReturn(true).when(tagMock).isInline();
            doReturn(false).when(target).isEffectivelyFirst();
            doReturn(true).when(target).nameIs("br");
            //Act Statement(s)
            boolean result = target.shouldIndent(outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                verify(outMock).prettyPrint();
                verify(outMock, times(2)).outline();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                element.verify(() -> Element.preserveWhitespace((Element) null), atLeast(1));
                verify(tagMock).isBlock();
                verify(tagMock).isInline();
                verify(target).isEffectivelyFirst();
                verify(target).nameIs("br");
            });
        }
    }

    //Sapient generated method id: ${82769142-e74a-38ea-9f72-a9ac95b75d92}, hash: F66FAD32195B32B95D1F8F8F49E684EC
    @Test()
    void outerHtmlHeadWhenAccumLengthGreaterThan0AndAttributesIsNotNullAndChildNodesIsEmptyAndTagNotIsSelfClosing() throws IOException {
        /* Branches:* (shouldIndent(out)) : true* (accum instanceof StringBuilder) : true* (((StringBuilder) accum).length() > 0) : true* (attributes != null) : true* (childNodes.isEmpty()) : true* (tag.isSelfClosing()) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document.OutputSettings outMock = mock(Document.OutputSettings.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn(0).when(outMock).indentAmount();
            doReturn(-1).when(outMock).maxPaddingWidth();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(true).when(target).shouldIndent(outMock);
            doReturn("return_of_getName1").when(tagMock).getName();
            StringBuilder stringBuilder = new StringBuilder();
            doNothing().when(attributesMock).html(stringBuilder, outMock);
            doReturn(false).when(tagMock).isSelfClosing();
            //Act Statement(s)
            target.outerHtmlHead(stringBuilder, -1, outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).indentAmount();
                verify(outMock).maxPaddingWidth();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).shouldIndent(outMock);
                verify(tagMock).getName();
                verify(attributesMock).html(stringBuilder, outMock);
                verify(tagMock).isSelfClosing();
            });
        }
    }

    //Sapient generated method id: ${c1f998f1-0f13-37e6-8b20-ec9ab5c2baed}, hash: 2297440E53DBA05F883CBE1471098F5E
    @Test()
    void outerHtmlHeadWhenTagIsSelfClosingAndOutSyntaxEqualsDocumentOutputSettingsSyntaxHtmlAndTagNotIsEmpty() throws IOException {
        /* Branches:* (shouldIndent(out)) : true* (accum instanceof StringBuilder) : false* (attributes != null) : true* (childNodes.isEmpty()) : true* (tag.isSelfClosing()) : true* (out.syntax() == Document.OutputSettings.Syntax.html) : true* (tag.isEmpty()) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document.OutputSettings outMock = mock(Document.OutputSettings.class);
        Appendable appendableMock = mock(Appendable.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn(1).when(outMock).indentAmount();
            doReturn(0).when(outMock).maxPaddingWidth();
            doReturn(Document.OutputSettings.Syntax.html).when(outMock).syntax();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(true).when(target).shouldIndent(outMock);
            doReturn("return_of_getName1").when(tagMock).getName();
            doNothing().when(attributesMock).html(appendableMock, outMock);
            doReturn(true).when(tagMock).isSelfClosing();
            doReturn(false).when(tagMock).isEmpty();
            //Act Statement(s)
            target.outerHtmlHead(appendableMock, 0, outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).indentAmount();
                verify(outMock).maxPaddingWidth();
                verify(outMock).syntax();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).shouldIndent(outMock);
                verify(tagMock).getName();
                verify(attributesMock).html(appendableMock, outMock);
                verify(tagMock).isSelfClosing();
                verify(tagMock).isEmpty();
            });
        }
    }

    //Sapient generated method id: ${29f6d681-df2b-3f97-acfc-148375cddeff}, hash: 9E32D520E8A1BBDBBB4D355DD6295004
    @Test()
    void outerHtmlHeadWhenAttributesIsNotNullAndChildNodesIsEmptyAndTagIsSelfClosingAndOutSyntaxEqualsDocumentOutputSettingsSynt() throws IOException {
        /* Branches:* (shouldIndent(out)) : true* (accum instanceof StringBuilder) : true* (((StringBuilder) accum).length() > 0) : true* (attributes != null) : true* (childNodes.isEmpty()) : true* (tag.isSelfClosing()) : true* (out.syntax() == Document.OutputSettings.Syntax.html) : true* (tag.isEmpty()) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document.OutputSettings outMock = mock(Document.OutputSettings.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn(0).when(outMock).indentAmount();
            doReturn(-1).when(outMock).maxPaddingWidth();
            doReturn(Document.OutputSettings.Syntax.html).when(outMock).syntax();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(true).when(target).shouldIndent(outMock);
            doReturn("return_of_getName1").when(tagMock).getName();
            StringBuilder stringBuilder = new StringBuilder();
            doNothing().when(attributesMock).html(stringBuilder, outMock);
            doReturn(true).when(tagMock).isSelfClosing();
            doReturn(true).when(tagMock).isEmpty();
            //Act Statement(s)
            target.outerHtmlHead(stringBuilder, -1, outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).indentAmount();
                verify(outMock).maxPaddingWidth();
                verify(outMock).syntax();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).shouldIndent(outMock);
                verify(tagMock).getName();
                verify(attributesMock).html(stringBuilder, outMock);
                verify(tagMock).isSelfClosing();
                verify(tagMock).isEmpty();
            });
        }
    }

    //Sapient generated method id: ${b4929452-8cbe-3ce9-8fed-9ec7af7f86b7}, hash: 58EF17B2ADEF75878CFC3BCDD1EC62A0
    @Test()
    void outerHtmlTailWhenOutPrettyPrintAndChildNodesNotIsEmptyAndTagFormatAsBlockAndPreserveWhitespaceParentNodeAndOutOutline() throws IOException {
        /* Branches:* (!(childNodes.isEmpty() && tag.isSelfClosing())) : false* (childNodes.isEmpty()) : false* (out.prettyPrint()) : true* (!childNodes.isEmpty()) : true* (tag.formatAsBlock()) : true* (!preserveWhitespace(parentNode)) : false* (out.outline()) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document.OutputSettings outMock = mock(Document.OutputSettings.class);
        Appendable appendableMock = mock(Appendable.class);
        try (MockedStatic<StringUtil> stringUtil = mockStatic(StringUtil.class);
             MockedStatic<Element> element = mockStatic(Element.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            doReturn(false).when(outMock).prettyPrint();
            doReturn(false).when(outMock).outline();
            doReturn(0).when(outMock).indentAmount();
            doReturn(0).when(outMock).maxPaddingWidth();
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("baseUri1")).thenAnswer((Answer<Void>) invocation -> null);
            element.when(() -> Element.preserveWhitespace((Node) null)).thenReturn(false);
            stringUtil.when(() -> StringUtil.padding(0, 0)).thenReturn("return_of_padding1");
            target = new Element(tagMock, "baseUri1", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(false).when(tagMock).isSelfClosing();
            doReturn(false).when(tagMock).formatAsBlock();
            doReturn("return_of_getName1").when(tagMock).getName();
            //Act Statement(s)
            target.outerHtmlTail(appendableMock, 0, outMock);
            //Assert statement(s)
            assertAll("result", () -> {
                verify(outMock).prettyPrint();
                verify(outMock).outline();
                verify(outMock).indentAmount();
                verify(outMock).maxPaddingWidth();
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("baseUri1"), atLeast(1));
                element.verify(() -> Element.preserveWhitespace((Node) null), atLeast(1));
                stringUtil.verify(() -> StringUtil.padding(0, 0), atLeast(1));
                verify(tagMock).isSelfClosing();
                verify(tagMock).formatAsBlock();
                verify(tagMock).getName();
            });
        }
    }

    //Sapient generated method id: ${d99cce78-8415-3d32-bb77-ae806f9ed14b}, hash: EBC10101B33EACC72B1FC6D9F4665E23
    @Test()
    void html1WhenNodeUtilsOutputSettingsThisPrettyPrint() {
        /* Branches:* (NodeUtils.outputSettings(this).prettyPrint()) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Appendable appendableMock = mock(Appendable.class);
        Document.OutputSettings documentOutputSettingsMock = mock(Document.OutputSettings.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(appendableMock).when(target).html((StringBuilder) any());
            nodeUtils.when(() -> NodeUtils.outputSettings(target)).thenReturn(documentOutputSettingsMock);
            doReturn(true).when(documentOutputSettingsMock).prettyPrint();
            //Act Statement(s)
            String result = target.html();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).html((StringBuilder) any());
                nodeUtils.verify(() -> NodeUtils.outputSettings(target), atLeast(1));
                verify(documentOutputSettingsMock).prettyPrint();
            });
        }
    }

    //Sapient generated method id: ${625f42a3-3330-3b24-9cdb-8607dd32d11b}, hash: 4B5CB6E8F35BE0172E4F84DA417295DF
    @Test()
    void html1WhenNodeUtilsOutputSettingsThisNotPrettyPrint() {
        /* Branches:* (NodeUtils.outputSettings(this).prettyPrint()) : false** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Appendable appendableMock = mock(Appendable.class);
        Document.OutputSettings documentOutputSettingsMock = mock(Document.OutputSettings.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(appendableMock).when(target).html((StringBuilder) any());
            nodeUtils.when(() -> NodeUtils.outputSettings(target)).thenReturn(documentOutputSettingsMock);
            doReturn(false).when(documentOutputSettingsMock).prettyPrint();
            //Act Statement(s)
            String result = target.html();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).html((StringBuilder) any());
                nodeUtils.verify(() -> NodeUtils.outputSettings(target), atLeast(1));
                verify(documentOutputSettingsMock).prettyPrint();
            });
        }
    }

    //Sapient generated method id: ${0ab9b732-5b98-300a-8a33-79b118c01097}, hash: 6A3546C998D66E02965B634C80DE6F4B
    @Test()
    void htmlWhenILessThanSize() {
        /* Branches:* (i < size) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Appendable appendableMock = mock(Appendable.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Appendable result = target.html(appendableMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(appendableMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${0f1aac95-a1f3-3d9a-996c-a2ac70629d08}, hash: E2D54FC6D2B7B17FB49E443047645896
    @Test()
    void html2Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Element elementMock2 = mock(Element.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).empty();
            doReturn(elementMock2).when(target).append("html1");
            //Act Statement(s)
            Element result = target.html("html1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).empty();
                verify(target).append("html1");
            });
        }
    }

    //Sapient generated method id: ${764db783-8b0e-317c-af70-ad2917d0d6f8}, hash: C7B0D35311EE984F638C8248E077D7D8
    @Test()
    void clone2WhenILessThanSize() throws CloneNotSupportedException {
        /* Branches:* (!nodesToProcess.isEmpty()) : true  #  inside clone method* (i < size) : true  #  inside clone method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Element elementMock = mock(Element.class);
        Node currParentMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("baseUri1")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "baseUri1", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(elementMock).when(target).doClone((Node) null);
            doReturn(0).when(currParentMock).childNodeSize();
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(currParentMock).ensureChildNodes();
            //Act Statement(s)
            Element result = target.clone();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(currParentMock));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("baseUri1"), atLeast(1));
                verify(target).doClone((Node) null);
                verify(currParentMock, atLeast(1)).childNodeSize();
                verify(currParentMock, atLeast(1)).ensureChildNodes();
            });
        }
    }

    //Sapient generated method id: ${da5a1dc2-f90f-3458-b0fa-476dc01911b6}, hash: 63058E08EB058D4007193822C56354C2
    @Test()
    void shallowClone1WhenAttributesIsNotNullAndDefaultBranch() {
        /* Branches:* (baseUri.isEmpty()) : true* (attributes == null) : false* (branch expression (line 88)) : false  #  inside <init> method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Attributes attributesMock2 = mock(Attributes.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("").when(target).baseUri();
            doReturn(attributesMock2).when(attributesMock).clone();
            //Act Statement(s)
            Element result = target.shallowClone();
            Element element = new Element(tagMock, (String) null, attributesMock2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(element));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(2));
                validate.verify(() -> Validate.notNull(""), atLeast(1));
                verify(target).baseUri();
                verify(attributesMock).clone();
            });
        }
    }

    //Sapient generated method id: ${75b5a098-77bf-3a04-b185-7888d971001c}, hash: 6E5F8320A551C7582F14F9B2D2B5F4A3
    @Test()
    void shallowClone1WhenAttributesIsNullAndDefaultBranch() {
        /* Branches:* (baseUri.isEmpty()) : false* (attributes == null) : true* (branch expression (line 88)) : false  #  inside <init> method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("C")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "C", (Attributes) null));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn("A").when(target).baseUri();
            //Act Statement(s)
            Element result = target.shallowClone();
            Element element = new Element(tagMock, "A", (Attributes) null);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(element));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(2));
                validate.verify(() -> Validate.notNull("C"), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).baseUri();
            });
        }
    }

    //Sapient generated method id: ${df79363f-048a-3695-9799-61720c1c239a}, hash: 9F28F273515FAF1C7D2B885AC24EA8C1
    @Test()
    void doClone1WhenElsSizeEquals1ThrowsRuntimeException() {
        /* Branches:* (els.size() == 1) : true  #  inside doClone method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            final RuntimeException result = assertThrows(RuntimeException.class, () -> {
                target.doClone(nodeMock);
            });
            CloneNotSupportedException cloneNotSupportedException = new CloneNotSupportedException();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                assertThat(result.getCause(), is(instanceOf(cloneNotSupportedException.getClass())));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${0e9cb0c5-8eff-373d-9771-de13608ba658}, hash: F1E6D5F9B2A2F1C1F15895E56263832B
    @Test()
    void doClone1WhenAttributesIsNull() throws CloneNotSupportedException {
        /* Branches:* (parent == null) : false  #  inside doClone method* (parent == null) : false  #  inside doClone method* (attributes != null) : false** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: childNodes*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", (Attributes) null);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.doClone(nodeMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${11121988-a512-3c40-b62e-a3505ae322ed}, hash: 45996156443A4C1181E95B21CB041B83
    @Test()
    void doClone1WhenAttributesIsNotNull() throws CloneNotSupportedException {
        /* Branches:* (parent == null) : true  #  inside doClone method* (parent == null) : true  #  inside doClone method* (!(this instanceof Document)) : true  #  inside doClone method* (doc != null) : true  #  inside doClone method* (attributes != null) : true** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: childNodes*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Document documentMock = mock(Document.class);
        Document documentMock2 = mock(Document.class);
        Attributes attributesMock2 = mock(Attributes.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = spy(new Element(tagMock, "A", attributesMock));
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(documentMock).when(target).ownerDocument();
            doReturn(documentMock2).when(documentMock).shallowClone();
            List<Node> nodeList = new ArrayList<>();
            doReturn(nodeList).when(documentMock2).ensureChildNodes();
            doReturn(attributesMock2).when(attributesMock).clone();
            Node node = null;
            //Act Statement(s)
            Element result = target.doClone(node);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(target).ownerDocument();
                verify(documentMock).shallowClone();
                verify(documentMock2).ensureChildNodes();
                verify(attributesMock).clone();
            });
        }
    }

    //Sapient generated method id: ${53251649-efc3-3699-ba55-c9b847f4a208}, hash: 3A4332C7C2766AE4FBA9B54130740E50
    @Test()
    void clearAttributes1WhenAttributesSizeEquals0() {
        /* Branches:* (attributes != null) : true* (hasAttributes()) : true  #  inside clearAttributes method* (it.hasNext()) : true  #  inside clearAttributes method* (attributes.size() == 0) : true** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            doReturn(0).when(attributesMock).size();
            //Act Statement(s)
            Element result = target.clearAttributes();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                verify(attributesMock).size();
            });
        }
    }

    //Sapient generated method id: ${bf57583c-47cc-3581-8708-1348557be904}, hash: 1FDA6391AB81F65C43F64D275B4D3F41
    @Test()
    void removeAttr1WhenHasAttributes() {
        /* Branches:* (hasAttributes()) : true  #  inside removeAttr method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("B")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.removeAttr("B");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull("B"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${de08df4e-c9b3-3abc-9e85-b4f4643c2be2}, hash: EF0787EF976DEB7236AEB380497C7CDE
    @Test()
    void root1WhenNodeParentNodeIsNotNull() {
        /* Branches:* (node.parentNode != null) : true  #  inside root method** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.root();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${db1b7cc7-548c-3519-bc63-8cf7ada29dcc}, hash: 8EDA82C2164FF009A24A20200261B959
    @Test()
    void traverse1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        NodeVisitor nodeVisitorMock = mock(NodeVisitor.class);
        try (MockedStatic<NodeTraversor> nodeTraversor = mockStatic(NodeTraversor.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(nodeVisitorMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeTraversor.when(() -> NodeTraversor.traverse(nodeVisitorMock, target)).thenAnswer((Answer<Void>) invocation -> null);
            //Act Statement(s)
            Element result = target.traverse(nodeVisitorMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(nodeVisitorMock), atLeast(1));
                nodeTraversor.verify(() -> NodeTraversor.traverse(nodeVisitorMock, target), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${554bbbf1-5212-342e-99de-bda86bd90610}, hash: 2798060E57BFD5950D9F6A15C327EBA0
    @Test()
    void forEachNode1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Consumer consumerMock = mock(Consumer.class);
        try (MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            //Act Statement(s)
            Element result = target.forEachNode(consumerMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, is(notNullValue()));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${eaf48a4e-d2f2-3434-bc4f-1847fbe649f9}, hash: 9DF9A274CECEFE612B067B60C4D70746
    @Test()
    void forEachTest() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        Consumer consumerMock = mock(Consumer.class);
        try (MockedStatic<NodeUtils> nodeUtils = mockStatic(NodeUtils.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            Stream stream = Stream.empty();
            nodeUtils.when(() -> NodeUtils.stream(target, Element.class)).thenReturn(stream);
            //Act Statement(s)
            Element result = target.forEach(consumerMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                nodeUtils.verify(() -> NodeUtils.stream(target, Element.class), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${74c35f30-6267-38c5-91c2-62a2069cdd65}, hash: E1735C730397B059CA96646CB658D676
    @Test()
    void filter1Test() {
        /** TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Arrange Statement(s)
        NodeFilter nodeFilterMock = mock(NodeFilter.class);
        try (MockedStatic<NodeTraversor> nodeTraversor = mockStatic(NodeTraversor.class);
             MockedStatic<Validate> validate = mockStatic(Validate.class)) {
            validate.when(() -> Validate.notNull(tagMock)).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull("A")).thenAnswer((Answer<Void>) invocation -> null);
            validate.when(() -> Validate.notNull(nodeFilterMock)).thenAnswer((Answer<Void>) invocation -> null);
            target = new Element(tagMock, "A", attributesMock);
            autoCloseableMocks = MockitoAnnotations.openMocks(this);
            nodeTraversor.when(() -> NodeTraversor.filter(nodeFilterMock, target)).thenReturn(NodeFilter.FilterResult.CONTINUE);
            //Act Statement(s)
            Element result = target.filter(nodeFilterMock);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(target));
                validate.verify(() -> Validate.notNull(tagMock), atLeast(1));
                validate.verify(() -> Validate.notNull("A"), atLeast(1));
                validate.verify(() -> Validate.notNull(nodeFilterMock), atLeast(1));
                nodeTraversor.verify(() -> NodeTraversor.filter(nodeFilterMock, target), atLeast(1));
            });
        }
    }
}
