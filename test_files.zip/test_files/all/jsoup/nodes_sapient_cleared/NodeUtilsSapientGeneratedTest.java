package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;

import org.jsoup.parser.Parser;

import static org.mockito.Mockito.times;

import org.junit.jupiter.api.Disabled;

import java.util.List;

import org.mockito.stubbing.Answer;
import org.jsoup.helper.Validate;
import org.mockito.MockedStatic;

import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;

import java.util.stream.Stream;
import java.util.Spliterator;
import java.util.Iterator;
import java.util.ArrayList;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class NodeUtilsSapientGeneratedTest {

    private final Node nodeMock = mock(Node.class);

    private final Document documentMock = mock(Document.class);

    //Sapient generated method id: ${9b93f6ab-c9ff-304d-b3c4-1e28ac691bbd}, hash: ED55EC09A97AA62C54AA9BE20C4F8F85
    @Test()
    void outputSettingsWhenOwnerIsNotNull() {
        /* Branches:* (owner != null) : true*/
        //Arrange Statement(s)
        doReturn(documentMock).when(nodeMock).ownerDocument();
        Document.OutputSettings documentOutputSettingsMock = mock(Document.OutputSettings.class);
        doReturn(documentOutputSettingsMock).when(documentMock).outputSettings();

        //Act Statement(s)
        Document.OutputSettings result = NodeUtils.outputSettings(nodeMock);

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(documentOutputSettingsMock));
            verify(nodeMock).ownerDocument();
            verify(documentMock).outputSettings();
        });
    }

    //Sapient generated method id: ${8496af81-0140-310f-b12c-2d71427cf3e3}, hash: 4A274FC8B5D6D689BD1C8A814BEFD7F1
    @Test()
    void outputSettingsWhenOwnerIsNull() {
        /* Branches:* (owner != null) : false*/
        //Arrange Statement(s)
        doReturn(null).when(nodeMock).ownerDocument();

        //Act Statement(s)
        Document.OutputSettings result = NodeUtils.outputSettings(nodeMock);

        //Assert statement(s)
        //TODO: Please implement equals method in OutputSettings for verification of the entire object or you need to adjust respective assertion statements
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            verify(nodeMock).ownerDocument();
        });
    }

    //Sapient generated method id: ${8460c81b-69ce-376f-b7a8-3d2b2318c272}, hash: 872B1C5A4BCE8B7D444EF5C297BC1E8D
    @Test()
    void parserWhenDocParserIsNotNull() {
        /* Branches:* (doc != null) : true* (doc.parser() != null) : true*/
        //Arrange Statement(s)
        doReturn(documentMock).when(nodeMock).ownerDocument();

        //Act Statement(s)
        Parser result = NodeUtils.parser(nodeMock);

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            verify(nodeMock).ownerDocument();
        });
    }

    //Sapient generated method id: ${307ad389-4f5b-3d6a-a3f3-728697852748}, hash: A9E7557943061DAF8BB8C3881F055B2F
    @Test()
    void parserWhenDocParserIsNull() {
        /* Branches:* (doc != null) : true* (doc.parser() != null) : false*/
        //Arrange Statement(s)
        doReturn(documentMock).when(nodeMock).ownerDocument();
        doReturn(null).when(documentMock).parser();

        //Act Statement(s)
        Parser result = NodeUtils.parser(nodeMock);

        //Assert statement(s)
        //TODO: Please implement equals method in Parser for verification of the entire object or you need to adjust respective assertion statements
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            verify(nodeMock).ownerDocument();
            verify(documentMock).parser();
        });
    }


    //Sapient generated method id: ${b4af2388-e781-3800-820a-b8ede09bd914}, hash: C708B61CF124362D74269B5A87AD3085
    @Test()
    void streamTest() {
        //Arrange Statement(s)
        Node nodeMock = mock(Node.class, "someNode");

        //Act Statement(s)
        Stream result = NodeUtils.stream(nodeMock, Node.class);

        //Assert statement(s)
        //TODO: Please implement equals method in Stream for verification of the entire object or you need to adjust respective assertion statements
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }
}
