package org.jsoup.nodes;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Disabled;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class RangeSapientGeneratedTest {

    private final Range.Position rangePositionMock = mock(Range.Position.class);

    private final Range.Position rangePositionMock2 = mock(Range.Position.class);

    private final Attributes attributesMock = mock(Attributes.class);

    private final Node nodeMock = mock(Node.class);

    //Sapient generated method id: ${a9331398-240e-36aa-9522-b3dc4bcf14ad}, hash: D101AFA9C0F7707E171D7C9C618F4A9C
    @Test()
    void startTest() {
        //Arrange Statement(s)
        Range target = new Range(rangePositionMock, rangePositionMock2);

        //Act Statement(s)
        Range.Position result = target.start();

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(rangePositionMock)));
    }


    //Sapient generated method id: ${ad1c9377-0a10-3767-87a5-3115a50be4cd}, hash: 9D1A26DB51DBE0BD7AEA3D751DA1E9BE
    @Test()
    void endTest() {
        //Arrange Statement(s)
        Range target = new Range(rangePositionMock, rangePositionMock2);

        //Act Statement(s)
        Range.Position result = target.end();

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(rangePositionMock2)));
    }


    //Sapient generated method id: ${9d3fab73-bbb5-3591-81d3-0ecc1b35cf8b}, hash: 7DF9BDA169DF1811896704753EBAB4F4
    @Test()
    void isTrackedWhenThisNotEqualsUntracked() {
        /* Branches:* (this != Untracked) : true*/
        //Arrange Statement(s)
        Range target = new Range(rangePositionMock, rangePositionMock2);

        //Act Statement(s)
        boolean result = target.isTracked();

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.TRUE)));
    }

    //Sapient generated method id: ${a934f835-acea-341d-a73e-6e2c19945c7f}, hash: 5E13DE788B38B3CB8C177D3C0CDDF9D7
    @Test()
    void isTrackedWhenThisEqualsUntracked() {
        /* Branches:* (this != Untracked) : false*/
        //Arrange Statement(s)
        Range target = new Range(rangePositionMock, rangePositionMock2);

        //Act Statement(s)
        boolean result = target.isTracked();

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(Boolean.FALSE)));
    }

    //Sapient generated method id: ${7c8a7e38-7f0f-3db9-a039-a8923ef670eb}, hash: 2E37CA762E109A081FA1970F2EE584DB
    @Test()
    void isImplicitWhenIsTrackedNot() {
        /* Branches:* (!isTracked()) : true*/
        //Arrange Statement(s)
        Range target = spy(new Range(rangePositionMock, rangePositionMock2));
        doReturn(false).when(target).isTracked();

        //Act Statement(s)
        boolean result = target.isImplicit();

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.FALSE));
            verify(target).isTracked();
        });
    }

    //Sapient generated method id: ${fc374971-1061-347c-8ab5-a9fa127d4371}, hash: 0C07D4D1010957E81FDB8FDF6C3F43C2
    @Test()
    void isImplicitWhenStartEqualsEnd() {
        /* Branches:* (!isTracked()) : false* (start.equals(end)) : true*/
        //Arrange Statement(s)
        Range target = spy(new Range(rangePositionMock, rangePositionMock));
        doReturn(true).when(target).isTracked();

        //Act Statement(s)
        boolean result = target.isImplicit();

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.TRUE));
            verify(target).isTracked();
        });
    }

    //Sapient generated method id: ${ee951d27-df19-3b79-995f-2cbb6d0afe02}, hash: 59DB60B949D4E8A34445E7EF999D86D9
    @Test()
    void isImplicitWhenStartNotEqualsEnd() {
        /* Branches:* (!isTracked()) : false* (start.equals(end)) : false*/
        //Arrange Statement(s)
        Range target = spy(new Range(rangePositionMock, rangePositionMock2));
        doReturn(true).when(target).isTracked();

        //Act Statement(s)
        boolean result = target.isImplicit();

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(Boolean.FALSE));
            verify(target).isTracked();
        });
    }

    //Sapient generated method id: ${3ac47b85-f6da-3d63-abd3-5efbf638ec13}, hash: 87F013BDE1B133C8F501296C1DD28CCB
    @Test()
    void ofWhenNotStartAndNodeNotHasAttributes() {
        /* Branches:* (start) : false* (!node.hasAttributes()) : true*/
        //Arrange Statement(s)
        doReturn(false).when(nodeMock).hasAttributes();

        //Act Statement(s)
        Range result = Range.of(nodeMock, false);
        Range range = Range.Untracked;

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(range));
            verify(nodeMock).hasAttributes();
        });
    }

    //Sapient generated method id: ${b6ce52bc-4013-3e6b-b77e-0b4ec030fde3}, hash: 5A01B74219FF84C5AF3F2A2AF1932A28
    @Test()
    void ofWhenRangeIsNotNull() {
        /* Branches:* (start) : true* (!node.hasAttributes()) : false* (range != null) : true*/
        //Arrange Statement(s)
        doReturn(true).when(nodeMock).hasAttributes();
        doReturn(attributesMock).when(nodeMock).attributes();
        Range rangeMock = mock(Range.class);
        doReturn(rangeMock).when(attributesMock).userData("jsoup.start");

        //Act Statement(s)
        Range result = Range.of(nodeMock, true);

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(rangeMock));
            verify(nodeMock).hasAttributes();
            verify(nodeMock).attributes();
            verify(attributesMock).userData("jsoup.start");
        });
    }

    //Sapient generated method id: ${e44015fd-e417-35ae-9c82-f145571db473}, hash: AE53D54C3A4C660940C849778D91924F
    @Test()
    void ofWhenRangeIsNull() {
        /* Branches:* (start) : true* (!node.hasAttributes()) : false* (range != null) : false*/
        //Arrange Statement(s)
        doReturn(true).when(nodeMock).hasAttributes();
        doReturn(attributesMock).when(nodeMock).attributes();
        doReturn(null).when(attributesMock).userData("jsoup.start");

        //Act Statement(s)
        Range result = Range.of(nodeMock, true);
        Range range = Range.Untracked;

        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(range));
            verify(nodeMock).hasAttributes();
            verify(nodeMock).attributes();
            verify(attributesMock).userData("jsoup.start");
        });
    }

    //Sapient generated method id: ${363d3698-f34c-39ad-914f-376a19498023}, hash: 1B7853CD46B63B8BE1495C3EA33A4DC1
    @Test()
    void toStringTest() {
        //Arrange Statement(s)
        Range.Position rangePositionMock = mock(Range.Position.class, "<init>_range.Position1");
        Range.Position rangePositionMock2 = mock(Range.Position.class, "<init>_range.Position2");
        Range target = new Range(rangePositionMock, rangePositionMock2);

        //Act Statement(s)
        String result = target.toString();

        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo("<init>_range.Position1-<init>_range.Position2")));
    }
}
