package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.nio.file.OpenOption;
import java.io.ByteArrayInputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;

import org.mockito.MockedStatic;

import java.io.File;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class DigestUtilsSapientGeneratedTest {

    private final MessageDigest messageDigestMock = mock(MessageDigest.class);

    private final MessageDigest messageDigestMock2 = mock(MessageDigest.class);

    private final Path pathMock = mock(Path.class);

    private final RandomAccessFile randomAccessFileMock = mock(RandomAccessFile.class);

    //Sapient generated method id: ${getDigestWhenCaughtNoSuchAlgorithmExceptionThrowsIllegalArgumentException}, hash: C5009DFB731F319DA482125816CB6C88
    @Test()
    public void getDigestWhenCaughtNoSuchAlgorithmExceptionThrowsIllegalArgumentException() {
        /* Branches:
         * (catch-exception (NoSuchAlgorithmException)) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        NoSuchAlgorithmException noSuchAlgorithmException = new NoSuchAlgorithmException();
        //Act Statement(s)
        final IllegalArgumentException result = assertThrows(IllegalArgumentException.class, () -> {
            DigestUtils.getDigest("<value>");
        });
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, is(notNullValue()));
            assertThat(result.getCause(), is(instanceOf(noSuchAlgorithmException.getClass())));
        });
    }

    //Sapient generated method id: ${getDigest1Test}, hash: 0B5D8927344255B4EE8B9884FE211D0E
    @Test()
    public void getDigest1Test() throws Exception {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Act Statement(s)
        MessageDigest result = DigestUtils.getDigest("A", messageDigestMock);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${getDigest1WhenCaughtException}, hash: 98453BBFA6FB3E6B3BA2CB7866AC4B00
    @Test()
    public void getDigest1WhenCaughtException() throws Exception {
        /* Branches:
         * (catch-exception (Exception)) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Act Statement(s)
        MessageDigest result = DigestUtils.getDigest("A", messageDigestMock);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(messageDigestMock)));
    }

    //Sapient generated method id: ${getMd2DigestTest}, hash: B6900A50DA879C818713C9E80E0F1D7A
    @Test()
    public void getMd2DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("MD2")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getMd2Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("MD2"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getMd5DigestTest}, hash: E56D7FC3F9FAE81874428CC76B90FD4C
    @Test()
    public void getMd5DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("MD5")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getMd5Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("MD5"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha1DigestTest}, hash: 3B3D74C217BAA5C82095318CF193BB37
    @Test()
    public void getSha1DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA-1")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha1Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA-1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha256DigestTest}, hash: 04D0E2E3CB0928DDDE2AAF66CED46491
    @Test()
    public void getSha256DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA-256")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha256Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA-256"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha3_224DigestTest}, hash: 1B40441E8969B83C7451C667ACDD501E
    @Test()
    public void getSha3_224DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA3-224")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha3_224Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA3-224"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha3_256DigestTest}, hash: 8A98894CA20E4FD1D90DEC88D0ADA41D
    @Test()
    public void getSha3_256DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA3-256")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha3_256Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA3-256"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha3_384DigestTest}, hash: 4004BCBA3BD4A1F92C2937B2343700A5
    @Test()
    public void getSha3_384DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA3-384")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha3_384Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA3-384"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha3_512DigestTest}, hash: 0B6EE8D044DA159E420EB442EF61A173
    @Test()
    public void getSha3_512DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA3-512")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha3_512Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA3-512"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha384DigestTest}, hash: D3D084C03AA4E31481AF9F28DFB66F5A
    @Test()
    public void getSha384DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA-384")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha384Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA-384"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha512_224DigestTest}, hash: 601ECE1E0341A625DAB03CD0BEAED9B3
    @Test()
    public void getSha512_224DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA-512/224")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha512_224Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA-512/224"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha512_256DigestTest}, hash: 802E089E65F636BD1124DBC937EF110A
    @Test()
    public void getSha512_256DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA-512/256")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha512_256Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA-512/256"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getSha512DigestTest}, hash: E34B419D22E09EA8B831DD230B356CA9
    @Test()
    public void getSha512DigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("SHA-512")).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getSha512Digest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getDigest("SHA-512"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${getShaDigestTest}, hash: 12B01BEF823555AC708377CE1A10BE1A
    @Test()
    public void getShaDigestTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha1Digest()).thenReturn(messageDigestMock);
            //Act Statement(s)
            MessageDigest result = DigestUtils.getShaDigest();
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(messageDigestMock));
                digestUtils.verify(() -> DigestUtils.getSha1Digest(), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${isAvailableWhenGetDigestMessageDigestAlgorithmNullIsNotNull}, hash: 960F51FE3DB2DA3D8A95A20F1BE1D88F
    @Test()
    public void isAvailableWhenGetDigestMessageDigestAlgorithmNullIsNotNull() throws Exception {
        /* Branches:
         * (getDigest(messageDigestAlgorithm, null) != null) : true
         */
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("messageDigestAlgorithm1", (MessageDigest) null)).thenReturn(messageDigestMock);
            //Act Statement(s)
            boolean result = DigestUtils.isAvailable("messageDigestAlgorithm1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.TRUE));
                digestUtils.verify(() -> DigestUtils.getDigest("messageDigestAlgorithm1", (MessageDigest) null), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${isAvailableWhenGetDigestMessageDigestAlgorithmNullIsNull}, hash: 42D6397B58F876F78FADAADEB2F34CAA
    @Test()
    public void isAvailableWhenGetDigestMessageDigestAlgorithmNullIsNull() throws Exception {
        /* Branches:
         * (getDigest(messageDigestAlgorithm, null) != null) : false
         */
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getDigest("messageDigestAlgorithm1", (MessageDigest) null)).thenReturn(null);
            //Act Statement(s)
            boolean result = DigestUtils.isAvailable("messageDigestAlgorithm1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(Boolean.FALSE));
                digestUtils.verify(() -> DigestUtils.getDigest("messageDigestAlgorithm1", (MessageDigest) null), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md2Test}, hash: E3ECD9E91A2F68CE0E8E76F440072A98
    @Test()
    public void md2Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getMd2Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.md2(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getMd2Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${md21Test}, hash: 434B7A35BF3FBF3687904714E83F2833
    @Test()
    public void md21Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getMd2Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.md2(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getMd2Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md22Test}, hash: 4D86B5F1A7517A26227EEA23757ED3F6
    @Test()
    public void md22Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.md2(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.md2("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.md2(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md2HexTest}, hash: DAA3F08BB4B031EFF501E91E54DFCA4F
    @Test()
    public void md2HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.md2(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.md2Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.md2(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md2Hex1Test}, hash: FD08B68D30E1CA0E4BE5D21B55B8025A
    @Test()
    public void md2Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.md2(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.md2Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.md2(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md2Hex2Test}, hash: AD91F406425B1112E53FCBDA8BB91A7C
    @Test()
    public void md2Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.md2("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.md2Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.md2("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md5Test}, hash: 268FB63079E122F111F66F82F5F54DBF
    @Test()
    public void md5Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getMd5Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.md5(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getMd5Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${md51Test}, hash: 5C44EB9DFDB6BE707266AACFB6215EF9
    @Test()
    public void md51Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getMd5Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.md5(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getMd5Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md52Test}, hash: 41FD43E2416BE0FEAF112D2AA30E1A6D
    @Test()
    public void md52Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.md5(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.md5("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.md5(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md5HexTest}, hash: 923E06562B955F695422DC19C53376B4
    @Test()
    public void md5HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.md5(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.md5Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.md5(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md5Hex1Test}, hash: BB063087404D4BEA8B04F28EDC81EF34
    @Test()
    public void md5Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.md5(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.md5Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.md5(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${md5Hex2Test}, hash: D9CDA53A11A63D604BE04A763133D2F6
    @Test()
    public void md5Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.md5("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.md5Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.md5("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${shaTest}, hash: AC8C354BAF6A1506716737FB63FCBFCD
    @Test()
    public void shaTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha1(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha1(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha1Test}, hash: 7F5978F75A717C17E0C334F3158C8A03
    @Test()
    public void sha1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha1(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha1(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha2Test}, hash: 0F9744FE36425E91A8F96FE7821C365F
    @Test()
    public void sha2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha1("data1")).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha1("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha1Test2}, hash: 456BB241364741B43F461518A97041C9
    @Test()
    public void sha1Test2() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha1Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha1(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha1Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha11Test}, hash: 2FA39CD726EA7A085B91EC356539316C
    @Test()
    public void sha11Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha1Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha1(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha1Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha12Test}, hash: 34A48F78CC875D9FE37AA26AB762B63C
    @Test()
    public void sha12Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha1(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha1("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha1(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha1HexTest}, hash: 1DD86D7A3AC95F3318B9847F93734FD5
    @Test()
    public void sha1HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha1(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha1Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha1(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha1Hex1Test}, hash: FD77BB8CCBDF6EDC4833A0D1E6E95370
    @Test()
    public void sha1Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha1(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha1Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha1(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha1Hex2Test}, hash: F902CFC2B3A1F450401EAF878C73F7D7
    @Test()
    public void sha1Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha1("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha1Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha1("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha256Test}, hash: E722FECA2BA4427AB5A10E51474671E7
    @Test()
    public void sha256Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha256Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha256(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha256Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha2561Test}, hash: C427827B05972370E684E54A01E34AB9
    @Test()
    public void sha2561Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha256Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha256(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha256Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha2562Test}, hash: D1A09BC7021B95C71510FC5B69E758DB
    @Test()
    public void sha2562Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha256(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha256("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha256(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha256HexTest}, hash: 10D30A65B2BC22E857D9614B3687C288
    @Test()
    public void sha256HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha256(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha256Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha256(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha256Hex1Test}, hash: 01E50F55C12FF55C4C587FF114E5DAF6
    @Test()
    public void sha256Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha256(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha256Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha256(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha256Hex2Test}, hash: 8C3FA3BC508BCD9CA54C9992300D25A4
    @Test()
    public void sha256Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha256("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha256Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha256("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_224Test}, hash: 0D3AD038D632DFBE59CB2C925DA053A6
    @Test()
    public void sha3_224Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha3_224Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha3_224(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha3_224Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha3_2241Test}, hash: 96B376314435BB3BD0559FDBD30235BE
    @Test()
    public void sha3_2241Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha3_224Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha3_224(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha3_224Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_2242Test}, hash: 08C1E59823ABB4F6E65D5E6486850F67
    @Test()
    public void sha3_2242Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha3_224(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha3_224("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha3_224(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_224HexTest}, hash: 3CA10EE9B13A0BA93E575E7FCB7771BD
    @Test()
    public void sha3_224HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha3_224(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_224Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_224(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_224Hex1Test}, hash: 5030A011128991763E70B3C2D9E5E465
    @Test()
    public void sha3_224Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha3_224(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_224Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_224(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_224Hex2Test}, hash: C1E52C31BAC08A1598AEAC725271A989
    @Test()
    public void sha3_224Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha3_224("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_224Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_224("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_256Test}, hash: 71FBE2D0BE50684B220D9945248A427A
    @Test()
    public void sha3_256Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha3_256Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha3_256(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha3_256Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha3_2561Test}, hash: 39FAFEEC2DE72DDE11547BEAE1804A98
    @Test()
    public void sha3_2561Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha3_256Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha3_256(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha3_256Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_2562Test}, hash: 332AF1B4E7275E9E00CE7BF825873843
    @Test()
    public void sha3_2562Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha3_256(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha3_256("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha3_256(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_256HexTest}, hash: 4D59F17B6CB273963151B8A90A6C4F6F
    @Test()
    public void sha3_256HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha3_256(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_256Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_256(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_256Hex1Test}, hash: C7EE7AECDCF4F7A5EB96D690B40A2F75
    @Test()
    public void sha3_256Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha3_256(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_256Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_256(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_256Hex2Test}, hash: FD4D795AE3503D7B999483C33D1871FB
    @Test()
    public void sha3_256Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha3_256("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_256Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_256("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_384Test}, hash: 2FDB8272C51A83182BD88D3A737A8B73
    @Test()
    public void sha3_384Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha3_384Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha3_384(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha3_384Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha3_3841Test}, hash: F4B3C74AC071890DACD1E451D82EA015
    @Test()
    public void sha3_3841Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha3_384Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha3_384(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha3_384Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_3842Test}, hash: 76FFB69D916A2FE47E8211AE5C056288
    @Test()
    public void sha3_3842Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha3_384(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha3_384("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha3_384(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_384HexTest}, hash: E71CD0ACD83001779395F1EA2AE86E18
    @Test()
    public void sha3_384HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha3_384(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_384Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_384(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_384Hex1Test}, hash: D2D54309BC029465C66D274D7345C274
    @Test()
    public void sha3_384Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha3_384(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_384Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_384(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_384Hex2Test}, hash: BAAA9726FA568CE6C0305B269561CD42
    @Test()
    public void sha3_384Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha3_384("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_384Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_384("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_512Test}, hash: 9ADFE7D6F006A3A3122152661016F7F1
    @Test()
    public void sha3_512Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha3_512Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha3_512(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha3_512Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha3_5121Test}, hash: 002038CC1E2B8DBEBEB0384CE4FF0210
    @Test()
    public void sha3_5121Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha3_512Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha3_512(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha3_512Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_5122Test}, hash: 885221A451119DE41C7D15D5D87DED05
    @Test()
    public void sha3_5122Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha3_512(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha3_512("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha3_512(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_512HexTest}, hash: F86945DE7C682DBFA04E22E28D063AD8
    @Test()
    public void sha3_512HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha3_512(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_512Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_512(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_512Hex1Test}, hash: 4F30A0603C087B5F5BCBC417ECFDA209
    @Test()
    public void sha3_512Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha3_512(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_512Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_512(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3_512Hex2Test}, hash: 625A364F0C74192BFCFA527F80E20840
    @Test()
    public void sha3_512Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha3_512("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha3_512Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha3_512("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha384Test}, hash: 2C487E18CBE786049D67ACD8287239E8
    @Test()
    public void sha384Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha384Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha384(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha384Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha3841Test}, hash: 617CF3AA3655102BDC98F130E6E5797C
    @Test()
    public void sha3841Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha384Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha384(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha384Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha3842Test}, hash: E9C6D4B6BBED391C6A33840B50A747FF
    @Test()
    public void sha3842Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha384(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha384("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha384(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha384HexTest}, hash: AE95C1E71DCA6CE50B920B844974EF0A
    @Test()
    public void sha384HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha384(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha384Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha384(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha384Hex1Test}, hash: 1F7F379621C81124A091B51759FE3357
    @Test()
    public void sha384Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha384(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha384Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha384(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha384Hex2Test}, hash: FB90643DF7C2BDBA820DFE4F13C11018
    @Test()
    public void sha384Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha384("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha384Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha384("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512Test}, hash: 02BE7B7F53E3F93ACE1890D8990C2538
    @Test()
    public void sha512Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha512Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha512(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha512Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha5121Test}, hash: B6A3134571A2B591F60ACB3E88CDC8FA
    @Test()
    public void sha5121Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha512Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha512(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha512Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha5122Test}, hash: D61E8421D23C7D37E40A23F42A2D6CC0
    @Test()
    public void sha5122Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha512(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha512("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha512(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_224Test}, hash: 51AF4A056488C30F133A190F1B32362B
    @Test()
    public void sha512_224Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha512_224Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha512_224(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha512_224Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha512_2241Test}, hash: 2E3E174863DE38B3AFB2644E73772ACE
    @Test()
    public void sha512_2241Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha512_224Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha512_224(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha512_224Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_2242Test}, hash: F9DE18D7DC58BAB488E5A63E21463B36
    @Test()
    public void sha512_2242Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha512_224(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha512_224("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha512_224(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_224HexTest}, hash: B0724D73327550A3E80582B2DF033DFA
    @Test()
    public void sha512_224HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha512_224(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512_224Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512_224(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_224Hex1Test}, hash: 19A37418B6A0B1A0DDF1A3DE0F0A2BC3
    @Test()
    public void sha512_224Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha512_224(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512_224Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512_224(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_224Hex2Test}, hash: 32621BA882335B68B57F440D4C83AFC1
    @Test()
    public void sha512_224Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha512_224("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512_224Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512_224("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_256Test}, hash: 75DC439939D8904D4236C97708C0B65A
    @Test()
    public void sha512_256Test() throws NoSuchAlgorithmException {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        /*try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
    digestUtils.when(() -> DigestUtils.getSha512_256Digest()).thenReturn(messageDigestMock);
    byte[] byteArray2 = new byte[] { (byte) 0 };
    byte[] byteArray = new byte[] { byteArray2 };
    //Act Statement(s)
    byte[] result = DigestUtils.sha512_256(byteArray);
    //Assert statement(s)
    assertAll("result", () -> {
        assertThat(result.length, equalTo(0));
        digestUtils.verify(() -> DigestUtils.getSha512_256Digest(), atLeast(1));
    });
}*/
    }

    //Sapient generated method id: ${sha512_2561Test}, hash: 41FA89F5096BBC593A833DDEC918BB5D
    @Test()
    public void sha512_2561Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.getSha512_256Digest()).thenReturn(messageDigestMock);
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.digest(messageDigestMock, inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha512_256(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.getSha512_256Digest(), atLeast(1));
                digestUtils.verify(() -> DigestUtils.digest(messageDigestMock, inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_2562Test}, hash: 17814215E34CEA6AA8178E94DA871BCD
    @Test()
    public void sha512_2562Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{(byte) 65};
            digestUtils.when(() -> DigestUtils.sha512_256(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            byte[] result = DigestUtils.sha512_256("A");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(byteArray));
                digestUtils.verify(() -> DigestUtils.sha512_256(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_256HexTest}, hash: B8496BDDB28FABCB7C26DECF3AE7513A
    @Test()
    public void sha512_256HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha512_256(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512_256Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512_256(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_256Hex1Test}, hash: 52D6F6E10638E9DA21D43B5787C7E3FC
    @Test()
    public void sha512_256Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha512_256(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512_256Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512_256(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512_256Hex2Test}, hash: 854AE57E1487ADE6A874FA35B12E6A5C
    @Test()
    public void sha512_256Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha512_256("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512_256Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512_256("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512HexTest}, hash: B8F9D9A679B84D0AC32E5EE64312C7E5
    @Test()
    public void sha512HexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            byte[] byteArray2 = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha512(byteArray2)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512Hex(byteArray2);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512(byteArray2), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512Hex1Test}, hash: 7DE9E039FEEB9D3C669464EC8A92BF18
    @Test()
    public void sha512Hex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha512(inputStream)).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512Hex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${sha512Hex2Test}, hash: C041E78F0755BE6631F819BDDF39C252
    @Test()
    public void sha512Hex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha512("data1")).thenReturn(byteArray);
            //Act Statement(s)
            String result = DigestUtils.sha512Hex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(""));
                digestUtils.verify(() -> DigestUtils.sha512("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${shaHexTest}, hash: CBE640F89352BB388F782482F1209046
    @Test()
    public void shaHexTest() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            digestUtils.when(() -> DigestUtils.sha1Hex(byteArray)).thenReturn("return_of_sha1Hex1");
            //Act Statement(s)
            String result = DigestUtils.shaHex(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_sha1Hex1"));
                digestUtils.verify(() -> DigestUtils.sha1Hex(byteArray), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${shaHex1Test}, hash: F07D3BE7194C568047345A7CB5446778
    @Test()
    public void shaHex1Test() throws IOException, NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            digestUtils.when(() -> DigestUtils.sha1Hex(inputStream)).thenReturn("return_of_sha1Hex1");
            //Act Statement(s)
            String result = DigestUtils.shaHex(inputStream);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_sha1Hex1"));
                digestUtils.verify(() -> DigestUtils.sha1Hex(inputStream), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${shaHex2Test}, hash: C4110F587ABDB47B0AE81EB8B092AD16
    @Test()
    public void shaHex2Test() throws NoSuchAlgorithmException {
        //Arrange Statement(s)
        try (MockedStatic<DigestUtils> digestUtils = mockStatic(DigestUtils.class, CALLS_REAL_METHODS)) {
            digestUtils.when(() -> DigestUtils.sha1Hex("data1")).thenReturn("return_of_sha1Hex1");
            //Act Statement(s)
            String result = DigestUtils.shaHex("data1");
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo("return_of_sha1Hex1"));
                digestUtils.verify(() -> DigestUtils.sha1Hex("data1"), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${updateDigestTest}, hash: D27B0CFCBC1796344FC7226AC85DECBF
    @Test()
    public void updateDigestTest() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        byte[] byteArray = new byte[]{};
        //Act Statement(s)
        MessageDigest result = DigestUtils.updateDigest(messageDigestMock, byteArray);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(messageDigestMock)));
    }

    //Sapient generated method id: ${updateDigest1Test}, hash: A738277A55603A043F16494DDA8A499F
    @Test()
    public void updateDigest1Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(64);
        //Act Statement(s)
        MessageDigest result = DigestUtils.updateDigest(messageDigestMock, byteBuffer);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(messageDigestMock)));
    }

    //Sapient generated method id: ${updateDigest4WhenReadGreaterThanMinus1}, hash: 708441F42E609169CF5577388FA67640
    @Test()
    public void updateDigest4WhenReadGreaterThanMinus1() throws IOException {
        /* Branches:
         * (read > -1) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
        //Act Statement(s)
        MessageDigest result = DigestUtils.updateDigest(messageDigestMock, inputStream);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(messageDigestMock)));
    }


    //Sapient generated method id: ${updateDigest7Test}, hash: 4E452487F132E4AB1B4EA2D04F4091DA
    @Test()
    public void updateDigest7Test() {
        /*
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Act Statement(s)
        MessageDigest result = DigestUtils.updateDigest(messageDigestMock, "A");
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(messageDigestMock)));
    }

    //Sapient generated method id: ${digestAsHexTest}, hash: B9A679CFF88EB5A9CC6EAE8E0966D241
    @Test()
    public void digestAsHexTest() {
        //Arrange Statement(s)
        DigestUtils target = spy(new DigestUtils(messageDigestMock));
        byte[] byteArray = new byte[]{};
        byte[] byteArray2 = new byte[]{};
        doReturn(byteArray).when(target).digest(byteArray2);
        //Act Statement(s)
        String result = target.digestAsHex(byteArray2);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(""));
            verify(target).digest(byteArray2);
        });
    }

    //Sapient generated method id: ${digestAsHex1Test}, hash: 3AF2B1958491661789FF672A7FE53688
    @Test()
    public void digestAsHex1Test() {
        //Arrange Statement(s)
        DigestUtils target = spy(new DigestUtils(messageDigestMock));
        byte[] byteArray = new byte[]{};
        doReturn(byteArray).when(target).digest((ByteBuffer) any());
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(64);
        //Act Statement(s)
        String result = target.digestAsHex(byteBuffer);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(""));
            verify(target).digest((ByteBuffer) any());
        });
    }

    //Sapient generated method id: ${digestAsHex2Test}, hash: 8319BB0DAFBC5E9FD867934BCD1F9FDF
    @Test()
    public void digestAsHex2Test() throws Throwable {
        //Arrange Statement(s)
        DigestUtils target = spy(new DigestUtils(messageDigestMock));
        byte[] byteArray = new byte[]{};
        File file = new File("pathname1");
        doReturn(byteArray).when(target).digest(file);
        //Act Statement(s)
        String result = target.digestAsHex(file);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(""));
            verify(target).digest(file);
        });
    }

    //Sapient generated method id: ${digestAsHex3Test}, hash: 3937E0F8D6B655542DADC6B26D333659
    @Test()
    public void digestAsHex3Test() throws IOException {
        //Arrange Statement(s)
        DigestUtils target = spy(new DigestUtils(messageDigestMock));
        byte[] byteArray = new byte[]{};
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
        doReturn(byteArray).when(target).digest(inputStream);
        //Act Statement(s)
        String result = target.digestAsHex(inputStream);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(""));
            verify(target).digest(inputStream);
        });
    }

    //Sapient generated method id: ${digestAsHex4Test}, hash: 1C3BA4A32074E153BBC67B23010E77B9
    @Test()
    public void digestAsHex4Test() throws Throwable {
        //Arrange Statement(s)
        DigestUtils target = spy(new DigestUtils(messageDigestMock));
        byte[] byteArray = new byte[]{};
        OpenOption[] openOptionArray = new OpenOption[]{};
        doReturn(byteArray).when(target).digest(pathMock, openOptionArray);
        //Act Statement(s)
        String result = target.digestAsHex(pathMock, openOptionArray);
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(""));
            verify(target).digest(pathMock, openOptionArray);
        });
    }

    //Sapient generated method id: ${digestAsHex5Test}, hash: 8186126F2AD2B07A46A623601D16232D
    @Test()
    public void digestAsHex5Test() {
        //Arrange Statement(s)
        DigestUtils target = spy(new DigestUtils(messageDigestMock));
        byte[] byteArray = new byte[]{};
        doReturn(byteArray).when(target).digest("data1");
        //Act Statement(s)
        String result = target.digestAsHex("data1");
        //Assert statement(s)
        assertAll("result", () -> {
            assertThat(result, equalTo(""));
            verify(target).digest("data1");
        });
    }
}
