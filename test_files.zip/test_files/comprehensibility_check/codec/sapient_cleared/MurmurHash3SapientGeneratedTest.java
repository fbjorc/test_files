package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
public class MurmurHash3SapientGeneratedTest {

    //Sapient generated method id: ${hash128Test}, hash: 70CD16CBFA8A651C8DCA2F7F8B13B60B
    @Test()
    public void hash128Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            long[] longArray = new long[]{};
            byte[] byteArray = new byte[]{};
            murmurHash3.when(() -> MurmurHash3.hash128(byteArray, 0, 0, 104729)).thenReturn(longArray);
            //Act Statement(s)
            long[] result = MurmurHash3.hash128(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(longArray));
                murmurHash3.verify(() -> MurmurHash3.hash128(byteArray, 0, 0, 104729), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash128x64Test}, hash: 025893341F50A18FD8283B0BB36D22F3
    @Test()
    public void hash128x64Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            long[] longArray = new long[]{};
            byte[] byteArray = new byte[]{};
            murmurHash3.when(() -> MurmurHash3.hash128x64(byteArray, 0, 0, 0)).thenReturn(longArray);
            //Act Statement(s)
            long[] result = MurmurHash3.hash128x64(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(longArray));
                murmurHash3.verify(() -> MurmurHash3.hash128x64(byteArray, 0, 0, 0), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash32Test}, hash: 229D8CBE3611A7B4291A61848A56DDBB
    @Test()
    public void hash32Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            murmurHash3.when(() -> MurmurHash3.hash32(byteArray, 0, 0, 104729)).thenReturn(0);
            //Act Statement(s)
            int result = MurmurHash3.hash32(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                murmurHash3.verify(() -> MurmurHash3.hash32(byteArray, 0, 0, 104729), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash321Test}, hash: 123C1D3774ADF44AE66BAAD5FAA5CFA6
    @Test()
    public void hash321Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            murmurHash3.when(() -> MurmurHash3.hash32(byteArray, 0, 104729)).thenReturn(0);
            //Act Statement(s)
            int result = MurmurHash3.hash32(byteArray, 0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                murmurHash3.verify(() -> MurmurHash3.hash32(byteArray, 0, 104729), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash322Test}, hash: 952D9FE85CBDF96BB19964BC0CC77AF2
    @Test()
    public void hash322Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            murmurHash3.when(() -> MurmurHash3.hash32(byteArray, 0, 0, 0)).thenReturn(0);
            //Act Statement(s)
            int result = MurmurHash3.hash32(byteArray, 0, 0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                murmurHash3.verify(() -> MurmurHash3.hash32(byteArray, 0, 0, 0), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash324Test}, hash: 998394084B8EFE7A332110FAFD9BF0F7
    @Test()
    public void hash324Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            murmurHash3.when(() -> MurmurHash3.hash32(0L, 104729)).thenReturn(0);
            //Act Statement(s)
            int result = MurmurHash3.hash32(0L);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                murmurHash3.verify(() -> MurmurHash3.hash32(0L, 104729), atLeast(1));
            });
        }
    }


    //Sapient generated method id: ${hash326Test}, hash: 8ED6FB67890192E3873AD6574B8298AE
    @Test()
    public void hash326Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            murmurHash3.when(() -> MurmurHash3.hash32(0L, 0L, 104729)).thenReturn(0);
            //Act Statement(s)
            int result = MurmurHash3.hash32(0L, 0L);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                murmurHash3.verify(() -> MurmurHash3.hash32(0L, 0L, 104729), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash32x86Test}, hash: ACB63F21D806A03B42ADC797E35181F3
    @Test()
    public void hash32x86Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            murmurHash3.when(() -> MurmurHash3.hash32x86(byteArray, 0, 0, 0)).thenReturn(0);
            //Act Statement(s)
            int result = MurmurHash3.hash32x86(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0));
                murmurHash3.verify(() -> MurmurHash3.hash32x86(byteArray, 0, 0, 0), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash64Test}, hash: 0CAB62D49BB5EF55D8645B2BDCD818F7
    @Test()
    public void hash64Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            murmurHash3.when(() -> MurmurHash3.hash64(byteArray, 0, 0, 104729)).thenReturn(0L);
            //Act Statement(s)
            long result = MurmurHash3.hash64(byteArray);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0L));
                murmurHash3.verify(() -> MurmurHash3.hash64(byteArray, 0, 0, 104729), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash641Test}, hash: EDE2C0D7A075F422EA47C2F6B2971A0B
    @Test()
    public void hash641Test() {
        //Arrange Statement(s)
        try (MockedStatic<MurmurHash3> murmurHash3 = mockStatic(MurmurHash3.class, CALLS_REAL_METHODS)) {
            byte[] byteArray = new byte[]{};
            murmurHash3.when(() -> MurmurHash3.hash64(byteArray, 0, 0, 104729)).thenReturn(0L);
            //Act Statement(s)
            long result = MurmurHash3.hash64(byteArray, 0, 0);
            //Assert statement(s)
            assertAll("result", () -> {
                assertThat(result, equalTo(0L));
                murmurHash3.verify(() -> MurmurHash3.hash64(byteArray, 0, 0, 104729), atLeast(1));
            });
        }
    }

    //Sapient generated method id: ${hash642WhenSwitchOffsetPlusLengthMinusIndexCase1}, hash: CFE9E70E607A2F7D96D45B2C8A9ED99E
    @Test()
    public void hash642WhenSwitchOffsetPlusLengthMinusIndexCase1() {
        /* Branches:
         * (i < nblocks) : true
         * (switch(offset + length - index) = 1) : true
         *
         * TODO: Help needed! Please adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.
         *  The test code, including the assertion statements, has been successfully generated.
         */
        //Arrange Statement(s)
        //byte[] byteArray2 = new byte[] { (byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5, (byte) 6, (byte) 7, (byte) 8 };
        //byte[] byteArray = new byte[] { byteArray2 };
        //Act Statement(s)
        //long result = MurmurHash3.hash64(byteArray, 8601547725015499320, -8601547725015499313, -8601547725015499320);
        //Assert statement(s)
        //assertAll("result", () -> assertThat(result, equalTo(0L)));
    }

    //Sapient generated method id: ${hash643Test}, hash: 0E4FB92C74675FA9A7485F9CC671B5BD
    @Test()
    public void hash643Test() {
        //Act Statement(s)
        long result = MurmurHash3.hash64(1);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(501179666091440628L)));
    }

    //Sapient generated method id: ${hash644Test}, hash: F694CED3BCC38E41C2FFA6F651192903
    @Test()
    public void hash644Test() {
        //Act Statement(s)
        long result = MurmurHash3.hash64(1L);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(6840239832827182823L)));
    }

    //Sapient generated method id: ${hash645Test}, hash: 7BD35788C1BA921D7F62BB457FD76EAD
    @Test()
    public void hash645Test() {
        //Act Statement(s)
        //long result = MurmurHash3.hash64((short) -8601547725015499320);
        //Assert statement(s)
        //assertAll("result", () -> assertThat(result, equalTo(7910691593646214214L)));
    }
}
