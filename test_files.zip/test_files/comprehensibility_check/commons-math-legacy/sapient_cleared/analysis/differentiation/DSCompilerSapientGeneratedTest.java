package org.apache.commons.math4.legacy.analysis.differentiation;

import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Test;
import org.apache.commons.math4.legacy.exception.NumberIsTooLargeException;
import org.apache.commons.math4.legacy.exception.DimensionMismatchException;
import org.apache.commons.math4.legacy.exception.MathArithmeticException;
import org.apache.commons.math4.legacy.exception.MathInternalError;
import org.apache.commons.math4.legacy.exception.NotPositiveException;

import static org.mockito.Mockito.doNothing;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.spy;
import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Disabled;

@Timeout(value = 5, threadMode = Timeout.ThreadMode.SEPARATE_THREAD)
class DSCompilerSapientGeneratedTest {

    //Sapient generated method id: ${f49db814-5b57-3df8-9022-fef123646a0c}, hash: 125E42185B5D698EED9E087F0818E060
    @Test()
    void getCompilerWhenOrderIndexOfParametersIndexOfCacheIsNotNull() throws NumberIsTooLargeException {
        /* Branches:* (cache != null) : true* (cache.length > parameters) : true* (cache[parameters].length > order) : true* (cache[parameters][order] != null) : true*/
        //Act Statement(s)
        DSCompiler result = DSCompiler.getCompiler(0, 0);
        //Assert statement(s)
        //TODO: Please implement equals method in DSCompiler for verification of the entire object or you need to adjust respective assertion statements
        assertAll(2, () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${b3558f7f-2dea-32a6-aa84-097e2c92b779}, hash: 4798983C0D3B6DC65A5C30F10C3BDBA4
    @Test()
    void getCompilerWhenParametersEquals0() throws NumberIsTooLargeException {
        /* Branches:* (cache != null) : true* (cache.length > parameters) : true* (cache[parameters].length > order) : true* (cache[parameters][order] != null) : false* (cache == null) : false* (cache == null) : false* (cache != null) : true* (i < cache.length) : true* (diag <= parameters + order) : true* (o <= JdkMath.min(order, diag)) : true* (newCache[p][o] == null) : true* (p == 0) : true* (o == 0) : true* (parameters == 0) : true  #  inside compileSizes method* (parameters == 0) : true  #  inside compileDerivativesIndirection method* (parameters == 0) : true  #  inside compileLowerIndirection method* (parameters == 0) : true  #  inside compileMultiplicationIndirection method* (parameters == 0) : true  #  inside compileCompositionIndirection method** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: compilers*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Act Statement(s)
        DSCompiler result = DSCompiler.getCompiler(0, 0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${cd313a52-8c48-3dea-ac2b-b07908f5481e}, hash: 6C33C914B24C46C21AF8FE7619A6A703
    @Test()
    void getCompilerWhenParametersEquals0AndParametersEquals0() throws NumberIsTooLargeException {
        /* Branches:* (cache != null) : true* (cache.length > parameters) : true* (cache[parameters].length > order) : true* (cache[parameters][order] != null) : false* (cache == null) : false* (cache == null) : false* (cache != null) : true* (i < cache.length) : true* (diag <= parameters + order) : true* (o <= JdkMath.min(order, diag)) : true* (newCache[p][o] == null) : true* (p == 0) : false* (o == 0) : true* (parameters == 0) : false  #  inside compileSizes method* (i < order) : true  #  inside compileSizes method* (parameters == 0) : false  #  inside compileDerivativesIndirection method* (order == 0) : true  #  inside compileDerivativesIndirection method* (parameters == 0) : false  #  inside compileLowerIndirection method* (order <= 1) : false  #  inside compileLowerIndirection method* (i < dSize) : true  #  inside compileLowerIndirection method* (parameters == 0) : true  #  inside compileMultiplicationIndirection method* (parameters == 0) : true  #  inside compileCompositionIndirection method** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: compilers*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Act Statement(s)
        DSCompiler result = DSCompiler.getCompiler(0, 0);
        //Assert statement(s)
        //TODO: Please implement equals method in DSCompiler for verification of the entire object or you need to adjust respective assertion statements
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${22cf2781-3dae-3d4c-a203-bdcba70beb23}, hash: 97F1139CF7E600F1205673DC05CC7267
    @Test()
    void getCompilerWhenParametersEquals0AndParametersEquals0AndParametersEquals0() throws NumberIsTooLargeException {
        /* Branches:* (cache != null) : true* (cache.length > parameters) : true* (cache[parameters].length > order) : true* (cache[parameters][order] != null) : false* (cache == null) : false* (cache == null) : false* (cache != null) : true* (i < cache.length) : true* (diag <= parameters + order) : true* (o <= JdkMath.min(order, diag)) : true* (newCache[p][o] == null) : true* (p == 0) : false* (o == 0) : true* (parameters == 0) : false  #  inside compileSizes method* (i < order) : true  #  inside compileSizes method* (parameters == 0) : false  #  inside compileDerivativesIndirection method* (order == 0) : false  #  inside compileDerivativesIndirection method* (i < vSize) : true  #  inside compileDerivativesIndirection method* (i < dSize) : true  #  inside compileDerivativesIndirection method* (parameters == 0) : true  #  inside compileLowerIndirection method* (parameters == 0) : true  #  inside compileMultiplicationIndirection method* (parameters == 0) : true  #  inside compileCompositionIndirection method** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: compilers*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Act Statement(s)
        DSCompiler result = DSCompiler.getCompiler(0, 0);
        //Assert statement(s)
        //TODO: Please implement equals method in DSCompiler for verification of the entire object or you need to adjust respective assertion statements
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${b7f236ca-cd09-3073-948b-e8f393cd93f2}, hash: BF00C11E7912CCA3EB2F046B505F7060
    @Test()
    void getCompilerWhen2IndexOfTermJEquals2IndexOfTermKAndParametersEquals0() throws NumberIsTooLargeException {
        /* Branches:* (cache != null) : true* (cache.length > parameters) : true* (cache[parameters].length > order) : true* (cache[parameters][order] != null) : false* (cache == null) : false* (cache == null) : false* (cache != null) : true* (i < cache.length) : true* (diag <= parameters + order) : true* (o <= JdkMath.min(order, diag)) : true* (newCache[p][o] == null) : true* (p == 0) : false* (o == 0) : true* (parameters == 0) : false  #  inside compileSizes method* (i < order) : true  #  inside compileSizes method* (parameters == 0) : false  #  inside compileDerivativesIndirection method* (order == 0) : true  #  inside compileDerivativesIndirection method* (parameters == 0) : false  #  inside compileLowerIndirection method* (order <= 1) : true  #  inside compileLowerIndirection method* (parameters == 0) : false  #  inside compileMultiplicationIndirection method* (order == 0) : false  #  inside compileMultiplicationIndirection method* (i < dSize) : true  #  inside compileMultiplicationIndirection method* (j < dRow.length) : true  #  inside compileMultiplicationIndirection method* (j < row.size()) : true  #  inside compileMultiplicationIndirection method* (termJ[0] > 0) : true  #  inside compileMultiplicationIndirection method* (k < row.size()) : true  #  inside compileMultiplicationIndirection method* (termJ[1] == termK[1]) : true  #  inside compileMultiplicationIndirection method* (termJ[2] == termK[2]) : true  #  inside compileMultiplicationIndirection method* (parameters == 0) : true  #  inside compileCompositionIndirection method** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: compilers*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Act Statement(s)
        DSCompiler result = DSCompiler.getCompiler(0, 0);
        //Assert statement(s)
        //TODO: Please implement equals method in DSCompiler for verification of the entire object or you need to adjust respective assertion statements
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${c82674fb-096d-3f99-92df-72a2f311f064}, hash: BB693D1ABC8C3C045AA56ADDD11EDD22
    @Test()
    void getCompilerWhenEqualsAndLLessThanTermJLengthAndLIndexOfTermJEqualsLIndexOfTermKAndEquals3() throws NumberIsTooLargeException {
        /* Branches:* (cache != null) : true* (cache.length > parameters) : true* (cache[parameters].length > order) : true* (cache[parameters][order] != null) : false* (cache == null) : false* (cache == null) : false* (cache != null) : true* (i < cache.length) : true* (diag <= parameters + order) : true* (o <= JdkMath.min(order, diag)) : true* (newCache[p][o] == null) : true* (p == 0) : false* (o == 0) : true* (parameters == 0) : false  #  inside compileSizes method* (i < order) : true  #  inside compileSizes method* (parameters == 0) : false  #  inside compileDerivativesIndirection method* (order == 0) : true  #  inside compileDerivativesIndirection method* (parameters == 0) : false  #  inside compileLowerIndirection method* (order <= 1) : true  #  inside compileLowerIndirection method* (parameters == 0) : false  #  inside compileMultiplicationIndirection method* (order == 0) : true  #  inside compileMultiplicationIndirection method* (parameters == 0) : false  #  inside compileCompositionIndirection method* (order == 0) : false  #  inside compileCompositionIndirection method* (i < dSize) : true  #  inside compileCompositionIndirection method* (for-each(derivativeCompiler.compIndirection[i])) : true  #  inside compileCompositionIndirection method* (i >= 0) : true  #  inside getPartialDerivativeIndex method* (ordersSum > order) : false  #  inside getPartialDerivativeIndex method* (derivativeOrder-- > 0) : false  #  inside getPartialDerivativeIndex method* (j < term.length) : true  #  inside compileCompositionIndirection method* (l < term.length) : true  #  inside compileCompositionIndirection method* (j < term.length) : true  #  inside compileCompositionIndirection method* (j == l) : true  #  inside compileCompositionIndirection method* (j < row.size()) : true  #  inside compileCompositionIndirection method* (termJ[0] > 0) : true  #  inside compileCompositionIndirection method* (k < row.size()) : true  #  inside compileCompositionIndirection method* (termJ.length == termK.length) : true  #  inside compileCompositionIndirection method* (equals) : true  #  inside compileCompositionIndirection method* (l < termJ.length) : true  #  inside compileCompositionIndirection method* (termJ[l] == termK[l]) : true  #  inside compileCompositionIndirection method* (equals) : true  #  inside compileCompositionIndirection method** TODO: Help needed! This method is not unit testable!*  Following variables could not be isolated/mocked: compilers*  Suggestions:*  You can pass them as constructor arguments or create a setter for them (avoid new operator)*  or adjust the input/test parameter values manually to satisfy the requirements of the given test scenario.*  The test code, including the assertion statements, has been successfully generated.*/
        //Act Statement(s)
        DSCompiler result = DSCompiler.getCompiler(0, 0);
        //Assert statement(s)
        //TODO: Please implement equals method in DSCompiler for verification of the entire object or you need to adjust respective assertion statements
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${d1a217fd-8058-3831-b2c2-683ae25cf1ba}, hash: D4491E42B2F26679CBD2CF90A6E75913
    @Test()
    void getPartialDerivativeIndexWhenOrdersLengthNotEqualsGetFreeParametersThrowsDimensionMismatchException() throws DimensionMismatchException, NumberIsTooLargeException {
        /* Branches:* (orders.length != getFreeParameters()) : true*/
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        int[] intArray = new int[]{0};
        //Act Statement(s)
        final DimensionMismatchException result = assertThrows(DimensionMismatchException.class, () -> {
            target.getPartialDerivativeIndex(intArray);
        });
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, is(notNullValue())));
    }

    //Sapient generated method id: ${77da7f1a-b366-392d-97b1-9da425ca095d}, hash: 3A42F27ADA0031F66F951CB18330BAAF
    @Test()
    void getPartialDerivativeIndexWhenILessThan0() throws DimensionMismatchException, NumberIsTooLargeException {
        /* Branches:* (orders.length != getFreeParameters()) : false* (i >= 0) : false  #  inside getPartialDerivativeIndex method*/
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        int[] intArray = new int[]{};
        //Act Statement(s)
        int result = target.getPartialDerivativeIndex(intArray);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result, equalTo(0)));
    }

    //Sapient generated method id: ${c9934e20-b0a2-3916-8c83-f4ad64703713}, hash: A94DC7E00A0B9903C92AE3D168D65328
    @Test()
    void getPartialDerivativeOrdersTest() throws NumberIsTooLargeException {
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        //Act Statement(s)
        int[] result = target.getPartialDerivativeOrders(0);
        //Assert statement(s)
        assertAll("result", () -> assertThat(result.length, equalTo(0)));
    }

    //Sapient generated method id: ${741ea812-fdd9-3301-bfe5-f133759be727}, hash: 4C4C0E739928417ACE42EF2789404806
    @Test()
    void linearCombination1WhenILessThanGetSize() throws NumberIsTooLargeException {
        /* Branches:* (i < getSize()) : true*/
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.5")};
        double[] doubleArray3 = new double[]{Double.parseDouble("0.25")};
        double[] doubleArray4 = new double[]{Double.parseDouble("0")};
        //Act Statement(s)
        target.linearCombination(Double.parseDouble("1.0"), doubleArray, 0, Double.parseDouble("0.5"), doubleArray2, 0, Double.parseDouble("0.25"), doubleArray3, 0, doubleArray4, 0);
        double[] doubleDoubleArray4Array = new double[]{Double.parseDouble("1.3125")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(doubleArray4, equalTo(doubleDoubleArray4Array)));
    }

    //Sapient generated method id: ${c591adcf-944d-3b2a-a1ff-0e89f24afea5}, hash: E013087E852FA4B1F91346D03A342B5D
    @Test()
    void multiplyWhenJLessThanMappingILength() throws NumberIsTooLargeException {
        /* Branches:* (i < multIndirection.length) : true* (j < mappingI.length) : true*/
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        double[] doubleArray = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray3 = new double[]{Double.parseDouble("0")};
        //Act Statement(s)
        target.multiply(doubleArray, 0, doubleArray2, 0, doubleArray3, 0);
        double[] doubleDoubleArray3Array = new double[]{Double.parseDouble("0.0")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(doubleArray3, equalTo(doubleDoubleArray3Array)));
    }

    //Sapient generated method id: ${794c11eb-5bc8-3938-87eb-bac190e77855}, hash: 792F5B822E257759A61212CA3600AF39
    @Test()
    void powWhenOperandOffsetIndexOfOperandEquals0AndINotLessThanFunctionLength() throws NumberIsTooLargeException {
        /* Branches:* (a == 0) : true* (operand[operandOffset] == 0) : true* (i < function.length) : false*/
        //Arrange Statement(s)
        DSCompiler target = spy(DSCompiler.getCompiler(0, 0));
        double[] doubleArray = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray3 = new double[]{};
        doNothing().when(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        //Act Statement(s)
        target.pow(Double.parseDouble("0.0"), doubleArray, 0, doubleArray3, 0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0));
    }

    //Sapient generated method id: ${c31027a8-2e50-3264-8872-2cda344b7ee8}, hash: E935D3807F459BC668C83870E6B78EC0
    @Test()
    void powWhenOperandOffsetIndexOfOperandLessThan0() throws NumberIsTooLargeException {
        /* Branches:* (a == 0) : true* (operand[operandOffset] == 0) : false* (operand[operandOffset] < 0) : true*/
        //Arrange Statement(s)
        DSCompiler target = spy(DSCompiler.getCompiler(0, 0));
        double[] doubleArray = new double[]{Double.parseDouble("-0.25")};
        double[] doubleArray2 = new double[]{Double.parseDouble("NaN")};
        double[] doubleArray3 = new double[]{};
        doNothing().when(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        //Act Statement(s)
        target.pow(Double.parseDouble("0.0"), doubleArray, 0, doubleArray3, 0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0));
    }

    //Sapient generated method id: ${d99b8973-53ee-3bcd-82f9-8a4d927cb3a4}, hash: 0622CC0F5F857C9E298932757A8F9D4F
    @Test()
    void pow1WhenPEquals0() throws NumberIsTooLargeException {
        /* Branches:* (p == 0) : true*/
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        double[] doubleArray = new double[]{};
        double[] doubleArray2 = new double[]{Double.parseDouble("0")};
        //Act Statement(s)
        target.pow(doubleArray, 0, Double.parseDouble("0.0"), doubleArray2, 0);
        double[] doubleDoubleArray2Array = new double[]{Double.parseDouble("1.0")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(doubleArray2, equalTo(doubleDoubleArray2Array)));
    }

    //Sapient generated method id: ${e42a6545-7dfa-3bc9-ae1b-1b0d03558649}, hash: EF7755DFCF497748E8ADE6C9FAE5F479
    @Test()
    void pow2WhenNEquals0() throws NumberIsTooLargeException {
        /* Branches:* (n == 0) : true*/
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        double[] doubleArray = new double[]{};
        double[] doubleArray2 = new double[]{Double.parseDouble("0")};
        //Act Statement(s)
        target.pow(doubleArray, 0, 0, doubleArray2, 0);
        double[] doubleDoubleArray2Array = new double[]{Double.parseDouble("1.0")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(doubleArray2, equalTo(doubleDoubleArray2Array)));
    }

    //Sapient generated method id: ${ec7d93de-1a08-3711-a8fd-ede0ee7f47cf}, hash: 97824E8577E89D6875F2E447CE422CA3
    @Test()
    void rootNWhenNEquals3AndIGreaterThanOrder() throws NumberIsTooLargeException {
        /* Branches:* (n == 2) : false* (n == 3) : true* (i <= order) : false*/
        //Arrange Statement(s)
        DSCompiler target = spy(DSCompiler.getCompiler(0, 0));
        double[] doubleArray = new double[]{Double.parseDouble("-1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("-1.0")};
        double[] doubleArray3 = new double[]{};
        doNothing().when(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        //Act Statement(s)
        target.rootN(doubleArray, 0, 3, doubleArray3, 0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0));
    }

    //Sapient generated method id: ${9b6a72e4-72fe-3323-b867-a3039035571c}, hash: 20B45A4FFB3BC648265C78C28D25A9E8
    @Test()
    void expm1Test() throws NumberIsTooLargeException {
        //Arrange Statement(s)
        DSCompiler target = spy(DSCompiler.getCompiler(0, 0));
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("1.7182818284590453")};
        double[] doubleArray3 = new double[]{};
        doNothing().when(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        //Act Statement(s)
        target.expm1(doubleArray, 0, doubleArray3, 0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0));
    }

    //Sapient generated method id: ${e78c906d-e8aa-3e18-9a79-e2fbbf627e66}, hash: EF649822B91C562631BEDB6064E99A77
    @Test()
    void logWhenOrderNotGreaterThan0() throws NumberIsTooLargeException {
        /* Branches:* (order > 0) : false*/
        //Arrange Statement(s)
        DSCompiler target = spy(DSCompiler.getCompiler(0, 0));
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray3 = new double[]{};
        doNothing().when(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        //Act Statement(s)
        target.log(doubleArray, 0, doubleArray3, 0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0));
    }

    //Sapient generated method id: ${880d158f-5297-39d1-b0c3-353097e99ee0}, hash: BF5D74CA07548A1C29F628C958372993
    @Test()
    void log10WhenOrderNotGreaterThan0() throws NumberIsTooLargeException {
        /* Branches:* (order > 0) : false*/
        //Arrange Statement(s)
        DSCompiler target = spy(DSCompiler.getCompiler(0, 0));
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray3 = new double[]{};
        doNothing().when(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        //Act Statement(s)
        target.log10(doubleArray, 0, doubleArray3, 0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0));
    }

    //Sapient generated method id: ${d9c8345a-91e4-3709-8ab2-d3ff99895f98}, hash: 42D9C14A44397E30D82A91FFBEB8C93D
    @Test()
    void acosWhenOrderNotGreaterThan0() throws NumberIsTooLargeException {
        /* Branches:* (order > 0) : false*/
        //Arrange Statement(s)
        DSCompiler target = spy(DSCompiler.getCompiler(0, 0));
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray3 = new double[]{};
        doNothing().when(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        //Act Statement(s)
        target.acos(doubleArray, 0, doubleArray3, 0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0));
    }

    //Sapient generated method id: ${1116e8b4-1b8b-35e0-9a80-0f33b0ff47a7}, hash: F8C5E2D00FAB267855E19F686C136B7A
    @Test()
    void acoshWhenOrderNotGreaterThan0() throws NumberIsTooLargeException {
        /* Branches:* (order > 0) : false*/
        //Arrange Statement(s)
        DSCompiler target = spy(DSCompiler.getCompiler(0, 0));
        double[] doubleArray = new double[]{Double.parseDouble("1.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray3 = new double[]{};
        doNothing().when(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        //Act Statement(s)
        target.acosh(doubleArray, 0, doubleArray3, 0);
        //Assert statement(s)
        assertAll("result", () -> verify(target).compose(doubleArray, 0, doubleArray2, doubleArray3, 0));
    }

    //Sapient generated method id: ${ea8152f8-28d8-3897-a9b6-db2105ceb351}, hash: B2F7A7039107B2C73FEBF271103F9A10
    @Test()
    void composeWhenKLessThanMappingIJLength() throws NumberIsTooLargeException {
        /* Branches:* (i < compIndirection.length) : true* (j < mappingI.length) : true* (k < mappingIJ.length) : true*/
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        double[] doubleArray = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray2 = new double[]{Double.parseDouble("0.0")};
        double[] doubleArray3 = new double[]{Double.parseDouble("0")};
        //Act Statement(s)
        target.compose(doubleArray, 0, doubleArray2, doubleArray3, 0);
        double[] doubleDoubleArray3Array = new double[]{Double.parseDouble("0.0")};
        //Assert statement(s)
        assertAll("result", () -> assertThat(doubleArray3, equalTo(doubleDoubleArray3Array)));
    }

    //Sapient generated method id: ${aa31e7a3-e914-325f-9854-314e0f68f2df}, hash: 7C105876EFB18EF41672DDA523B705B8
    @Test()
    void checkCompatibilityWhenOrderEqualsCompilerOrder() throws DimensionMismatchException, NumberIsTooLargeException {
        /* Branches:* (parameters != compiler.parameters) : false* (order != compiler.order) : false*/
        //Arrange Statement(s)
        DSCompiler target = DSCompiler.getCompiler(0, 0);
        DSCompiler dSCompiler = DSCompiler.getCompiler(0, 0);
        //Act Statement(s)
        target.checkCompatibility(dSCompiler);
    }
}
